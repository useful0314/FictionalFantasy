# Limitless — complete Build 41 export

This package is the source and assets behind the published Build 41 of Limitless (the five-character fighting game with Gojo, Sukuna, Naruto, Mahito and Spider-Man).

## Put the same game on another website

1. Extract this ZIP.
2. Upload the **contents of `publish/`** to the new website's static/public web directory. `index.html` must be at the URL you want to use for the game.
3. Enable HTTPS on that website.
4. Visit that URL and click Play. The game and character lab are already built; you do not need Python or Node.js just to host them.
5. Have all players reload before creating a new private room.

You can also upload `publish/` under a path such as `/games/limitless/`. Open `/games/limitless/index.html`. For a game inside another page, see `publish/embed-example.html` and the embedding notes in `MIGRATION-GUIDE.md`.

The exported game files are not tied to a ChatGPT login. The original site's Git metadata, deployment identity and credentials are not part of this portable package. This export does not change the existing published game.

## What is included

| Path | Purpose |
|---|---|
| `publish/index.html` | Complete playable game, with Three.js, PeerJS, game scripts, CSS, textures and recordings embedded. |
| `publish/character-lab.html` | Existing character prototype lab. |
| `publish/embed-example.html` | Example wrapper for placing the game in another website. |
| `project/src/` | Complete editable gameplay, models, animations, VFX, shaders, maps, input, UI and networking. |
| `project/assets/` | Individual audio and texture files used by the build. |
| `project/vendor/` | The exact bundled library versions and any vendor notices. |
| `project/build.py` | Existing standard-library-only Python build script. |
| `project/tests/` | Existing automated test harness and regression suites, including Build 41. |
| `project/*.md` | Existing project guides, move specifications and build notes. Older build notes are historical; current source and BUILD41.md take precedence. |
| `project/THIRD-PARTY-NOTICES.txt` | Existing dependency attribution and license notices. |
| `ASSET-AND-SOURCE-MAP.md` | Where to find the models, animation systems, effects, audio and maps. |
| `MIGRATION-GUIDE.md` | Hosting, local testing, rebuilding, embedding, multiplayer and troubleshooting. |
| `ASSET-INVENTORY.csv` | Every included source/asset/dependency file, its size and SHA-256 checksum. |
| `EXPORT-PROVENANCE.json` | Source commit and export validation results. |
| `SHA256SUMS.txt` | Integrity checksums for the package's files. |

## Edit and rebuild

Edit files inside `project/src/` and replace audio/textures in `project/assets/` as needed. Then run this from the `project` directory:

```sh
python3 build.py --site
```

On Windows, use `py build.py --site` if Python is installed through the Windows launcher. The game output is `project/dist/index.html`; the lab output is `project/dist/character-lab.html`. Upload those new files after editing. The build script also writes `project/Limitless-Arena.html`.

No npm install is required by the existing game build. Node.js is only needed to run the JavaScript tests; the exact graphics and networking browser libraries are already in `vendor/`.

## Local preview

From the extracted package root:

```sh
python3 -m http.server 8000 --bind 127.0.0.1 --directory publish
```

Then open `http://localhost:8000`. On Windows, substitute `py` for `python3`. Stop the preview with Ctrl+C. This is a local development server, not a public production hosting setup.

## Models and animation files

The playable character models are generated in JavaScript from articulated Three.js parts. The model-building code and all procedural animation code are included. There are no original Blender, FBX or GLB character files to copy; recreating the game in a different engine would require porting or exporting those procedural models and animations. Rehosting this web game does not require that conversion.

## Multiplayer dependency

The current private-room implementation uses PeerJS/WebRTC. The browser client library is included, but the public signaling service is external. Moving the HTML files does not turn that service into part of your website. See MIGRATION-GUIDE.md for the actual network configuration and official references.
