# Limitless Build 41 — assets and source map

All paths below are relative to the extracted package. This is the existing implementation, copied from published source commit `13be5eb5d7861980e8de11e52dc5fe9b855834ae`. The export does not replace the game's architecture or change any moves.

## Playable output and build inputs

| Resource | Location | What it contains |
|---|---|---|
| Compiled game | `publish/index.html` | Game, UI, both browser libraries, all six supplied recordings and both textures, embedded into one HTML file. |
| Compiled prototype lab | `publish/character-lab.html` | The existing character selection/prototype laboratory, separate from the playable roster. |
| HTML assembly | `project/src/index.html`, `project/build.py` | Template and existing build order. Run the build script rather than manually reordering modules. |
| Main simulation | `project/src/game.js` | Scene setup, fighter integration, shared combat and movement, game loop and camera. |
| Game styles and UI | `project/src/style.css`, `project/src/presentation.css`, `project/src/combat-feel.css` | Main interface and presentation styles; character-specific styles are also included in `src/`. |
| Runtime input | `project/src/controls.js`, `project/src/session.js` | Keyboard, mouse, controller, mobile layout/settings and session handling. |
| Roster and health display | `project/src/roster.js`, `project/src/roster-health.js` | Match configuration, roster handling and multi-fighter health UI. |

## Character models and rigs

These are articulated models constructed in JavaScript, not downloaded mesh files. Their component geometry, materials, colors, rig joints and decorative parts are in the source below. Preserve the existing module build order and shared rig contracts when porting individual parts.

| Model | Source |
|---|---|
| Gojo and four-armed Sukuna | `project/src/block-models.js`, integrated through `project/src/game.js` |
| Naruto | `project/src/naruto-model.js` delegates to the Naruto branch in `project/src/block-models.js` |
| Mahito and his transformed details | `project/src/mahito-model.js`, `project/src/mahito.js` |
| Spider-Man | `project/src/spiderman-model.js` extends the common block rig |
| Kurama | `project/src/kurama-model.js` |
| Mahito's domain hands and amalgamation | `project/src/mahito-hands.js`, `project/src/mahito-amalgamation.js`, `project/src/mahito-transfiguration.js` |
| Character lab prototype models | `project/src/lab/models.js`, with candidate data in `project/src/lab/characters.js` |

Exact source examples: `naruto-model.js` returns `fighterBlockModel('naruto',attach)`. `spiderman-model.js` begins its model with `fighterBlockModel('spiderman')`. The shared block factory creates Three.js groups and meshes; there are no missing FBX, GLB, Blender, animation-clip or skeleton files needed to run this website.

## Animation, techniques and VFX

| System | Main source files under `project/src/` |
|---|---|
| Shared animation and polished locomotion | `animation.js`, `animation-polish.js` |
| Ground and aerial light combinations | `light-combo.js`, `air-combat.js` |
| Anticipation, startup and combat response | `technique-startup.js`, `combat-response.js`, `combat-system.js` |
| Impact presentation, particles and camera feedback | `combat-feel.js`, `combat-vfx.js`, `battle-readability.js`, `presentation.js`, plus shared code in `game.js` |
| Gojo's Blue, Red, Purple and flight | `game.js`, `animation.js`, `technique-startup.js`, `combat-vfx.js` |
| Sukuna's World Cutting Slash | `sukuna-world-cut.js`, `sukuna-world-cut-vfx.js` |
| Naruto techniques and animations | `naruto.js`, `naruto-animation.js`, `naruto-vfx.js` |
| Clone jumps, wall motion and substitution | `naruto-mobility.js`, `wall-motion.js`, `naruto-speedlines.js`, `naruto-substitution.js` |
| Mahito techniques and animations | `mahito.js`, `mahito-animation.js`, `mahito-vfx.js`, `mahito-transfiguration.js` |
| Spider-Man combat, webs and movement | `spiderman.js`, `spiderman-animation.js`, `spiderman-vfx.js` |
| Domains, barriers, clashes and burnout | `domains.js`, `barriers.js`, `domain-cinematics.js`, `domain-mixed.js`, `domain-burnout.js`, `finishers.js` |
| Naruto Mindscape and its clone/fox presentation | `mindscape.js`, `mindscape-vfx.js`, `mindscape-sphere.js`, `mindscape-clones.js`, `kurama-domain.js`, `kurama-model.js` |
| Mahito domain | `mahito-domain.js`, `mahito-hands.js`, `mahito-amalgamation.js` |
| Prototype lab | `lab/engine.js`, `lab/animation.js`, `lab/index.html` |

All tracked modules are retained, including historical compatibility code. This map identifies useful starting points; it is not permission to omit the other files. Shader strings, generated particles, motion trails and procedural geometry live in these JavaScript modules. There is no separate paid VFX pack to install.

## Maps

| Map selection | Internal ID | Main construction source |
|---|---|---|
| Night District | `district` | `project/src/city.js`, shared stage setup in `project/src/game.js` |
| Sunlit Harbor | `harbor` | `project/src/maps.js` |
| Shattered Sanctuary (golden sunset) | `sanctuary` | `project/src/maps.js` |
| Skyline Boroughs | `metro` | `project/src/map-metro.js`, registered in `project/src/maps.js` |

Buildings, streets, collision geometry, lighting and map materials are generated from this code. Separate scene-editor project files are not required for the current web game.

## Individual media files

These eight files are the complete tracked `assets/` directory. Their original bytes are included in `project/assets/`; the build also embeds them into the compiled game.

| File | Runtime asset key | Role |
|---|---|---|
| `project/assets/audio/domain-clash.mp3` | `clash` | Domain-clash recording/loop |
| `project/assets/audio/sukuna-domain.mp3` | `sukunaDomain` | Sukuna domain recording |
| `project/assets/audio/hollow-nuke.mp3` | `hollowNuke` | Hollow Nuke recording |
| `project/assets/audio/gojo-cast.mp3` | `gojoCast` | Gojo domain cast voice |
| `project/assets/audio/sukuna-cast.mp3` | `sukunaCast` | Sukuna domain cast voice |
| `project/assets/audio/gojo-theme.mp3` | `gojoTheme` | Gojo domain theme |
| `project/assets/textures/stone.png` | `stone` | Stone texture |
| `project/assets/textures/fabric.png` | `fabric` | Fabric texture |

`project/build.py` defines those key-to-file mappings and injects them through `window.ARENA_ASSETS`. `project/src/audio.js` handles playback and also synthesizes general sound effects and four adaptive music layers through Web Audio. Those generated sounds are code, not missing MP3 files. The UI uses code/CSS and generated SVG elements; no external font download was found in the application source.

Reference videos or images discussed in chat are not runtime assets and are not required to reproduce this published build. Only files actually present in the published repository are represented as included media.

## Exact bundled dependencies and runtime requirements

| Dependency | Included version/source | Use |
|---|---|---|
| Three.js | Revision **170**, `project/vendor/three.module.js` | Rendering, geometry, materials, math and scene graphs |
| PeerJS | **1.5.5**, `project/vendor/peerjs.min.js` | Browser-to-browser room connections |
| Python | Python 3, standard library only | Optional rebuild through `project/build.py` |
| Node.js | JavaScript test runner | Optional existing `.mjs` test suites |
| Browser platform | WebGL2, Web Audio, WebRTC, storage and supported input APIs | Runtime for the existing web implementation |

The bundled graphics/networking libraries are used directly; no CDN library fetch or package installation is needed for the prebuilt pages. Keep `project/THIRD-PARTY-NOTICES.txt` and `project/vendor/peerjs-LICENSE.txt` with redistributed source. The minified PeerJS file references an optional debug source map that was not in the original repository; that source map is not required at runtime.

## Networking configuration and boundaries

The actual `project/src/network.js` declares:

```js
const VERSION='limitless-41.0',PREFIX='limitless41-',MAX=6,
```

Its shared `openPeer(id)` method constructs the client as:

```js
const peer=this.peer=new window.Peer(id,{debug:0});
```

This means the game retains PeerJS's default connection configuration; it does not specify a private signaling host or custom TURN credentials. The room host uses `PREFIX+this.code`, and guests connect to that same room ID. The current protocol supports six fighters and the five playable characters. The room host runs the simulation; if it disconnects, the match stops.

`project/src/network.js` supplies transport/rooms, and `project/src/roster.js` and `project/src/game.js` contain roster/state integration. There is no separate backend, database dump, account system, dedicated game-server binary or private server configuration in this repository to export. See `MIGRATION-GUIDE.md` for signaling/TURN deployment notes and primary documentation.

## Browser preferences

The existing local-storage keys are `limitless.controls.v3`, `limitless.touch-layout.v1`, `limitless.match.v1`, `limitless.settings.v3`, `limitless.map`, `limitless.audio.v3` and `limitless.lab.pick`. They are scoped to the browser's website origin. The ZIP includes the preference-handling code, not a player's private browser data.

## Integrity and verification

`ASSET-INVENTORY.csv` lists every copied project file with a SHA-256 hash. `SHA256SUMS.txt` covers the package files. `EXPORT-PROVENANCE.json` records the source commit, HTML hashes and actual validation outcomes. Existing test suites and harnesses are included under `project/tests/`; their assertions can be inspected alongside the source.
