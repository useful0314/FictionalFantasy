# Moving Limitless to another website

## A. Static hosting

Use `publish/` as the hosting output directory. No backend application or build command is needed for the supplied prebuilt version. Both game pages are self-contained HTML documents. A website builder must support hosting HTML/JavaScript or embedding a separately hosted game; pasting the game source into a normal text editor or blog paragraph will not execute it.

Keep the original filenames unless you also change links to them. The application has no server-side route tree or database migration in this build. An existing website can link to the game or put its files in a subdirectory.

Keep the response MIME type for the game as `text/html`. Hosts that force uploaded HTML to download as an attachment will not run it as a page. If a host imposes Content Security Policy, it must permit the app's inline scripts/styles and its embedded `data:` module import, textures and audio. The network connections required by PeerJS must also be allowed. Do not disable your entire site's security policy; use a dedicated game page/origin and adapt its policy to the inspected build.

## B. Embedding

The included `publish/embed-example.html` loads `./index.html` in an iframe. You can adapt its `src` to the game URL on your new host. It grants fullscreen, autoplay and gamepad permissions; the player still needs to click/tap to start audio and focus the game.

For your own trusted game page, the supplied example uses no sandbox attribute. If a website builder forces a sandbox, it must allow scripts and the required storage/origin behavior, and include `allow-pointer-lock` for free mouse-camera control. An overly restrictive builder can prevent this game from working even when the same URL works directly.

MDN states: “\"sandboxed\" `<iframe>`s block Pointer lock.” It identifies `allow-pointer-lock` as the sandbox opt-in. Source: https://developer.mozilla.org/en-US/docs/Web/API/Pointer_Lock_API#iframe_limitations (see **IFrame limitations**).

Iframe permission reference: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/iframe

## C. Rebuilding and testing source

Run `python3 build.py --site` from `project/`. The build script uses Python's standard library and reads the local `src`, `assets` and `vendor` files. It writes a standalone game and a static deployment folder. Do not open `project/src/index.html` as though it were the compiled game: it contains assembly placeholders.

Example regression commands, from `project/`:

```sh
node tests/build41.mjs
node tests/online-controls.mjs
node tests/domains.mjs
node tests/audio.mjs
```

Tests use a simulation harness and mocked renderer/audio. Passing these tests does not establish device frame rate, actual WebRTC connectivity or subjective animation/audio quality.

After rebuilding, copy `project/dist/index.html` and `project/dist/character-lab.html` into the new site's output folder. The exported `publish/` is a snapshot: editing source does not automatically update that copy.

## D. Online rooms and external services

The game uses host-authoritative peer-to-peer matches: the room host simulates the fight and sends state to guests. The exported website is not a dedicated multiplayer game server. The host must remain connected.

PeerJS's official server guide says: “By default, it connects to the free PeerJS Cloud server.” It also states: “PeerServer only handles signaling.” Source: https://peerjs.com/server/getting-started

Signaling introduces players so their browsers can establish WebRTC data connections. A static web host alone does not replace it. The unchanged client configuration is documented in ASSET-AND-SOURCE-MAP.md, with exact source excerpts.

The official guide identifies TURN as necessary for peers behind symmetric NATs. This export includes no private TURN service, relay credentials or server subscription. Test online rooms between devices on different networks after migration. If some networks cannot establish connections, use a TURN service and configure the client appropriately; changing the site's logo/domain alone will not resolve that network constraint.

For complete infrastructure independence, deploy your own compatible PeerServer and configure `host`, `port`, `path` and `secure` in the shared `openPeer(id)` constructor in `project/src/network.js` (used by both hosts and guests). Configure an appropriate WebRTC `iceServers` list if you use TURN. Those servers are additional deployments; none are silently created by this export.

PeerJS warns that its cloud service is shared and manually chosen IDs may collide. Source: https://peerjs.com/server/cloud

The existing `limitless41-` room namespace and `limitless-41.0` protocol remain unchanged. Two unchanged copies can use the same signaling namespace. If you want the new site to be an isolated game population, change the shared `PREFIX` room-namespace constant used by both host and join paths, and rebuild. If you change the wire format, update the protocol version and make every player use that matching build.

## E. Preferences and user data

Settings, keybinds, touch layouts and similar preferences are stored in the player's browser. Moving to a different website origin does not copy those existing browser preferences; players may need to set them again. Active matches and room connections are session state, not downloadable database rows in this project.

The export contains no account credentials, private deployment tokens, Git history, browser profiles or live player session data.

## F. Practical checks on the new URL

1. Confirm the screen identifies Build 41 and all five characters are selectable.
2. Test the four maps and the character lab page.
3. Click the game, rotate the camera, and test keyboard/mouse, touch or controller as appropriate.
4. Enable sound and verify both generated effects and supplied domain recordings.
5. Create a private room and join it from a second device, preferably on a different network.
6. Check a domain clash and a six-fighter session for device-specific performance.
7. Reload after changing a setting to verify storage works on the new host.

The package's provenance file records the export checks actually performed. A live deployment on your chosen new host still needs the checks above.
