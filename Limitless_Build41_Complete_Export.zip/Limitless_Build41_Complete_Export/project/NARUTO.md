# Naruto Uzumaki — Build 23 implementation

Naruto was added in Build 17; Build 18 adds Mindscape and moves Tailed Beast Bomb to slot 5. The original file layout, procedural rig approach, fighter roster, input actions, charge release, shared cooldown, damage/guard rules, terrain/barrier collision, ultimate meter, sound engine and host-authoritative networking remain in use. Domain portrait cut-ins remain disabled. Caster-only 360° cameras and participant split views use the actual arena scene; see `MINDSCAPE.md`.

The source download contains the complete implementations below, every modified integration file, the original assets and libraries, and the rebuilt standalone game. There are no abbreviated functions, missing imported models, placeholder asset URLs or paid dependencies.

## 1. Full character and combat source

| File | Complete implementation |
| --- | --- |
| `src/naruto.js` | `NARUTO` tuning, `NARUTO_KIT`, five attacks, swept hit tests, damage delivery, interruptions, fifth-move activation, wind zone, finish/reset cleanup, host/guest state and manual text |
| `src/naruto-model.js` | `fighterModelNaruto(attach=true)`, using the existing articulated `Group`/`Mesh` rig contract |
| `src/naruto-animation.js` | All character poses, motion tracks, two-bone hand-sign/palm positioning, movement states, secondary motion, limb trails and ultimate camera |
| `src/naruto-vfx.js` | Bounded smoke/chakra particles, instanced clone rigs, spiral spheres, wind blades/zones, impacts, cracks, lifted stones, nine-tail cloak, beam, embers and cinematic dimming |
| `src/naruto.css` | Third character card, orange character styling and cinematic shade |

The model has separate shoulder, elbow, hand, finger, hip, knee, ankle, head, hair, jacket-hem and headband-tail joints. Its appearance includes blond spikes, six cheek marks, a Leaf forehead plate, orange/black raised-collar jacket, blue open-toed sandals and a strapped leg pouch. Idle, run, jump, fall, landing, hit reaction, guard, dodge, ragdoll recovery and knockout use those joints.

Naruto has 1,000 HP, 100 stamina and the existing 100-point energy bar, labeled **CHAKRA** while selected. Ground jumps are free. He has no flight. Clone Boost costs 5 chakra with no cooldown or airtime cap, a 5.5 m Chakra Dash and stamina-driven wall running; see `NARUTO-MOBILITY.md` for controls, timing, costs and hooks. His existing four-hit light chain deals 12 + 16 + 20 + 27 = 75 damage. Keyboard defaults are 1–4 for charged techniques, 5 for Tailed Beast Bomb, Q for Mindscape, and C to replenish chakra. Move 5 has a mobile button and defaults to D-pad right; all inputs use the existing remapping system.

## 2. Move statistics

Durations are authoritative in seconds; frames below are rounded at 60 Hz. A tap queues release until minimum anticipation has elapsed. Holding increases charge `q` from 0 to 1; damage is `maximum × (0.35 + 0.65 × q)`. Holding a completed charge for three more seconds automatically releases it. Chakra spending stops at full charge. An immediate tap pays only its initial cost; a later release pays for the time actually charged.

The existing engine has **one shared special cooldown per fighter**. These are the values assigned to that existing timer, not a new set of independent cooldown slots. For moves 1–4 the timer starts on release and overlaps action/recovery. Another special also requires the current action to finish. Move 5 starts its 12-second timer on activation. Q uses the existing ultimate-meter/domain gate.

| Move / input | Damage at minimum → full charge | Shared cooldown | Chakra: tap → full | Minimum startup → full-charge time | Action / recovery |
| --- | --- | --- | --- | --- | --- |
| Shadow Clone Barrage / 1 | 42 → 120; full hits 24 + 24 + 24 + 48 | 1.80 s / 108 f | 8 → 14.5 | 0.40 s / 24 f → 0.65 s / 39 f | 1.28 s / 77 f; 0.32 s / 19 f |
| Uzumaki Combo / 2 | 56 → 160; full hits 25 + 35 + 40 + 60 | 1.65 s / 99 f | 10 → 15 | 0.20 s / 12 f → 0.50 s / 30 f | 1.16 s / 70 f; 0.30 s / 18 f |
| Rasengan / 3 | 63 → 180, one confirmed hit | 1.10 s / 66 f | 12 → 19.5 | 0.45 s / 27 f → 0.75 s / 45 f | 0.48 s / 29 f; 0.32 s / 19 f |
| Rasenshuriken / 4 | 77 → 220: contact 60 + cutting 60 + burst 100 at full charge | 1.50 s / 90 f | 20 → 36.9 | 0.85 s / 51 f → 1.30 s / 78 f | Throw 0.30 s / 18 f; recovery 0.42 s / 25 f |
| Nine-Tails Chakra Mode → Tailed Beast Bomb / 5 | Direct hit 520; nearby blast falls from 520 toward 234 at the edge | 12.00 s / 720 f | 45 chakra + 30% ultimate | Transformation/charge 2.10 s / 126 f | Fire 0.65 s / 39 f; recovery 0.65 s / 39 f |

Mindscape on Q uses the existing full-meter threshold of 99 and consumes that meter. The existing once-per-match emergency use below 5 HP is preserved. Its three stages, clash multipliers and sure-hit are detailed in `MINDSCAPE.md`. Tailed Beast Bomb on 5 is now an ordinary special with its existing transformation, projectile and cinematic.

### Hit windows, range and collision

Distances use the existing game's meter-scale world coordinates. The inherited fighter collision allowance is 0.8 m around `headPos`, 1.45 m above the actor position. Listed capsule/projectile radii are the attack radius before that allowance. Area zones use their listed sphere radius directly against `headPos`. Terrain and domain barriers constrain travel, and existing barrier ownership/capture checks reject cross-boundary damage.

| Move | Reach / travel | Hitbox shape and size | Actual active events |
| --- | --- | --- | --- |
| Shadow Clone Barrage | Each clone travels at most 18 m from its spawn beside Naruto; Naruto's final dash is capped at 10 m | Clone strikes: 0.65 m capsule, radius 1.15 m. Owner's final strike: 2.9 m capsule, radius 1.15 m | Three staggered clone contacts at 0.24, 0.50 and 0.76 s after release; owner hit at 1.08 s. Each selects the nearest eligible fighter in its capsule. Clone approaches commit to the player’s facing/aim direction at release; the first opponent in each forward lane or a wall can shorten travel. Rear and side opponents do not redirect the clones |
| Uzumaki Combo | Up to 10 m dash; stops short of a target aligned in front | First three strikes: 2.5 m capsules; final strike: 2.9 m capsule. Radius 1.25 m | Punch at 0.20 s, spin kick at 0.42 s, uppercut at 0.64 s, axe kick at 1.02 s after release |
| Rasengan | Charge-scaled lunge of 10.4–16 m | Swept capsule covering the previous-to-current movement segment plus 1.2 m forward, radius 1.2 m | First eligible contact during the 0.48 s lunge; only one impact per cast |
| Rasenshuriken | Projectile travels up to 96 m from its muzzle at 44 m/s; maximum unobstructed flight about 2.18 s / 131 f | Swept projectile sphere radius 1.1 m; impact creates a spherical cutting zone radius 4.5–9 m according to charge | Throws 0.13 s after release. Contact explosion, then six ticks at 0.20 s intervals across 1.20 s / 72 f, then one burst. Each event can damage all eligible opponents in the zone |
| Tailed Beast Bomb | Projectile travels up to 120 m from its muzzle at 82 m/s; maximum unobstructed flight about 1.46 s / 88 f | Swept projectile sphere radius 3 m; spherical explosion radius 18 m | Fires at 2.10 s after pressing 5. Explodes on first fighter, terrain, barrier, ground or maximum-range contact. Direct target takes full damage; other targets use distance falloff |

Both projectiles originate 2.1 m in front of Naruto's `headPos`; Rasenshuriken adds 0.3 m of height. Their flight and zone lifetimes are independent of the actor's throw/recovery interval. Wind damage is not guaranteed if an opponent leaves the zone. Clones are attack presentations, not extra fighters, targets or teammates.

### Knockback, defense and interruption

Forces below are velocity impulses in existing game units per second. Forward impulses use the committed aim direction's X/Z components; vertical values are applied separately. Radial impulses use the direction from explosion center to victim. Existing gravity (22 units/s²), drag, terrain impacts and ragdoll behavior generate the arcs.

| Move | Knockback | Blockable? | Interruptible? |
| --- | --- | --- | --- |
| Shadow Clone Barrage | Each clone: forward 1.5, up 1. Final owner strike: forward 12, up 6 | No: existing special guard-penetration rule | Yes. A successful damaging hit cancels charge/action and removes pending clone strikes |
| Uzumaki Combo | Punch/kick: forward 1.5, up 1. Uppercut: forward 1.5, up 9; Naruto follows with up 9. Slam: forward 4, then victim Y velocity set to −15 and Naruto Y velocity to −10 | No | Yes, including between hits. Already landed hits remain |
| Rasengan | Forward 20, up 5; triggers the existing strong-hit ragdoll | No | Yes, before impact; no refund for energy already spent |
| Rasenshuriken | Contact/cutting ticks: no impulse. Final burst: radial 14, up 6 | No | Charge and throw are interruptible. A released projectile and its zone continue after the caster is hit |
| Tailed Beast Bomb | Radial 30, up 12; triggers the existing strong-hit ragdoll | No | Transformation/charge is vulnerable. A hit before firing cancels it; the 45 chakra, 30% ultimate and cooldown stay spent. A fired bomb continues after interruption |

The inherited ragdoll multiplies resulting horizontal velocity by 1.25 and raises vertical velocity to at least `10 + min(4, horizontalImpulse × 0.095)`. For a stationary victim and horizontal aim, Rasengan therefore begins near 25 horizontal / 11.9 upward, and the bomb near 37.5 horizontal / 12.85 upward. Existing velocity can alter those results. The combo slam explicitly drives the victim downward and triggers cracks/dust on landing.

All five attacks still pass through the original `hurt()` checks: eligible opponents, HP, domain boundaries and dodge immunity. A timed dodge can avoid a hit. Blocking is not an interrupt by itself. Naruto cannot start another special, jump, dodge, light attack or recharge chakra during his committed move; damage, stun, ragdoll, knockout or Infinite Void suppression can stop him. Existing practice resource refill remains active.

### Animation and effect tuning

`NARUTO` at the top of `src/naruto.js` groups move durations, charge times, damage, cooldowns, costs, hit radii, projectile/zone settings, hit-stop, shake, palette and pool sizes. `NARUTO_POSES` and `NARUTO_TRACKS` at the top of `src/naruto-animation.js` contain the complete authored poses/keyframes. `NARUTO_VFX` at the top of `src/naruto-vfx.js` groups effect colors, lifetimes, sphere sizes and cinematic dimming. If changing move durations, adjust the corresponding authored track times as well.

| Move | Anticipation → action → follow-through | Shake / hit-stop |
| --- | --- | --- |
| Clone Barrage | Crossed-finger seal → smoke spawns, staggered forward clone rushes, owner punch → stance recovery | 0.18 / 35 ms per confirmed strike |
| Uzumaki Combo | Crouch/lean → dash, punch, full spin, rising uppercut, chambered axe kick → compressed landing and stance | 0.32 / 40 ms; slam extends freeze to 65 ms, landing 60 ms with 0.40 shake |
| Rasengan | Palm formation with blue spirals and rising synthetic hum → eased lunge and sharp thrust → arm/torso release into idle | 0.50 / 60 ms |
| Rasenshuriken | Overhead four-blade sphere → throwing snap → torso and arm settle; projectile leaves spinning wind zone | 0.60 / 55 ms on final burst |
| Tailed Beast Bomb / 5 | Crouch, golden fox cloak/eyes, lifted ground and inward particles → heavy bomb release/beam, explosion and embers → cloak and camera fade back | 0.35 transformation, 1.0 release, 1.65 explosion / 75 ms on confirmed blast |

Smoothstep gives eased body transitions; impact keyframes use ease-out-back. Joint targets use exponential blending with a 0.052 s time constant (about 120 ms to reach 90% of a new pose). Secondary hair, jacket and headband motion follows with a 0.12 s time constant. Body lean, torso rotation, leg chambers and volume-preserving squash/stretch accompany attacks. Hand and foot trails reuse the particle pool. Hit-stop freezes simulation/character animation briefly without adding damage.

The Tailed Beast Bomb camera moves toward Naruto, retreats beside him before the sphere obscures him, then smoothly returns. It honors the existing Cinematic camera option and free-cursor/orbit override. Screen flashes and shake honor their existing settings. Golden cloak shaders flicker; a localized post-process warp gives heat shimmer. Finishing a match completes the recovery/camera return without applying more attack damage.

The added presentation uses 900 particle slots, 48 clone slots for six simultaneous three-clone casts, 32 impact rigs, six charge rigs, 18 projectile rigs and 12 wind-zone rigs. Clone meshes share geometry/materials through 23 instanced batches. Particle arrays and pose/collision scratch objects are reused. Cast/contact events and the pre-existing engine still allocate some objects; this is not a claim of a zero-allocation engine. Pools bound the added visual workload, but 60 FPS must be measured on the target browser/device.

### Balance against the existing characters

Naruto's close-range full-charge specials deal 120/160/180, below Hollow Purple's 280 and Furnace's 300 including burn. Rasenshuriken's 220 requires both contact and staying in its zone, has the largest chakra cost and a readable overhead startup. The bomb’s 520 direct hit has a vulnerable 2.1-second startup, costs 45 chakra, locks the existing shared special timer for 12 seconds, and has a finite projectile with radial falloff. Mindscape’s complete sure-hit totals 500, below Infinite Void’s 550 and Malevolent Shrine’s 600. Naruto's shared cooldowns and single committed action limit chaining. Existing Gojo/Sukuna values are unchanged. These are starting balance choices verified by simulation; competitive human playtesting may warrant tuning.

## 3. Hookup checklist

All of these hooks are already included in the complete source archive. No new plugin, model download or paid asset is required.

- [x] **Registration/model:** `src/game.js` adds `KITS.naruto`; `src/roster.js` routes `ensureActorRig()` to `fighterModelNaruto()`. Existing per-actor rig caches allow duplicate Narutos.
- [x] **Inputs/UI:** existing `special1`–`special4` and `domain` actions remain; `special5` is added through the same keyboard/touch/gamepad router. `src/index.html` adds the character card and room option; `src/session.js` selects the kit, labels chakra/ultimate, and fills existing mobile buttons.
- [x] **Charge/cooldown:** `startCharge()`, `releaseCharge()` and `src/technique-startup.js` read Naruto's constants. The existing three-second full-charge release, energy spending and shared cooldown remain authoritative.
- [x] **Moves/hitboxes:** `executeTechnique()`, `updateTechniques()` and `updateProjectiles()` dispatch Naruto records to `src/naruto.js`. Damage still goes through `hurt()`. Terrain, barrier, gravity, guard, dodge and ragdoll helpers remain shared.
- [x] **Clone helper:** `ensureNarutoClones()` / `animateNarutoClones()` in `src/naruto-vfx.js` render bounded, instanced copies. The owner's technique record owns hit timing and damage; there is no separate clone AI or player registration.
- [x] **New projectile/zone records:** `naruto-shuriken` and `naruto-bomb` live in the existing `projectiles` array; `naruto` and `naruto-wind` live in the existing `techniques` array. Existing generic projectile visuals skip these types so they do not double-render.
- [x] **Animation/VFX:** `src/animation.js` delegates Naruto to `animateNaruto()`; `src/session.js` runs the pooled visuals and Naruto hit-stop. The original compositor has optional Naruto heat uniforms, zero outside the effect. `src/naruto.css` supplies the cinematic shade.
- [x] **Domain and fifth move:** Q enters the same `castDomain()` / `spendUltimate()` path as the other characters. `src/mindscape.js` adds Naruto-only staged damage and clash gain. The separate `castNarutoBomb()` uses slot 5, chakra and 30% ultimate. Naruto can use the existing clash drill.
- [x] **Audio:** five attack cues and five Kurama/domain cues are synthesized to `src/audio.js`. Existing recordings are preserved; no external sound files are required for Naruto.
- [x] **AI/private rooms:** roster character choices include Naruto; AI chooses his existing five action slots. `src/session.js` validates/packs/reconstructs Naruto actions and projectiles. Guests send input only; host combat owns all damage. Protocol is `limitless-23.0`: every room participant must refresh to Build 23.
- [x] **Cleanup:** damage/knockout interrupts the current action; reset/leave clears pooled effects and snapshots; finish completes recovery/camera without late damage.
- [x] **Cut-ins:** `DOMAIN_CUTOUTS_ENABLED=false` in `src/cutouts.js` disables single-cast and multi-way portrait overlays and portrait warming. White barriers, world effects and cast audio remain. `src/domain-cinematics.js` adds caster-local orbit and participant split cameras.
- [x] **Build:** `build.py` inserts the four Naruto modules in dependency order at `/*NARUTO*/` and appends `naruto.css`. Run `python3 build.py` to rebuild `Limitless-Arena.html`; add `--site` to write `dist/index.html` too.

To play the download, extract the archive and open `Limitless-Arena.html`. To edit, open `src/` and run the existing build script. For an already modified copy of Build 16, use the source table/checklist to merge the narrow hooks; do not load the new modules twice or introduce a second input/update loop.

## Verification

Run `node tests/build23.mjs` for 18 spherical-domain, clone-assault, burnout, substitution and mobility checks, `node tests/build22.mjs` for 11 shared-wall/model checks, and `node tests/build21.mjs` for 17 mobility/HUD/domain/slash checks and `node tests/build20.mjs` for 16 mobility/city/clash scenarios, `node tests/build19.mjs` for 17 mobility scenarios, `node tests/build18.mjs` for 17 Mindscape/camera/input/clone scenarios, `node tests/build17.mjs` for 20 updated Naruto scenarios and `node tests/build14.mjs` for 16 free-for-all/network/domain scenarios. These exercise real Three.js geometry/math with a simulated DOM/renderer, input actions and host/guest packets. Coverage includes all five damage totals, actual charge costs, interruption, automatic release, barriers/scenery, launch/slam, dodge/guard, duplicate characters, six simultaneous clone casts, bounded cleanup, no cut-ins and the winning-bomb camera return.

Isolated Mesa GLES previews inspected the articulated model, hand sign, held Rasengan, overhead throw, combo poses, cloak and knockout. The new shaders were compiled/linked separately. Browser-native rendering, sustained 60 FPS, audio output, physical touch/controller behavior and live Internet WebRTC sessions were not playtested in this environment.
