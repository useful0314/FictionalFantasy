# Build 33 — Blue pursuit and airborne casting

This is a focused update to the existing Gojo techniques and shared animation/movement hooks.

## Blue

- Main guided path: **26–40m**, depending on charge (previously 22–34m).
- Main velocity: **24m/s** after the existing brief launch ease (previously 12m/s).
- Aim follows through a **0.10s exponential lag**, followed by fast angular steering. Full 180-degree turns use quaternion interpolation so opposite headings cannot stall the field.
- The final controllable sweep lasts **1s** at **22–26m/s**, then Blue anchors. A second Blue press still anchors it immediately; the anchored lifetime remains three seconds.
- The stable surrounding particle pool increases from 160 to **240** saturated blue/cyan points. Performance mode draws **96** points from the same pool. Charge convergence and release also have more blue particles.

The tuning lives in `LIMITLESS_OUTPUT.blue` at the top of `src/combat-vfx.js`. The host owns steering in `src/game.js`; guests continue receiving authoritative position and direction through the existing snapshot.

## Red and cast animation

- Red's white central charge sphere and the small white startup sphere are hidden. Red convergence particles, red energy shells and fingertip glow remain. The firing beam, muzzle flash and impact are unchanged.
- Blue gathers with a bent arm, pulls across the body, opens the guiding palm, then extends into release. The wrist, fingers, torso and trailing arm move through the pose.
- Red gathers beside the shoulder, extends its pointing finger, then snaps forward with recoil and follow-through.
- Both poses use the current roster blending, eased phases, squash/stretch, and existing hair/clothing secondary motion. The pose cache and particle geometry are reused.
- Blue release follow-through lasts **0.56s**; Red lasts **0.50s**. Move startup, charge timing, damage, energy cost and attack lock remain unchanged.

Animation constants are grouped in `TECHNIQUE_MOTION` in `src/technique-startup.js`. `src/animation.js` applies the hand poses; `src/animation-polish.js` accepts their wrist targets through its existing detail pass.

## Airborne hover

Charging or releasing Blue/Red temporarily suppresses gravity and eases vertical velocity toward zero over a **0.07s** time constant. Bent knees and a small cosmetic bob make the pose float naturally. Grounded casts stay grounded. Normal gravity resumes after follow-through, cancellation or an interruption. Blue's later remote guidance does not prolong hover.

The hover does not toggle flight. If flight was already enabled, its normal energy drain continues, and ascent/descent controls resume when the cast ends. Hits clear the release pose so hover cannot restart after hit reaction. This uses the existing charge and special-animation fields; no additional snapshot fields or input bindings are required.

## Validation

`tests/build33.mjs` covers delayed/faster steering and full reversals, 30/60/144fps guidance, particle quality switching, sphere removal and unchanged firing effects, aerial hold/release/cancel/hit behavior, existing flight controls, distinct reusable animation poses, and guest snapshots. Existing Build 32, technique VFX, mechanics, animation and online tests cover the surrounding systems.

These are simulation and scene-graph checks. A browser visual review was unavailable in this workspace; no on-device frame-rate measurement is claimed.

Private rooms use protocol `limitless-33.0` / room prefix `limitless33-`. All participants should refresh to Build 33.
