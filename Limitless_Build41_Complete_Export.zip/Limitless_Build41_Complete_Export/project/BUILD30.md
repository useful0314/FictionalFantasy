# Build 30 — Mahito: Self-Embodiment of Perfection

The supplied manga reference drives this revision: a near-black void, giant overlapping ivory palms, clenched fists and arms at several depths. The existing blocky models remain. Three staggered spherical layers place hands above, below and around players, including airborne expansions. Palms breathe and fingers curl; appearance and exit are eased. Existing clipping keeps them inside the physical barrier. The low setting uses 96 hands; normal uses 224. Each hand batch still uses three instanced draws, shared geometry and cached transform scratch objects.

Mahito's own successful domain melee/touch now begins a 1.18-second transfiguration. The victim locks in place, stretches asymmetrically, twists, swells and contracts into an ivory/dark-violet particle burst. HP reaches zero at the pop. Other combatants continue fighting; final elimination uses the existing result flow. Only one execution per victim is allowed. A committed touch completes if the domain expires. If the round ends first through another attack, unfinished executions are cancelled. Practice keeps its existing no-KO rule. Dodge, impossible AI protection, outside-barrier exclusion, ranged/summon behavior, domain cost/lifetime, clash rules and burnout remain intact. Chasing hands remain damage attacks, not execution attacks.

## New helper and hooks

- `src/mahito-transfiguration.js`: host timers, replicated bounded execution list, reversible rig pose overlays and pooled burst emission. Tunables at the top in `MAHITO_SOUL`.
- `src/game.js`: contact starts the helper after dodge/AI protection checks; pending victims cannot act or take duplicate damage.
- `src/session.js`: updates authoritative ages; restores overlays before the regular animator, applies them afterward; receives execution snapshots.
- `src/mahito.js`: adds execution state to its existing packet, validates it, resets it on new matches and documents the move behavior.
- `build.py` and `tests/harness.mjs`: load the helper alongside the existing Mahito domain files.
- `src/mahito-vfx.js`: `MAHITO_REALM` controls layer sizes, color, fog, motion and transitions. `src/mahito-hands.js` contains ivory/ink hand materials.
- Private-room protocol is `limitless-30.0`; everyone should refresh before joining.

No paid assets, new dependencies or new inputs are required.

## Verification

39 automated groups passed: Build 30 (7), Build 25 (14), Build 26 (10), Build 29 (8). Tests exercise real Three.js rigs, all four character deformations, 30/60/120 Hz timing, FFA eliminations, domain expiry, reset, both hand budgets, aerial sphere coverage, invalid packet rejection, host/guest animation and existing combat mechanics. The old instant-execution assertion now waits for the intentional pop timing.

Native Mesa geometry previews were inspected for the domain, stretched pose and inflated pose. These approximate materials and are not browser screenshots. Browser, phone/controller, actual Internet multiplayer and measured FPS remain unverified.
