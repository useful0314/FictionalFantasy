# Build 37 — Hold-to-swing and Spider-Man motion

**Hold 4 to swing; let go to release.** Use the same saved Web Swing binding, touch button, or controller chord (default LT/L2 + A/Cross). The on-screen hint reads: “Hold to swing · let go to release · aim at a surface”. Jump remains an optional early release. After releasing or missing, release the input and hold again for a new attachment.

The exact crosshair attachment from Build 36 stays fixed on the chosen surface. Swinging now has an eased launch, progressive web catch, damped rope tension and gradual steering through reversals. Letting go preserves the current velocity, including downward motion, and carries speed into the existing airborne movement. Landing ends the carry and returns to the existing landing animation.

Spider-Man shoots the web, catches the tension, extends into a dive and tucks his legs while rising. His body banks through turns and faces his travel direction smoothly. The firing arm points toward the actual anchor; fingers change from the web-shooting gesture to a grip. Releasing adds a tuck and open airborne pose before blending into normal movement. Arm rotations follow the shortest rotational path, including when the anchor is behind him. Web flutter settles as the line tightens; the existing speed lines and camera FOV response remain active.

## Tuning

`SPIDER_SWING` is grouped at the top of `src/spiderman.js`.

| Setting | Value |
| --- | ---: |
| Maximum physics step | 1/120s |
| Launch easing | 240ms |
| Ground launch upward impulse | 28m/s, applied over the easing window |
| Forward launch target | 32m/s |
| Tension catch starts / blends | 90ms / 280ms |
| Steering / reel smoothing | 180ms / 180ms |
| Maximum steering turn | 4.8rad/s |
| Tension spring / damping | 68 / 16 |
| Maximum tension acceleration | 210m/s² |
| Body blend / facing blend | 110ms / 130ms |
| Release animation | 600ms |
| Maximum turn bank | 0.48rad |

Existing `SPIDER` tuning retains the 68m/s speed cap, 125m attachment range, 4 energy attachment cost, 4 energy/s drain, 0.25s attachment cooldown and 9s maximum continuous swing.

## Integration

- `src/game.js`: the existing special-release hook detaches Web Swing even when a menu or another state blocks casting; the existing release movement preserves ground contact on landing.
- `src/spiderman.js`: held input check, eased swing physics, release state and network serialization. A cleared or stale remote input releases the web. Repeated presses do not toggle it off.
- `src/spiderman-animation.js` and `src/animation.js`: swing poses, bank/facing blend, anchor-directed arm and smooth release. Combat and hit reactions take precedence over release presentation.
- `src/spiderman-vfx.js`: existing six-actor strand buffers carry settling flutter without adding meshes or particle pools.
- `src/session.js`: updated control copy and release animation playback between network snapshots. `src/network.js` uses `limitless-37.0`; every private-room player must refresh to Build 37.

No new dependencies or paid assets. New animation scratch vectors, quaternions and pose arrays are cached per fighter; the existing web buffers are reused.

## Verification

96 check groups passed: `build37` (16), `build36` (11), `build35` (13), `online-controls` (15), `build27` (10), `build29` (8), and `mechanics` (23). Retained Build 35/36 swing tests now hold the normalized action while exercising the existing behavior.

New checks cover keyboard repeat and remapping, mouse binding, touch up/cancel/lost capture, overlapping input sources, controller chord release and disconnect, pause/blur/cursor/orbit release, early Jump release, no automatic reattachment, exact release velocity, ground launch and matching 30/60/120Hz trajectories, bounded movement and 180-degree steering, destroyed/hidden anchors, energy exhaustion, interruption, cast/dive/rise/release poses, anchor-directed arm, bounded arm rotation, landing, pool reuse, fixed web endpoints, guest input edges, host stale-input release and malformed animation snapshots.

Browser/GPU/device visual QA was unavailable. Checks use real Three.js math and scene state with the existing simulation harness. They do not certify frame rate or public-network WebRTC performance.
