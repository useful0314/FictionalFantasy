import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const g=createGame(),results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function reset(character='gojo',map='district'){g.ctx.character=character;g.ctx.map=map;g.run('selectedCharacter=character;selectedMap=map;resetMatch("practice");player.pos.set(0,.13,0);enemy.pos.set(0,.13,8);enemy.stun=999;cinematic=null;');}
check('Every special accepts a quick tap, finishes its startup, and fires at minimum power without further charging',()=>{
 for(const c of ['gojo','sukuna'])for(let kind=1;kind<=4;kind++){reset(c);g.ctx.kind=kind;g.run('startCharge(kind);releaseCharge(kind)');assert(g.run('charge.releaseRequested'));const energy=g.state().player.energy;
 g.run('updateHeldCharge(player,techniqueStartup(player,kind)-.001)');assert(g.state().charge);assert.equal(g.run('player.specialKind'),0);
 g.run('updateHeldCharge(player,.002)');assert.equal(g.state().charge,null);assert.equal(g.run('player.specialKind'),kind);assert.equal(g.run('player.specialPower'),0);assert.equal(g.state().player.energy,energy);
 }
});
check('All eight moves auto-release exactly three seconds after full charge, with full power',()=>{
 for(const c of ['gojo','sukuna'])for(let kind=1;kind<=4;kind++){reset(c);g.ctx.kind=kind;g.run('startCharge(kind);updateHeldCharge(player,charge.max);updateHeldCharge(player,2.99)');assert(g.state().charge);assert(Math.abs(g.run('charge.fullHold')-2.99)<1e-6);g.run('updateHeldCharge(player,.011)');assert.equal(g.state().charge,null);assert.equal(g.run('player.specialPower'),1);assert.equal(g.run('player.specialKind'),kind);}
});
check('Interrupted queued casts stay canceled, and exhausted charges cannot be held forever',()=>{
 reset();g.run('startCharge(2);releaseCharge(2);hurt(player,2,enemy,"special");updateHeldCharge(player,2);syncCombatVisuals()');assert.equal(g.state().charge,null);assert.equal(g.run('player.specialKind'),0);assert.equal(g.run('startupRigs.size'),0);
 reset();g.run('player.energy=5;startCharge(1);updateHeldCharge(player,3.01)');assert.equal(g.state().charge,null);assert.equal(g.state().blue.q,0);
});
check('Every startup has moving convergent particles and a finite articulated pose',()=>{
 const poses=[];for(const c of ['gojo','sukuna'])for(let kind=1;kind<=4;kind++){reset(c);g.ctx.kind=kind;g.run('startCharge(kind);for(let i=0;i<12;i++){updateHeldCharge(player,.02);animateFighter(player,.02);}syncCombatVisuals();scene.updateMatrixWorld(true)');assert.equal(g.run('startupRigs.size'),1);const before=g.run('Array.from(startupRigs.get("0-0").streaks.instanceMatrix.array).join()');g.run('updateHeldCharge(player,.06);animateFighter(player,.06);syncCombatVisuals()');assert.notEqual(g.run('Array.from(startupRigs.get("0-0").streaks.instanceMatrix.array).join()'),before);assert(g.run('Array.from(startupRigs.get("0-0").streaks.instanceMatrix.array).every(Number.isFinite)'));poses.push(g.run('JSON.stringify(player.limbs.map(l=>l.arm.rotation.toArray()))'));}assert(new Set(poses).size>=7);
});
check('The larger domain captures targets at 40m and excludes targets beyond 54m',()=>{reset();g.run('enemy.pos.z=40;activateDomain(player)');assert(g.state().domain.captured);reset();g.run('enemy.pos.z=65;activateDomain(player)');assert(!g.state().domain.captured);});
check('The white exterior is opaque and every domain visual is bounded by the physical shell',()=>{
 for(const c of ['gojo','sukuna']){reset(c);g.run('activateDomain(player);updateBarrierVisuals()');assert(g.run('Array.from(barrierVisuals.values())[0].shell.material.depthWrite'));assert.equal(g.run('Array.from(barrierVisuals.values())[0].shell.material.transparent'),false);assert.equal(g.run('Array.from(barrierVisuals.values())[0].shell.material.side'),0);assert(g.run('domainVisual.userData.dome.geometry.parameters.radius<DOMAIN_ENCLOSURE.radius'));assert(g.run('(()=>{let ok=true;domainVisual.traverse(o=>{if(o.material&&!o.material.userData.domainClip)ok=false;});return ok;})()'));}
});
check('The map selector persists its choice and preserves the original city as an option',()=>{
 g.run('phase="menu";chooseMap("harbor")');assert.equal(g.state().map,'harbor');assert.equal(g.elements.get('map-harbor')['aria-pressed'],'true');assert(g.elements.get('mapDescription').textContent.includes('lighthouse'));g.run('chooseMap("district")');assert.equal(g.state().map,'district');assert.equal(g.run('buildings.length'),32);
});
check('The three maps have distinct layouts and support scenery destruction and full restoration',()=>{
 const layouts=[];for(const map of ['district','harbor','sanctuary']){reset('gojo',map);layouts.push(g.run('pieces.map(p=>p.pos.toArray().join()).join(";")'));const count=g.run('pieces.length');assert(count>80);g.run('destroyAt(pieces[0].pos,6,150)');assert(g.state().destroyed>0);g.run('restoreArena()');assert.equal(g.state().destroyed,0);assert.equal(g.run('pieces.length'),count);assert(g.run('groundHeight(V(0,0,0),0)')>=0);}assert.equal(new Set(layouts).size,3);
});
check('Domain endings restore the selected map lighting and exact surface materials',()=>{
 for(const map of ['district','harbor','sanctuary']){reset('sukuna',map);const color=g.run('scene.background.getHex()'),material=g.run('floor.material');g.run('activateDomain(player);domain=null;clearDomainVisual()');assert.equal(g.run('scene.background.getHex()'),color);assert.equal(g.run('floor.material'),material);assert.equal(g.run('shrine.visible'),map==='district');}
});
check('The online handshake selects the host map and accepts its matching terrain snapshot',()=>{
 for(const map of ['district','harbor','sanctuary']){reset('gojo',map);const guest=createGame();setupReplica(g,guest);assert.equal(guest.state().map,map);assert.equal(guest.run('net.arena'),map);guest.ctx.packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet)');assert.equal(guest.run('pieces.length'),g.run('pieces.length'));assert.equal(guest.run('JSON.stringify(pieces.map(p=>[p.pos.toArray(),p.size.toArray()]))'),g.run('JSON.stringify(pieces.map(p=>[p.pos.toArray(),p.size.toArray()]))'));}
});
check('Guests receive queued quick casts and full-charge release countdowns',()=>{
 reset();g.run('startCharge(2);releaseCharge(2);updateHeldCharge(player,.2)');const guest=createGame();setupReplica(g,guest);guest.ctx.packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));guest.run('receiveState(packet);updateReplica(.016);syncCombatVisuals()');assert(guest.run('remoteCharge.releaseRequested'));assert.equal(guest.run('remoteCharge.releaseQ'),0);assert.equal(guest.run('startupRigs.size'),1);
 reset();g.run('startCharge(2);updateHeldCharge(player,1.6);updateHeldCharge(player,2)');guest.ctx.packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));guest.run('receiveState(packet);updateReplica(.016)');assert.equal(guest.run('remoteCharge.fullHold'),2);
});
check('Reset clears startup rigs and map changes do not add duplicate terrain',()=>{
 reset();g.run('startCharge(3);updateHeldCharge(player,.5);syncCombatVisuals()');assert(g.run('startupRigs.size')>0);reset('gojo','sanctuary');assert.equal(g.run('startupRigs.size'),0);const count=g.run('stage.children.length');for(let i=0;i<3;i++){reset('gojo','harbor');reset('gojo','sanctuary');}assert.equal(g.run('stage.children.length'),count);
});
console.log(JSON.stringify({scope:'Build 09 quick-cast timing, animation, enclosure containment, maps and replicated state simulation.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
