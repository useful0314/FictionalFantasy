import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(character='gojo'){
 const g=createGame();g.debug.select(character);g.reset('duel');
 g.run('for(const p of pieces){p.alive=false;p.m.visible=false;}player.pos.set(0,.13,0);player.vel.set(0,0,0);enemy.pos.set(0,.13,-2);enemy.vel.set(0,0,0);enemy.stun=0;enemy.nextSlash=enemy.nextFire=999;enemy.bot=false;enemy.input.yaw=Math.PI;yaw=pitch=0;time=1;resetCombatFeel();');return g;
}
check('All five rigs flash on confirmed damage, without changing base materials or shared character geometry',()=>{
 for(const character of ['gojo','sukuna','naruto','mahito','spiderman']){
  const g=game();g.ctx.character=character;g.run('ensureActorRig(enemy,character);globalThis.s=prepareCombatFeelRig(enemy);globalThis.before=s.materials.map(m=>[m.color.getHex(),m.opacity,m.map]);globalThis.meshes=[];enemy.body.traverse(o=>{if(o.isMesh)meshes.push([o,o.geometry]);});hurt(enemy,40,player,"special",V(1,0,0));');
  assert(g.run('enemy.hp===960&&s.flash.value===1&&prepareCombatFeelRig(player).flash.value===0'),character);
  g.run('updateCombatFeel(.2)');assert(g.run('s.flash.value===0&&s.materials.every((m,i)=>m.color.getHex()===before[i][0]&&m.opacity===before[i][1]&&m.map===before[i][2])&&meshes.every(([o,g])=>o.geometry===g)'),character);
 }
});
check('Flash shader hooks match the bundled Three.js material chunks and keep independent uniforms on duplicate characters',()=>{
 const g=game();g.run('ensureActorRig(enemy,"gojo");globalThis.a=prepareCombatFeelRig(player);globalThis.b=prepareCombatFeelRig(enemy);globalThis.ok=true;for(const state of [a,b])for(const m of state.materials){const source=m.isMeshStandardMaterial?THREE.ShaderLib.standard:THREE.ShaderLib.basic;const shader={fragmentShader:source.fragmentShader,uniforms:{}};m.onBeforeCompile(shader,renderer);ok&&=shader.uniforms.uConfirmedHit===state.flash&&shader.fragmentShader.includes("mix(gl_FragColor.rgb")&&shader.fragmentShader.includes("#include <clipping_planes_fragment>")&&shader.fragmentShader.includes("#include <fog_fragment>");}confirmedContact(enemy,player,50);');
 assert(g.run('ok&&a.flash!==b.flash&&a.flash.value===0&&b.flash.value===1&&a.materials.every(m=>!b.materials.includes(m))'));
});
check('Blocking, perfect dodging and invulnerability do not masquerade as damaging white flashes',()=>{
 const g=game();g.run('enemy.block=true;enemy.blockTime=1;globalThis.blocked=hurt(enemy,12,player,"light");');assert(g.run('!blocked&&enemy.hp===1000&&prepareCombatFeelRig(enemy).flash.value===0&&combatFeel.pool.some(e=>e.kind==="guard"&&e.g.visible&&e.accent.color.getHex()===COMBAT_FEEL.guardBlue)'));
 g.run('resetCombatFeel();enemy.block=false;enemy.hp=800;enemy.dodge=.3;enemy.dodgeWindow=.2;globalThis.dodged=hurt(enemy,30,player);');assert(g.run('!dodged&&enemy.hp===815&&prepareCombatFeelRig(enemy).flash.value===0&&combatFeel.pool.some(e=>e.kind==="evade"&&e.g.visible)'));
 g.run('resetCombatFeel();enemy.dodge=0;enemy.bot=true;enemy.difficulty="impossible";hurt(enemy,50,player)');assert(g.run('prepareCombatFeelRig(enemy).flash.value===0&&combatFeel.pool.every(e=>!e.g.visible)'));
});
check('Repeated domain-like chip damage fades between pulses instead of pinning the body white',()=>{
 const g=game();g.run('globalThis.s=prepareCombatFeelRig(enemy);confirmedContact(enemy,player,.5,"chip");updateCombatFeel(.13);globalThis.first=s.flash.value;confirmedContact(enemy,player,.5,"chip");updateCombatFeel(.01);globalThis.second=s.flash.value;updateCombatFeel(.12);confirmedContact(enemy,player,.5,"chip");updateCombatFeel(.01);');
 assert(g.run('first===0&&second===0&&s.flash.value>0&&s.flash.value<=.3&&enemy.hp===1000'));
});
check('Character flash, contact effects and direction options persist independently of full-screen flashes',()=>{
 const storage=new Map([['limitless.settings.v3',JSON.stringify({flash:false,camDistance:12})]]),g=createGame({storage});g.reset();g.run('confirmedContact(enemy,player,30);updateCombatFeel(.01)');assert(g.run('prepareCombatFeelRig(enemy).flash.value>0&&options.flash===false'));
 for(const id of ['characterHitFlashes','contactEffects','damageDirection']){const el=g.elements.get(id);el.checked=false;el.onchange({target:el});}
 const h=createGame({storage});assert(h.run('!options.hitFlashes&&!options.impactEffects&&!options.damageDirection&&!options.flash&&options.camDistance===12'));
 h.reset();h.run('confirmedContact(player,enemy,90,"heavy");updateCombatFeel(.01)');assert(h.run('prepareCombatFeelRig(player).flash.value===0&&combatFeel.pool.every(e=>!e.g.visible)&&combatFeel.threats.every(n=>+n.el.style.opacity===0)'));
});
check('Recoil follows left, right, front and back impacts without moving the authoritative body',()=>{
 const g=game();for(const [x,z,axis,sign]of [[1,0,'tilt',-1],[-1,0,'tilt',1],[0,1,'lean',1],[0,-1,'lean',-1]]){
  g.ctx.vector=[x,0,z];g.run('resetCombatFeel();enemy.root.rotation.y=0;globalThis.pos=enemy.pos.clone();globalThis.vel=enemy.vel.clone();confirmedContact(enemy,player,20,"hit",V(...vector));updateCombatFeel(.035);globalThis.pose=sampleHitRecoil(enemy);');
  assert(g.run(`pose.${axis}*${sign}>.08&&pose.squash<1&&enemy.pos.equals(pos)&&enemy.vel.equals(vel)`));
 }
 g.run('updateCombatFeel(.3)');assert.equal(g.run('sampleHitRecoil(enemy)'),null);
});
check('Ragdolls, defeated fighters and soul executions retain their own reactions',()=>{
 const g=game();g.run('confirmedContact(enemy,player,140,"heavy",V(0,4,-20));updateCombatFeel(.035);enemy.ragdollT=1;');assert.equal(g.run('sampleHitRecoil(enemy)'),null);
 g.run('enemy.ragdollT=0;enemy.hp=0;');assert.equal(g.run('sampleHitRecoil(enemy)'),null);
 g.run('enemy.hp=1000;mahitoSouls.push({id:1,target:enemy.id,owner:player.id,popped:false,t:0,p:enemy.pos.clone()})');assert.equal(g.run('sampleHitRecoil(enemy)'),null);
});
check('Domain executions restore exact original character materials after their silhouette phase',()=>{
 for(const kind of ['gojo','sukuna']){const g=game(kind);g.ctx.kind=kind;g.run('globalThis.original=[];enemy.body.traverse(o=>{if(o.isMesh)original.push([o,o.material]);});confirmedContact(enemy,player,90,"heavy");beginDomainFinisher(player,kind);updateFinisher(3.4);globalThis.changed=original.some(([o,m])=>o.material!==m);clearFinisher();updateCombatFeel(.3);');assert(g.run('changed&&original.every(([o,m])=>o.material===m)&&prepareCombatFeelRig(enemy).flash.value===0&&enemy.body.visible'));}
});
check('Hit recoil reaches both existing animators, and Mahito forms retain their scale',()=>{
 for(const c of ['gojo','sukuna','naruto','mahito','spiderman']){const g=game();g.ctx.character=c;g.run('ensureActorRig(enemy,character);enemy.root.rotation.y=0;enemy.input.yaw=0;enemy.hp=1000;hurt(enemy,20,player,"special",V(2,0,0));updateCombatFeel(.035);animateFighter(enemy,1/60);animateMahitoDetail(enemy,1/60);enemy.root.updateMatrixWorld(true);globalThis.finite=true;enemy.root.traverse(o=>{finite&&=o.matrixWorld.elements.every(Number.isFinite)});');assert(g.run('finite&&Math.abs(enemy.body.rotation.z)>.005&&enemy.body.scale.y>0&&enemy.body.scale.y<=1'),c);}
 const g=game('mahito');g.run('player.mahitoForm=1;player.mahitoFormTime=5;animateMahitoDetail(player,.5);globalThis.formScale=player.root.scale.clone();confirmedContact(player,enemy,40);updateCombatFeel(.035);animateFighter(player,1/60);animateMahitoDetail(player,1/60)');assert(g.run('player.root.scale.x>=formScale.x&&player.mahitoForm===1'));
});
check('The fixed burst pool reuses objects and expires even through hundreds of contacts',()=>{
 const g=game();g.run('globalThis.refs=combatFeel.pool.map(e=>[e,e.g,e.star.geometry,e.accent]);globalThis.seedBefore=seed;for(let i=0;i<250;i++)confirmedContact(enemy,player,30,"hit",V(0,0,-1));');assert(g.run('combatFeel.pool.length===18&&combatFeel.pool.every((e,i)=>refs[i][0]===e&&refs[i][1]===e.g&&refs[i][2]===e.star.geometry&&refs[i][3]===e.accent)&&seed===seedBefore'));
 g.run('updateCombatFeel(.5)');assert(g.run('combatFeel.pool.every(e=>!e.g.visible&&Number.isFinite(e.g.position.x))'));
});
check('Contact effects preserve depth testing, cull distant visual clutter and billboard only the compact core',()=>{
 const g=game();g.run('enemy.pos.x=200;confirmedContact(enemy,player,100,"heavy");');assert(g.run('combatFeel.pool.every(e=>!e.g.visible)'));
 g.run('enemy.pos.x=2;camera.rotation.set(.3,.4,0);confirmedContact(enemy,player,100,"heavy",V(1,0,0));globalThis.burst=combatFeel.pool.find(e=>e.g.visible);updateCombatFeel(.02);globalThis.world=burst.g.quaternion.clone().multiply(burst.core.quaternion)');assert(g.run('burst.accent.depthTest&&burst.white.depthTest&&!burst.accent.depthWrite&&world.angleTo(camera.quaternion)<1e-6'));
});
check('Fourth-hit accents use the real combo outcome and keep its existing damage and hit-stop',()=>{
 const g=game();g.run('player.combo=3;globalThis.before=enemy.hp;hurt(enemy,27,player,"light",V(0,5,-15));');assert(g.run('enemy.hp===before-27&&hitStop===.035&&combatFeel.pool.some(e=>e.kind==="finish"&&e.size>1)&&contactSound("finish","light",player)==="hitFinish"'));assert.equal(g.elements.get('hitConfirm').dataset.kind,'finish');
});
check('Incoming direction rotates with the camera, is local to the victim, and keeps several attackers',()=>{
 const g=game();g.run('enemy.pos.set(10,.13,0);camera.position.set(0,3,7);camera.lookAt(V(0,3,-10));confirmedContact(player,enemy,90,"heavy");updateCombatFeel(.01);globalThis.arrow=combatFeel.threats.find(n=>n.age<1);globalThis.angle1=arrow.el.style.transform;camera.lookAt(V(10,3,7));updateCombatFeel(.01);globalThis.angle2=arrow.el.style.transform;');assert(g.run('angle1!==angle2&&+arrow.el.style.opacity>0&&arrow.heavy'));
 g.run('resetCombatFeel();confirmedContact(enemy,player,30);');assert(g.run('combatFeel.threats.every(n=>n.age===99)'));
 g.run('for(let i=0;i<5;i++)markIncomingHit({id:"a"+i,pos:V(i*3,0,-5)},"hit");');assert.equal(g.run('combatFeel.threats.filter(n=>n.age===0).length'),4);g.run('updateCombatFeel(1)');assert(g.run('combatFeel.threats.every(n=>+n.el.style.opacity===0)'));
});
check('Hit direction records the damage origin without tracking an attacker through walls afterward',()=>{
 const g=game();g.run('markIncomingHit(enemy,"hit");globalThis.origin=combatFeel.threats[0].source.clone();enemy.pos.set(90,40,-60);updateCombatFeel(.05)');assert(g.run('combatFeel.threats[0].source.equals(origin)'));
});
check('Landings scale with actual fall speed and their rings sit on the landing surface',()=>{
 const g=game();g.run('landingContact(player,2,.4);');assert(g.run('combatFeel.pool.every(e=>!e.g.visible)'));
 g.run('player.pos.y=35;landingContact(player,20,.6);globalThis.ring=combatFeel.pool.find(e=>e.kind==="land"&&e.g.visible);globalThis.normal=V(0,0,1).applyQuaternion(ring.g.quaternion);');assert(g.run('Math.abs(ring.origin.y-35.035)<1e-6&&normal.distanceTo(V(0,1,0))<1e-6&&!ring.star.visible&&!ring.core.visible'));
});
check('Pause freezes effects; resume, rematch and rig switching clean up all transient feedback',()=>{
 const g=game();g.run('confirmedContact(player,enemy,100,"heavy");updateCombatFeel(.02);globalThis.s=prepareCombatFeelRig(player);globalThis.age=s.age;phase="pause";updateCombatFeel(2);');assert(g.run('s.age===age&&combatFeel.pool.some(e=>e.g.visible)'));
 g.run('phase="play";resetMatch("duel");');assert(g.run('combatFeel.states.every(s=>s.flash.value===0&&s.age===99)&&combatFeel.pool.every(e=>!e.g.visible)&&combatFeel.threats.every(n=>+n.el.style.opacity===0)'));
 g.run('globalThis.count=combatFeel.states.length;for(let i=0;i<20;i++){ensureActorRig(player,"naruto");ensureActorRig(player,"gojo");}');assert(g.run('combatFeel.states.length<=count+1'));
});
check('Private-room replicas display the same hit style, direction and target as the host',()=>{
 const h=game();h.run('mode="online";net.role="host";netEvents.length=0;player.combo=3;hurt(enemy,27,player,"light",V(2,3,-15))');const g=createGame();setupReplica(h,g);g.ctx.packet=JSON.parse(h.run('JSON.stringify(onlineSnapshot())'));assert(g.run('validState(packet)'));g.run('receiveState(packet);updateCombatFeel(.01)');
 assert(g.run('prepareCombatFeelRig(player).flash.value>0&&prepareCombatFeelRig(enemy).flash.value===0&&combatFeel.pool.some(e=>e.kind==="finish")&&combatFeel.threats.some(n=>n.age<1)&&presentation.hit===0'));
 assert(Math.abs(g.run('prepareCombatFeelRig(player).dir.x')-h.run('prepareCombatFeelRig(enemy).dir.x'))<1e-7);
});
check('Malformed or zero-damage replica events cannot create false hit feedback or invalid transforms',()=>{
 const g=game();g.run('replayEvent(["hit",[enemy.id,0,player.id,"finish",[0,0,1]]],actorById);replayEvent(["hit",["missing",50,player.id]],actorById);replayEvent(["hit",[enemy.id,NaN,player.id]],actorById)');assert(g.run('combatFeel.pool.every(e=>!e.g.visible)&&prepareCombatFeelRig(enemy).flash.value===0'));
 g.run('replayEvent(["hit",[enemy.id,30,player.id,"unknown",[NaN,0,1]]],actorById);');assert(g.run('prepareCombatFeelRig(enemy).dir.toArray().every(Number.isFinite)&&combatFeel.pool.some(e=>e.kind==="hit")'));
});
check('Thirty- and 120-Hz presentation updates agree on flash/recoil time and do not change combat resources',()=>{
 const snapshots=[];for(const hz of [30,120]){const g=game();g.run('confirmedContact(enemy,player,50,"heavy",V(1,0,0))');for(let i=0;i<hz/10;i++)g.run(`updateCombatFeel(${1/hz})`);snapshots.push(g.run('[prepareCombatFeelRig(enemy).flash.value,sampleHitRecoil(enemy).tilt,enemy.hp,enemy.energy,enemy.stamina]'));}
 for(let i=0;i<snapshots[0].length;i++)assert(Math.abs(snapshots[0][i]-snapshots[1][i])<1e-7);
});
check('Six-fighter frame loops with hits, forms and all maps retain finite transforms',()=>{
 const g=createGame();for(const map of ['district','harbor','sanctuary','metro']){g.ctx.map=map;g.run('selectedMap=map;matchSetup.bots=["gojo","sukuna","naruto","mahito","spiderman"];resetMatch("duel");for(let i=1;i<bodies.length;i++){bodies[i].bot=false;bodies[i].pos.copy(player.pos).add(V(i*3,0,-2));time+=.2;hurt(bodies[i],30,player,"special",V(i*.3,0,1));}');g.advance(.4);assert(g.run('bodies.every(f=>f.pos.toArray().every(Number.isFinite)&&f.root.matrixWorld.elements.every(Number.isFinite))&&combatFeel.states.every(s=>Number.isFinite(s.flash.value))'),map);}
});
console.log(JSON.stringify({scope:'Build 40: combat outcomes, real Three.js material/geometry state, synthetic input and host/guest snapshots. Shader hooks inspected, not GPU-rendered.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
