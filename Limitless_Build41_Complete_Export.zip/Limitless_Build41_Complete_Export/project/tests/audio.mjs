import assert from 'node:assert/strict';
import {createGame} from './harness.mjs';
const scheduled=[];
class Param {constructor(){this.value=0;this.events=[];}setValueAtTime(v,t){this.value=v;this.events.push(['set',v,t]);}linearRampToValueAtTime(v,t){this.value=v;this.events.push(['linear',v,t]);}exponentialRampToValueAtTime(v,t){this.value=v;this.events.push(['exponential',v,t]);}setTargetAtTime(v,t){this.value=v;this.events.push(['target',v,t]);}cancelScheduledValues(t){this.events.push(['cancel',t]);}}
class Node {constructor(){for(const k of ['gain','frequency','Q','pan','threshold','knee','ratio','attack','release'])this[k]=new Param();this.connections=[];}connect(n){this.connections.push(n);}disconnect(){}start(...a){this.started=a;scheduled.push(this);}stop(...a){this.stopped=a;}}
class AudioContext {constructor(){this.currentTime=0;this.sampleRate=44100;this.state='running';this.destination=new Node();}createGain(){return new Node();}createDynamicsCompressor(){return new Node();}createConvolver(){return new Node();}createStereoPanner(){return new Node();}createBiquadFilter(){return new Node();}createOscillator(){return new Node();}createBufferSource(){return new Node();}createBuffer(channels,length){return {getChannelData:()=>new Float32Array(length)};}async decodeAudioData(){return {duration:22.125714};}async resume(){this.state='running';}}
const g=createGame({audioContext:AudioContext}),sound=g.run('sound');
sound.assets.clash='data:audio/mpeg;base64,AAECAw==';
await sound.unlock();await Promise.resolve();
assert(sound.buffer);assert.equal(sound.buffer.duration,22.125714);
sound.setClash(true);assert.equal(sound.voices.length,1);assert(sound.loopRunning);
const voice=sound.voices[0];assert.equal(voice.s.buffer,sound.buffer);assert(Math.abs(sound.nextLoop-(22.125714-.65+.035))<.001);
assert(voice.g.gain.events.some(e=>e[0]==='linear'&&e[1]===1));assert(voice.g.gain.events.some(e=>e[0]==='linear'&&e[1]===0));
sound.setClash(true);assert.equal(sound.voices.length,1,'Repeated frames must not restart the clip');
sound.setClash(false);assert.equal(sound.loopRunning,false);assert.equal(voice.s.stopped[0],.65);assert.equal(sound.voices.length,0);
sound.setVolume('music',.25);assert.equal(sound.music.gain.value,.25);sound.setEnabled(false);assert.equal(sound.master.gain.value,0);sound.setEnabled(true);
for(const n of ['step','light','hit','guard','parry','dodge','blue','red','purple','slash','fire','furnaceImpact','fusion','teleport','burst','domain','ui'])sound.play(n,1,.5);
assert(scheduled.length>40);sound.update({charge:.7,color:'red'});assert(sound.drone.g.gain.value>0);sound.update();assert.equal(sound.drone.g.gain.value,0);
// A decode finishing after the clash ends must not bring the recording back.
const s2=new g.win.ArenaAudio({clash:'data:audio/mpeg;base64,AA=='});s2.activeClash=true;const loading=s2.unlock();s2.setClash(false);await loading;await Promise.resolve();assert(!s2.loopRunning);
sound.assets.sukunaDomain='data:audio/mpeg;base64,AAECAw==';sound.assets.hollowNuke=sound.assets.sukunaDomain;
await sound.decodeClip('sukunaDomain');await sound.decodeClip('hollowNuke');
sound.syncCue('shrine','sukunaDomain','domain-1',1.5,{duration:12});const shrine=sound.cues.get('shrine');
assert.equal(shrine.s.started[1],1.5,'Late guest starts at the domain age');assert(Math.abs(shrine.s.stopped[0]-10.526)<.001);
sound.syncCue('shrine','sukunaDomain','domain-1',2);assert.equal(sound.cues.get('shrine'),shrine);
sound.stopCue('shrine');assert.equal(sound.cues.has('shrine'),false);assert(shrine.s.stopped[0]<.3);
sound.syncCue('shrine','sukunaDomain','victory-2',0,{duration:12});assert.notEqual(sound.cues.get('shrine'),shrine);assert.equal(sound.cues.get('shrine').s.started[1],0);
sound.play('hollowNuke');assert.equal(sound.cues.get('nuke').clip,'hollowNuke');assert.equal(sound.cues.get('nuke').s.started[1],0);
sound.setVolume('recordings',.3);assert.equal(sound.recordings.gain.value,.3);assert.equal(sound.music.gain.value,.25,'Separate recording and clash buses');
sound.stopCues();assert.equal(sound.cues.size,0);
// Startup voices keep their full clip; realm music uses its own bus and ducks under speech.
sound.clips.set('gojoCast',{duration:5.269});sound.clips.set('sukunaCast',{duration:7.784});sound.clips.set('gojoTheme',{duration:20.584});
sound.syncCue('cast-gojo','gojoCast','spoken-1',.7);const spoken=sound.cues.get('cast-gojo');assert.equal(spoken.s.started[1],.7);assert(Math.abs(spoken.s.stopped[0]-4.595)<.001);assert.equal(spoken.mix.connections[0],sound.recordings);
sound.syncCue('voidTheme','gojoTheme','void-1',2,{duration:12,bus:'music'});const theme=sound.cues.get('voidTheme');assert.equal(theme.s.started[1],2);assert.equal(theme.mix.connections[0],sound.music);assert(Math.abs(theme.s.stopped[0]-10.026)<.001);
sound.duckCue('voidTheme',.3);assert.equal(theme.mix.gain.value,.3);sound.duckCue('voidTheme',1);assert.equal(theme.mix.gain.value,1);sound.syncCue('voidTheme','gojoTheme','void-1',3,{duration:12,bus:'music'});assert.equal(sound.cues.get('voidTheme'),theme);sound.stopCues();assert.equal(sound.cues.size,0);
// A domain ending while its clip decodes cannot start a stale source.
let resolveClip;const delayed=new g.win.ArenaAudio({sukunaDomain:'data:audio/mpeg;base64,AA=='});delayed.ctx=new AudioContext();delayed.ctx.decodeAudioData=()=>new Promise(r=>resolveClip=r);delayed.recordings=new Node();
delayed.syncCue('shrine','sukunaDomain','late',0,{duration:12});const decode=delayed.decodeClip('sukunaDomain');delayed.stopCue('shrine');const before=scheduled.length;resolveClip({duration:26.4});await decode;assert.equal(scheduled.length,before);
// A late decode of a still-active cue seeks instead of replaying its opening.
delayed.clips.clear();delayed.syncCue('shrine','sukunaDomain','active',0,{duration:12});const pending=delayed.decodeClip('sukunaDomain');delayed.ctx.currentTime=2;resolveClip({duration:26.4});await pending;assert.equal(delayed.cues.get('shrine').s.started[1],2);
// Build 40: distinct impact envelopes use the existing spatial audio bus and obey mute.
const profiles=[];
for(const name of ['hitKick','hitFinish','hitHeavy','land']){sound.ctx.currentTime+=4;for(const n of scheduled)if(!n.ended&&n.stopped?.[0]<=sound.ctx.currentTime){n.ended=true;n.onended?.();}const start=scheduled.length;sound.play(name,1,.4);const nodes=scheduled.slice(start);assert(nodes.length>=2,name);assert(nodes.every(n=>n.started.every(Number.isFinite)&&n.stopped.every(Number.isFinite)),name);profiles.push(nodes.map(n=>n.frequency.events).flat().map(e=>e[1]).join(','));}
assert.equal(new Set(profiles).size,4,'Every impact profile must have a distinct envelope');
sound.setEnabled(false);sound.ctx.currentTime+=1;const muted=scheduled.length;sound.play('hitFinish');assert.equal(scheduled.length,muted);sound.setEnabled(true);
console.log('Audio lifecycle and Build 40 impact checks passed: existing clips/buses, late-decode cleanup, four distinct finite impact envelopes and mute. Audio is mocked; not auditioned.');
// Build 41: synchronized stems, bus priorities, voice limits and lifecycle.
sound.ctx.currentTime+=5;for(const n of scheduled)if(!n.ended&&n.stopped?.[0]<=sound.ctx.currentTime){n.ended=true;n.onended?.();}
sound.mixBattle(true,1,1,false,false,false,false,true,3);
assert.equal(sound.scoreNodes.length,4);const stemNodes=sound.scoreNodes,stemBuffers=sound.scoreBuffers;
assert(stemNodes.every(n=>n.s.loop&&n.s.started[0]===stemNodes[0].s.started[0]&&n.s.started[1]===3&&n.g.connections[0]===sound.music));
sound.mixBattle(true,1,.1,false,true,false,false,true,3.1);assert.equal(sound.scoreNodes,stemNodes);assert(sound.scoreTargets[2]>0&&sound.scoreTargets[3]>.4);assert.equal(sound.fxBed.gain.value,1);
sound.mixBattle(true,1,.1,false,true,true,false,true,3.2);assert.equal(sound.fxBed.gain.value,.22);assert(stemNodes[1].g.gain.value<.2);
sound.ctx.currentTime+=1;sound.play('parry');sound.mixBattle(true,1,1,false,false,false,false,true);assert.equal(sound.fxBed.gain.value,.34);
sound.ctx.currentTime+=2;sound.mixBattle(true,0,1,false,false,false,false,true);assert.equal(sound.fxBed.gain.value,1);assert.equal(sound.scoreTargets[1],0);assert.equal(sound.scoreTargets[2],0);
sound.setClash(true);sound.mixBattle(true,1,1,true,false,true,true,true);assert.equal(sound.scoreNodes,null);assert.equal(sound.voices[0].mix.gain.value,.3);assert(stemNodes.every(n=>n.s.stopped[0]>sound.ctx.currentTime));
sound.setClash(false);sound.mixBattle(true,1,1,true,false,false,false,true,4);assert.equal(sound.scoreBuffers,stemBuffers);assert.notEqual(sound.scoreNodes,stemNodes);assert(sound.scoreTargets[3]>.3);
sound.mixBattle(false,1,1,false,false,false,false,true);assert.equal(sound.scoreNodes,null);
sound.mixBattle(true,1,1,false,false,false,false,false);assert.equal(sound.scoreNodes,null);
sound.setVolume('music',0);sound.mixBattle(true,1,1,false,false,false,false,true);assert.equal(sound.scoreNodes,null);sound.setVolume('music',.65);
sound.ctx.currentTime+=5;for(const n of scheduled)if(!n.ended&&n.stopped?.[0]<=sound.ctx.currentTime){n.ended=true;n.onended?.();}
for(let i=0;i<200;i++)sound.tone();assert.equal(sound.ordinaryVoices,32);const priorities=sound.priorityVoices;sound.play('parry');assert(sound.priorityVoices>priorities&&sound.priorityVoices<=12);assert.equal(sound.ordinaryVoices,32);
sound.mixBattle(true,1,1,false,false,false,false,true);sound.setEnabled(false);assert.equal(sound.scoreNodes,null);
console.log('Build 41 audio checks passed: synchronized adaptive stems, speech/impact ducking, supplied-track priority, reserved voices, pause and mute cleanup.');
