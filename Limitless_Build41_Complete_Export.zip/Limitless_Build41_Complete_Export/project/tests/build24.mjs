import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function runner(character='naruto',side=1){
 const g=createGame();Object.assign(g.ctx,{character,side});
 g.run('selectedCharacter=character;selectedMap="harbor";resetMatch("duel");enemy.stun=999;for(const p of pieces)p.alive=p.m.visible=false;pieces.push({alive:true,solid:true,platform:false,pos:V(-side*5,35,0),size:V(10,70,160)});player.pos.set(side*.46,15,0);player.grounded=false;player.energy=100;player.stamina=maxStamina(player);yaw=side*Math.PI/2;pitch=0;keys.add("KeyW");keys.add("ShiftLeft");for(let i=0;i<20;i++)updateControlled(player,1/60);keys.delete("KeyW");keys.add(side===1?"KeyD":"KeyA");for(let i=0;i<40;i++)updateControlled(player,1/60);keys.delete("KeyD");keys.delete("KeyA");keys.add("KeyW");');return g;
}
check('All characters keep sprint momentum when aiming parallel, slightly inward or directly into either wall face',()=>{
 for(const character of ['naruto','gojo','sukuna'])for(const side of [-1,1])for(const angle of [0,.15,.4,Math.PI/2]){
  const g=runner(character,side);g.ctx.angle=angle;g.run('yaw=side*angle;globalThis.st=player.stamina;globalThis.energy=player.energy;globalThis.boosts=narutoMobility(player).uses;jumpFighter(player);globalThis.speeds=[];for(let i=0;i<27;i++){const p=player.pos.clone();updateControlled(player,1/60);speeds.push(Math.hypot(player.pos.x-p.x,player.pos.z-p.z)*60);}');
  assert(g.run('Math.min(...speeds)>25&&Math.max(...speeds)<28.1'));
  assert(g.run('side*player.pos.x>1.6&&player.narutoMobility.dir.z<-.98'));
  assert(g.run('player.energy===energy&&player.stamina===st&&player.narutoMobility.uses===boosts'));
 }
});
check('Camera pitch and clear outward aim are retained, with no loss of existing tangential speed at steep pitch',()=>{
 for(const pitch of [-.8,0,.8]){const g=runner();g.ctx.lookPitch=pitch;g.run('yaw=-.5;pitch=lookPitch;globalThis.aim=aimFor(player);jumpFighter(player);');assert(g.run('player.narutoMobility.dir.distanceTo(aim)<1e-8'));}
 const g=runner();g.run('yaw=.2;pitch=-.8;jumpFighter(player);globalThis.min=99;for(let i=0;i<24;i++){const p=player.pos.clone();updateControlled(player,1/60);min=Math.min(min,Math.hypot(player.pos.x-p.x,player.pos.z-p.z)*60);}');assert(g.run('min>25'));assert(g.run('player.narutoMobility.dir.y>.7'));
});
check('A direct inward jump from a stationary climb clears the wall without inventing a sideways run',()=>{
 const g=runner();g.run('narutoMobility(player).wallVelocity.set(0,11,0);player.vel.set(0,11,0);yaw=Math.PI/2;jumpFighter(player)');assert(g.run('player.narutoMobility.dir.x>.99&&Math.abs(player.narutoMobility.dir.z)<.001'));
});
check('Takeoff is stable at 30, 60 and 120 Hz and still stops at a separate thin obstacle',()=>{
 for(const hz of [30,60,120]){const g=runner();g.ctx.hz=hz;g.run('yaw=.2;globalThis.z0=player.pos.z;jumpFighter(player);for(let i=0;i<Math.round(.4*hz);i++)updateControlled(player,1/hz)');assert(g.run('z0-player.pos.z>10.3&&z0-player.pos.z<11.2'));}
 const g=runner();g.run('yaw=.2;globalThis.wallZ=player.pos.z-4;pieces.push({alive:true,solid:true,platform:false,pos:V(0,35,wallZ),size:V(120,70,.04)});jumpFighter(player);for(let i=0;i<12;i++)updateControlled(player,.05);');assert(g.run('player.pos.z>=wallZ+.44'));
});
check('Resolved launch direction travels through the existing host/guest mobility snapshot',()=>{
 const host=createGame();host.run('net.role="host";net.localId="p0";net.roster=[{id:"p0",character:"gojo",bot:false},{id:"p1",character:"naruto",bot:false}];beginOnline("gojo","harbor");countdown=0;const w=pieces.find(p=>p.solid&&p.size.y>3);player.pos.set(w.pos.x+w.size.x/2+.46,w.pos.y, w.pos.z);player.grounded=false;const m=narutoMobility(player);m.kind=3;m.wallIndex=pieces.indexOf(w);m.normal.set(1,0,0);m.wallVelocity.set(0,3,-26);yaw=.2;pitch=-.3;jumpFighter(player);');
 const guest=createGame();setupReplica(host,guest);guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet)');assert(guest.run('enemy.narutoMobility.kind===4&&enemy.narutoMobility.dir.x>0&&enemy.narutoMobility.dir.z<0'));assert(Math.abs(guest.run('enemy.narutoMobility.dir.y')-host.run('player.narutoMobility.dir.y'))<.0011);
});
console.log(JSON.stringify({scope:'Targeted wall-jump simulation and real host/guest packets; no browser play or FPS claim.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
