import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';

const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(error){results.push({name,pass:false,error:error.stack});}}
function gojo(){
 const g=createGame();g.debug.select('gojo');g.reset('practice');
 g.debug.setup({player:{pos:[0,20,20],hp:1000,energy:100},enemy:{pos:[60,20,20],hp:1000,stun:999},yaw:0,pitch:0});
 g.run('for(const p of pieces)p.alive=p.m.visible=false;player.grounded=enemy.grounded=false;');return g;
}

check('Released Blue turns promptly toward repeated aim changes and has an expanded guided flight',()=>{
 const g=gojo();
 g.run(`createBlue(player,1,V(0,0,-1));globalThis.testBlue=blue;globalThis.blueRange=blue.range;
  yaw=-Math.PI/2;for(let i=0;i<9;i++)updateBlue(1/60,testBlue);globalThis.firstTurn=testBlue.dir.clone();
  yaw=Math.PI;globalThis.redirectStart=testBlue.p.clone();for(let i=0;i<15;i++)updateBlue(1/60,testBlue);
  globalThis.secondTurn=testBlue.dir.clone();globalThis.redirectTravel=testBlue.p.clone().sub(redirectStart);
  createBlue(player,1,V(0,0,-1));globalThis.sweepBlue=blue;sweepBlue.travelled=sweepBlue.range-.01;updateBlue(1/60,sweepBlue);
  yaw=-Math.PI/2;globalThis.sweepStart=sweepBlue.p.clone();for(let i=0;i<9;i++)updateBlue(1/60,sweepBlue);globalThis.sweepTurn=sweepBlue.dir.clone();globalThis.sweepTravel=sweepBlue.p.clone().sub(sweepStart);`);
 assert(g.run('blueRange>=30'),'full charge should provide at least 30m of guided travel');
 assert(g.run('firstTurn.x>.65'),'Blue should visibly answer a 90-degree aim change within 150ms');
 assert(g.run('secondTurn.z>.1&&redirectTravel.z>0'),'a second aim change must redirect both heading and travel, not merely its VFX');
 assert(g.run("testBlue.phase==='travel'&&testBlue.p.distanceTo(testBlue.origin)<testBlue.range"),'redirecting inside the expanded range should keep Blue under travel control');
 assert(g.run("sweepBlue.phase==='sweep'&&sweepTurn.x>.75&&sweepTravel.x>0"),'Blue must remain directly steerable after its main travel range is spent');
});

check('Blue still anchors on a second press, deals its original tick damage, and fuses only with its owner Red',()=>{
 const g=gojo();
 g.run(`createBlue(player,1,V(0,0,-1));startCharge(1,player);globalThis.anchored=blue;
  enemy.pos.copy(anchored.p).add(V(0,-1.45,0));globalThis.hpBefore=enemy.hp;updateBlue(.25,anchored);
  globalThis.blueTick=hpBefore-enemy.hp;globalThis.expectedTick=charged(BALANCE.blueDPS,1)*.25;
  enemy.pos.set(60,20,20);anchored.p.set(0,21.45,10);anchored.o.g.position.copy(anchored.p);
  fireRed(V(0,21.45,20),V(0,0,-1),.6,enemy);globalThis.foreignRedPreserved=blueFor(player)===anchored&&bombs.length===0;
  fireRed(V(0,21.45,20),V(0,0,-1),.6,player);globalThis.fused=bomb;`);
 assert(g.run("anchored.phase==='hold'&&!chargeFor(player)"),'second Blue press must remain the explicit anchor command');
 assert.equal(g.run('blueTick'),g.run('expectedTick'),'presentation/control work must not change Blue damage');
 assert(g.run('foreignRedPreserved'),'an opponent Red must not fuse with the caster Blue');
 assert(g.run('!blueFor(player)&&fused&&Math.abs(fused.q-.8)<1e-9&&fused.owner===player'),'owner Red should preserve the average-charge Hollow Bomb fusion');
 g.run('updateBomb(2.99,fused)');assert(g.run('bombs.includes(fused)'),'fusion must retain its full three-second warning');
 g.run('updateBomb(.02,fused)');assert(!g.run('bombs.includes(fused)'),'fusion must still detonate after the warning');
});

check('Blue, Red and Purple use rich reusable particle rigs with finite transforms',()=>{
 const g=gojo();
 g.run(`globalThis.limitlessTestRigs=['blue','red','purple'].map(kind=>makeTechniqueRig(kind));
  limitlessTestRigs.forEach((rig,i)=>updateTechniqueRig(rig,{p:V(i*8,3,0),dir:V(.2,.1,1).normalize(),q:1,t:.4,size:2}));
  globalThis.rigStats=limitlessTestRigs.map(rig=>{const nodes=[],geometries=[];let pooled=0;rig.g.traverse(o=>{nodes.push(o.id);if(o.geometry)geometries.push(o.geometry.id);if(o.isInstancedMesh)pooled+=o.count||0;if(o.isPoints)pooled+=o.geometry?.attributes?.position?.count||0;});return {kind:rig.kind,nodes,geometries,pooled};});
  for(let frame=0;frame<120;frame++)limitlessTestRigs.forEach((rig,i)=>updateTechniqueRig(rig,{p:V(i*8,3,0),dir:V(.2,.1,1).normalize(),q:1,t:.4+frame/60,size:2}));
  scene.updateMatrixWorld(true);globalThis.rigStatsAfter=limitlessTestRigs.map(rig=>{const nodes=[],geometries=[];let finite=true;rig.g.traverse(o=>{nodes.push(o.id);if(o.geometry)geometries.push(o.geometry.id);if(!o.matrixWorld.elements.every(Number.isFinite))finite=false;});return {nodes,geometries,finite};});`);
 const before=g.run('rigStats'),after=g.run('rigStatsAfter');
 before.forEach((stats,i)=>{
  assert(stats.nodes.length>=10,stats.kind+' needs at least ten persistent visual layers');
  assert(stats.pooled>=24,stats.kind+' needs a reusable pool of at least 24 surrounding particles');
  assert.deepEqual(after[i].nodes,stats.nodes,stats.kind+' must not allocate scene nodes per frame');
  assert.deepEqual(after[i].geometries,stats.geometries,stats.kind+' must reuse geometry per frame');
  assert(after[i].finite,stats.kind+' generated a non-finite transform');
 });
});

check('Full-output Blue, Red and Purple are visibly larger than their previous presentation',()=>{
 const g=gojo();
 g.run(`createBlue(player,1,V(0,0,-1));startCharge(2,player);chargeFor(player,2).t=chargeFor(player,2).max;chargeFor(player,2).elapsed=1;
  projectiles.push({id:++techniqueSerial,type:'purple',owner:player,o:orb(C.purple,2.5),p:V(7,4,0),dir:V(0,0,-1),q:1,t:.1,hit:false});syncCombatVisuals();
  globalThis.fullSizes={blue:techniqueRigs.get('blue'+blue.id).g.scale.x,red:techniqueRigs.get('charge0').g.scale.x,purple:techniqueRigs.get('shot'+projectiles[0].id).g.scale.x};`);
 const sizes=g.run('fullSizes');assert(sizes.blue>1.35,'Blue should exceed its former 1.35 full-output scale');assert(sizes.red>1.15,'Red should exceed its former 1.15 full-output scale');assert(sizes.purple>2.5,'Purple should exceed its former 2.5 full-output scale');
});

check('Blue release, Red impact and Purple impact are layered, finite, replayable, and expire cleanly',()=>{
 const host=gojo();host.run("net.role='host';mode='online';playCombatFX('blueRelease',V(-4,3,-6),5,1,V(0,0,-1));playCombatFX('red',V(0,3,-6),8,1,V(0,0,-1));playCombatFX('purpleImpact',V(4,3,-6),12,1,V(0,0,-1));");
 const stats=host.run(`effects.filter(e=>['impact-blueRelease','impact-red','impact-purpleImpact'].includes(e.m.name)).map(e=>{let nodes=0,finite=true;e.m.updateMatrixWorld(true);e.m.traverse(o=>{nodes++;if(!o.matrixWorld.elements.every(Number.isFinite))finite=false;});return {name:e.m.name,nodes,finite};})`);
 assert.equal(stats.length,3);for(const effect of stats){assert(effect.nodes>=10,effect.name+' needs at least ten visual layers');assert(effect.finite,effect.name+' generated a non-finite transform');}
 const guest=createGame();setupReplica(host,guest);guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));
 guest.run('receiveState(packet)');assert(guest.run("effects.some(e=>e.m.name==='impact-blueRelease')&&effects.some(e=>e.m.name==='impact-purpleImpact')"),'new Limitless release/impact effects must be accepted by guest event replay');
 host.run('for(let i=0;i<360;i++)updateEffects(1/60)');guest.run('for(let i=0;i<360;i++)updateEffects(1/60)');
 assert.equal(host.run("effects.filter(e=>e.type==='technique').length"),0);assert.equal(guest.run("effects.filter(e=>e.type==='technique').length"),0);
});

check('Red and Purple retain their damage contracts, and Purple creates its dedicated impact',()=>{
 const g=gojo();
 g.run(`player.pos.set(0,20,8);enemy.pos.set(0,20,-3);enemy.hp=1000;globalThis.redBefore=enemy.hp;
  fireRed(headPos(player),V(0,0,-1),1,player);globalThis.redDamage=redBefore-enemy.hp;globalThis.redExpected=charged(BALANCE.red,1);
  enemy.pos.set(0,20,-3);enemy.vel.set(0,0,0);enemy.hp=1000;globalThis.purpleBefore=enemy.hp;
  executeTechnique(player,3,1,V(0,0,-1));for(let i=0;i<40&&!effects.some(e=>e.m.name==='impact-purpleImpact');i++)updateProjectiles(1/60);
  globalThis.purpleDamage=purpleBefore-enemy.hp;globalThis.purpleExpected=charged(BALANCE.purple,1);`);
 assert(g.run("effects.some(e=>e.m.name==='impact-purpleImpact')"),'a direct Purple hit should trigger the dramatic dedicated impact');
 assert.equal(g.run('redDamage'),g.run('redExpected'),'the VFX upgrade must not alter Red damage');
 assert.equal(g.run('purpleDamage'),g.run('purpleExpected'),'the VFX upgrade must not alter Purple damage');
});

check('Online Blue snapshots validate, preserve one visual identity through steering, and reject malformed control data',()=>{
 const host=gojo();host.run("createBlue(player,.85,V(0,0,-1));for(let i=0;i<8;i++)updateBlue(1/60,blue)");
 const guest=createGame();setupReplica(host,guest);
 const packet=()=>JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));
 guest.ctx.packet=packet();assert(guest.run('validState(packet)'));guest.run('receiveState(packet);updateReplica(1/60);syncCombatVisuals();globalThis.blueRigId=techniqueRigs.get("blue"+packet.blues[0].id).g.id;');
 host.run('yaw=-Math.PI/2;for(let i=0;i<12;i++)updateBlue(1/60,blue)');guest.ctx.packet=packet();assert(guest.run('validState(packet)'));
 guest.run('receiveState(packet);updateReplica(1/60);syncCombatVisuals();globalThis.blueRigIdAfter=techniqueRigs.get("blue"+packet.blues[0].id).g.id;globalThis.blueReplicaError=blues[0].p.distanceTo(V(...packet.blues[0].p));');
 assert.equal(guest.run('blueRigIdAfter'),guest.run('blueRigId'),'steering updates must reuse the same Blue rig');
 assert(guest.run('blueReplicaError<.002'),'guest Blue should follow the authoritative controlled position');
 guest.run("packet.blues[0].phase='invalid'");assert.equal(guest.run('validState(packet)'),false);
 guest.ctx.packet=packet();guest.run("packet.blues[0].phase='travel';packet.blues[0].dir=[NaN,0,1]");assert.equal(guest.run('validState(packet)'),false);
});

check('Reset removes all persistent Limitless rigs and their hidden legacy orbs',()=>{
 const g=gojo();
 g.run(`createBlue(player,1,V(0,0,-1));projectiles.push({id:++techniqueSerial,type:'purple',owner:player,o:orb(C.purple,2),p:V(5,4,0),dir:V(0,0,-1),q:1,t:0,hit:false});
  globalThis.legacyBlue=blue.o;globalThis.legacyPurple=projectiles[0].o;
  startCharge(2,player);syncCombatVisuals();globalThis.preResetRigs=techniqueRigs.size;`);
 assert(g.run('preResetRigs>=3'));
 g.debug.start('practice');
 assert.equal(g.run('techniqueRigs.size'),0);assert.equal(g.run("scene.children.filter(o=>o.name?.startsWith('technique-')).length"),0);
 assert(g.run('!legacyBlue.g.parent&&!legacyPurple.g.parent'),'reset must detach the legacy simulation orbs hidden behind the richer rigs');
});

console.log(JSON.stringify({scope:'Build 32 Gojo output control, presentation pools, host/guest continuity and cleanup; simulation only.',results},null,2));
if(results.some(result=>!result.pass))process.exitCode=1;
