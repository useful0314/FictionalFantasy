import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[],near=(a,b,e=.015)=>assert(Math.abs(a-b)<e,`${a} != ${b}`);
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(character='gojo'){
 const g=createGame();g.ctx.character=character;
 g.run(`selectedCharacter=character;selectedMap='harbor';resetMatch('duel');for(const p of pieces)p.alive=p.m.visible=false;player.pos.set(0,.12,0);enemy.pos.set(0,.12,-30);enemy.stun=999;player.energy=player.ult=100;yaw=pitch=0;
 globalThis.visualStep=(dt)=>{time+=dt;animateFighter(player,dt);animateMahitoDetail(player,dt);player.root.updateMatrixWorld(true);};
 globalThis.visualAttack=(index,end=.125,hz=120,kind=0,counter=false)=>{player.attackIsLight=true;player.attackKind=kind;player.attackCounter=counter;player.combo=index;player.attackMax=(counter?.32:[.34,.4,.38,.4][kind])*(player.character==='mahito'?MAHITO.arms[player.mahitoArm].tempo:1);for(let i=0;i<=Math.floor(end*hz);i++){player.attack=Math.max(0,player.attackMax-i/hz);visualStep(1/hz);}};
 for(let i=0;i<60;i++)visualStep(1/60);`);return g;
}
check('All four models strike with anatomical right fist, left fist, right foot, then left foot',()=>{
 for(const character of ['gojo','sukuna','naruto','mahito']){const g=game(character);for(let combo=0;combo<4;combo++){
  g.ctx.combo=combo;g.run('visualAttack(combo);globalThis.aim=aimFor(player);globalThis.hands=player.limbs.slice(0,2).map(l=>l.hand.getWorldPosition(V()).sub(player.pos).dot(aim));globalThis.feet=(player.blockRig||player.mahitoRig).feet.map(l=>l.getWorldPosition(V()).sub(player.pos).dot(aim));');
  if(combo<2){assert(g.run(`Math.abs(player.limbs[${combo}].elbow.rotation.x)<.12&&player.limbs[${1-combo}].elbow.rotation.x<-1.8`),character+' fist '+combo);assert(g.run(`hands[${combo}]>hands[${1-combo}]+.2`),character+' punch reach');}
  else{const foot=combo-2;assert(g.run(`feet[${foot}]>feet[${1-foot}]+.7`),character+' kick reach');assert(g.run(`Math.abs(player.legs[${foot}].rotation.z)>1.3&&player.knees[${foot}].rotation.x<.15`),character+' kick extension');}
  g.run('for(let i=16;i<=32;i++){player.attack=Math.max(0,player.attackMax-i/120);visualStep(1/120);}');
 }}
});
check('Roundhouse flows into the spinning kick without reversing or resetting, at 30/60/120 Hz',()=>{
 for(const hz of [30,60,120])for(const character of ['gojo','sukuna','naruto','mahito']){const g=game(character);g.ctx.hz=hz;g.run(`visualAttack(2,.267,hz);globalThis.turnStart=player.body.rotation.y;globalThis.lastYaw=turnStart;globalThis.backward=0;globalThis.maxShift=0;globalThis.prior=player.body.position.clone();player.combo=3;player.attackMax=.34;for(let i=0;i<Math.ceil(.34*hz);i++){player.attack=.34-i/hz;visualStep(1/hz);backward=Math.min(backward,player.body.rotation.y-lastYaw);lastYaw=player.body.rotation.y;maxShift=Math.max(maxShift,player.body.position.distanceTo(prior));prior.copy(player.body.position);}`);assert(g.run('turnStart>2&&backward>-.001&&lastYaw>6.1&&maxShift<.5'),character+' '+hz+' '+JSON.stringify(g.run('({turnStart,backward,lastYaw,maxShift})')));}
});
check('Abandoned or delayed third hits settle cleanly, and blocked/hit/dodge overrides keep priority',()=>{
 for(const character of ['gojo','sukuna','naruto','mahito']){const g=game(character);g.run('visualAttack(2,.33);player.attack=0;player.comboHits=0;player.comboTimer=0;for(let i=0;i<90;i++)visualStep(1/60);');assert(g.run('Math.abs(player.body.rotation.y)<.13&&!player.rosterAnim.comboMotion.render'));
  g.run('visualAttack(2,.267);player.block=true;visualStep(1/60);');assert(g.run('!player.rosterAnim.comboMotion.render&&player.body.rotation.y>1'));
  g.run('player.block=false;player.attack=0;for(let i=0;i<50;i++)visualStep(1/60);visualAttack(3);player.hitReact=.22;visualStep(1/60);');assert(!g.run('player.rosterAnim.comboMotion.render'));
  g.run('player.hitReact=0;player.dodge=.2;visualStep(1/60);');assert(!g.run('player.rosterAnim.comboMotion.render'));
 }
});
check('Delayed fourth hits continue turning forward from any point in the roundhouse exit',()=>{
 for(const pause of [.03,.15,.22,.34,.5]){const g=game('naruto');g.ctx.pause=pause;g.run('visualAttack(2,.333);player.attack=0;player.comboHits=3;player.comboTimer=.7;for(let i=0;i<Math.floor(pause*120);i++)visualStep(1/120);globalThis.before=player.body.rotation.y;globalThis.previous=before;globalThis.back=0;player.combo=3;for(let i=0;i<40;i++){player.attack=.34-i/120;visualStep(1/120);back=Math.min(back,player.body.rotation.y-previous);previous=player.body.rotation.y;}');assert(g.run('back>-.001&&previous>before+.3'),pause+' '+JSON.stringify(g.run('({back,before,previous})')));}
});
// Directional variants were replaced in Build 29; see build29.mjs.
check('Actual light attacks retain confirmed progression, damage, stamina cost and finisher knockback',()=>{
 for(const character of ['gojo','sukuna','naruto','mahito']){const g=game(character),damage=character==='sukuna'?[10,14,17,23]:[12,16,20,27];for(let i=0;i<4;i++){
  g.ctx.i=i;g.run('enemy.pos.copy(player.pos).add(V(0,0,-2));enemy.vel.set(0,0,0);enemy.dodge=0;enemy.stun=999;player.stamina=100;globalThis.before=enemy.hp;lightAttack(player);');assert.equal(g.run('player.combo'),i);near(g.run('player.stamina'),97);near(g.run('pendingHits.at(-1).t'),.12);near(g.run('player.attackMax'),.34);g.advance(.16);near(g.run('before-enemy.hp'),damage[i]);assert.equal(g.run('player.comboHits'),i===3?0:i+1);if(i===3)assert(g.run('enemy.vel.y>1&&enemy.vel.z< -5'));g.advance(.24);
 }}
});
check('Misses and guards still break confirmed chains, and animation never creates extra hit events',()=>{
 const g=game();g.run('lightAttack(player)');g.advance(.4);assert(g.run('player.comboHits===0&&enemy.hp===1000&&pendingHits.length===0'));
 g.run('enemy.pos.copy(player.pos).add(V(0,0,-2));enemy.block=true;enemy.blockTime=1;enemy.input.yaw=Math.PI;lightAttack(player);resolveLight(pendingHits.shift())');assert.equal(g.run('player.comboHits'),0);
 g.run('globalThis.hp=enemy.hp;globalThis.count=pendingHits.length;for(let c=0;c<4;c++)visualAttack(c,.33);');near(g.run('enemy.hp'),g.run('hp'));assert.equal(g.run('pendingHits.length'),g.run('count'));
});
check('Mahito blades and hammers use the same limbs at their original tempos; guns keep firing',()=>{
 for(const arm of [1,3]){const g=game('mahito');g.ctx.arm=arm;g.run('player.mahitoArm=arm;globalThis.tempo=MAHITO.arms[arm].tempo;visualAttack(2,.12*tempo+.005,1000);');assert(g.run('player.legs[0].rotation.z< -1.3&&player.knees[0].rotation.x<.15'));}
 const g=game('mahito');g.run('player.mahitoArm=2;enemy.pos.z=-15;lightAttack(player)');g.advance(.2);assert.equal(g.run('mahitoBullets.length'),1);assert(!g.run('player.rosterAnim.comboMotion.render'));assert.equal(g.run('player.comboHits'),0);g.advance(.6);near(g.run('enemy.hp'),988);
 for(const form of [1,2,3]){g.ctx.form=form;g.run('player.mahitoArm=0;player.mahitoForm=form;player.mahitoFormTime=10;player.attack=0;player.hitReact=0;visualAttack(3);');assert(g.run('player.root.matrixWorld.elements.every(Number.isFinite)&&player.legs[1].rotation.z>1.3'));}
});
check('Sukuna lower hands guard during both kicks and all joints/feet remain articulated',()=>{
 const g=game('sukuna');for(const i of [2,3]){g.ctx.i=i;g.run('visualAttack(i);');assert(g.run('player.limbs.slice(2).every(l=>l.elbow.rotation.x< -1&&l.arm.rotation.x>-.8)'));assert(g.run('player.root.updateMatrixWorld(true);player.blockRig.major.every(p=>p.matrixWorld.elements.every(Number.isFinite))'));}
});
check('Guest light poses progress between 20 Hz snapshots without mutating combat state',()=>{
 const host=game();host.run('net.role="host";net.localId="p0";net.roster=[{id:"p0",character:"gojo",bot:false},{id:"p1",character:"naruto",bot:false}];beginOnline("gojo","harbor");countdown=0;lightAttack(player);');
 const guest=createGame();setupReplica(host,guest);guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);globalThis.actor=actorById("p0");globalThis.attack=actor.attack;globalThis.hp=actor.hp;globalThis.poses=[];for(let i=0;i<4;i++){narutoReplicaAge=i/60;animateFighter(actor,1/60);poses.push(actor.limbs[0].arm.rotation.x);}');assert(guest.run('new Set(poses.map(x=>x.toFixed(5))).size===4&&actor.attack===attack&&actor.hp===hp&&pendingHits.length===0'));
});
check('Repeated chains reuse animation buffers and the existing bounded particle pool',()=>{
 const g=game('mahito');g.run('visualAttack(0);globalThis.state=player.rosterAnim.comboMotion;globalThis.pose=state.pose;globalThis.start=state.start;globalThis.pool=ensureNarutoVisuals().particles;for(let chain=0;chain<12;chain++){for(let c=0;c<4;c++)visualAttack(c,.3,60);player.attack=0;for(let i=0;i<25;i++)visualStep(1/60);}');assert(g.run('player.rosterAnim.comboMotion===state&&state.pose===pose&&state.start===start&&narutoVisuals.particles===pool&&pool.life.length===NARUTO.particlePool'));assert(g.run('Math.abs(player.body.rotation.y)<.2&&player.mahitoRig.locks.every(l=>Math.abs(l.rotation.z-l.userData.restZ)<.2)'));
});
console.log(JSON.stringify({scope:'Actual Three.js poses, combat simulation and in-memory host/guest snapshots; no browser/FPS claim.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
