import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const g=createGame(),results=[];
const near=(a,b,tol=1e-6)=>assert(Math.abs(a-b)<tol,`${a} != ${b}`);
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function reset(character='sukuna'){g.ctx.character=character;g.run('selectedCharacter=character;selectedMap="district";resetMatch("practice");player.pos.set(0,.13,0);enemy.pos.set(70,.13,70);enemy.stun=999;yaw=0;pitch=0;cinematic=null;');}

check('Ground jumps and repeated Sukuna air steps work at zero stamina, with the increased impulses',()=>{
 for(const c of ['gojo','sukuna']){reset(c);g.run('player.stamina=0');assert(g.run('jumpFighter(player)'));near(g.run('player.stamina'),0);near(g.run('player.vel.y'),c==='gojo'?9:10.2);g.run('player.airJumpCooldown=0;player.pos.y=5');assert.equal(g.run('jumpFighter(player)'),c==='sukuna');if(c==='sukuna')near(g.run('player.vel.y'),12.5);}
});
check('Gojo flight sprint covers 36m per second; dodge impulse is 22',()=>{
 reset('gojo');g.run('player.pos.set(0,12,70);player.flying=true;player.grounded=false;keys.add("KeyW");keys.add("ShiftLeft");for(let i=0;i<60;i++)updateControlled(player,1/60)');near(g.run('player.pos.z'),34);assert(g.run('player.stamina')>0);
 reset();g.run('dodge(player)');near(g.run('player.vel.length()'),22);near(g.run('player.stamina'),136);
});
check('Sukuna light chain deals 64 total and Gojo retains 75',()=>{
 for(const c of ['gojo','sukuna']){reset(c);g.run('for(let i=0;i<4;i++){enemy.pos.set(0,.13,-2.5);enemy.stun=0;enemy.vel.set(0,0,0);resolveLight({f:player,combo:i,kind:0,air:false,counter:false});}');near(g.run('enemy.hp'),c==='sukuna'?936:925);}
});
check('Two distinct casts spend shared energy independently; each release preserves the other',()=>{
 reset();g.run('startCharge(3);startCharge(1);startCharge(2)');assert.equal(g.run('chargesFor(player).length'),2);near(g.run('player.energy'),77);
 g.run('updateHeldCharge(player,.5)');near(g.run('player.energy'),65.5);g.run('releaseCharge(1)');assert(g.run('!!chargeFor(player,3)'));assert(!g.run('!!chargeFor(player,1)'));
 g.run('startCharge(2)');assert.equal(g.run('chargesFor(player).length'),2);assert.equal(g.run('chargeFor(player,2).slot'),1);g.run('releaseCharge(3);updateHeldCharge(player,.36)');assert(!g.run('!!chargeFor(player,3)'));assert(g.run('!!chargeFor(player,2)'));assert.equal(g.run('chargeFor(player,2).slot'),1);
});
check('Depleted dual casts release after the hold limit without negative energy or duplicated payments',()=>{
 reset();g.run('player.energy=23;startCharge(3);startCharge(1);updateHeldCharge(player,3.001)');near(g.run('player.energy'),0);assert.equal(g.run('chargesFor(player).length'),0);near(g.run('player.specialPower'),0);near(g.run('player.auxSpecialPower'),0);
});
check('Interruptions cancel both arm slots and clear their charge visuals',()=>{
 reset();g.run('startCharge(3);startCharge(1);updateHeldCharge(player,.5);animateFighter(player,.1);syncCombatVisuals()');assert.equal(g.run('startupRigs.size'),2);g.run('hurt(player,1,enemy,"special");syncCombatVisuals()');assert.equal(g.run('chargesFor(player).length'),0);assert.equal(g.run('startupRigs.size'),0);assert.equal(g.run('techniqueRigs.size'),0);
});
check('Upper and lower hands hold different techniques with distinct positions and finite geometry',()=>{
 reset();g.run('startCharge(1);startCharge(3);for(let i=0;i<30;i++){updateHeldCharge(player,.02);animateFighter(player,.02);}syncCombatVisuals();scene.updateMatrixWorld(true)');assert.equal(g.run('startupRigs.size'),2);assert(g.run('startupRigs.get("0-0").g.position.distanceTo(startupRigs.get("0-1").g.position)')>.35);assert(g.run('player.limbs.every(l=>l.hand.matrixWorld.elements.every(Number.isFinite))'));assert(g.run("techniqueRigs.get('charge0-lower').bow.children.length")>15);
});
check('Furnace flies at 90–120m/s and can be detonated once without extra energy',()=>{
 for(const q of [0,1]){reset();g.ctx.q=q;g.run('executeTechnique(player,3,q,V(0,0,-1));updateProjectiles(.1)');near(g.run('projectiles[0].p.z'),-1.7-(90+30*q)*.1);const energy=g.run('player.energy');assert(g.run('detonateFurnace(player)'));assert(!g.run('detonateFurnace(player)'));near(g.run('player.energy'),energy);assert.equal(g.run('projectiles.length'),0);near(g.run('techniques.find(t=>t.type==="burn").radius'),(12+10*q)*.75);assert(g.run('effects.some(e=>e.m.name==="vfx-furnaceBurst")')||g.run('effects.filter(e=>e.type==="technique").length')>=2);}
});
check('Furnace swept contact hits between frames, launches the target and stops at terrain',()=>{
 reset();g.run('enemy.pos.set(0,.13,-6);enemy.stun=0;executeTechnique(player,3,1,V(0,0,-1));scene.updateMatrixWorld(true);updateProjectiles(.05)');assert.equal(g.run('projectiles.length'),0);assert(g.run('enemy.hp')<800);assert(g.run('enemy.ragdollT')>0);
 reset();g.run('const b=buildings.find(b=>b.x===22&&b.z===22);player.pos.set(b.x-b.w/2-4,.13,b.z);globalThis.wallX=b.x-b.w/2;executeTechnique(player,3,1,V(1,0,0));scene.updateMatrixWorld(true);updateProjectiles(.1)');assert.equal(g.run('projectiles.length'),0);near(g.run('techniques.find(t=>t.type==="burn").p.x'),g.run('wallX'),.15);
});
check('Furnace explodes on a domain shell without damaging an outside opponent',()=>{
 reset();g.run('enemy.pos.set(0,.13,70);activateDomain(player);executeTechnique(player,3,1,V(0,0,1));for(let i=0;i<35;i++)updateProjectiles(1/60)');assert.equal(g.run('projectiles.length'),0);near(g.run('enemy.hp'),1000);assert(g.run('techniques.some(t=>t.type==="burn")'));
});
check('Spatial Shift warps 8–36m and accepts repeated quick casts using cursed energy',()=>{
 reset('gojo');near(g.run('teleportDestination(1).z'),-36);near(g.run('teleportDestination(0).z'),-8);
 g.run('for(let i=0;i<4;i++){startCharge(4);releaseCharge(4);updateHeldCharge(player,.06);}');near(g.run('player.pos.z'),-32);near(g.run('player.energy'),92);near(g.run('player.cooldown'),0);assert(g.run('effects.filter(e=>e.type==="technique").length')>=12);
});
check('Cursed Rush covers about 35m, ragdolls on contact and respects sealed barriers',()=>{
 reset();g.run('executeTechnique(player,4,1,V(0,0,-1));for(let i=0;i<30;i++)updateTechniques(1/60)');assert(g.run('player.pos.z')< -34&&g.run('player.pos.z')> -36);
 reset();g.run('enemy.pos.set(0,.13,-10);enemy.stun=0;executeTechnique(player,4,1,V(0,0,-1));updateTechniques(.15)');near(g.run('enemy.hp'),900);assert(g.run('enemy.ragdollT')>0);assert(g.run('enemy.vel.z')<=-40);
 reset();g.run('activateDomain(player);player.pos.z=-50;executeTechnique(player,4,1,V(0,0,-1));updateTechniques(.15)');assert(g.run('headPos(player).distanceTo(enclosureCenter())')<54);
});
check('Guests receive both charges and independent releases; malformed duplicate slots are rejected',()=>{
 reset();g.run('mode="online";net.role="host";startCharge(3);startCharge(1);updateHeldCharge(player,.5)');const guest=createGame();setupReplica(g,guest);guest.ctx.packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);updateReplica(.016);syncCombatVisuals()');assert.equal(guest.run('chargesFor(enemy).length'),2);assert.equal(guest.run('startupRigs.size'),2);
 g.run('releaseCharge(1)');guest.ctx.packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));guest.run('receiveState(packet);updateReplica(.016);syncCombatVisuals()');assert.equal(guest.run('chargesFor(enemy).length'),1);assert.equal(guest.run('chargeFor(enemy).kind'),3);
 g.run('startCharge(2)');guest.ctx.packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));guest.run('packet.actors[0].aux.slot=packet.actors[0].charge.slot');assert(!guest.run('validState(packet)'));
});
check('Remote Sukuna can detonate a launched arrow through the existing special action',()=>{
 reset('gojo');g.run('mode="online";net.role="host";enemy.stun=0;enemy.energy=100;remoteInput.yaw=Math.PI;remoteInput.pitch=0;actionFor(enemy,"special3",true);actionFor(enemy,"special3",false);updateHeldCharge(enemy,.86)');assert(g.run('hasFurnaceArrow(enemy)'));const energy=g.run('enemy.energy');g.run('actionFor(enemy,"special3",true);actionFor(enemy,"special3",false)');assert(!g.run('hasFurnaceArrow(enemy)'));near(g.run('enemy.energy'),energy);
});
check('Wheel controls are opt-in; angle, alternate zoom and free orbit preserve combat aim',()=>{
 reset('gojo');g.event('wheel',{deltaY:100,deltaMode:0});near(g.run('options.camTilt'),0);g.run('options.wheelCamera=true');g.event('wheel',{deltaY:100,deltaMode:0});near(g.run('options.camTilt'),.2);g.event('wheel',{deltaY:100,deltaMode:0,shiftKey:true});near(g.run('options.camDistance'),8.2);
 const before=g.run('yaw');g.event('mousedown',{button:1});g.event('mousemove',{movementX:200,movementY:50});assert(g.run('cameraOrbit.active'));assert(g.run('cameraOrbit.yaw')<-.4);near(g.run('yaw'),before);g.run('updateCamera(.016)');assert(g.run('camera.position.toArray().every(Number.isFinite)'));g.event('mouseup',{button:1,target:g.elements.get('settingsButton')});assert(!g.run('cameraOrbit.active'));g.event('mousedown',{button:1});g.event('blur');assert(!g.run('cameraOrbit.active'));
});
check('Phone editor drags without attacking, persists positions, and separates orientations',()=>{
 const h=createGame();h.reset('practice');h.run('controls.prefs.touch="on";controls.save();showSettings();controls.editLayout(true)');const button=h.document.querySelectorAll('[data-action]').find(e=>e.dataset.action==='special2');button.getBoundingClientRect=()=>({left:600,top:500,width:60,height:50});
 button.dispatchEvent({type:'pointerdown',pointerId:7,clientX:625,clientY:520,preventDefault(){}});button.dispatchEvent({type:'pointermove',pointerId:7,clientX:925,clientY:620,preventDefault(){}});button.dispatchEvent({type:'pointercancel',pointerId:7});assert.equal(h.run('charge'),null);assert.equal(h.run('controls.layoutDrag'),null);assert.equal(button.style['--layout-x'],'900px');assert.equal(button.style['--layout-y'],'600px');h.run('controls.editLayout(false)');const saved=JSON.parse(h.storage.get('limitless.touch-layout.v1'));assert(saved.landscape['action-special2'].x>0);assert.equal(Object.keys(saved.portrait).length,0);
 const reloaded=createGame({storage:h.storage});near(reloaded.run('controls.layouts.landscape["action-special2"].x'),saved.landscape['action-special2'].x);reloaded.run('innerWidth=430;innerHeight=900;controls.editLayout(true);controls.resetLayout();controls.editLayout(false)');assert(Object.keys(JSON.parse(h.storage.get('limitless.touch-layout.v1')).portrait).length>0);near(reloaded.run('controls.layouts.landscape["action-special2"].x'),saved.landscape['action-special2'].x);
});
check('Sanctuary has a golden sky and low sun; domains and map changes restore the correct lighting',()=>{
 reset();g.run('applyArenaMap("sanctuary")');assert(g.run('sky.getObjectByName("golden-sunset-sky")!==undefined'));assert(g.run('sun.color.r>sun.color.b'));near(g.run('sun.position.y'),35);g.run('activateDomain(player);domain=null;clearDomainVisual()');near(g.run('sun.position.y'),35);g.run('applyArenaMap("district")');near(g.run('sun.position.y'),65);assert.equal(g.run('scene.background.getHex()'),0x091322);
});
check('Reset clears auxiliary charges, release poses and presentation objects',()=>{
 reset();g.run('startCharge(1);startCharge(3);updateHeldCharge(player,.5);syncCombatVisuals();resetMatch("practice")');assert.equal(g.run('chargesFor(player).length'),0);assert.equal(g.run('player.auxSpecialKind'),0);assert.equal(g.run('startupRigs.size'),0);assert.equal(g.run('techniqueRigs.size'),0);
});
console.log(JSON.stringify({scope:'Build 10 combat, host/guest state, camera and synthetic phone-layout checks. No browser/device playtest.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
