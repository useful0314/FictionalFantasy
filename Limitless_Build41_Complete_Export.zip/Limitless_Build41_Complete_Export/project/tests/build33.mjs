import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';

const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(error){results.push({name,pass:false,error:error.stack});}}
function arena(){
 const g=createGame();g.debug.select('gojo');g.reset('practice');
 g.debug.setup({player:{pos:[0,20,20],hp:1000,energy:100},enemy:{pos:[100,20,20],hp:1000,stun:999},yaw:0,pitch:0});
 g.run('for(const p of pieces)p.alive=p.m.visible=false;player.grounded=enemy.grounded=false;player.vel.set(0,0,0);');return g;
}

check('Blue trails a camera turn, catches up quickly, travels farther, and survives a full reversal',()=>{
 const g=arena();g.run(`createBlue(player,1,V(0,0,-1));globalThis.testBlue=blue;yaw=-Math.PI/2;
  updateBlue(1/60,testBlue);globalThis.firstHeading=testBlue.dir.clone();
  for(let i=0;i<17;i++)updateBlue(1/60,testBlue);globalThis.followHeading=testBlue.dir.clone();
  globalThis.motionStart=testBlue.p.clone();yaw=Math.PI/2;
  for(let i=0;i<30;i++)updateBlue(1/60,testBlue);globalThis.reverseHeading=testBlue.dir.clone();
  globalThis.travelDistance=testBlue.travelled;`);
 assert(g.run('testBlue.range>34&&testBlue.range<=44'),'range should be a moderate increase over Build 32');
 assert(g.run('firstHeading.x>.01&&firstHeading.x<.25'),'the first frame must trail the camera without snapping or ignoring the turn');
 assert(g.run('followHeading.x>.97'),'Blue should catch up to a 90-degree turn in 300ms');
 assert(g.run('reverseHeading.x<-.95'),'a 180-degree turn must not stall normalization');
 assert(g.run('travelDistance>16'),'Blue should cover ground at high velocity while turning');
 assert(g.run('testBlue.dir.toArray().every(Number.isFinite)&&Math.abs(testBlue.dir.length()-1)<1e-6'));
});

check('Blue guidance behaves consistently at different frame rates',()=>{
 const samples=[];
 for(const fps of [30,60,144]){
  const g=arena();g.ctx.testFPS=fps;g.run(`createBlue(player,1,V(0,0,-1));yaw=-Math.PI/2;
   for(let i=0;i<testFPS;i++)updateBlue(1/testFPS,blue);globalThis.guidanceSample={heading:blue.dir.toArray(),distance:blue.travelled};`);
  samples.push(g.run('guidanceSample'));
 }
 for(const sample of samples){assert(sample.heading[0]>.99,'aim-position pursuit should point toward the selected side');for(let axis=0;axis<3;axis++)assert(Math.abs(sample.heading[axis]-samples[1].heading[axis])<.015);assert(Math.abs(sample.distance-samples[1].distance)<.2,'frame rate must not materially change flight speed');}
});

check('Blue has a reusable blue particle pool that scales down and back up with quality',()=>{
 const g=arena();g.run(`createBlue(player,1,V(0,0,-1));syncCombatVisuals();globalThis.field=techniqueRigs.get('blue'+blue.id);globalThis.pool=field.cloud.geometry;
  globalThis.fullDraw=pool.drawRange.count;particleBudget=600;syncCombatVisuals();globalThis.lowDraw=pool.drawRange.count;
  particleBudget=2000;for(let i=0;i<120;i++)syncCombatVisuals();globalThis.fullAgain=pool.drawRange.count;`);
 assert(g.run('fullDraw>=220&&lowDraw>=80&&lowDraw<fullDraw&&fullAgain===fullDraw'));
 assert(g.run('field.cloud.geometry===pool'),'quality changes should reuse the same allocated particle geometry');
 assert(g.run('field.cloud.material.uniforms.uColor.value.b>field.cloud.material.uniforms.uColor.value.r*3'));
 assert(g.run('field.cloud.material.uniforms.uAccent.value.b>field.cloud.material.uniforms.uAccent.value.r*3'));
});

check('Red has no white charge sphere locally or on a guest, and still fires its beam and impact',()=>{
 const host=arena();host.down('Digit2');host.advance(.7);
 assert(host.run("!charge.orb.g.visible&&!techniqueRigs.get('charge0').core.visible&&!startupRigs.get('0-0').core.visible"));
 const guest=createGame();setupReplica(host,guest);guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));
 assert(guest.run('validState(packet)'));guest.run('receiveState(packet);updateReplica(1/60);syncCombatVisuals();');
 assert(guest.run("Array.from(techniqueRigs.values()).filter(r=>r.kind==='red').every(r=>!r.core.visible)&&Array.from(startupRigs.values()).filter(r=>r.character==='gojo'&&r.kind===2).every(r=>!r.core.visible)"));
 host.up('Digit2');host.advance(.02);
 assert(host.run("!charge&&['impact-redMuzzle','impact-redBeam','impact-red'].every(name=>effects.some(e=>e.m.name===name))"),'removing the charging sphere must preserve the firing and impact effects');
});

check('Both casts hover during charge and release, then resume falling without enabling flight',()=>{
 for(const kind of [1,2]){
  const g=arena();g.down('Digit'+kind);g.advance(.7);
  assert(g.run('Math.abs(player.pos.y-20)<.001&&!player.flying'),'charge should hold height without toggling flight');
  g.up('Digit'+kind);g.advance(.2);assert(g.run('Math.abs(player.pos.y-20)<.001'),'release follow-through should still hover');
  g.advance(.95);assert(g.run('player.pos.y<18&&!player.flying&&!limitlessAirCast(player)'),'gravity must resume after the release animation');
 }
});

check('Hover eases out aerial momentum and ends on interruption or cancellation; ground casts stay grounded',()=>{
 const g=arena();g.run('player.vel.y=10');g.down('Digit1');g.advance(1/60);
 assert(g.run('player.vel.y>0&&player.vel.y<10'),'entering hover should brake smoothly rather than snap velocity');
 g.advance(.5);assert(g.run('player.vel.y<.01&&player.pos.y<20.7'));
 g.run('hurt(player,20,enemy,"special",V(0,-2,0),.2)');g.advance(.2);
 assert(g.run('!charge&&!limitlessAirCast(player)&&player.vel.y<-2'),'a hit must cancel the hovering cast');
 const cancel=arena();cancel.down('Digit2');cancel.advance(.2);cancel.run('cancelCharge(player)');cancel.advance(.2);assert(cancel.run('player.pos.y<20&&!limitlessAirCast(player)'));
 const release=arena();release.down('Digit1');release.advance(.5);release.up('Digit1');release.run('hurt(player,20,enemy,"special",V(0,-1,0),.2)');release.advance(.25);assert(release.run('player.specialKind===0&&!limitlessAirCast(player)&&player.pos.y<19.7'),'a hit during release must end hover for the rest of that cast');
 const ground=arena();ground.run('player.pos.y=.13;player.grounded=true');ground.down('Digit2');ground.advance(.6);assert(ground.run('player.grounded&&player.pos.y<.2&&!limitlessAirCast(player)'));
 const purple=arena();purple.down('Digit3');purple.advance(.35);assert(purple.run('player.pos.y<19&&!limitlessAirCast(player)'),'other moves must retain their existing gravity behavior');
});

check('Existing flight remains enabled and resumes vertical controls when the cast ends',()=>{
 const g=arena();g.run('player.flying=true');g.down('Space');g.down('Digit2');g.advance(.6);
 assert(g.run('player.flying&&Math.abs(player.pos.y-20)<.001'),'flight ascent input must not fight casting hover');
 g.run('cancelCharge(player)');g.advance(.2);assert(g.run('player.flying&&player.pos.y>21'),'normal flight controls should resume immediately after cancellation');
});

check('Blue and Red have distinct wind-up and release poses, animated hands, and finite reusable joints',()=>{
 const poses=[];
 for(const kind of [1,2]){
  const g=arena();g.down('Digit'+kind);g.advance(.12);const early=g.run('player.limbs.map(l=>l.arm.rotation.x)');
  g.advance(.55);g.run('globalThis.savedPose=player.specialPoseCache[0]');
  const held=g.run('player.limbs.map(l=>l.arm.rotation.x)');assert(Math.abs(early[kind-1]-held[kind-1])>.25,'the casting arm must move through readable anticipation');
  if(kind===1)assert(g.run('player.limbs[0].fingers.every(f=>f.rotation.x>-.2)&&player.limbs[0].hand.rotation.x<-.15'),'Blue should visibly open and turn the guiding palm');
  else assert(g.run('player.limbs[1].fingers[0].rotation.x>-.05&&player.limbs[1].fingers[1].rotation.x<-1.3'),'Red should extend its firing finger and curl the other fingers');
  poses.push(held);g.run('globalThis.chargePoint=techniqueChargePosition(player,charge)');g.up('Digit'+kind);
  if(kind===1)assert(g.run('blue.p.distanceTo(chargePoint)<.15'),'Blue should leave the animated palm without jumping to a head-based origin');
  g.advance(.15);
  assert(g.run('player.specialPoseCache[0]===savedPose'),'animation poses must be reused');
  assert(g.run('(()=>{player.root.updateMatrixWorld(true);let finite=true;player.root.traverse(o=>{if(!o.matrixWorld.elements.every(Number.isFinite))finite=false;});return finite;})()'));
  g.advance(1);g.reset('practice');assert(g.run('!limitlessAirCast(player)&&!charge&&player.specialKind===0'));
 }
 assert(Math.abs(poses[0][0]-poses[1][0])>.4&&Math.abs(poses[0][1]-poses[1][1])>.4,'Blue and Red should use different leading-arm silhouettes');
});

check('Airborne casting state and pose reach guests through existing fighter snapshots',()=>{
 const host=arena();host.down('Digit1');host.advance(.7);
 const guest=createGame();setupReplica(host,guest);guest.ctx.casterId=host.run('player.id');guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));
 assert(guest.run('validState(packet)'));guest.run('receiveState(packet);updateReplica(1/60);globalThis.caster=actorById(casterId);animateFighter(caster,1/60);');
 assert(guest.run('limitlessAirCast(caster)&&Math.abs(caster.pos.y-20)<.001&&caster.specialPoseCache[0].limitless'));
 host.up('Digit1');host.advance(.15);guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));
 guest.run('receiveState(packet);updateReplica(1/60);animateFighter(caster,1/60);');assert(guest.run('limitlessAirCast(caster)&&caster.specialKind===1'));
});

console.log(JSON.stringify({scope:'Build 33 delayed Blue control, Red charge cleanup, casting animation and aerial movement; simulation only.',results},null,2));
if(results.some(result=>!result.pass))process.exitCode=1;
