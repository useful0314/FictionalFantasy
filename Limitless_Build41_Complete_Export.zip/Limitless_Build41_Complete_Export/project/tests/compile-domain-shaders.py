"""Compile/link the exported domain GLSL on headless Mesa GLES (not browser QA).
Run tests/domains.mjs with DOMAIN_SHADER_EXPORT, then pass that JSON path here.
"""
import ctypes as c
import json
import sys

egl = c.CDLL('libEGL.so.1')
egl.eglGetProcAddress.argtypes=[c.c_char_p]
egl.eglGetProcAddress.restype=c.c_void_p
def proc(name,restype,args):
    ptr=egl.eglGetProcAddress(name.encode())
    if not ptr: raise RuntimeError('Unavailable GL entry point: '+name)
    return c.CFUNCTYPE(restype,*args)(ptr)
def efunc(name,restype,args):
    fn=getattr(egl,name);fn.restype=restype;fn.argtypes=args;return fn

display=proc('eglGetPlatformDisplayEXT',c.c_void_p,[c.c_uint,c.c_void_p,c.POINTER(c.c_int)])(0x31DD,None,None)
major,minor=c.c_int(),c.c_int()
assert efunc('eglInitialize',c.c_uint,[c.c_void_p,c.POINTER(c.c_int),c.POINTER(c.c_int)])(display,c.byref(major),c.byref(minor)),'EGL could not initialize'
assert efunc('eglBindAPI',c.c_uint,[c.c_uint])(0x30A0)
attrs=(c.c_int*13)(0x3033,1,0x3040,4,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3038)
config=c.c_void_p();count=c.c_int()
assert efunc('eglChooseConfig',c.c_uint,[c.c_void_p,c.POINTER(c.c_int),c.POINTER(c.c_void_p),c.c_int,c.POINTER(c.c_int)])(display,attrs,c.byref(config),1,c.byref(count)) and count.value
context=efunc('eglCreateContext',c.c_void_p,[c.c_void_p,c.c_void_p,c.c_void_p,c.POINTER(c.c_int)])(display,config,None,(c.c_int*3)(0x3098,2,0x3038))
assert context,'GLES context unavailable'
assert efunc('eglMakeCurrent',c.c_uint,[c.c_void_p,c.c_void_p,c.c_void_p,c.c_void_p])(display,None,None,context)
create=proc('glCreateShader',c.c_uint,[c.c_uint]);source=proc('glShaderSource',None,[c.c_uint,c.c_int,c.POINTER(c.c_char_p),c.POINTER(c.c_int)])
compile_shader=proc('glCompileShader',None,[c.c_uint]);get=proc('glGetShaderiv',None,[c.c_uint,c.c_uint,c.POINTER(c.c_int)])
log=proc('glGetShaderInfoLog',None,[c.c_uint,c.c_int,c.POINTER(c.c_int),c.c_char_p])
create_program=proc('glCreateProgram',c.c_uint,[]);attach=proc('glAttachShader',None,[c.c_uint,c.c_uint]);link=proc('glLinkProgram',None,[c.c_uint]);getp=proc('glGetProgramiv',None,[c.c_uint,c.c_uint,c.POINTER(c.c_int)]);logp=proc('glGetProgramInfoLog',None,[c.c_uint,c.c_int,c.POINTER(c.c_int),c.c_char_p])
delete_shader=proc('glDeleteShader',None,[c.c_uint]);delete_program=proc('glDeleteProgram',None,[c.c_uint])
vertex_prefix='precision highp float; attribute vec3 position,normal; attribute vec2 uv; uniform mat4 modelMatrix,modelViewMatrix,projectionMatrix,viewMatrix; uniform mat3 normalMatrix;\n'
results=[]
for item in json.load(open(sys.argv[1])):
    shaders=[]
    for kind,prefix,body in [(0x8B31,vertex_prefix,item['vertex']),(0x8B30,'precision highp float;\n',item['fragment'])]:
        shader=create(kind);text=(prefix+body).encode();ptr=c.c_char_p(text);source(shader,1,c.byref(ptr),None);compile_shader(shader);ok=c.c_int();get(shader,0x8B81,c.byref(ok))
        if not ok.value:
            buf=c.create_string_buffer(16384);log(shader,len(buf),None,buf);raise RuntimeError(item['name']+': '+buf.value.decode())
        shaders.append(shader)
    program=create_program()
    for shader in shaders:attach(program,shader)
    link(program);ok=c.c_int();getp(program,0x8B82,c.byref(ok))
    if not ok.value:
        buf=c.create_string_buffer(16384);logp(program,len(buf),None,buf);raise RuntimeError(item['name']+': '+buf.value.decode())
    results.append({'shader':item['name'],'compiled_and_linked':True})
    delete_program(program)
    for shader in shaders:delete_shader(shader)
print(json.dumps({'scope':'Actual headless GLES shader compilation/linking only; no browser render', 'results':results}))
efunc('eglMakeCurrent',c.c_uint,[c.c_void_p,c.c_void_p,c.c_void_p,c.c_void_p])(display,None,None,None)
efunc('eglDestroyContext',c.c_uint,[c.c_void_p,c.c_void_p])(display,context)
efunc('eglTerminate',c.c_uint,[c.c_void_p])(display)
