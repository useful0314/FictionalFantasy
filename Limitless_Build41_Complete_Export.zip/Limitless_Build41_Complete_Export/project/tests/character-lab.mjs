import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import * as Three from '../vendor/three.module.js';
import {Element} from './harness.mjs';
class Node extends Element{
 constructor(tag='div'){super(tag);this._html='';this.value='';}
 set innerHTML(html){this._html=html;this.children=[];for(const match of html.matchAll(/<button\b([^>]*)>/g)){const n=new Node('button');for(const a of match[1].matchAll(/([\w-]+)="([^"]*)"/g)){if(a[1]==='class')n.classList.add(...a[2].split(' '));else n.setAttribute(a[1],a[2]);}this.append(n);}}
 get innerHTML(){return this._html;}
 getBoundingClientRect(){return {width:900,height:550,left:0,top:0};}
 scrollIntoView(){}select(){}
}
const elements=new Map(),html=fs.readFileSync(new URL('../src/lab/index.html',import.meta.url),'utf8');for(const x of html.matchAll(/id="([^"]+)"/g))elements.set(x[1],new Node(x[1]==='pickText'?'input':'div'));
const document={hidden:false,activeElement:null,documentElement:new Node(),createElement:tag=>new Node(tag),getElementById:id=>{assert(elements.has(id),id);return elements.get(id);},querySelectorAll:selector=>selector==='.move'?elements.get('moves').children:[]};
for(const e of elements.values())e.ownerDocument=document;
class Renderer{constructor(){this.domElement=new Node('canvas');this.shadowMap={};}setPixelRatio(){}setSize(){}render(scene,camera){scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);}}
const win=new Node(),storage=new Map();win.devicePixelRatio=1;win.matchMedia=()=>({matches:false});const ctx=vm.createContext({THREE:{...Three,WebGLRenderer:Renderer},window:win,document,localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},navigator:{clipboard:{writeText:async s=>{win.copied=s;}}},requestAnimationFrame(){},console});
let code=fs.readFileSync(new URL('../src/lab/engine.js',import.meta.url),'utf8').replace(/^import[^\n]+/,'const THREE=globalThis.THREE;');for(const [tag,file]of [['LAB_CHARACTERS','characters'],['LAB_MODELS','models'],['LAB_ANIMATION','animation']])code=code.replace('/*'+tag+'*/',fs.readFileSync(new URL('../src/lab/'+file+'.js',import.meta.url),'utf8'));vm.runInContext(code,ctx);
const lab=win.characterLab,results=[];assert.equal(elements.get('roster').children.length,6);assert.equal(elements.get('moves').children.length,4);
for(let index=0;index<6;index++){
 lab.select(index);const name=lab.snapshot().selected;assert.equal(elements.get('roster').children[index]['aria-pressed'],'true');
 for(let move=0;move<4;move++){
  lab.playMove(move);let moved=false,fxShown=false;for(let n=0;n<360;n++){lab.step(1/60);const s=lab.snapshot();if(s.active){moved ||= s.position.some((v,i)=>Math.abs(v-[-1.6,0,0][i])>.1);fxShown ||= s.fx.children.some(o=>o.visible)||s.particles>0;}s.model.traverse(o=>assert(o.matrixWorld.elements.every(Number.isFinite),name+' model transform'));s.fx.traverse(o=>assert(o.matrixWorld.elements.every(Number.isFinite),name+' effect transform'));assert(s.particles<=360);}
  assert.equal(lab.snapshot().active,null);assert(fxShown,name+' move '+move+' needs visible effects');if(move===3)assert(moved,name+' mobility must move');results.push(name+' / move '+(move+1));
 }
}
lab.select(5);assert.equal(lab.snapshot().rigCount,6);elements.get('pick').onclick();assert.equal(storage.get('limitless.lab.pick'),'toji');await elements.get('copy').onclick();assert(win.copied.includes('Toji Fushiguro'));assert.equal(elements.get('selection').hidden,false);
elements.get('showcase').onclick();for(let i=0;i<250;i++)lab.step(1/60);assert(lab.snapshot().active,'full-kit tour should start its next move');elements.get('showcase').onclick();
elements.get('resetView').onclick();assert.equal(elements.get('rotate')['aria-pressed'],'false');
console.log(JSON.stringify({passed:results.length,scope:'All 24 move demos complete with finite model/effect transforms, bounded particles and moving mobility; roster buttons, selection, copy and kit tour work. Simulation only.'}));
// Optional model-only contact sheet, projected from the actual geometry for silhouette inspection.
if(process.env.LAB_SHEET){let svg='<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="440" viewBox="0 0 1200 440"><rect width="1200" height="440" fill="#14241a"/>';
 for(let index=0;index<6;index++){lab.select(index);for(let i=0;i<40;i++)lab.step(1/60);const s=lab.snapshot(),root=s.model,cam=new Three.PerspectiveCamera(32,200/360,.1,100);cam.position.set(root.position.x+3,2.8,8);cam.lookAt(root.position.x,1.4,0);cam.updateMatrixWorld(true);const tris=[],a=new Three.Vector3(),b=new Three.Vector3(),c=new Three.Vector3(),n=new Three.Vector3(),ab=new Three.Vector3(),ac=new Three.Vector3();root.traverse(o=>{if(!o.isMesh)return;let ancestor=o;while(ancestor){if(!ancestor.visible)return;ancestor=ancestor.parent;}const p=o.geometry.attributes.position,indices=o.geometry.index?.array;const count=indices?indices.length:p.count;for(let j=0;j<count;j+=3){a.fromBufferAttribute(p,indices?indices[j]:j).applyMatrix4(o.matrixWorld);b.fromBufferAttribute(p,indices?indices[j+1]:j+1).applyMatrix4(o.matrixWorld);c.fromBufferAttribute(p,indices?indices[j+2]:j+2).applyMatrix4(o.matrixWorld);ab.copy(b).sub(a);ac.copy(c).sub(a);n.crossVectors(ab,ac).normalize();if(n.dot(ab.copy(cam.position).sub(a))<0)continue;const z=(a.distanceTo(cam.position)+b.distanceTo(cam.position)+c.distanceTo(cam.position))/3,light=.48+Math.max(0,n.dot(new Three.Vector3(-.4,.8,.65).normalize()))*.62,col=o.material.color.clone().multiplyScalar(light);a.project(cam);b.project(cam);c.project(cam);const points=[a,b,c].map(v=>`${index*200+(v.x*.5+.5)*200},${25+(-v.y*.5+.5)*360}`).join(' ');tris.push({z,points,color:'#'+col.getHexString()});}});tris.sort((a,b)=>b.z-a.z);svg+=tris.map(t=>`<polygon points="${t.points}" fill="${t.color}"/>`).join('');svg+=`<text x="${index*200+100}" y="414" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#ede9d6">${s.selected}</text>`;}
 svg+='</svg>';fs.writeFileSync(process.env.LAB_SHEET,svg);
}
