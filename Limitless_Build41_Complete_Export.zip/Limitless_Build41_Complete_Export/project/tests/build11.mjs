import assert from 'node:assert/strict';
import {createGame} from './harness.mjs';
const results=[],near=(a,b,tol=1e-6)=>assert(Math.abs(a-b)<tol,`${a} != ${b}`);
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(){const g=createGame();g.reset('practice');g.run('document.pointerLockElement=renderer.domElement;globalThis.lockCount=0;renderer.domElement.requestPointerLock=()=>{lockCount++;document.pointerLockElement=renderer.domElement;document.dispatchEvent({type:"pointerlockchange"});return Promise.resolve();};document.exitPointerLock=()=>{document.pointerLockElement=null;document.dispatchEvent({type:"pointerlockchange"});};');return g;}
check('Cursor toggle unlocks without pausing, suppresses mouse attacks, and clicks the clash drill',()=>{
 const g=game();g.down('AltLeft');g.up('AltLeft');assert(g.run('cursorFree'));assert.equal(g.state().phase,'play');assert(!g.run('menuOpen'));assert.equal(g.document.pointerLockElement,null);assert(g.document.body.classList.contains('cursor-mode'));
 const aim=g.run('yaw');g.event('mousemove',{movementX:200,movementY:80});near(g.run('yaw'),aim);g.event('mousedown',{button:0});g.event('mouseup',{button:0});assert.equal(g.run('pendingHits.length'),0);assert.equal(g.run('player.attack'),0);
 g.elements.get('drillButton').click();assert.equal(g.state().mode,'practice');assert(g.state().enemyCast);assert(!g.run('cursorFree'));assert(g.run('lockCount')>0);g.down('KeyQ');g.up('KeyQ');assert(g.state().clash);
});
check('The same cursor key restores mouse aim; unexpected unlock still pauses normally',()=>{
 const g=game();g.down('AltLeft');g.up('AltLeft');g.down('AltLeft');g.up('AltLeft');assert(!g.run('cursorFree'));assert.equal(g.run('lockCount'),1);g.event('mousemove',{movementX:100,movementY:0});assert(g.run('yaw')<0);
 g.document.pointerLockElement=null;g.document.dispatchEvent({type:'pointerlockchange'});assert.equal(g.state().phase,'pause');
});
check('Hold cursor mode lasts until keyup and releases safely on focus loss',()=>{
 const g=game();g.run('options.cursorBehavior="hold"');g.down('AltLeft');assert(g.run('cursorFree'));assert(g.run('controls.held.has("cursor")'));g.up('AltLeft');assert(!g.run('cursorFree'));assert.equal(g.run('lockCount'),1);
 g.down('AltLeft');g.event('blur');assert.equal(g.state().phase,'pause');assert(!g.run('cursorFree'));assert.equal(g.run('lockCount'),1);
});
check('Cursor can be rebound to Ctrl without duplicate bindings and survives reload',()=>{
 const g=game();g.run('controls.bind("cursor","ControlLeft")');assert.equal(g.run('controls.bindings.descend'),'AltLeft');g.down('ControlLeft');g.up('ControlLeft');assert(g.run('cursorFree'));assert(!g.run('keys.has("ControlLeft")'));
 const saved=createGame({storage:g.storage});assert.equal(saved.run('controls.bindings.cursor'),'ControlLeft');assert.equal(saved.run('controls.bindings.descend'),'AltLeft');
 const old=new Map([['limitless.controls.v3',JSON.stringify({keys:{special1:'AltLeft',special2:'KeyV'}})]]),migrated=createGame({storage:old});assert.equal(migrated.run('controls.bindings.special1'),'AltLeft');assert.notEqual(migrated.run('controls.bindings.cursor'),'AltLeft');assert.notEqual(migrated.run('controls.bindings.orbitView'),'KeyV');assert.equal(migrated.run('new Set(Object.values(controls.bindings)).size'),migrated.run('Object.keys(controls.bindings).length'));
});
check('Character view reaches the front without rotating the fighter and keeps its angle until disabled',()=>{
 const g=game();g.run('player.pos.set(0,.13,0);enemy.pos.set(60,.13,60);yaw=0;pitch=0;lockOn=true;options.cinematics=false;animateFighter(player,.02)');const facing=g.run('player.root.rotation.y');g.down('KeyV');g.up('KeyV');assert(g.run('options.freeOrbit'));g.event('mousemove',{movementX:1400,movementY:0});g.run('updateCamera(1);animateFighter(player,.02)');near(g.run('yaw'),0);near(g.run('player.root.rotation.y'),facing);assert(g.run('camera.position.z')< -5);assert(g.document.body.classList.contains('character-view'));
 const orbit=g.run('cameraOrbit.yaw');g.run('updateCamera(.5)');near(g.run('cameraOrbit.yaw'),orbit);g.event('wheel',{deltaY:-100,deltaMode:0});assert(g.run('options.camDistance')<7);g.down('KeyV');g.up('KeyV');assert(!g.run('options.freeOrbit'));g.run('lockOn=false;updateCamera(.5)');assert(Math.abs(g.run('cameraOrbit.yaw'))<.02);
});
check('A free cursor can drag the arena to orbit without relocking or attacking',()=>{
 const g=game();g.down('AltLeft');g.up('AltLeft');g.down('KeyV');g.up('KeyV');const canvas=g.run('renderer.domElement');canvas.dispatchEvent({type:'pointerdown',pointerType:'mouse',button:0,preventDefault(){}});g.event('mousedown',{button:0,target:canvas});g.event('pointermove',{movementX:500,movementY:50});g.event('pointerup',{button:0});g.event('mouseup',{button:0});assert(g.run('cameraOrbit.yaw')< -1);assert.equal(g.run('lockCount'),0);assert.equal(g.run('pendingHits.length'),0);near(g.run('yaw'),0);assert(g.run('cursorFree'));
});
check('Settings preserve cursor behavior and character view; online camera actions stay local',()=>{
 const g=game();g.elements.get('cursorBehavior').value='hold';g.elements.get('cursorBehavior').dispatchEvent({type:'change'});g.elements.get('freeOrbit').checked=true;g.elements.get('freeOrbit').dispatchEvent({type:'change'});const reloaded=createGame({storage:g.storage});assert.equal(reloaded.run('options.cursorBehavior'),'hold');assert(reloaded.run('options.freeOrbit'));
 g.run('mode="online";net.role="guest";localEdges.length=0;options.cursorBehavior="toggle"');g.down('AltLeft');g.up('AltLeft');g.down('KeyV');g.up('KeyV');assert.equal(g.run('localEdges.length'),0);assert.equal(g.state().phase,'play');
});
check('Ground jumps stay free; extra Sukuna jumps consume 3 cursed energy and reject insufficient energy',()=>{
 const g=game();g.run('selectedCharacter="sukuna";resetMatch("duel");player.stamina=0;player.energy=6;');assert(g.run('jumpFighter(player)'));near(g.run('player.energy'),6);near(g.run('player.stamina'),0);g.run('player.pos.y=5;player.airJumpCooldown=0');assert(g.run('jumpFighter(player)'));near(g.run('player.energy'),3);g.run('player.airJumpCooldown=0');assert(g.run('jumpFighter(player)'));near(g.run('player.energy'),0);g.run('player.airJumpCooldown=0');assert(!g.run('jumpFighter(player)'));near(g.run('player.stamina'),0);
 g.run('mode="online";enemy.character="sukuna";enemy.stun=0;enemy.grounded=false;enemy.pos.y=5;enemy.energy=3;actionFor(enemy,"jump",true)');near(g.run('enemy.energy'),0);assert(g.run('enemy.jumpPose')>0);
});
check('Gojo flight costs 2 cursed energy per second; only sprinting drains stamina',()=>{
 const g=game();g.run('mode="duel";player.pos.set(0,12,70);player.flying=true;player.grounded=false;player.stamina=100;player.energy=100;for(let i=0;i<60;i++)updateControlled(player,1/60)');near(g.run('player.stamina'),100);near(g.run('player.energy'),98);
 g.run('keys.add("KeyW");keys.add("ShiftLeft");for(let i=0;i<60;i++)updateControlled(player,1/60)');near(g.run('player.stamina'),95.5);near(g.run('player.energy'),96);
});
check('Flight starts at zero stamina, requires cursed energy and ends on depletion for local and remote Gojo',()=>{
 const g=game();g.run('mode="duel";player.stamina=0;player.energy=1;actionFor(player,"fly",true)');assert(g.run('player.flying'));g.run('player.pos.y=12;updateControlled(player,.6)');near(g.run('player.energy'),0);assert(!g.run('player.flying'));assert(g.run('player.vel.y')<0);g.run('actionFor(player,"fly",true)');assert(!g.run('player.flying'));
 g.run('player.flying=true;player.energy=0;actionFor(player,"fly",true)');assert(!g.run('player.flying'));
 g.run('mode="online";enemy.character="gojo";enemy.stun=0;enemy.stamina=0;enemy.energy=3;enemy.pos.y=12;actionFor(enemy,"fly",true);updateControlled(enemy,.5)');assert(g.run('enemy.flying'));near(g.run('enemy.energy'),2);near(g.run('enemy.stamina'),0);
});
console.log(JSON.stringify({scope:'Build 11 pointer-lock lifecycle, practice UI clicks, orbit camera, persisted bindings and movement costs. Simulated DOM, no physical-device playtest.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
