import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(character='mahito'){const g=createGame();g.ctx.character=character;g.run('selectedCharacter=character;selectedMap="harbor";resetMatch("duel");for(const p of pieces)p.alive=p.m.visible=false;player.pos.set(0,.12,0);enemy.pos.set(0,.12,-18);enemy.stun=999;player.energy=player.ult=100;yaw=pitch=0;');return g;}
check('All four characters have a 1.5-second dodge gate, unchanged immunity and a reset on new match',()=>{
 for(const character of ['gojo','sukuna','naruto','mahito']){const g=game(character);g.run('dodge(player)');assert.equal(g.run('player.dodgeCooldown'),1.5);assert.equal(g.run('player.dodge'),.34);assert.equal(g.run('player.dodgeWindow'),.2);g.run('for(let i=0;i<60;i++)updateControlled(player,1/60);dodge(player)');assert(g.run('player.dodgeCooldown<.51&&player.dodge===0'));g.run('for(let i=0;i<32;i++)updateControlled(player,1/60);dodge(player)');assert.equal(g.run('player.dodgeCooldown'),1.5);g.run('resetMatch("duel")');assert.equal(g.run('player.dodgeCooldown'),0);}
});
check('Normal dodge gains about two metres during its active window; Naruto dash travels 7.5m',()=>{
 const g=game('gojo');g.run('DODGE.impulse=22;dodge(player);for(let i=0;i<21;i++)updateControlled(player,1/60);globalThis.oldDistance=player.pos.z;player.pos.set(0,.12,0);player.vel.set(0,0,0);player.dodge=player.dodgeCooldown=0;DODGE.impulse=36;dodge(player);for(let i=0;i<21;i++)updateControlled(player,1/60);globalThis.gain=player.pos.z-oldDistance;');assert(g.run('gain>2&&gain<2.3'));
 const n=game('naruto');n.run('dodge(player);for(let i=0;i<24;i++)updateControlled(player,1/60)');assert(n.run('Math.abs(player.pos.z)>7.49&&Math.abs(player.pos.z)<7.51'));
});
check('Extended dodges respect thin walls and the domain sphere at 30/60/120 Hz',()=>{
 for(const character of ['gojo','sukuna','naruto','mahito'])for(const hz of [30,60,120]){const g=game(character);g.ctx.hz=hz;g.run('pieces.push({alive:true,solid:true,pos:V(0,10,-3),size:V(40,20,.04)});keys.add("KeyW");dodge(player);keys.clear();for(let i=0;i<hz/2;i++)updateControlled(player,1/hz)');assert(g.run('player.pos.z>=-2.56'));}
 const b=game('gojo');b.run('activateDomain(player);player.pos.set(0,.12,52);dodge(player);for(let i=0;i<30;i++)updateControlled(player,1/60)');assert(b.run('player.pos.z<53.5'));
});
check('Domain assigns four hands to each caught rival, never the owner or outside players',()=>{
 const g=game();g.run('matchSetup.bots=["gojo","sukuna","naruto","mahito","gojo"];resetMatch("duel");for(const f of bodies){f.pos.set(f.slot*5,30,0);f.stun=999;}player.stun=0;bodies[5].pos.x=130;activateDomain(player);updateMahitoDomain(domain,.1)');assert.equal(g.run('domain.mahitoHunters.length'),16);assert(g.run('domain.mahitoHunters.every(h=>h.target!==player.id&&h.target!==bodies[5].id)&&bodies.slice(1,5).every(b=>domain.mahitoHunters.filter(h=>h.target===b.id).length===4)'));
});
check('Hands visibly wind up, home in 3D, deal contact damage once, then recover',()=>{
 const g=game();g.run('player.pos.y=enemy.pos.y=30;activateDomain(player);updateMahitoDomain(domain,.01);domain.mahitoHunters.length=1;globalThis.h=domain.mahitoHunters[0];globalThis.before=h.p.clone();for(let i=0;i<25;i++)updateMahitoDomain(domain,1/60)');assert(g.run('h.phase===0&&h.p.distanceTo(before)===0&&enemy.hp===1000'));
 g.run('enemy.pos.x+=2;enemy.pos.y+=3;for(let i=0;i<70;i++)updateMahitoDomain(domain,1/60)');assert(g.run('enemy.hp===976&&h.phase===2&&h.p.y>30'));g.run('for(let i=0;i<10;i++)updateMahitoDomain(domain,1/60)');assert.equal(g.run('enemy.hp'),976);
});
check('Guard reduces hand damage by 45%; dodge avoids it; hand contact never executes',()=>{
 for(const defense of ['guard','dodge','none']){const g=game();g.ctx.defense=defense;g.run('activateDomain(player);updateMahitoDomain(domain,.01);domain.mahitoHunters.length=1;const h=domain.mahitoHunters[0];h.p.copy(headPos(enemy)).add(V(0,0,1));h.dir.set(0,0,-1);h.phase=1;h.age=0;enemy.block=defense==="guard";enemy.blockTime=1;enemy.dodge=defense==="dodge"?.3:0;enemy.dodgeWindow=0;updateMahitoDomain(domain,.016)');const hp=g.run('enemy.hp');assert(Math.abs(hp-(defense==='guard'?986.8:defense==='dodge'?1000:976))<1e-7);assert.equal(g.run('domain.mahitoHunters[0].phase'),2);}
});
check('Clashes have no pursuing hand damage; ending, death and reset clear attacks',()=>{
 const g=game();g.run('enemy.ult=100;enemy.stun=0;castDomain(player);castDomain(enemy);globalThis.hp=enemy.hp;for(let i=0;i<100;i++)updateDomains(1/60)');assert(g.run('!!clash&&!domain&&enemy.hp===hp&&packMahitoHands().length===0'));
 g.run('activateDomain(player);updateMahitoDomain(domain,.1);endActiveDomain(domain)');assert(g.run('!domain&&packMahitoHands().length===0&&player.techniqueBurnout===15'));
 const d=game();d.run('activateDomain(player);updateMahitoDomain(domain,.1);player.hp=0;updateMahitoDomain(domain,.1)');assert(d.run('!domain&&packMahitoHands().length===0'));d.run('resetMatch("duel")');assert.equal(d.run('packMahitoHands().length'),0);
});
check('Hand pools stay bounded at six fighters and quality changes do not alter attacks',()=>{
 const g=game();g.run('matchSetup.bots=["gojo","sukuna","naruto","mahito","gojo"];resetMatch("practice");for(const f of bodies){f.pos.set(f.slot*5,20,0);f.stun=999;}activateDomain(player);updateMahitoDomain(domain,.01);particleBudget=900;animateDomainVisual()');assert(g.run('domain.mahitoHunters.length===20&&domainVisual.userData.mahitoHands.palm.count===96&&domainVisual.userData.mahitoHands.hunters.palm.count===20'));g.run('particleBudget=2400;animateDomainVisual()');assert(g.run('domainVisual.userData.mahitoHands.palm.count===224&&domain.mahitoHunters.length===20'));
});
check('All Mahito move and form animations remain finite and settle without pose resets',()=>{
 const g=game();for(const k of [1,2,3,4,5,6]){g.ctx.kind=k;g.run('player.hp=500;player.ult=100;player.stun=0;player.cooldown=0;player.mahitoAction=null;startMahitoMove(player,kind);for(let i=0;i<180;i++){updateMahitoFighter(player,1/60);animateFighter(player,1/60);animateMahitoDetail(player,1/60);}player.root.updateMatrixWorld(true);globalThis.finite=true;player.root.traverse(o=>{finite=finite&&o.matrixWorld.elements.every(Number.isFinite);})');assert(g.run('finite'));}
 for(const arm of [1,2,3]){g.ctx.arm=arm;g.run('player.mahitoAction=null;player.grounded=true;player.flying=false;player.mahitoForm=0;player.mahitoArm=arm;player.attack=0;player.stun=0;lightAttack(player);globalThis.maxStep=0;for(let i=0;i<90;i++){const x=player.limbs[1].arm.rotation.x;player.attack=Math.max(0,player.attack-1/60);animateFighter(player,1/60);animateMahitoDetail(player,1/60);maxStep=Math.max(maxStep,Math.abs(player.limbs[1].arm.rotation.x-x));}');assert(g.run('maxStep<.7&&Math.abs(player.limbs[1].arm.rotation.x+.3)<.05'));}
});
check('Hands and cooldowns replicate to the guest, with malformed/outside/owner packets rejected',()=>{
 const host=game();host.run('net.role="host";net.localId="p0";net.roster=[{id:"p0",character:"mahito",bot:false},{id:"p1",character:"gojo",bot:false}];beginOnline("mahito","harbor");countdown=0;activateDomain(player);updateMahitoDomain(domain,.3);dodge(enemy)');
 const guest=createGame();setupReplica(host,guest);guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);animateDomainVisual()');assert(guest.run('mahitoReplica.hands.length===4&&domainVisual.userData.mahitoHands.hunters.palm.count===4&&player.dodgeCooldown===1.5'));
 guest.run('packet.mahito.hands[0].target=packet.domain.owner');assert(!guest.run('validState(packet)'));guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));guest.run('packet.actors[0].dodgeCooldown=9');assert(!guest.run('validState(packet)'));
});
console.log(JSON.stringify({scope:'Combat simulation, real Three.js rigs and host/guest packets. No browser/device FPS claim.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
