import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createGame,setupReplica} from './harness.mjs';
const g=createGame(),results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
const finite=()=>g.run('(()=>{scene.updateMatrixWorld(true);let ok=true;scene.traverse(o=>{if(!o.matrixWorld.elements.every(Number.isFinite))ok=false;});return ok;})()');
function reset(character='gojo'){g.debug.select(character);g.reset('practice');g.debug.setup({player:{pos:[0,.13,8]},enemy:{pos:[40,.13,0],stun:999},yaw:0,pitch:0});}
check('Every held special, including CPU Furnace, builds finite scene geometry',()=>{
 for(const c of ['gojo','sukuna'])for(let k=1;k<=4;k++){reset(c);g.down('Digit'+k);g.advance(.85);assert(finite(),c+' '+k);g.up('Digit'+k);g.advance(.15);assert(finite());}
 reset('gojo');g.run("cpuCharge={kind:3,t:.5,duration:1.2,q:.45,o:orb(0xff8a39,.5)};syncCombatVisuals()");assert(finite());assert(g.run("techniqueRigs.has('charge1')"));
});
check('Three-second fusion preserves chip damage, burst damage and caster immunity',()=>{
 reset();g.debug.setup({enemy:{pos:[0,.13,-6],hp:100}});g.run("createBlue(player,1,V(0,0,-1));blue.p.set(0,1.5,-6);anchorBlue();startBomb(1);syncCombatVisuals()");
 assert(g.run("techniqueRigs.get('fusion'+bomb.id).satellites.length===2"));const hp=g.state().enemy.hp;g.advance(1);assert(g.state().bomb);assert(g.state().enemy.hp<hp);assert(finite());
 g.advance(1.9);assert(g.state().bomb,'Must not burst early');g.advance(.15);assert.equal(g.state().bomb,null);assert.equal(g.state().player.hp,1000);assert(g.state().enemy.hp<35);assert(g.run("effects.some(e=>e.m.name==='impact-hollow')"));assert(finite());
});
check('Furnace is an oriented flame arrow and strikes breakable scenery',()=>{
 reset('sukuna');g.run("player.pos.set(0,.13,8);const wall=pieces.find(p=>p.platform);wall.m.position.set(0,1.5,2);wall.pos.copy(wall.m.position);wall.m.scale.set(3,3,.5);wall.size.copy(wall.m.scale);wall.alive=true;scene.updateMatrixWorld(true);executeTechnique(player,3,1,V(0,0,-1));updateProjectiles(.01);syncCombatVisuals()");
 assert(g.run("Array.from(techniqueRigs.values()).some(r=>r.kind==='furnace'&&!r.bow.visible)"));assert(g.run('projectiles[0].o.shell.visible===false'));g.advance(.2);
 assert.equal(g.run("projectiles.filter(p=>p.type==='fire').length"),0);assert(g.run("techniques.some(t=>t.type==='burn')"));assert(g.run("effects.some(e=>e.m.name==='impact-furnace')"));assert(finite());
});
check('Guest renders the same projectile orientation and reuses its scene object',()=>{
 reset('sukuna');g.run("executeTechnique(player,3,.6,V(.3,.1,-1).normalize());updateProjectiles(.02);syncCombatVisuals()");const guest=createGame();setupReplica(g,guest);
 const packet=()=>JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));guest.ctx.packet=packet();guest.run('receiveState(packet);updateReplica(.016);syncCombatVisuals()');
 const rig=guest.run("Array.from(techniqueRigs.values()).find(r=>r.kind==='furnace')");assert(rig);const id=g.run('projectiles[0].id');assert(guest.run('replicas.has("projectile"+'+id+')'));
 g.run('updateProjectiles(.02)');guest.ctx.packet=packet();guest.run('receiveState(packet);updateReplica(.016);syncCombatVisuals()');assert.equal(guest.run('techniqueRigs.get("shot"+'+id+')'),rig);
 const expected=g.run('projectiles[0].dir.toArray()'),actual=guest.run('V(0,0,1).applyQuaternion(techniqueRigs.get("shot"+'+id+').g.quaternion).toArray()');actual.forEach((n,i)=>assert(Math.abs(n-expected[i])<.002));
});
check('Impact events are replicated once per event without changing guest health',()=>{
 reset();const hp=g.state().player.hp;g.run("replayEvent(['vfx',['hollow',[0,3,0],25,.8,[0,0,-1]]],i=>i===1?player:enemy)");assert(g.run("effects.some(e=>e.m.name==='impact-hollow')"));assert.equal(g.state().player.hp,hp);
 const n=g.run('effects.length');g.run("replayEvent(['vfx',['unknown',[0,3,0],25,.8,[0,0,-1]]],i=>player)");assert.equal(g.run('effects.length'),n);
});
check('All impact effects expire and release their geometry',()=>{
 reset();g.run("for(const k of ['hollow','blueRelease','red','redBeam','redMuzzle','purpleRelease','purpleImpact','airStep','launchImpact','furnace','cleave','teleport'])playCombatFX(k,V(0,3,0),9,.7)");assert(finite());g.run('for(let i=0;i<180;i++)updateEffects(1/60)');assert.equal(g.run("effects.filter(e=>e.type==='technique').length"),0);
});
check('Reset removes persistent technique rigs, including canceled charges',()=>{
 reset('sukuna');g.down('Digit3');g.advance(.9);assert(g.run('techniqueRigs.size')>0);g.debug.start('practice');assert.equal(g.run('techniqueRigs.size'),0);assert.equal(g.run("sound.cues.size"),0);
});
check('Shrine activation and clash victory use fresh cues; repeated frames do not restart',()=>{
 reset('sukuna');g.run('activateDomain(player);syncBattleAudio()');const first=g.run("sound.cues.get('shrine')");assert.equal(first.clip,'sukunaDomain');g.run('syncBattleAudio()');assert.equal(g.run("sound.cues.get('shrine')"),first);
 g.run('domain=null;beginClash();syncBattleAudio()');assert.equal(g.run("sound.cues.has('shrine')"),false);assert(g.run('sound.activeClash'));
 g.run('clash.joinRemaining=0;clash.scores[player.id]=12;updateDomains(.01);syncBattleAudio()');const second=g.run("sound.cues.get('shrine')");assert(second);assert.notEqual(second.token,first.token);assert.equal(g.run('sound.activeClash'),false);
 g.run("phase='pause';syncBattleAudio()");assert.equal(g.run('sound.cues.size'),0);
});
check('New snapshot geometry fields reject malformed vectors before rendering',()=>{
 reset();g.run("executeTechnique(player,3,.7,V(0,0,-1))");const packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));packet.projectiles[0].dir=[null,0,1];g.ctx.badPacket=packet;assert.equal(g.run('validState(badPacket)'),false);
});
if(process.env.VFX_SHADER_EXPORT){
 reset();g.run("for(const kind of ['fusion','blue','red','purple','furnace','slash'])makeTechniqueRig(kind);for(const kind of ['hollow','blueRelease','red','redBeam','purpleRelease','purpleImpact','furnace'])playCombatFX(kind,V(),10,1);activateDomain(player)");
 const shaders=g.run("(()=>{const found=new Map();scene.traverse(o=>{const m=o.material;if(m?.isShaderMaterial&&m!==pm){const key=m.vertexShader+'\\u0000'+m.fragmentShader;found.set(key,{name:o.name||'technique-'+found.size,vertex:m.vertexShader,fragment:m.fragmentShader});}});return Array.from(found.values());})()");fs.writeFileSync(process.env.VFX_SHADER_EXPORT,JSON.stringify(shaders));
}
console.log(JSON.stringify({scope:'Technique presentation, collision, recording cues, replication and cleanup; simulation only.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
