import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[],near=(a,b,t=.015)=>assert(Math.abs(a-b)<t,`${a} != ${b}`);
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(){const g=createGame();g.run('selectedCharacter="naruto";matchSetup.bots=["gojo"];resetMatch("duel");player.pos.set(0,.13,20);enemy.pos.set(0,.13,12);enemy.stun=999;player.energy=100;player.ult=100;yaw=0;pitch=0;');return g;}
function cast(g,k){g.ctx.testKind=k;if(k===5)g.run('startCharge(5)');else{g.run('startCharge(testKind)');g.advance(g.run('NARUTO.moves[testKind].charge'));g.run('releaseCharge(testKind)');}}
check('Naruto selects through the existing menu and owns articulated, independent parts',()=>{
 const g=game();assert.equal(g.run('KITS.naruto.names.length'),5);assert.equal(g.run('player.limbs.length'),2);assert.equal(g.run('player.limbs.every(l=>l.arm!==l.elbow&&l.elbow!==l.hand&&l.fingers.length===4)'),true);assert(g.run('player.narutoRig.parts["leaf-protector"]!==undefined'));assert(g.run('player.narutoRig.parts["whisker--1-0"]!==undefined'));assert.equal(g.elements.get('energyLabel').textContent,'CHAKRA');assert.equal(g.elements.get('abilityNameQ').textContent,'MINDSCAPE · KURAMA’S CAGE');assert(g.run('jumpFighter(player)'));g.run('player.airJumpCooldown=0');assert(g.run('jumpFighter(player)'));near(g.run('player.energy'),95);near(g.run('player.stamina'),100);
});
check('All five attacks reach their configured maximum through real charge, movement and damage updates',()=>{
 const expected=[0,120,160,180,220,520],cost=[0,14.5,15,19.5,36.9,45];
 for(let k=1;k<=5;k++){const g=game();cast(g,k);g.advance(5);near(1000-g.run('enemy.hp'),expected[k]);near(g.run('player.energy'),100-cost[k]);assert.equal(g.run('techniques.length'),0);assert.equal(g.run('projectiles.length'),0);assert.equal(g.run('player.narutoAction'),null);assert.equal(g.run('domain'),null);}
});
check('A tap waits for anticipation; holding full charge auto-releases after three seconds',()=>{
 const g=game();g.run('startCharge(3);releaseCharge(3);updateHeldCharge(player,.44)');assert.equal(g.run('player.narutoAction'),null);near(g.run('enemy.hp'),1000);g.run('updateHeldCharge(player,.011)');assert.equal(g.run('player.narutoAction.kind'),3);near(g.run('player.narutoAction.q'),0);
 const h=game();h.run('startCharge(4);updateHeldCharge(player,1.3);updateHeldCharge(player,2.99)');assert(h.run('!!chargeFor(player)'));h.run('updateHeldCharge(player,.011)');assert.equal(h.run('chargeFor(player)'),null);assert.equal(h.run('player.narutoAction.kind'),4);near(h.run('player.energy'),63.1);
});
check('Insufficient chakra rejects casts, and shared cooldown/recovery prevents overlapping actions',()=>{
 const g=game();g.run('player.energy=7.9;startCharge(1)');assert.equal(g.run('chargeFor(player)'),null);near(g.run('player.energy'),7.9);g.run('player.energy=100;executeTechnique(player,2,1,V(0,0,-1));startCharge(3);lightAttack(player);dodge(player)');assert.equal(g.run('chargeFor(player)'),null);assert.equal(g.run('pendingHits.length'),0);near(g.run('player.dodge'),0);g.advance(2);g.run('player.cooldown=.3;startCharge(3)');assert.equal(g.run('chargeFor(player)'),null);g.advance(.31);g.run('startCharge(3)');assert(g.run('!!chargeFor(player,3)'));
});
check('A damaging hit interrupts charge, clones and ultimate before their release',()=>{
 for(const k of [1,3,5]){const g=game();if(k===3)g.run('startCharge(3)');else cast(g,k);g.advance(.08);g.run('hurt(player,1,enemy,"special");');g.advance(3);near(g.run('enemy.hp'),1000);assert.equal(g.run('player.narutoAction'),null);assert.equal(g.run('chargeFor(player)'),null);assert.equal(g.run('narutoVisuals.clones.filter(c=>c.active).length'),0);}
});
check('Move 5 uses chakra and 30 meter while Mindscape uses the existing full meter and emergency rule',()=>{
 const g=game();g.run('startCharge(5)');near(g.run('player.ult'),70);near(g.run('player.energy'),55);assert.equal(g.run('castFor(player)'),null);g.run('interruptNaruto(player);player.hp=4;player.ult=0;castDomain(player)');assert(g.run('player.emergency'));assert(g.run('!!castFor(player)'));g.run('setCast(player,null);castDomain(player)');assert.equal(g.run('castFor(player)'),null);
});
check('Specials penetrate guard while dodges can avoid Rasengan without duplicate impact damage',()=>{
 const g=game();g.run('enemy.block=true;enemy.blockTime=1;executeTechnique(player,3,1,V(0,0,-1));for(let i=0;i<70;i++)updateTechniques(1/60)');near(g.run('enemy.hp'),820);
 const h=game();h.run('enemy.dodge=1;enemy.dodgeWindow=0;executeTechnique(player,3,1,V(0,0,-1));for(let i=0;i<70;i++)updateTechniques(1/60)');near(h.run('enemy.hp'),1000);
});
check('Uzumaki uppercut rises, axe kick descends, and landing emits ground cracks',()=>{
 const g=game();cast(g,2);g.advance(.83);assert(g.run('enemy.pos.y')>.4);g.advance(.55);assert(g.run('narutoVisuals.fx.some(e=>e.kind==="ground")'));g.advance(1);near(g.run('enemy.pos.y'),.12);near(g.run('enemy.hp'),840);
});
check('Naruto impact freezes simulation briefly and then releases it',()=>{
 const g=game();g.run('narutoImpact(player,enemy,1,V(0,0,-1),1,1,3);globalThis.before=enemy.pos.clone();globalThis.frozenAt=matchTime');g.advance(2/60);near(g.run('enemy.pos.distanceTo(before)'),0);g.advance(.1);assert(g.run('enemy.pos.distanceTo(before)')>0);near(g.run('narutoFreeze'),0);
});
check('Clones cannot extend their hitbox beyond their travel range',()=>{
 const g=game();g.run('enemy.pos.set(0,.13,-30);executeTechnique(player,1,1,V(0,0,-1))');g.advance(2);near(g.run('enemy.hp'),1000);
});
check('Sealed barriers stop Naruto projectiles, melee travel and damage across the boundary',()=>{
 for(const k of [1,2,3,4,5]){const g=game();g.run('enemy.pos.set(0,.13,0);player.pos.set(0,.13,80);activateDomain(enemy);player.ult=100;');g.ctx.testKind=k;g.run('if(testKind===5)startCharge(5);else executeTechnique(player,testKind,1,V(0,0,-1));');g.advance(5);near(g.run('enemy.hp'),1000);assert(g.run('player.pos.z')>=54);}
});
check('Rasenshuriken damages every nearby opponent once per zone tick',()=>{
 const g=game();g.run('matchSetup.bots=["gojo","sukuna"];resetMatch("duel");player.pos.set(0,.13,20);enemy.pos.set(0,.13,12);bodies[2].pos.set(1,.13,12);for(const f of bodies)if(f!==player)f.stun=999;narutoLaunch(player,4,1,V(0,0,-1));');g.advance(4);near(g.run('enemy.hp'),780);near(g.run('bodies[2].hp'),780);
});
check('Released projectiles survive caster hit interruption and collide with scenery',()=>{
 const g=game();g.run('narutoLaunch(player,4,1,V(0,0,-1));hurt(player,1,enemy,"special")');g.advance(4);near(g.run('enemy.hp'),780);
 const h=game();h.run('const b=buildings.find(b=>b.x===22&&b.z===22);player.pos.set(b.x-b.w/2-5,.13,b.z);enemy.pos.set(b.x+b.w/2+4,.13,b.z);narutoLaunch(player,4,1,V(1,0,0));');h.advance(.2);assert.equal(h.run('projectiles.length'),0);assert(h.run('techniques.some(a=>a.type==="naruto-wind")'));near(h.run('enemy.hp'),1000);
});
check('Guest snapshots reconstruct duplicate Narutos, clones, shots, wind zones and animation age',()=>{
 const host=game();host.run('net.role="host";net.localId="p0";net.roster=[{id:"p0",character:"naruto",bot:false},{id:"p1",character:"naruto",bot:false},{id:"b0",character:"gojo",bot:true,difficulty:"easy"}];beginOnline("naruto");countdown=0;player.pos.set(0,.13,20);enemy.pos.set(0,.13,12);for(const f of bodies)if(f!==player)f.stun=999;executeTechnique(player,1,1,V(0,0,-1));updateTechniques(.15);');
 const guest=createGame();setupReplica(host,guest);
 function sync(){guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);updateReplica(.016);updateNarutoVisuals(.016)');}
 sync();assert.equal(guest.run('enemy.character'),'naruto');near(guest.run('enemy.narutoAction.t'),.15);assert(guest.run('narutoVisuals.clones.some(c=>c.active)'));assert.equal(guest.run('enemy.root===player.root'),false);
 host.run('interruptNaruto(player);updateTechniques(.01);narutoLaunch(player,4,1,V(0,0,-1));');sync();assert(guest.run('narutoVisuals.shots.some(r=>r.g.visible&&r.kind===4)'));host.advance(.3);sync();assert(guest.run('narutoVisuals.zones.some(r=>r.g.visible)'));
 guest.ctx.packet.naruto[0].owner='fake';assert(!guest.run('validState(packet)'));
 host.run('player.energy=100;player.ult=100;player.cooldown=0;player.stun=0;startCharge(5)');sync();assert.equal(guest.run('cinematic?.type'),'naruto');host.run('hurt(player,1,enemy,"special");updateTechniques(.01)');sync();assert(guest.run('cinematic.t>=cinematic.duration-.65'));guest.advance(.7);assert.equal(guest.run('cinematic'),null);
});
check('A remote human Naruto uses the existing input edges and cannot forge damage',()=>{
 const g=game();g.run('net.role="host";net.localId="p0";net.roster=[{id:"p0",character:"naruto",bot:false},{id:"p1",character:"naruto",bot:false}];beginOnline("naruto");countdown=0;enemy.stun=0;enemy.input.lastAt=performance.now();enemy.energy=100;receiveInput({held:["special3"],edges:[["special3",true]],yaw:Math.PI,pitch:0,move:[0,0],hp:1},"p1")');assert(g.run('!!chargeFor(enemy,3)'));near(g.run('player.hp'),1000);g.run('updateHeldCharge(enemy,.75);receiveInput({held:[],edges:[["special3",false]],yaw:Math.PI,pitch:0,move:[0,0]},"p1")');assert.equal(g.run('enemy.narutoAction.kind'),3);near(g.run('enemy.energy'),80.5);
});
check('Domain overlays remain removed for single and three-way casts',()=>{
 const g=createGame();g.run('matchSetup.bots=["sukuna","gojo"];resetMatch("practice");for(const f of bodies){f.pos.set(0,.13,0);f.ult=100;}castDomain(player);castDomain(enemy);castDomain(bodies[2]);');assert.equal(g.run('clash.participants.length'),3);assert.equal(g.run('cutoutState'),null);assert.equal(g.elements.get('domainCutouts').children.length,0);assert(g.elements.get('domainCutouts').classList.contains('hidden'));
});
check('Pose matrices stay finite, joints blend, and clone/particle pools remain bounded after reuse',()=>{
 const g=game();const nodes=g.run('scene.children.length'),pool=g.run('narutoVisuals.clones.length');for(let k=1;k<=5;k++){g.ctx.testKind=k;g.run('player.energy=100;player.ult=100;player.cooldown=0;player.stun=0;player.hp=1000;enemy.hp=1000;enemy.stun=999;player.pos.set(0,.13,20);enemy.pos.set(0,.13,12);if(testKind===5)startCharge(5);else executeTechnique(player,testKind,1,V(0,0,-1));');g.advance(4.5);assert(g.run('player.limbs.every(l=>l.hand.matrixWorld.elements.every(Number.isFinite))'));assert(g.run('player.body.scale.toArray().every(v=>Number.isFinite(v)&&v>0)'));}
 near(g.run('narutoVisuals.clones.length'),pool);near(g.run('narutoVisuals.particles.life.length'),900);assert(g.run('narutoVisuals.cloneBatches.length')<30);g.run('resetMatch("practice")');assert.equal(g.run('narutoVisuals.clones.filter(c=>c.active).length'),0);assert.equal(g.run('player.narutoAction'),null);assert(g.run('scene.children.length')<nodes+20);
});
check('A winning ultimate settles its pose and camera without post-match damage or stuck effects',()=>{
 const g=game();g.run('enemy.hp=1;startCharge(5)');g.advance(2.9);assert.equal(g.run('phase'),'finish');g.advance(.75);assert.equal(g.run('player.narutoAction'),null);assert.equal(g.run('cinematic'),null);assert.equal(g.run('techniques.filter(a=>a.type.startsWith("naruto")).length'),0);assert.equal(g.run('projectiles.length'),0);assert.equal(g.elements.get('narutoCinema').style.opacity,'0');assert(g.run('Array.from(narutoVisuals.cloaks.values()).every(c=>!c.g.visible)'));
});
check('An obstruction exactly at the end of a projectile step still stops it',()=>{
 const g=game();g.run('globalThis.savedWall=narutoWallDistance;narutoWallDistance=(o,d,max)=>{narutoScratch.blocked=true;return max;};enemy.pos.set(50,.13,0);narutoLaunch(player,4,1,V(0,0,-1));updateProjectiles(1/60);narutoWallDistance=savedWall;');assert.equal(g.run('projectiles.length'),0);assert.equal(g.run('techniques.filter(a=>a.type==="naruto-wind").length'),1);
});
check('Six simultaneous Narutos reuse eighteen clones and cancellation never reaches guests',()=>{
 const g=game();g.run('matchSetup.bots=["naruto","naruto","naruto","naruto","naruto"];resetMatch("duel");for(let i=0;i<bodies.length;i++){const f=bodies[i];f.pos.set(i*4,.13,20);f.stun=0;executeTechnique(f,1,1,V(0,0,-1));}updateNarutoVisuals(.1);');assert.equal(g.run('bodies.length'),6);assert.equal(g.run('narutoVisuals.clones.filter(c=>c.active).length'),18);g.run('interruptNaruto(player)');assert.equal(g.run('packNaruto().some(a=>a.owner===player.id)'),false);
});
console.log(JSON.stringify({scope:'Build 17 Naruto mechanics, isolated Three.js scene, simulated inputs, and host/guest snapshots. No browser/device FPS claim.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
