import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(character='gojo'){const g=createGame();g.debug.select(character);g.reset('duel');g.run('for(const p of pieces){p.alive=false;p.m.visible=false;}player.pos.set(0,.12,0);player.vel.set(0,0,0);player.grounded=true;player.energy=100;player.stamina=100;enemy.pos.set(0,.12,-20);enemy.stun=999;yaw=pitch=0;');return g;}
check('All five selections show their own complete move list, stamina and saved key bindings',()=>{
 const g=createGame();for(const [c,count]of [['gojo',5],['sukuna',6],['naruto',6],['mahito',7],['spiderman',4]]){g.ctx.fighterChoice=c;g.run("selectCharacter(fighterChoice)");const list=g.elements.get('loadoutPreview');assert.equal(list.children.length,count);assert(list.children.every(e=>e.children[1].textContent?.length>0));assert.match(g.elements.get('fighterVitals').textContent,c==='sukuna'?/150 STAMINA/:/100 STAMINA/);}
 g.run('controls.bind("special1","KeyZ");syncControlCopy()');assert.match(g.elements.get('loadoutPreview').children[0].children[0].textContent,/Z/);
});
check('Feedback settings preserve existing settings and persist across reloads',()=>{
 const storage=new Map([['limitless.settings.v3',JSON.stringify({camDistance:12,quality:'performance',shakeStrength:2,hitMarkers:false})]]);const g=createGame({storage});assert(g.run('options.camDistance===12&&options.shakeStrength===1&&!options.hitMarkers&&options.damageNumbers'));
 const strength=g.elements.get('shakeStrength');strength.value='.35';strength.oninput({target:strength});const numbers=g.elements.get('showDamageNumbers');numbers.checked=false;numbers.onchange({target:numbers});const h=createGame({storage});assert(h.run('options.shakeStrength===.35&&!options.damageNumbers&&options.camDistance===12'));
});
check('Damage numbers merge quick hits, reuse a fixed pool, expire, and reset without timers',()=>{
 const g=game();const timers=g.timers.length;g.run('damageText(enemy,12);damageText(enemy,16);');assert.equal(g.run('presentation.numbers.filter(n=>n.age<1).length'),1);assert.equal(g.run('presentation.numbers.find(n=>n.age<1).total'),28);
 g.run('globalThis.nodes=presentation.numbers.map(n=>n.el);for(let i=0;i<160;i++){for(const n of presentation.numbers)n.age+=.13;damageText(enemy,10);}');assert(g.run('presentation.numbers.length===28&&presentation.numbers.every((n,i)=>n.el===nodes[i])'));assert.equal(g.elements.get('damageNumbers').children.length,28);assert.equal(g.timers.length,timers);
 g.run('updatePresentation(1)');assert(g.run('presentation.numbers.every(n=>n.el.style.display==="none")'));g.run('damageText(player,25);resetPresentation()');assert(g.run('presentation.numbers.every(n=>n.age===99)'));
});
check('Damage numbers stay in world space while the camera moves and hide behind the view',()=>{
 const g=game();g.run('camera.position.set(0,3,6);camera.lookAt(V(0,2,-20));camera.updateMatrixWorld(true);damageText(enemy,75);updatePresentation(.03);globalThis.number=presentation.numbers.find(n=>n.age<1);globalThis.x=number.el.style.left;camera.position.x=6;camera.lookAt(V(0,2,-20));camera.updateMatrixWorld(true);updatePresentation(.03)');assert(g.run('number.el.style.display==="block"&&number.el.style.left!==x'));g.run('camera.lookAt(V(0,3,50));camera.updateMatrixWorld(true);updatePresentation(.03)');assert.equal(g.run('number.el.style.display'),'none');
});
check('Hit, block and perfect dodge cues reflect actual combat outcomes without changing damage',()=>{
 const g=game();g.run('enemy.stun=0;enemy.pos.set(0,.12,-2);enemy.input.yaw=Math.PI;enemy.block=true;enemy.blockTime=1;globalThis.blocked=hurt(enemy,12,player,"light");');assert(g.run('!blocked&&enemy.hp===1000&&presentation.hit===0'));assert.equal(g.elements.get('combatCue').textContent,'BLOCKED');
 g.run('player.stun=0;enemy.block=false;time=1;globalThis.hit=hurt(enemy,140,player,"special");');assert(g.run('hit&&enemy.hp===860&&presentation.hit>0'));assert.equal(g.elements.get('hitConfirm').dataset.kind,'heavy');
 g.run('player.dodge=.3;player.dodgeWindow=.2;player.hp=800;hurt(player,20,enemy,"light");');assert(g.run('player.hp===815'));assert.equal(g.elements.get('combatCue').textContent,'PERFECT DODGE');
});
check('Feedback respects toggles and does not confirm unrelated hits in a free-for-all',()=>{
 const g=game();g.run('globalThis.third={id:"b2",character:"naruto"};combatCue(enemy,third,"hit",100)');assert(g.run('presentation.hit===0&&presentation.damage===0'));g.run('options.hitMarkers=false;combatCue(enemy,player,"hit",100);combatCue(player,enemy,"hit",100);options.damageNumbers=false;damageText(enemy,10);');assert(g.run('presentation.hit===0&&presentation.damage===0&&presentation.numbers===null'));
});
check('Health damage trails delay then settle; target swaps and healing never inherit stale damage',()=>{
 const g=game();g.run('updatePresentation(.01);player.hp=600;updatePresentation(.1);');assert(g.run('presentation.health.get("player").trail===1000'));assert.equal(g.elements.get('phealthTrack')['aria-valuenow'],'600');g.run('for(let i=0;i<150;i++)updatePresentation(1/60)');assert(g.run('presentation.health.get("player").trail<601'));g.run('player.hp=900;updatePresentation(.01)');assert(g.run('presentation.health.get("player").trail>=900'));
 g.run('globalThis.otherActor={id:"b4",hp:300};healthTrail("target",otherActor,$("ehealthTrail"),$("ehealthTrack"),.1)');assert(g.run('presentation.health.get("target").trail===300'));assert.equal(g.elements.get('ehealthTrack')['aria-valuenow'],'300');
});
check('Every FFA opponent has a distinct label, matching color, trail and eliminated state',()=>{
 const g=createGame();g.run('matchSetup.bots=["gojo","sukuna","naruto","mahito","spiderman"];resetMatch("duel");updateOpponentHealthBars();updatePresentation(.01);');assert.equal(g.elements.get('opponentHealthBars').children.length,5);assert(g.run('bodies.filter(f=>f!==player).every(f=>{const r=opponentHealthRows.get(f.id);return r.trail&&r.row.style["--fighter-color"]===fighterTone(f)&&r.track["aria-valuenow"]==="1000";})'));
 g.run('bodies[3].hp=0;updateOpponentHealthBars();updatePresentation(.1)');assert(g.run('opponentHealthRows.get(bodies[3].id).row.classList.contains("out")'));assert.equal(g.run('opponentHealthRows.get(bodies[3].id).value.textContent'),'OUT');
});
check('Ability feedback reads the existing cooldown, energy, meter and technique-seal rules',()=>{
 const g=game('naruto');g.run('player.energy=0;updateAbilityReadiness()');assert.equal(g.elements.get('abilityStatus3').textContent,'CHAKRA');g.run('player.energy=100;player.ult=20;updateAbilityReadiness()');assert.equal(g.elements.get('abilityStatus5').textContent,'METER');g.run('player.ult=100;player.cooldown=2.3;updateAbilityReadiness()');assert.equal(g.elements.get('abilityStatus3').textContent,'2.3s');assert.equal(g.elements.get('touchSpecial3').dataset.status,'2.3s');g.run('player.techniqueBurnout=8;updateAbilityReadiness()');assert.equal(g.elements.get('abilityStatus3').textContent,'BURNOUT');g.run('player.soulSlot=3;player.soulTime=2;updateAbilityReadiness()');assert.equal(g.elements.get('abilityStatus3').textContent,'SEALED');assert(g.run('player.energy===100&&player.ult===100&&player.cooldown===2.3'));
});
check('Spider air-chase followups and Mahito full-health healing show their actual availability',()=>{
 const g=game('spiderman');g.run('const s=spiderState(player);s.cd[1]=2;s.link=enemy;s.linkTime=2;enemy.pos.y=10;updateAbilityReadiness()');assert.equal(g.elements.get('abilityStatus1').textContent,'CHASE');g.run('player.energy=0;updateAbilityReadiness()');assert.equal(g.elements.get('abilityStatus1').textContent,'ENERGY');
 const h=game('mahito');h.run('updateAbilityReadiness()');assert.equal(h.elements.get('abilityStatus4').textContent,'FULL HP');h.run('player.ult=10;updateAbilityReadiness()');assert.equal(h.elements.get('abilityStatus6').textContent,'METER');
});
check('Match results use real statistics and do not rebuild or steal focus on repeated snapshots',()=>{
 const g=game();g.run('player.score=430;player.damageTaken=212;player.hp=788;enemy.score=212;winnerId=player.id;matchTime=85;presentResults();globalThis.row=$("resultRoster").children[0];$("resultMenuButton").focus();presentResults()');assert.equal(g.elements.get('resultBreakdown').children[2].children[1].textContent,'1:25');assert.match(g.elements.get('resultRoster').children[0].children[1].textContent,/WINNER · 430/);assert(g.run('$("resultRoster").children[0]===row&&document.activeElement===$("resultMenuButton")'));
});
check('Camera collision prevents the smoothed camera from lingering behind a thin wall',()=>{
 const g=game();g.run('globalThis.wall=piece(V(0,3,3),V(10,8,.15),0x555555,true);wall.solid=true;camPos.set(0,3,9);options.camDistance=10;options.shake=false;updateCamera(1/60)');assert(g.run('camera.position.z<2.8&&camera.position.z>0'));g.run('globalThis.ray=presentation.camera.ray;globalThis.hits=presentation.camera.hits;wall.alive=false;for(let i=0;i<60;i++)updateCamera(1/60)');assert(g.run('camera.position.z>9&&presentation.camera.ray===ray&&presentation.camera.hits===hits'));
});
check('Camera queries respect destroyed and domain-hidden scenery',()=>{
 const g=game();g.run('globalThis.wall=piece(V(0,3,3),V(10,8,.15),0x555555,true);wall.solid=true;globalThis.distance=cameraSurfaceDistance(V(0,2,0),V(0,0,1),10);wall.domainHidden=true;globalThis.hiddenDistance=cameraSurfaceDistance(V(0,2,0),V(0,0,1),10)');assert(g.run('distance<3&&hiddenDistance===10'));
});
check('Camera shake is continuous, respects strength, and never advances the gameplay random seed',()=>{
 const g=game();g.run('time=1;shake=1;options.shake=true;options.shakeStrength=1;globalThis.seedBefore=seed;camera.position.set(0,0,0);presentationShake();globalThis.offset=camera.position.clone();time+=1/120;camera.position.set(0,0,0);presentationShake();globalThis.nextOffset=camera.position.clone();options.shakeStrength=0;camera.position.set(0,0,0);presentationShake()');assert(g.run('seed===seedBefore&&offset.length()>.01&&offset.length()<.3&&offset.distanceTo(nextOffset)<.18&&camera.position.length()===0'));
});
check('Every character has finite, blended strafe and braking poses without moving its gameplay body',()=>{
 for(const c of ['gojo','sukuna','naruto','mahito','spiderman']){const g=game(c);g.run('for(let i=0;i<60;i++){player.pos.x+=.1;animateFighter(player,1/60);}globalThis.before=player.pos.clone();globalThis.state=rosterAnimationState(player);globalThis.strafe=state.motion.side;for(let i=0;i<16;i++)animateFighter(player,1/60);');assert(g.run('Math.abs(strafe)>.8&&state.motion.speed<2&&player.pos.distanceTo(before)===0&&Number.isFinite(player.body.rotation.x)&&Number.isFinite(player.legs[0].rotation.z)'),c);g.run('player.root.updateMatrixWorld(true);globalThis.finite=true;player.root.traverse(o=>{finite&&=o.matrixWorld.elements.every(Number.isFinite)})');assert(g.run('finite'),c);}
});
check('Locomotion polish leaves attack, airborne, wall and web poses to their existing animators',()=>{
 const g=game();for(const state of ['player.attack=.2','player.grounded=false','player.narutoMobility={kind:3}','player.character="spiderman";player.spider={action:{kind:4}}']){g.ctx.setup=state;g.run('player.character="gojo";player.attack=0;player.grounded=true;player.narutoMobility=null;player.spider=null;globalThis.pose=narutoPoseTemplate({lean:.3,ll:.8,rl:-.8});globalThis.copy=Array.from(pose);');g.run(state);g.run('polishLocomotion(player,pose,rosterAnimationState(player),1/60,true)');assert(g.run('pose.every((v,i)=>v===copy[i])'),state);}
});
check('Afterimage cleanup disposes its material but preserves borrowed character geometry',()=>{
 const g=game();g.run('afterImage(player,C.mint);globalThis.ghost=effects.at(-1);globalThis.geometry=ghost.m.children[0].geometry;globalThis.geometryDisposed=0;globalThis.materialDisposed=0;geometry.addEventListener("dispose",()=>geometryDisposed++);ghost.mat.addEventListener("dispose",()=>materialDisposed++);updateEffects(1)');assert(g.run('geometryDisposed===0&&materialDisposed===1&&!ghost.m.parent'));
 const h=game();h.run('afterImage(player,C.mint);globalThis.geometry=effects.at(-1).m.children[0].geometry;globalThis.disposed=0;geometry.addEventListener("dispose",()=>disposed++);resetMatch("duel")');assert.equal(h.run('disposed'),0);
});
check('Auto resolution waits for sustained slow frames, respects its floor and restores gradually',()=>{
 const g=game();g.run('options.quality="auto";setQuality();globalThis.baseRatio=presentation.auto.base;for(let i=0;i<90;i++)sampleAdaptiveQuality(1/30);globalThis.duringWarmup=presentation.auto.scale;for(let i=0;i<900;i++)sampleAdaptiveQuality(1/30);globalThis.low=renderer.getPixelRatio();for(let i=0;i<4000;i++)sampleAdaptiveQuality(1/60)');assert(g.run('duringWarmup===1&&Math.abs(low/baseRatio-.65)<.001&&presentation.auto.scale===1&&renderer.getPixelRatio()===baseRatio&&pm.uniforms.ratio.value===baseRatio'));
});
check('Manual quality, pause, background tabs and isolated stalls do not trigger adaptive resizing',()=>{
 const g=game();g.run('options.quality="quality";setQuality();globalThis.ratio=renderer.getPixelRatio();for(let i=0;i<600;i++)sampleAdaptiveQuality(.05);options.quality="auto";phase="pause";for(let i=0;i<600;i++)sampleAdaptiveQuality(.05);phase="play";document.hidden=true;for(let i=0;i<600;i++)sampleAdaptiveQuality(.05);document.hidden=false;for(let i=0;i<30;i++)sampleAdaptiveQuality(1);');assert(g.run('renderer.getPixelRatio()===ratio&&player.hp===1000&&player.energy===100'));
});
check('Moving shadow coverage follows outer-map fights while preserving each arena light direction',()=>{
 const g=game();for(const map of ['district','harbor','sanctuary','metro']){g.ctx.map=map;g.run('applyArenaMap(map);renderer.shadowMap.enabled=true;player.pos.set(180,42,-160);globalThis.original=sun.position.clone().normalize();updateArenaLighting();globalThis.current=sun.position.clone().sub(sun.target.position).normalize();');assert(g.run('current.distanceTo(original)<1e-7&&Math.abs(sun.target.position.x-player.pos.x)<.2&&Math.abs(sun.target.position.z-player.pos.z)<.2&&sun.shadow.camera.far>=360'));}
});
check('Host and guest hit confirmations belong to the correct player',()=>{
 const h=game();h.run('mode="online";net.role="host";enemy.stun=0;enemy.bot=false;netEvents.length=0;time=1;hurt(enemy,30,player,"special")');const g=createGame();setupReplica(h,g);g.ctx.packet=JSON.parse(h.run('JSON.stringify(onlineSnapshot())'));assert(g.run('validState(packet)'));g.run('receiveState(packet)');assert(g.run('presentation.hit===0&&presentation.damage>0'),'guest sees incoming hit, not an outgoing confirmation');
 h.run('netEvents.length=0;time=2;hurt(player,25,enemy,"special")');g.ctx.packet=JSON.parse(h.run('JSON.stringify(onlineSnapshot())'));g.run('receiveState(packet)');assert(g.run('presentation.hit>0'),'guest receives its own confirmed hit');
});
check('Malformed feedback events are ignored and valid perfect-dodge events stay local',()=>{
 const g=game();g.run('replayEvent(["hit",["missing",20,player.id]],actorById);replayEvent(["hit",[enemy.id,NaN,player.id]],actorById);replayEvent(["evade",["missing",player.id]],actorById);');assert(g.run('presentation.hit===0&&presentation.numbers===null'));g.run('replayEvent(["evade",[player.id,enemy.id]],actorById)');assert.equal(g.elements.get('combatCue').textContent,'PERFECT DODGE');assert(g.run('presentation.numbers.some(n=>n.heal&&n.total===15)'));
});
check('Full-frame six-fighter matches retain finite state across all maps and character rigs',()=>{
 const g=createGame();for(const map of ['district','harbor','sanctuary','metro']){g.ctx.map=map;g.run('selectedMap=map;matchSetup.bots=["gojo","sukuna","naruto","mahito","spiderman"];resetMatch("duel");');g.advance(1);assert(g.run('bodies.length===6&&bodies.every(f=>f.pos.toArray().every(Number.isFinite)&&f.root.matrixWorld.elements.every(Number.isFinite))'));assert.equal(g.elements.get('opponentHealthBars').children.length,5);}
});
console.log(JSON.stringify({scope:'Build 39: real Three.js geometry and scene-state simulation, synthetic input and host/guest snapshots. No browser/GPU/device QA.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
