import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[],near=(a,b)=>assert(Math.abs(a-b)<.01,`${a} != ${b}`);
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(character='gojo'){const g=createGame();g.ctx.character=character;g.run(`selectedCharacter=character;selectedMap='harbor';resetMatch('duel');for(const p of pieces)p.alive=p.m.visible=false;player.pos.set(0,.13,0);enemy.pos.set(0,.13,-30);enemy.stun=999;player.energy=player.ult=100;yaw=pitch=0;globalThis.poseStep=dt=>{time+=dt;animateFighter(player,dt);animateMahitoDetail(player,dt);player.root.updateMatrixWorld(true);};for(let i=0;i<60;i++)poseStep(1/60);`);return g;}
function pose(g,combo=0,p=.9){g.ctx.combo=combo;g.ctx.p=p;g.run('player.grounded=false;player.pos.y=5;pitch=p;player.comboHits=combo;player.comboTimer=.85;player.attack=player.stun=player.recovery=0;lightAttack(player);for(let i=0;i<=15;i++){player.attack=player.attackMax-i/120;poseStep(1/120);}');}
check('All movement directions retain the four ground hits, costs and startup',()=>{
 for(const character of ['gojo','sukuna','naruto','mahito']){const g=game(character);for(const held of [[],['KeyW'],['KeyA'],['KeyS'],['KeyD'],['KeyW','KeyD','ShiftLeft']])for(let i=0;i<4;i++){g.ctx.held=held;g.ctx.i=i;g.run('keys.clear();held.forEach(k=>keys.add(k));player.grounded=true;player.attack=player.stun=player.recovery=0;player.comboHits=i;player.comboTimer=.85;player.stamina=100;lightAttack(player)');assert(g.run('player.attackKind===0&&!player.attackAir&&player.combo===i'));near(g.run('player.attackMax'),.34);near(g.run('pendingHits.at(-1).t'),.12);near(g.run('player.stamina'),97);}}
});
check('Analog and remote movement retain the ground combo; counters retain fast timing',()=>{
 const g=game();g.run('controls.set("forward",true,"stick");player.counterWindow=.3;lightAttack(player)');assert(g.run('keys.has("KeyW")&&player.attackKind===0&&player.attackCounter'));near(g.run('pendingHits.at(-1).t'),.09);g.run('enemy.stun=0;enemy.grounded=true;enemy.input.keys.add("KeyW");enemy.comboHits=2;enemy.comboTimer=.8;lightAttack(enemy)');assert(g.run('enemy.attackKind===0&&enemy.combo===2'));
});
check('Air style follows aim at startup and stays fixed during the swing',()=>{
 for(const c of ['gojo','sukuna','naruto','mahito']){const g=game(c);for(const [p,kind] of [[.8,3],[-.8,2],[0,0]]){g.ctx.p=p;g.run('keys.add("KeyW");player.grounded=false;player.pos.y=5;player.attack=0;pitch=p;lightAttack(player)');assert.equal(g.run('player.attackKind'),kind);assert(g.run('player.attackAir'));g.run('pitch=-pitch;poseStep(.02)');assert.equal(g.run('player.attackKind'),kind);near(g.run('player.attackMax'),.34);}}
});
check('Actual air contact poses use downward legs, rising fists and tucked level legs',()=>{
 for(const c of ['gojo','sukuna','naruto','mahito']){const d=game(c);pose(d);assert(d.run('player.knees[0].rotation.x<.12&&player.knees[1].rotation.x>1.4&&player.body.rotation.x>.3'));assert(d.run('(player.blockRig||player.mahitoRig).feet[0].getWorldPosition(V()).y<(player.blockRig||player.mahitoRig).feet[1].getWorldPosition(V()).y-.35'));const s=game(c);pose(s,3,1.1);assert(s.run('player.knees.every(k=>k.rotation.x<.1)&&player.body.scale.y>1.04'));const u=game(c);pose(u,0,-.9);assert(u.run('player.limbs[0].arm.rotation.x< -2.6&&player.limbs[0].hand.getWorldPosition(V()).y>player.headGroup.getWorldPosition(V()).y'));const l=game(c);pose(l,0,0);assert(l.run('player.knees[0].rotation.x>1.2&&player.knees[1].rotation.x>.6&&Math.abs(player.limbs[0].elbow.rotation.x)<.12'));}
});
check('Aerial kicks extend the correct foot and tuck the opposite leg',()=>{
 for(const combo of [2,3]){const g=game('naruto');pose(g,combo,0);g.ctx.k=combo-2;assert(g.run('Math.abs(player.legs[k].rotation.z)>1.3&&player.knees[k].rotation.x<.15&&player.knees[1-k].rotation.x>1.3'));}
});
check('Real air hits reach above/below, keep damage and direct finishing knockback correctly',()=>{
 for(const c of ['gojo','sukuna','naruto','mahito'])for(const down of [true,false]){const g=game(c);g.ctx.down=down;g.run('player.grounded=false;player.pos.set(0,5,0);pitch=down?1.3:-1.3;enemy.pos.copy(player.pos).addScaledVector(aimFor(player),2.5);player.comboHits=3;player.comboTimer=.8;lightAttack(player);resolveLight(pendingHits.shift())');near(g.run('enemy.hp'),c==='sukuna'?977:973);assert(g.run(down?'enemy.vel.y< -9':'enemy.vel.y>9'));assert.equal(g.run('player.comboHits'),0);}
 const g=game();g.run('player.pos.y=5;player.grounded=false;pitch=1.3;enemy.pos.copy(player.pos).add(V(0,-9,0));lightAttack(player);resolveLight(pendingHits.shift())');near(g.run('enemy.hp'),1000);assert.equal(g.run('player.comboHits'),0);
});
check('Landing blends air poses, reactions override them, and pose changes never move physics',()=>{
 for(const hz of [30,60,120]){const g=game('naruto');pose(g);g.ctx.hz=hz;g.run('globalThis.pos=player.pos.clone();globalThis.vel=player.vel.clone();player.grounded=true;for(let i=0;i<hz/5;i++){player.attack=Math.max(0,player.attack-1/hz);poseStep(1/hz)}');assert(g.run('player.pos.equals(pos)&&player.vel.equals(vel)&&player.root.matrixWorld.elements.every(Number.isFinite)&&player.knees[0].rotation.x<.9'));g.run('player.hitReact=.2;poseStep(1/60)');assert(!g.run('player.rosterAnim.comboMotion.render'));}
});
check('Guests receive the air style and animate it without client-side damage',()=>{
 const h=game('sukuna');h.run('net.role="host";net.localId="p0";net.roster=[{id:"p0",character:"sukuna",bot:false},{id:"p1",character:"naruto",bot:false}];beginOnline("sukuna","harbor");countdown=0;player.grounded=false;player.pos.y=5;pitch=1.2;lightAttack(player)');const g=createGame();setupReplica(h,g);g.ctx.packet=JSON.parse(h.run('JSON.stringify(onlineSnapshot())'));assert(g.run('validState(packet)'));g.run('receiveState(packet);globalThis.f=actorById("p0");globalThis.hp=f.hp;for(let i=0;i<16;i++){narutoReplicaAge=i/120;animateFighter(f,1/120)}');assert(g.run('f.attackAir&&f.attackKind===3&&f.knees[0].rotation.x<.12&&f.hp===hp&&pendingHits.length===0'));
});
console.log(JSON.stringify({scope:'Three.js geometry, combat simulation and in-memory networking. No browser/FPS claim.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
