import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(error){results.push({name,pass:false,error:error.stack});}}
function arena(character='gojo',map='district'){
 const g=createGame();g.debug.select(character);g.ctx.testMap=map;g.run('selectedMap=testMap');g.reset('practice');
 g.debug.setup({player:{pos:[0,20,0],hp:1000},enemy:{pos:[140,20,0],stun:999},yaw:0,pitch:0});return g;
}
check('Blue reaches the opposite side of the caster after firing straight ahead, at every charge level and frame rate',()=>{
 for(const fps of [30,60,144])for(const q of [0,1]){
  const g=arena();g.ctx.fps=fps;g.ctx.q=q;g.run(`createBlue(player,q,V(0,0,-1));for(let i=0;i<fps*2;i++)updateBlue(1/fps,blue);
   globalThis.front=blue.p.clone();yaw=Math.PI;for(let i=0;i<fps*2.5;i++)updateBlue(1/fps,blue);`);
  assert(g.run('front.z<-blue.range*.95'),'Blue first reaches the front of the caster');
  assert(g.run("blue.phase==='sweep'&&blue.p.z>blue.range*.95&&Math.abs(blue.p.x)<.1"),'a real 180-degree position change must finish before control expires');
  assert(g.run('blue.p.toArray().every(Number.isFinite)'));
 }
});
check('Blue can sweep a full circle, lift, track caster movement and settle without drifting beyond reach',()=>{
 const g=arena();g.run(`createBlue(player,1,V(0,0,-1));for(let i=0;i<120;i++)updateBlue(1/60,blue);
  globalThis.visited=[];for(let turn=1;turn<=4;turn++){yaw=turn*Math.PI/2;for(let i=0;i<60;i++)updateBlue(1/60,blue);visited.push(blue.p.clone().sub(headPos(player)).normalize().dot(aimFor(player)));}
  player.pos.x+=8;pitch=-.45;for(let i=0;i<60;i++)updateBlue(1/60,blue);`);
 assert(g.run('visited.every(dot=>dot>.95)'),'all four quadrants should be reachable');
 assert(g.run("blue.phase==='sweep'&&blue.p.y>30&&blue.p.distanceTo(headPos(player))<blue.range+.5"));
 g.run('startCharge(1,player)');assert(g.run("blue.phase==='hold'"));g.run('updateBlue(3.01,blue)');assert(g.run('!blue'));
});
check('Blue keeps its barrier collision and guests receive the longer guided phase',()=>{
 const host=arena();host.run('enemy.pos.set(0,20,10);activateDomain(player);createBlue(player,1,V(0,0,-1));for(let i=0;i<300;i++)updateBlue(1/60,blue)');
 const guest=createGame();setupReplica(host,guest);guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);updateReplica(1/60)');
 assert(guest.run("replicaState.blues[0].phase==='sweep'&&replicaState.blues[0].sweep>3"));
 host.run('player.pos.z=-40;blue.p.copy(enclosureCenter()).add(V(0,0,-53.7));blue.dir.set(0,0,-1);blue.phase="travel";blue.travelled=0;updateBlue(.05,blue)');
 assert(host.run("blue.phase==='hold'&&blue.p.distanceTo(enclosureCenter())<DOMAIN_ENCLOSURE.radius"));
});
check('Every domain clears intersecting buildings and map decorations on all four maps, and restores them on exit',()=>{
 const g=arena();
 for(const map of ['district','harbor','sanctuary','metro'])for(const character of ['gojo','sukuna','naruto','mahito']){
  g.ctx.testMap=map;g.run('selectedMap=testMap');g.debug.select(character);g.reset('practice');
  g.run(`globalThis.near=pieces.find(p=>p.solid);player.pos.copy(near.pos);enemy.pos.copy(player.pos).add(V(0,0,4));
   globalThis.aliveBefore=pieces.map(p=>p.alive?'1':'0').join('');activateDomain(player);`);
  assert(g.run('near.domainHidden&&!near.m.visible&&!arenaPieceActive(near)'),map+' '+character);
  assert(g.run('pieces.filter(p=>domainTouchesPiece(p,domain)).every(p=>!p.m.visible)'));
  assert(g.run('domainTerrain.roots.every(item=>!item.object.visible)'));
  assert(g.run('pieces.map(p=>p.alive?"1":"0").join("")===aliveBefore'),'displacement must not destroy the map');
  g.run('endActiveDomain(domain)');assert(g.run('near.m.visible&&arenaPieceActive(near)&&domainTerrain.roots.length===0'));
 }
});
check('Airborne domains displace complete skyscrapers without invisible walls, platforms or projectile blockers',()=>{
 const g=arena('gojo','metro');g.run(`globalThis.building=buildings.find(b=>b.floors>=15);globalThis.part=building.parts.find(p=>p.level===12&&p.solid);
  player.pos.copy(part.pos);enemy.pos.copy(part.pos).add(V(0,0,4));globalThis.wall=narutoMobility(enemy);wall.kind=3;wall.wallIndex=pieces.indexOf(part);wall.wallVelocity.set(0,3,20);activateDomain(player);globalThis.before=player.pos.clone();resolveDistrictCollision(player,before);`);
 assert(g.run('building.parts.every(p=>p.domainHidden&&!p.m.visible)'),'lower floors and roof attachments of an intersecting tower should disappear too');
 assert(g.run('player.pos.distanceTo(before)<1e-8&&groundHeight(player.pos,100)===.12'));
 assert(g.run('wall.kind===0&&wall.wallExit>0&&wall.wallCarry.z===20'),'a displaced wall should smoothly release its runner');
 assert(g.run('narutoWallDistance(player.pos,V(1,0,0),10)===10'),'removed walls must not stop a technique');
 assert(g.run('!narutoWallCandidate(player,V(1,0,0))'),'removed walls must not allow wall-running');
 assert(g.run('pieces.some(p=>p.solid&&!p.domainHidden&&p.m.visible)'),'distant buildings remain in the arena');
});
check('Clashes, winner transitions and arena reconstruction preserve displacement and prior destruction',()=>{
 const g=arena('gojo','metro');g.run(`player.pos.set(0,20,-65);enemy.pos.set(0,20,-60);globalThis.broken=pieces.find(p=>p.solid&&p.pos.z<-90);breakPiece(broken);
  beginClash();globalThis.hidden=pieces.find(p=>p.alive&&p.solid&&p.domainHidden);globalThis.mask=pieces.map(p=>p.domainHidden?'1':'0').join('');`);
 assert(g.run('hidden&&!hidden.m.visible&&clash'));
 g.run('activateDomain(player)');assert(g.run('pieces.map(p=>p.domainHidden?"1":"0").join("")===mask&&!hidden.m.visible'));
 g.run('endActiveDomain(domain)');assert(g.run('hidden.m.visible&&!broken.alive&&!broken.m.visible'));
 g.run('activateDomain(player);restoreArena()');assert(g.run('broken.alive&&hidden.domainHidden&&!hidden.m.visible'));
 g.reset('practice');assert(g.run('pieces.every(p=>!p.domainHidden&&p.m.visible)'));
});
check('Repeated private-room snapshots never resurrect displaced scenery; outside viewers retain their map',()=>{
 const host=arena('sukuna','metro');host.run('player.pos.set(0,20,-65);enemy.pos.set(130,1,80);activateDomain(player)');
 const guest=createGame();setupReplica(host,guest);
 for(let i=0;i<3;i++){guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);updateReplica(1/60)');}
 assert(guest.run('!insideEnclosure(player)&&domainTerrain.roots.length===0'));
 assert(guest.run('pieces.some(p=>p.domainHidden)&&pieces.filter(p=>p.domainHidden).every(p=>!p.m.visible)'));
 assert(guest.run('pieces.some(p=>!p.domainHidden&&p.m.visible)'));
 host.run('endActiveDomain(domain)');guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));guest.run('receiveState(packet);updateReplica(1/60)');
 assert(guest.run('pieces.every(p=>!p.domainHidden&&p.m.visible===p.alive)'));
});
console.log(JSON.stringify({scope:'Build 34 simulation and scene-state checks; no browser rendering.',results},null,2));
if(results.some(result=>!result.pass))process.exitCode=1;
