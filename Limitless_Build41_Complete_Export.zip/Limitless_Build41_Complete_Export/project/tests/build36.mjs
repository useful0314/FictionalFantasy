import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(error){results.push({name,pass:false,error:error.stack});}}
function game(){const g=createGame();g.debug.select('spiderman');g.reset('practice');g.run('for(const p of pieces){p.domainHidden=true;p.m.visible=false;}player.pos.set(0,.13,0);player.vel.set(0,0,0);player.grounded=true;enemy.pos.set(70,.13,0);enemy.stun=999;yaw=pitch=0;');return g;}
function wall(g){g.run('globalThis.wall=piece(V(0,30,-42),V(36,60,4),0x668899,true);wall.solid=true;camera.position.set(3,5,8);camera.lookAt(V(4,28,-40));');}
check('Expanded city has 32 high rises, 72 total buildings, reachable 96m roofs and safe bounds',()=>{
 const g=game();g.run('applyArenaMap("metro")');
 assert(g.run('WORLD.radius===260&&WORLD.ceiling===124&&camera.far===800'));
 assert(g.run('buildings.length===72&&buildings.filter(b=>b.kind==="tower").length===32&&Math.max(...buildings.map(b=>b.floors*4))===96'));
 assert(g.run('buildings.every(b=>Math.hypot(Math.abs(b.x)+b.w/2,Math.abs(b.z)+b.d/2)<WORLD.radius-1)'));
 assert(g.run('buildings.every((b,i)=>buildings.slice(i+1).every(c=>Math.abs(b.x-c.x)>=(b.w+c.w)/2||Math.abs(b.z-c.z)>=(b.d+c.d)/2))'),'no overlapping building footprints');
 assert(g.run('base.scale.x===260/176&&base.scale.z===260/176&&floor.scale.y===260/176&&edge.scale.y===260/176'));
 assert(g.run('groundHeight(V(0,5,245),8)===.12'),'new south avenue has ground');
 g.run('player.pos.set(0,90,230);spiderMoveTo(player,V(0,100,235))');assert(g.run('player.pos.z>234&&player.pos.y>99'),'larger horizontal and vertical bounds are physical');
 for(const id of ['district','harbor','sanctuary']){g.ctx.id=id;g.run('applyArenaMap(id)');assert(g.run('WORLD.radius===176&&WORLD.ceiling===72&&base.scale.x===1&&floor.scale.y===1&&camera.far===520'));}
 g.run('applyArenaMap("metro")');assert(g.run('buildings.length===72&&WORLD.radius===260'),'cached map restores new bounds');
});
check('Private-room map generation and destruction indices agree across clients',()=>{
 const h=createGame();h.debug.select('spiderman');h.run('selectedMap="metro"');h.reset('online');const g=createGame();setupReplica(h,g);
 assert.equal(h.run('JSON.stringify(pieces.map(p=>[p.pos.toArray(),p.size.toArray()]))'),g.run('JSON.stringify(pieces.map(p=>[p.pos.toArray(),p.size.toArray()]))'));
 h.run('breakPiece(buildings.find(b=>b.x===194).parts[18])');g.ctx.packet=JSON.parse(h.run('JSON.stringify(onlineSnapshot())'));assert(g.run('validState(packet)'));g.run('receiveState(packet);updateReplica(1/60)');assert.equal(g.run('pieces.filter(p=>!p.alive).length'),h.run('pieces.filter(p=>!p.alive).length'));
 assert(g.run('WORLD.radius===260&&WORLD.ceiling===124'));
});
check('Shoulder camera, zoom and FOV hit the exact crosshair surface instead of the character aim',()=>{
 const g=game();wall(g);
 for(const [x,y,z,fov] of [[3,5,8,62],[-8,9,12,76],[.3,2,2,48]]){g.ctx.cam=[x,y,z];g.ctx.fov=fov;g.run('camera.position.fromArray(cam);camera.fov=fov;camera.updateProjectionMatrix();camera.lookAt(V(4,28,-40));globalThis.hit=findSpiderAnchor(player);');assert(g.run('hit&&hit.piece===wall&&hit.anchor.distanceTo(V(4,28,-40))<1e-7'));assert(g.run('Math.hypot(hit.anchor.clone().project(camera).x,hit.anchor.clone().project(camera).y)<1e-8'));}
 g.run('updateSpiderHUD()');assert(g.elements.get('reticle').classes.has('web-ready'));assert.match(g.elements.get('reticle').dataset.web,/WEB/);
});
check('A miss next to a building never snaps to it or spends energy / cooldown',()=>{
 const g=game();wall(g);g.run('camera.lookAt(V(18.25,28,-40));');assert(!g.run('findSpiderAnchor(player)'));assert(!g.run('(keys.add("Digit4"),startSpiderMove(player,4))'));assert(g.run('player.energy===100&&spiderState(player).cd[4]===0'));
 g.run('updateSpiderHUD()');assert.equal(g.elements.get('reticle').dataset.web,'NO ANCHOR');assert(!g.elements.get('reticle').classes.has('web-ready'));
 g.run('camera.lookAt(V(0,200,-40));');assert(!g.run('findSpiderAnchor(player)'),'open sky misses');
});
check('Nearest rendered surface wins, including attached roof details and narrow ledges',()=>{
 const g=game();wall(g);g.run('globalThis.front=piece(V(2,17,-20),V(12,34,2),0x555566,true);front.solid=true;camera.position.set(0,4,5);camera.lookAt(V(2,20,-19));globalThis.hit=findSpiderAnchor(player);');assert(g.run('hit&&hit.piece===front&&Math.abs(hit.anchor.z+19)<1e-7'));
 const h=game();h.run('player.pos.set(0,20,8);globalThis.roof=piece(V(0,10,-30),V(20,20,20),0x556677,true);roof.solid=true;box(roof.m,V(0,.65,0),V(.3,.3,.3),mapMaterial(0x778899));camera.position.set(0,32,5);camera.lookAt(V(0,26,-30));globalThis.hit=findSpiderAnchor(player);');assert(h.run('hit&&hit.piece===roof&&hit.anchor.distanceTo(V(0,26,-30))<1e-6'),'rendered roof attachment, not an AABB guess');
 const j=game();j.run('globalThis.ledge=piece(V(0,12,-24),V(8,.3,3),0x778899,true);camera.position.set(0,5,5);camera.lookAt(V(0,12,-22.5));globalThis.hit=findSpiderAnchor(player);');assert(j.run('hit&&hit.piece===ledge'),'platform ledge is a physical anchor');
});
check('Reach limit is measured from Spider-Man, with no invented or out-of-range anchors',()=>{
 const g=game();g.run('globalThis.farWall=piece(V(0,10,-120),V(12,20,2),0x556677,true);farWall.solid=true;camera.position.set(0,3,16);camera.lookAt(V(0,10,-119));');assert(g.run('!!findSpiderAnchor(player)'),'camera offset must not consume reach');
 g.run('farWall.pos.z=farWall.m.position.z=-130;camera.lookAt(V(0,10,-129));');assert(!g.run('(keys.add("Digit4"),startSpiderMove(player,4))'));assert.equal(g.run('player.energy'),100);
});
check('A camera peek cannot fire through a nearer wall, and domain barriers stop web rays',()=>{
 const g=game();wall(g);g.run('globalThis.blocker=piece(V(0,5,-6),V(3,10,2),0x334455,true);blocker.solid=true;camera.position.set(10,5,4);camera.lookAt(V(0,20,-40));');assert(!g.run('findSpiderAnchor(player)'),'body-to-anchor route crosses the corner');
 const h=game();h.run('globalThis.outside=piece(V(0,25,-85),V(30,50,4),0x778899,true);outside.solid=true;camera.position.set(0,3,5);camera.lookAt(V(0,25,-83));domain={id:99,owner:enemy,origin:V(0,.13,0),capturedIds:[player.id,enemy.id],t:1};');assert(!h.run('findSpiderAnchor(player)'));
});
check('Fixed web point matches the drawn strand and releases destroyed / hidden anchors',()=>{
 const g=game();wall(g);g.run('(keys.add("Digit4"),startSpiderMove(player,4));globalThis.fixed=player.spider.action.anchor.clone();player.spider.action.t=.3;animateFighter(player,1/60);updateSpiderVisuals(1/60);');assert(g.run('player.spider.action?.anchor.distanceTo(V(4,28,-40))<1e-6'));
 assert(g.run('V(...spiderVisuals[0].data.slice(189,192)).distanceTo(fixed)<1e-4'),'visible strand ends at chosen point');
 g.run('camera.lookAt(V(-80,30,0));updateSpiderHUD();');assert(g.run('player.spider.action.anchor.distanceTo(fixed)===0'),'turning after attachment does not move the anchor');
 g.run('wall.domainHidden=true;wall.m.visible=false;updateSpider(1/60)');assert(g.run('!player.spider.action&&player.spider.momentum>0'));g.run('wall.domainHidden=false;wall.m.visible=true;player.spider.cd[4]=0;camera.lookAt(V(4,28,-40));(keys.add("Digit4"),startSpiderMove(player,4));wall.alive=false;updateSpider(1/60)');assert(g.run('!player.spider.action'));assert(!g.run('findSpiderAnchor(player)'));
});
check('Guest sends its camera ray on the swing press; host computes and replicates the same anchor',()=>{
 const h=createGame();h.debug.select('gojo');h.run('selectedMap="metro"');h.reset('online');h.run('ensureActorRig(enemy,"spiderman");enemy.stun=0;enemy.pos.set(0,12,0);enemy.grounded=false;enemy.vel.set(0,0,0);');
 const g=createGame();setupReplica(h,g);g.ctx.packet=JSON.parse(h.run('JSON.stringify(onlineSnapshot())'));g.run('receiveState(packet);updateReplica(1/60);camera.position.set(3,18,8);camera.lookAt(V(-18,45,-51));globalThis.preview=findSpiderAnchor(player)?.anchor.clone();globalThis.sent=null;net.input=p=>{sent=p;};onAction("special4",true,"keyboard");');assert(g.run('preview&&sent.edges[0].length===3'));
 h.ctx.input=JSON.parse(g.run('JSON.stringify(sent)'));h.run('receiveInput(input,enemy.id)');assert(h.run('enemy.spider?.action?.kind===4'));const actual=JSON.parse(h.run('JSON.stringify(enemy.spider.action.anchor.toArray())')),expected=JSON.parse(g.run('JSON.stringify(preview.toArray())'));assert(actual.every((n,i)=>Math.abs(n-expected[i])<1e-7));
 g.ctx.packet=JSON.parse(h.run('JSON.stringify(onlineSnapshot())'));assert(g.run('validState(packet)'));g.run('receiveState(packet);updateReplica(1/60);updateSpiderVisuals(1/60)');const replicated=JSON.parse(g.run('JSON.stringify(player.spider.action.anchor.toArray())'));assert(replicated.every((n,i)=>Math.abs(n-actual[i])<.001),'existing snapshots quantize world vectors to millimetres');
});
check('Network rejects malformed view rays and impossible camera positions without spending resources',()=>{
 const g=game();wall(g);g.run('ensureActorRig(enemy,"spiderman");enemy.bot=false;enemy.stun=0;enemy.pos.set(0,.13,0);enemy.energy=100;globalThis.view=captureSpiderView();');
 for(const change of ['view.direction=[0,0,0]','view.direction=[NaN,0,-1]','view.origin=[Infinity,0,0]','view.direction=[0,0,-3]']){g.run('view=captureSpiderView();'+change);assert(!g.run('window.ArenaNet.validWebView(view)'));assert(!g.run('findSpiderAnchor(enemy,view)'));}
 g.run('view=captureSpiderView();view.origin=[80,5,8];');assert(!g.run('startSpiderMove(enemy,4,view)'));assert(g.run('enemy.energy===100&&spiderState(enemy).cd[4]===0'));
 g.run('globalThis.received=0;globalThis.protocol=new window.ArenaNet({input:()=>received++});protocol.role="host";protocol.state="playing";protocol.match=1;globalThis.record={handshake:true,inputSeq:-1,rateAt:performance.now(),count:0,conn:{close(){}}};globalThis.packet={t:"input",match:1,seq:1,held:["special4"],edges:[["special4",true,captureSpiderView()]],yaw:0,pitch:0,move:[0,0]};protocol.receive(packet,record)');assert.equal(g.run('received'),1);
 g.run('packet.seq++;packet.edges[0][2].direction=[0,0,4];protocol.receive(packet,record)');assert.equal(g.run('received'),1);
 g.run('packet.seq++;packet.edges=[["special1",true,captureSpiderView()]];protocol.receive(packet,record)');assert.equal(g.run('received'),1);
});
check('Real tallest tower windows and roofs are exact targets in the expanded northern blocks',()=>{
 const g=game();g.run('applyArenaMap("metro");globalThis.tower=buildings.find(b=>b.floors===24);player.pos.set(tower.x,72,tower.z-20);camera.position.set(tower.x+2,76,tower.z-23);camera.lookAt(V(tower.x,80,tower.z-12));globalThis.hit=findSpiderAnchor(player);');assert(g.run('hit&&hit.piece.building===tower.id&&hit.anchor.y>79&&hit.anchor.y<81'));assert(g.run('Math.hypot(hit.anchor.clone().project(camera).x,hit.anchor.clone().project(camera).y)<1e-8'));
 g.run('player.pos.set(tower.x,112,tower.z+27);camera.position.set(tower.x+2,116,tower.z+29);camera.lookAt(V(tower.x-7,96,tower.z-7));globalThis.hit=findSpiderAnchor(player);');assert(g.run('hit&&hit.piece.building===tower.id&&hit.anchor.y>=95.9'));
 g.run('player.pos.set(tower.x,7,tower.z+18);camera.position.set(tower.x,10,tower.z+15);camera.lookAt(V(tower.x,2.7644,tower.z+15));globalThis.hit=findSpiderAnchor(player);');assert(g.run('hit&&hit.piece.building===tower.id&&Math.abs(hit.anchor.y-2.7644)<1e-5'),'outer awning surface remains aimable from above');
});
console.log(JSON.stringify({scope:'Build 36 deterministic simulation, real Three.js ray/geometry and input protocol checks. No browser/GPU/device QA.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
