import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(){const g=createGame();g.run('selectedCharacter="mahito";selectedMap="harbor";resetMatch("duel");for(const p of pieces)p.alive=p.m.visible=false;player.pos.set(0,.12,0);enemy.pos.set(0,.12,-30);enemy.stun=999;enemy.nextSlash=999;player.energy=100;player.ult=100;yaw=pitch=0;');return g;}
check('Articulated model, arm cycling and keyboard/touch/controller/network slot six',()=>{
 const g=game();assert(g.run('player.root.name==="mahito"&&player.limbs.length===2&&player.knees.length===2&&player.mahitoRig.wings.length===2'));
 assert(g.run('controls.bindings.special6==="Digit6"&&controls.padBindings.special6==="B7"&&window.ArenaNet.actions.has("special6")'));assert(!g.elements.get('ability6').classes.has('hidden'));assert(!g.elements.get('touchSpecial6').classes.has('hidden'));
 for(const value of [1,2,3,1]){g.down('Digit1');g.up('Digit1');assert.equal(g.run('player.mahitoArm'),value);g.advance(.6);}
});
check('Blade reach, gun projectile and hammer damage/tempo are distinct',()=>{
 const b=game();b.run('player.mahitoArm=1;enemy.pos.z=-5;lightAttack(player)');b.advance(.3);assert(b.run('enemy.hp<1000&&enemy.hp>990'));
 const g=game();g.run('player.mahitoArm=2;enemy.pos.z=-15;lightAttack(player)');g.advance(.22);assert.equal(g.run('mahitoBullets.length'),1);g.advance(.6);assert.equal(g.run('enemy.hp'),988);
 const h=game();h.run('player.mahitoArm=3;enemy.pos.z=-3;lightAttack(player)');assert(h.run('player.attackMax>.6'));h.advance(.4);assert(h.run('enemy.hp<972&&enemy.ragdollT>0'));
});
check('Owned summons fight rivals, refresh within the pool and expire',()=>{
 const g=game();g.run('enemy.pos.z=-8;startCharge(2,player)');g.advance(2);assert(g.run('mahitoUnits.length===4&&mahitoUnits.every(u=>u.owner===player)&&enemy.hp<1000'));
 g.run('startCharge(2,player)');g.advance(1);assert.equal(g.run('mahitoUnits.length'),4);g.advance(8.5);assert.equal(g.run('mahitoUnits.length'),0);
});
check('Serpent is fast, steerable and hits each rival once',()=>{
 const g=game();g.run('enemy.pos.z=-12;startCharge(3,player)');g.advance(.95);assert(g.run('player.pos.z<-15&&enemy.hp===900'));g.run('yaw=-Math.PI/2');g.advance(.8);assert(g.run('player.pos.x>20&&player.mahitoAction.dir.x>.95'));g.advance(2);assert(!g.run('mahitoBusy(player)'));assert.equal(g.run('enemy.hp'),900);
});
check('Serpent respects thin city walls and domain barriers',()=>{
 const g=game();g.run('const p=V(0,30,-8),size=V(100,60,.04);pieces.push({alive:true,solid:true,platform:false,pos:p,size,m:box(scene,p,size)});startCharge(3,player)');g.advance(2);assert(g.run('player.pos.z>=-7.6'));
 const b=game();b.run('activateDomain(player);startCharge(3,player)');b.advance(3);assert(b.run('player.pos.distanceTo(domain.origin)<54'));
});
check('Serpent can reverse aim by 180 degrees at 30/60/120 Hz',()=>{
 for(const hz of [30,60,120]){const g=game();g.ctx.hz=hz;g.run('startCharge(3,player);for(let i=0;i<hz;i++)updateMahitoFighter(player,1/hz);yaw=Math.PI;for(let i=0;i<hz;i++)updateMahitoFighter(player,1/hz);');assert(g.run('player.mahitoAction.dir.z>.98'));}
});
check('Healing is stationary, delayed by startup and interrupted by damage',()=>{
 const g=game();g.run('player.hp=500;startCharge(4,player);keys.add("KeyW")');g.advance(.5);assert.equal(g.run('player.hp'),500);assert(g.run('Math.abs(player.pos.z)<.01'));g.advance(1);assert(g.run('player.hp>535&&player.hp<550'));
 g.run('hurt(player,30,enemy,"special",V());globalThis.postHit=player.hp;keys.clear()');g.advance(2);assert.equal(g.run('player.hp'),g.run('postHit'));assert(!g.run('mahitoBusy(player)'));
});
check('Big/Small alter size, speed and damage; Winged flies; expiration restores normal',()=>{
 const g=game();g.run('startCharge(5,player)');g.advance(.6);assert(g.run('player.mahitoForm===1&&player.root.scale.x>1.7&&mahitoSpeedScale(player)<1&&mahitoDamageScale(player)>1'));
 g.run('startCharge(5,player)');g.advance(.6);assert(g.run('player.mahitoForm===2&&player.root.scale.x<.6&&mahitoSpeedScale(player)>1&&mahitoDamageScale(player)<1'));
 g.run('startCharge(5,player)');g.advance(.6);assert(g.run('player.flying&&player.mahitoForm===3&&player.mahitoRig.wings.every(w=>w.visible)'));g.run('keys.add("Space")');g.advance(.5);assert(g.run('player.pos.y>4'));g.run('keys.clear()');g.advance(12);assert(g.run('player.mahitoForm===0&&!player.flying&&Math.abs(player.root.scale.x-1)<.01'));
});
check('Cursed Touch costs 20%, requires contact, seals one technique and expires',()=>{
 const g=game();g.run('enemy.pos.z=-2;startCharge(6,player)');assert.equal(g.run('player.ult'),80);g.advance(.5);assert(g.run('enemy.soulSlot===1&&enemy.soulTime>7&&enemy.hp===1000'));g.run('enemy.stun=0;startCharge(1,enemy)');assert(!g.run('chargeFor(enemy)'));g.run('enemy.stun=999');g.advance(8.2);assert(g.run('enemy.soulSlot===0&&enemy.soulTime===0'));
 const m=game();m.run('startCharge(6,player)');m.advance(1);assert(m.run('player.ult===80&&!enemy.soulTime&&enemy.hp===1000'));m.run('player.ult=19;startCharge(6,player)');assert(m.run('!mahitoBusy(player)&&player.ult===19'));
});
check('Touch respects dodge and does not refund a miss',()=>{
 const g=game();g.run('enemy.pos.z=-2;enemy.dodge=1;startCharge(6,player)');g.advance(.7);assert(g.run('!enemy.soulTime&&player.ult===80'));
});
check('Domain retains full-meter startup, sphere, 12-second lifetime and burnout',()=>{
 const g=game();g.run('castDomain(player)');assert(g.run('player.ult===0&&!!castFor(player)&&!domain'));g.advance(1.7);assert(g.run('domain.owner===player&&!!domainVisual.userData.mahitoHands&&insideEnclosure(enemy)&&mahitoSpeedScale(player)>1&&mahitoSpeedScale(enemy)<1'));g.advance(12.2);assert(g.run('!domain&&player.techniqueBurnout>14'));g.run('startCharge(6,player)');assert(!g.run('mahitoBusy(player)'));
});
check('Only own contact executes; summons/projectiles do not; existing practice immunity remains',()=>{
 const g=game();g.run('enemy.pos.z=-2;activateDomain(player);hurt(enemy,12,player,"mahito-shot")');assert.equal(g.run('enemy.hp'),988);g.run('hurt(enemy,12,player,"mahito-summon")');assert.equal(g.run('enemy.hp'),976);g.run('enemy.block=true;enemy.blockTime=1;enemy.input.yaw=Math.PI;hurt(enemy,12,player,"light")');g.run('updateMahitoSouls(MAHITO_SOUL.duration)');assert(g.run('enemy.hp===0&&phase==="finish"&&!lastFinisher&&Number.isFinite(finishTime)'));
 const p=game();p.run('mode="practice";enemy.pos.z=-2;activateDomain(player);hurt(enemy,1,player,"light")');assert.equal(p.run('enemy.hp'),1);
});
check('Hands cover the sphere and coexist with other realms in elevated three-way clashes',()=>{
 const g=game();g.run('matchSetup.bots=["naruto","gojo"];resetMatch("duel");for(const f of bodies){f.pos.set(0,30,f.slot*4);f.ult=100;f.stun=0;}castDomain(player);castDomain(enemy);castDomain(bodies[2])');assert(g.run('clash.participants.length===3&&!!domainVisual.userData.mahitoHands&&!!domainVisual.userData.hole&&domainVisual.userData.mixedMindscape'));
 g.run('clash.t=3;animateDomainVisual();const h=domainVisual.userData.mahitoHands;globalThis.low=Infinity;globalThis.high=-Infinity;const mat=new THREE.Matrix4();for(let i=0;i<h.palm.count;i++){h.palm.getMatrixAt(i,mat);low=Math.min(low,mat.elements[13]);high=Math.max(high,mat.elements[13]);}');assert(g.run('low< -20&&high>20'));
});
check('Six Mahitos, bounded summons, host/guest state validation and match reset',()=>{
 const host=game();host.run('net.role="host";net.localId="p0";net.roster=Array.from({length:6},(_,i)=>({id:"p"+i,character:"mahito",bot:false}));beginOnline("mahito","harbor");countdown=0;for(const f of bodies){f.energy=100;f.ult=100;startCharge(2,f);updateMahitoFighter(f,.7);updateMahitoFighter(f,.4);f.cooldown=0;startCharge(5,f);updateMahitoFighter(f,.5);}enemy.soulSlot=6;enemy.soulTime=4;');assert.equal(host.run('mahitoUnits.length'),24);
 const guest=createGame();setupReplica(host,guest);guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);updateMahitoVisuals(.016)');assert(guest.run('mahitoReplica.units.length===24&&player.soulSlot===6&&player.mahitoForm===1'));guest.run('packet.mahito.units[0].owner="invalid"');assert(!guest.run('validState(packet)'));
 host.run('resetMatch("duel")');assert(host.run('mahitoUnits.length===0&&mahitoBullets.length===0&&bodies.every(f=>!f.soulTime&&!f.mahitoAction&&!f.mahitoForm)'));
});
console.log(JSON.stringify({scope:'Real Three.js rig/simulation and host/guest packets. No browser/device or FPS claim.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
