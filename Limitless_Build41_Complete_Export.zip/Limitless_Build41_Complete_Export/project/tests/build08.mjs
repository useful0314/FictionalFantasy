import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const g=createGame(),results=[];
const near=(a,b,tol=1e-6)=>assert(Math.abs(a-b)<tol,`${a} != ${b}`);
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function reset(character='gojo'){g.debug.select(character);g.reset('practice');g.debug.setup({player:{pos:[0,.13,0],stun:0},enemy:{pos:[0,.13,12],stun:999},yaw:Math.PI,pitch:0});}
check('Heian Sukuna has 150 stamina, a proportional bar, full regeneration and a four-arm rig',()=>{
 reset('sukuna');near(g.state().player.stamina,150);assert.equal(g.run('player.limbs.length'),4);assert.equal(g.run('enemy.limbs.length'),2);g.run('updateHUD()');assert.equal(g.elements.get('stamBar').style.width,'100%');
 g.run('player.stamina=75;updateHUD()');assert.equal(g.elements.get('stamBar').style.width,'50%');g.advance(4);near(g.state().player.stamina,150);reset();near(g.state().player.stamina,100);near(g.run('enemy.stamina'),150);
});
check('Both additional arms animate across the moveset, guard, sprint, domain and ragdoll',()=>{
 const poses=[];for(const code of ['player.sprinting=true;player.lastPos=V(0,.13,-1)','player.block=true','startCharge(1)','startCharge(2)','startCharge(3)','startCharge(4)','castDomain(player,true)',"hurt(player,1,enemy,'special',V(25,8,0))"]){reset('sukuna');g.run(code);g.run('for(let i=0;i<12;i++)animateFighter(player,1/60);scene.updateMatrixWorld(true)');poses.push(g.run('JSON.stringify(player.limbs.slice(2).map(l=>[l.arm.rotation.toArray(),l.elbow.rotation.toArray()]))'));assert(g.run('player.limbs.every(l=>l.hand.matrixWorld.elements.every(Number.isFinite))'));}assert(new Set(poses).size>=6);
});
check('The full Nuke has 115m radius and still hits a target sprinting away for its three-second fuse',()=>{
 reset();g.run("mode='online';remoteInput.yaw=Math.PI;remoteInput.pitch=0;remoteInput.keys.add('KeyW');remoteInput.keys.add('ShiftLeft');enemy.stun=0;enemy.pos.z=10;createBlue(player,1,forward());blue.p.copy(headPos(player));startBomb(1)");near(g.state().bomb.radius,115);
 g.run('for(let i=0;i<180;i++){updateControlled(enemy,1/60);updateBomb(1/60)}');assert(g.state().enemy.pos[2]>80);assert(g.state().enemy.hp<900);near(g.state().player.hp,1000);assert.equal(g.state().bomb,null);
 reset();g.run('createBlue(player,0,forward());startBomb(0)');near(g.state().bomb.radius,60);
});
check('The forming barrier is visible, fixed to the cast origin, and escapable before sealing',()=>{
 reset();g.run('castDomain(player,true);updateDomains(.6);updateBarrierVisuals()');assert.equal(g.run('barrierVisuals.size'),1);near(g.run('Array.from(barrierVisuals.values())[0].uniforms.uBuild.value'),.6/1.55);assert(g.elements.get('domainStage').textContent.includes('TARGET INSIDE'));
 g.run('enemy.pos.z=80;player.pos.x=2;updateDomains(.96);updateBarrierVisuals()');assert.equal(g.state().domain.captured,false);near(g.run('domain.origin.x'),0);assert.equal(g.run('barrierVisuals.size'),1);assert(g.run('Array.from(barrierVisuals.values())[0].uniforms.uSealed.value')===1);
});
check('A sealed domain contains movement, airborne launches and teleport destinations',()=>{
 reset();g.run('activateDomain(player);player.pos.set(0,.13,53);yaw=Math.PI;const destination=teleportDestination(1);globalThis.teleportTest=destination;');assert(g.run('teleportTest.distanceTo(domain.origin)')<54);
 g.run('player.pos.set(0,50,40);player.vel.set(0,15,30);constrainBarrier(player,player.pos,V(0,.13,0),player.vel)');assert(g.run('headPos(player).distanceTo(enclosureCenter())')<=53.31);assert(g.run('player.vel.dot(headPos(player).sub(enclosureCenter()).normalize())')<=0);
 g.run('enemy.pos.set(100,.13,0);constrainBarrier(enemy)');assert(g.run('headPos(enemy).distanceTo(enclosureCenter())')<=53.31);
});
check('An opponent left outside cannot enter, teleport through, or damage across the shell',()=>{
 reset();g.run('enemy.pos.set(80,.13,0);activateDomain(player);const dst=V(-80,.13,0);constrainBarrier(enemy,dst,enemy.pos);globalThis.outsideDestination=dst');assert(g.run('outsideDestination.x')>54);
 const hp=g.state().player.hp;assert.equal(g.run("hurt(player,100,enemy,'special')"),false);near(g.state().player.hp,hp);
 g.run('enemy.pos.set(0,.13,0);constrainBarrier(enemy)');assert(g.run('headPos(enemy).distanceTo(enclosureCenter())')>=54.69);
});
check('The shell intercepts Red rays and traveling projectiles',()=>{
 reset();g.run('enemy.pos.z=90;activateDomain(player)');near(g.run('barrierRayDistance(headPos(player),V(0,0,1))'),54);
 g.run('executeTechnique(player,3,1,V(0,0,1));for(let i=0;i<160;i++)updateProjectiles(1/60)');assert.equal(g.run('projectiles.length'),0);near(g.state().enemy.hp,1000);
 g.run('fireRed(headPos(player),V(0,0,1),1,player)');near(g.state().enemy.hp,1000);
});
check('Interrupted casting removes its forming shell and stops the spoken callout',()=>{
 reset();g.run('castDomain(player,true);updateBarrierVisuals();syncBattleAudio()');assert.equal(g.run("sound.cues.get('cast-p0').clip"),'gojoCast');assert(!g.run("sound.cues.has('voidTheme')"));
 g.run("hurt(player,1,enemy,'light');updateBarrierVisuals();syncBattleAudio()");assert.equal(g.run('barrierVisuals.size'),0);assert.equal(g.state().playerCast,null);assert(!g.run("sound.cues.has('cast-p0')"));
});
check('Both cast voices survive a clash, and Void theme starts once after Gojo wins',()=>{
 reset();g.run('enemy.stun=0;castDomain(enemy,true);castDomain(player,true);syncBattleAudio();updateBarrierVisuals()');assert(g.state().clash);assert.equal(g.run("sound.cues.get('cast-p0').clip"),'gojoCast');assert.equal(g.run("sound.cues.get('cast-b0').clip"),'sukunaCast');assert(!g.run("sound.cues.has('voidTheme')"));const center=g.run('clash.origin.toArray()');
 g.run('clash.joinRemaining=0;clash.scores[player.id]=12;updateDomains(.01);syncBattleAudio()');const theme=g.run("sound.cues.get('voidTheme')");assert.equal(theme.clip,'gojoTheme');assert.equal(theme.bus,'music');g.run('syncBattleAudio()');assert.equal(g.run("sound.cues.get('voidTheme')"),theme);near(g.run('domain.origin.z'),center[2]);
 g.run("phase='pause';syncBattleAudio()");assert(!g.run("sound.cues.has('voidTheme')"));assert(!g.run("sound.cues.has('cast-p0')"));
});
check('An outside viewer sees the closed shell in the normal city, without entering the realm',()=>{
 reset();g.run('player.pos.z=90;enemy.pos.z=0;activateDomain(enemy);updateBarrierVisuals()');assert(!g.state().domain.captured);assert.equal(g.run('domainVisual.children.length'),0);assert(g.run('sky.visible'));assert(g.run('Array.from(barrierVisuals.values())[0].shell.material.depthWrite'));assert(g.elements.get('domainStage').textContent.includes('YOU ARE OUTSIDE'));
});
check('Guest receives the same cast origin, progress, callout token, stamina and enlarged Nuke radius',()=>{
 reset();g.run('mode="online";net.role="host";castDomain(player,true);updateDomains(.7);syncBattleAudio()');const guest=createGame();setupReplica(g,guest);
 guest.ctx.packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));guest.run('receiveState(packet);updateReplica(.016);updateBarrierVisuals();syncBattleAudio()');near(guest.state().player.stamina,150);near(guest.run('enemyCast.t'),.7);near(guest.run('enemyCast.origin.z'),0);near(guest.run("sound.cues.get('cast-p0').token"),g.run("sound.cues.get('cast-p0').token"));
 g.run('playerCast=null;createBlue(player,1,forward());startBomb(1);playCombatFX("hollow",V(),115,1)');guest.ctx.packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));guest.run('receiveState(packet);updateReplica(.016);syncCombatVisuals()');near(guest.state().bomb.radius,115);near(guest.run("techniqueRigs.get('bombField'+bomb.id).g.scale.x"),115);
});
check('Ending and resetting domains removes physical collision and barrier geometry',()=>{
 reset();g.run('activateDomain(player);updateBarrierVisuals();updateDomains(12);updateBarrierVisuals()');assert.equal(g.run('barrierVisuals.size'),0);assert.equal(g.run('barrierRayDistance(headPos(player),V(0,0,1))'),Infinity);g.run('castDomain(player,true);updateBarrierVisuals()');g.debug.start('practice');assert.equal(g.run('barrierVisuals.size'),0);assert.equal(g.run('sound.cues.size'),0);
});
console.log(JSON.stringify({scope:'Build 08 model, stamina, expanded blast, physical enclosure, audio cues and guest simulation.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
