import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(error){results.push({name,pass:false,error:error.stack});}}
function game(){const g=createGame();g.debug.select('spiderman');g.reset('practice');g.run('for(const p of pieces){p.domainHidden=true;p.m.visible=false;}player.pos.set(0,10,0);player.vel.set(0,0,0);player.grounded=false;enemy.pos.set(70,.13,0);enemy.stun=999;yaw=-.11;pitch=-.55;globalThis.wall=piece(V(0,45,-74),V(26,90,4),0x668899,true);wall.solid=true;camera.position.set(2,13,6);camera.lookAt(V(8,55,-72));');return g;}
function ticks(g,n=36,hz=60){g.ctx.n=n;g.ctx.hz=hz;g.run('for(let i=0;i<n;i++){updateSpider(1/hz);animateFighter(player,1/hz);updateSpiderVisuals(1/hz);}');}
function held(g){assert(g.run('player.spider?.action?.kind===4'));}
function released(g){assert(g.run('!player.spider?.action'));}
check('Keyboard hold sustains swing; repeat presses never toggle; releasing preserves the full velocity',()=>{
 const g=game();g.down('Digit4');held(g);const id=g.run('player.spider.action.id');ticks(g,24);g.event('keydown',{code:'Digit4',repeat:true});g.down('Digit4');held(g);assert.equal(g.run('player.spider.action.id'),id);
 g.run('player.vel.set(24,-8,-32)');const velocity=g.run('JSON.stringify(player.vel.toArray())');g.up('Digit4');released(g);assert.equal(g.run('JSON.stringify(player.vel.toArray())'),velocity);assert(g.run('player.spider.momentum===SPIDER.releaseCarry&&player.spider.releaseTime===SPIDER_SWING.releasePose'));ticks(g,12);released(g);
});
check('Rebound keyboard and mouse actions release on up and on rebinding',()=>{
 const g=game();g.run('controls.bind("special4","KeyR")');g.down('Digit4');released(g);g.up('Digit4');g.down('KeyR');held(g);g.up('KeyR');released(g);
 g.run('player.spider.cd[4]=0;controls.bind("special4","Mouse1")');g.event('mousedown',{button:1});held(g);g.event('mouseup',{button:1});released(g);
 g.run('player.spider.cd[4]=0;controls.bind("special4","KeyR")');g.down('KeyR');held(g);g.run('controls.bind("special4","KeyT")');released(g);
});
check('Touch up, cancellation and lost capture release; another held source keeps the swing attached',()=>{
 const g=game(),button=g.document.querySelectorAll('[data-action]').find(e=>e.dataset.action==='special4');
 for(const type of ['pointerup','pointercancel','lostpointercapture']){g.run('spiderState(player).cd[4]=0');button.dispatchEvent({type:'pointerdown',pointerId:7,preventDefault(){}});held(g);button.dispatchEvent({type,pointerId:7});released(g);}
 g.run('player.spider.cd[4]=0');g.down('Digit4');button.dispatchEvent({type:'pointerdown',pointerId:8,preventDefault(){}});g.up('Digit4');held(g);button.dispatchEvent({type:'pointerup',pointerId:8});released(g);
});
check('Controller chord holds, releases either button, and disconnects without a stuck web or accidental jump',()=>{
 const g=game(),pad={connected:true,mapping:'standard',id:'Test pad',axes:[0,0,0,0],buttons:Array.from({length:17},()=>({pressed:false,value:0}))};g.pads.push(pad);
 for(const which of [0,6]){g.run('spiderState(player).cd[4]=0');pad.buttons[6].pressed=pad.buttons[0].pressed=true;g.run('controls.poll(1/60)');held(g);ticks(g,4);pad.buttons[which].pressed=false;g.run('controls.poll(1/60)');released(g);assert(!g.run('controls.held.has("jump")'));pad.buttons[6].pressed=pad.buttons[0].pressed=false;g.run('controls.poll(1/60)');}
 g.run('player.spider.cd[4]=0');pad.buttons[6].pressed=pad.buttons[0].pressed=true;g.run('controls.poll(1/60)');held(g);pad.connected=false;g.run('controls.poll(1/60)');released(g);
});
check('Pause, blur, cursor mode and free orbit safely release the held action',()=>{
 for(const close of ['pause()','setCursorMode(true)','setCharacterView(true)','blur']){const g=game();g.down('Digit4');held(g);if(close==='blur')g.event('blur');else g.run(close);released(g);assert(!g.run('keys.has("Digit4")'));}
});
check('Jump can release early; holding the old input never auto-reattaches or spends more energy',()=>{
 const g=game();g.down('Digit4');ticks(g,30);assert(g.run('jumpFighter(player)'));released(g);const energy=g.run('player.energy');ticks(g,30);released(g);assert.equal(g.run('player.energy'),energy);g.up('Digit4');g.run('camera.position.copy(headPos(player));camera.lookAt(V(8,55,-72));');g.down('Digit4');held(g);
});
check('Launch eases in, rope never teleports the body, and 30/60/120Hz follow the same arc',()=>{
 const paths=[];for(const hz of [30,60,120]){const g=game();g.run('player.pos.y=.13;player.grounded=true');g.down('Digit4');assert.equal(g.run('player.vel.length()'),0);g.ctx.hz=hz;g.run('globalThis.maxStep=0;globalThis.old=player.pos.clone();globalThis.path=[];for(let i=0;i<hz*1.2;i++){old.copy(player.pos);updateSpider(1/hz);maxStep=Math.max(maxStep,player.pos.distanceTo(old));if(i===hz*.2-1||i===hz*.6-1||i===hz*1.2-1)path.push(player.pos.toArray());}');held(g);assert(g.run('player.pos.y>1&&player.vel.length()>25&&player.vel.length()<=SPIDER.swingSpeed+.001'));assert(g.run('maxStep<=SPIDER.swingSpeed/hz+.001'));paths.push(JSON.parse(g.run('JSON.stringify(path)')));}
 for(const path of paths)for(let i=0;i<3;i++)assert(Math.hypot(...path[i].map((n,j)=>n-paths[1][i][j]))<.02);
});
check('A 180-degree aim reversal banks progressively and keeps the attachment fixed',()=>{
 const g=game();g.down('Digit4');ticks(g,30);g.run('globalThis.fixed=player.spider.action.anchor.clone();globalThis.beforeYaw=player.spider.action.steerYaw;yaw+=Math.PI;');ticks(g,1);assert(g.run('Math.abs(player.spider.action.steerYaw-beforeYaw)<=SPIDER_SWING.turnSpeed/60+.00001'));assert(g.run('Math.abs(player.spider.action.bank)>0&&player.spider.action.anchor.distanceTo(fixed)===0'));ticks(g,12);assert(g.run('Math.abs(player.body.rotation.z)>.04&&player.pos.toArray().every(Number.isFinite)'));
});
check('No phantom attachments; depletion, destruction, hidden scenery and interruptions detach',()=>{
 for(const why of ['player.energy=0','wall.alive=false','wall.domainHidden=true','player.stun=.5','player.hp=0']){const g=game();g.down('Digit4');g.run(why);ticks(g,1);released(g);}
 const g=game();g.run('camera.lookAt(V(0,200,0))');g.down('Digit4');released(g);assert(g.run('player.energy===100&&spiderState(player).cd[4]===0'));g.run('camera.lookAt(V(8,55,-72))');ticks(g,10);released(g);g.up('Digit4');g.down('Digit4');held(g);
});
check('Cast, catch, dive, rise and release use distinct poses; the firing arm points at the fixed anchor',()=>{
 const g=game();g.down('Digit4');g.run('globalThis.poses=[]');for(const t of [.06,.23,.9]){g.ctx.t=t;g.run('player.spider.action.t=t;animateFighter(player,1/60);poses.push(Array.from(player.spider.pose));');}assert(g.run('poses[0][NP.rx]!==poses[1][NP.rx]&&poses[1][NP.ll]!==poses[2][NP.ll]'));
 g.run('player.spider.action.t=.9;player.vel.y=-26;for(let i=0;i<30;i++)animateFighter(player,1/60);globalThis.dive=Array.from(player.spider.pose);player.vel.y=26;for(let i=0;i<30;i++)animateFighter(player,1/60);globalThis.rise=Array.from(player.spider.pose);');assert(g.run('dive[NP.lean]>.3&&rise[NP.lean]<-.15&&rise[NP.lk]>1.5&&dive[NP.lk]<.6'));
 assert(g.run('(()=>{const l=player.limbs[1];player.root.updateMatrixWorld(true);const p=l.arm.getWorldPosition(V()),q=l.arm.getWorldQuaternion(new THREE.Quaternion());return V(0,-1,0).applyQuaternion(q).dot(player.spider.action.anchor.clone().sub(p).normalize())>.999;})()'));
 g.up('Digit4');g.run('player.spider.releaseTime=SPIDER_SWING.releasePose-.14;globalThis.tuck=Array.from(spiderPoseTarget(player));player.spider.releaseTime=SPIDER_SWING.releasePose-.35;globalThis.open=Array.from(spiderPoseTarget(player));');assert(g.run('tuck[NP.lk]>1.7&&open[NP.rx]>.4&&open[NP.lx]<0'));ticks(g,40);assert(g.run('player.spider.releaseTime===0&&spiderPoseTarget(player)===null'));
});
check('Release presentation yields immediately to combat, landing and hit reactions',()=>{
 const g=game();g.down('Digit4');ticks(g,24);g.up('Digit4');for(const state of ['player.attack=.3','player.grounded=true','player.stun=.2','player.dodge=.2']){g.run('player.attack=player.stun=player.dodge=0;player.grounded=false;player.spider.releaseTime=.4;'+state);assert.equal(g.run('spiderPoseTarget(player)'),null);}
});
check('A descending release lands cleanly instead of keeping the airborne carry and pose active',()=>{
 const g=game();g.down('Digit4');ticks(g,20);g.up('Digit4');g.run('player.pos.set(0,.2,0);player.vel.set(20,-15,0);moveFighter(player,1/60);animateFighter(player,1/60)');assert(g.run('player.grounded&&player.vel.y===0&&player.spider.momentum===0&&player.spider.releaseTime===0&&spiderPoseTarget(player)===null'));assert(g.run('jumpFighter(player)'));
});
check('Web catch and release use bounded arm rotations for anchors in front, beside and behind the body',()=>{
 for(const z of [-72,0,72]){const g=game();g.ctx.z=z;g.run('wall.alive=false;piece(V(z===0?72:0,45,z),V(8,90,8),0x668899,true).solid=true;camera.lookAt(V(z===0?72:0,55,z));player.vel.set(0,10,-25);actionFor(player,"special4",true);globalThis.rot=player.limbs[1].arm.quaternion.clone();globalThis.entry=0;for(let i=0;i<40;i++){rot.copy(player.limbs[1].arm.quaternion);player.spider.action.t+=1/60;animateFighter(player,1/60);entry=Math.max(entry,rot.angleTo(player.limbs[1].arm.quaternion));}actionFor(player,"special4",false);globalThis.exit=0;for(let i=0;i<36;i++){rot.copy(player.limbs[1].arm.quaternion);player.spider.releaseTime=Math.max(0,player.spider.releaseTime-1/60);animateFighter(player,1/60);exit=Math.max(exit,rot.angleTo(player.limbs[1].arm.quaternion));}');assert(g.run('entry<.5&&exit<.45'));}
});
check('The web and animation reuse pools; all three strand endpoints stay on the chosen surface',()=>{
 const g=game();g.down('Digit4');ticks(g,25);g.run('globalThis.data=spiderVisuals[0].data;globalThis.flow=player.spider.visual.flow;globalThis.end=player.spider.action.anchor.clone();');ticks(g,20);assert(g.run('spiderVisuals.length===MAX_FIGHTERS&&spiderVisuals[0].data===data&&player.spider.visual.flow===flow'));assert(g.run('[189,381,573].every(i=>V(...data.slice(i,i+3)).distanceTo(end)<.0001)'));
});
check('Remote hold and release edges, missing-up reconciliation, and the stale input timeout detach on the host',()=>{
 const g=game();g.run('mode="online";net.role="host";ensureActorRig(enemy,"spiderman");enemy.bot=false;enemy.stun=0;enemy.pos.copy(player.pos);enemy.energy=100;player.pos.x=70;globalThis.press={held:["special4"],edges:[["special4",true,captureSpiderView()]],yaw:-.11,pitch:-.55,move:[0,0]};receiveInput(press,enemy.id);');assert(g.run('enemy.spider.action?.kind===4'));g.run('receiveInput({...press,held:[],edges:[["special4",false]]},enemy.id)');assert(g.run('!enemy.spider.action'));
 g.run('enemy.spider.cd[4]=0;receiveInput(press,enemy.id);receiveInput({...press,held:[],edges:[]},enemy.id)');assert(g.run('!enemy.spider.action'));
 g.run('enemy.spider.cd[4]=0;receiveInput(press,enemy.id)');assert(g.run('enemy.spider.action?.kind===4'));g.clock.now+=600;g.run('step(1/60)');assert(g.run('!enemy.spider.action'));
});
check('Guests send both hold edges and release animation / bank / tension replicate with validation',()=>{
 const h=createGame();h.debug.select('gojo');h.reset('online');h.run('ensureActorRig(enemy,"spiderman");enemy.stun=0');const g=createGame();setupReplica(h,g);g.run('globalThis.inputs=[];net.input=p=>inputs.push(p);');g.down('Digit4');g.up('Digit4');assert(g.run('inputs.some(p=>p.edges.some(e=>e[0]==="special4"&&e[1]===true&&e[2]))&&inputs.some(p=>p.edges.some(e=>e[0]==="special4"&&e[1]===false)&&!p.held.includes("special4"))'));
 const a=game();a.down('Digit4');ticks(a,25);a.run('yaw+=1');ticks(a,8);g.ctx.p=JSON.parse(a.run('JSON.stringify(packSpider(player))'));assert(g.run('validSpider(p,"spiderman",new Set(bodies.map(f=>f.id)))'));g.run('receiveSpider(player,p);animateFighter(player,1/60)');assert(g.run('player.spider.action.bank===p.a.bank&&player.spider.action.load===p.a.load'));
 a.up('Digit4');g.ctx.p=JSON.parse(a.run('JSON.stringify(packSpider(player))'));g.run('receiveSpider(player,p)');assert(g.run('!player.spider.action&&player.spider.releaseTime===SPIDER_SWING.releasePose'));
 for(const corrupt of ['p.releaseTime=NaN','p.releaseTime=4']){g.ctx.p=JSON.parse(a.run('JSON.stringify(packSpider(player))'));g.run(corrupt);assert(!g.run('validSpider(p,"spiderman",new Set(bodies.map(f=>f.id)))'));}
 a.run('spiderState(player).cd[4]=0;camera.position.copy(headPos(player));camera.lookAt(V(8,55,-72))');a.down('Digit4');for(const corrupt of ['p.a.bank=2','p.a.load=-1','p.a.load=Infinity']){g.ctx.p=JSON.parse(a.run('JSON.stringify(packSpider(player))'));g.run(corrupt);assert(!g.run('validSpider(p,"spiderman",new Set(bodies.map(f=>f.id)))'));}
});
console.log(JSON.stringify({scope:'Build 37 pure simulation, Three.js scene state and synthetic keyboard/touch/pad/network checks. No browser/GPU/device QA.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
