import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(error){results.push({name,pass:false,error:error.stack});}}
function game(map='district',hide=true){const g=createGame();g.debug.select('spiderman');g.ctx.map=map;g.run('selectedMap=map');g.reset('practice');if(hide)g.run('for(const p of pieces){p.domainHidden=true;p.m.visible=false;}');g.run('player.pos.set(0,.13,0);player.vel.set(0,0,0);player.grounded=true;enemy.pos.set(140,.13,0);enemy.stun=999;yaw=0;pitch=.12;camera.position.set(2,5,6);camera.lookAt(V(0,.02,-60));');return g;}
function ticks(g,n=60,hz=60){g.ctx.n=n;g.ctx.hz=hz;g.run('for(let i=0;i<n;i++){updateSpider(1/hz);animateFighter(player,1/hz);updateSpiderVisuals(1/hz);}');}
function slide(g){assert(g.run('player.spider?.action?.kind===4&&player.spider.action.sliding&&player.grounded'));}
function building(g){g.run('globalThis.wall=piece(V(0,45,-74),V(26,90,4),0x668899,true);wall.solid=true;camera.lookAt(V(8,55,-72));');}
check('Every map aims at the exact visible ground under the crosshair, with cached static paving',()=>{
 for(const map of ['district','harbor','sanctuary','metro']){const g=game(map);assert(g.run('(()=>{const h=findSpiderAnchor(player);return h&&h.up&&h.ground&&Math.hypot(h.anchor.clone().project(camera).x,h.anchor.clone().project(camera).y)<1e-7;})()'));g.run('globalThis.cache=spiderGroundMeshes();updateSpiderHUD()');assert(g.run('spiderGroundMeshes()===cache'));assert.match(g.elements.get('reticle').dataset.web,/SLIDE/);g.down('Digit4');slide(g);}
});
check('Too-close, out-of-range, outside-arena and open-sky shots do not spend resources',()=>{
 const g=game();for(const target of [[0,-.08,.3],[0,-.08,-150],[0,120,-40]]){g.ctx.target=target;g.run('camera.position.copy(headPos(player));camera.lookAt(V(...target))');g.down('Digit4');assert(g.run('!player.spider?.action&&player.energy===100&&spiderState(player).cd[4]===0'));g.up('Digit4');}
 g.run('applyArenaMap("metro");player.pos.set(250,.13,0);camera.position.set(250,4,0);camera.lookAt(V(262,-.08,0));');assert(!g.run('findSpiderAnchor(player)'));
});
check('Ground shots accelerate into a slide without a hop and keep the chosen anchor and resource costs',()=>{
 const g=game();g.down('Digit4');slide(g);g.run('globalThis.fixed=player.spider.action.anchor.clone();globalThis.maxY=player.pos.y;for(let i=0;i<60;i++){updateSpider(1/60);animateFighter(player,1/60);maxY=Math.max(maxY,player.pos.y);}');slide(g);assert(g.run('maxY<=.131&&player.pos.z< -18&&player.vel.length()>40&&player.vel.y===0'));assert(g.run('player.spider.action.anchor.distanceTo(fixed)===0&&Math.abs(player.energy-92)<1e-7&&player.spider.momentum===0'));
});
check('Arriving at a ground anchor brakes smoothly and holds position without oscillation',()=>{
 const g=game();g.down('Digit4');ticks(g,180);slide(g);assert(g.run('player.vel.length()<.1&&player.pos.distanceTo(player.spider.action.anchor)<2.5'));const p=g.run('player.pos.z');ticks(g,60);assert(Math.abs(g.run('player.pos.z')-p)<.05);slide(g);
});
check('Ground steering changes the slide path progressively while the web stays fixed',()=>{
 const g=game();g.down('Digit4');ticks(g,30);g.run('globalThis.fixed=player.spider.action.anchor.clone();keys.add("KeyD");globalThis.oldYaw=player.spider.action.steerYaw');ticks(g,1);assert(g.run('Math.abs(player.spider.action.steerYaw-oldYaw)<=SPIDER_SWING.turnSpeed/60+.0001'));ticks(g,40);slide(g);assert(g.run('player.pos.x>1&&player.spider.action.anchor.distanceTo(fixed)===0&&Math.abs(player.body.rotation.z)>.01'));
});
check('Landing from a building swing keeps its web, horizontal momentum, timer and energy continuous',()=>{
 const g=game();building(g);g.down('Digit4');g.run('player.spider.action.t=.8;player.spider.action.launch.set(0,0,0);player.pos.set(0,.14,0);player.vel.set(12,-30,-34);player.grounded=false;globalThis.id=player.spider.action.id;globalThis.fixed=player.spider.action.anchor.clone();globalThis.energy=player.energy;');ticks(g,1,120);slide(g);assert(g.run('player.spider.action.id===id&&player.spider.action.anchor.distanceTo(fixed)===0&&player.spider.action.t>.8&&player.spider.action.t<.82'));assert(g.run('Math.abs(player.vel.x-12)<1.5&&Math.abs(player.vel.z+34)<1.5&&player.spider.releaseTime===0&&Math.abs(player.energy-(energy-SPIDER.swingDrain/120))<1e-8'));ticks(g,25);slide(g);assert(g.run('player.body.position.y<-.3'));
});
check('Airborne ground shots immediately enter a slide on contact',()=>{
 const g=game();g.run('player.pos.y=.14;player.grounded=false;player.vel.set(0,-12,-20)');g.down('Digit4');ticks(g,1,120);slide(g);assert(g.run('player.spider.action.t<.02&&player.vel.y===0'));
});
check('Rooftop contact slides, crossing its edge resumes swinging, and the street catches the next landing',()=>{
 const g=game();building(g);g.run('globalThis.roof=piece(V(0,5,0),V(12,.4,16),0x557788,true);roof.solid=true;player.pos.set(0,5.24,4);player.grounded=false;camera.position.set(0,9,8);camera.lookAt(V(8,20,-72));');g.down('Digit4');g.run('player.spider.action.t=.8;player.spider.action.launch.set(0,0,0);player.vel.set(0,-15,-30)');ticks(g,1,120);slide(g);assert(g.run('Math.abs(player.pos.y-5.2)<1e-6'));g.run('globalThis.leftRoof=false;globalThis.street=false;for(let i=0;i<180&&player.spider.action;i++){updateSpider(1/120);const a=player.spider.action;if(!a)break;if(!a.sliding&&player.pos.y<5.2)leftRoof=true;if(leftRoof&&a.sliding&&player.pos.y<.2){street=true;break;}}');assert(g.run('leftRoof&&street'),'roof edge transitions to air then street slide');
});
check('Walls stop a slide and domain barriers prevent ground attachments across the enclosure',()=>{
 const g=game();g.down('Digit4');g.run('piece(V(0,3,-10),V(25,6,2),0x334455,true).solid=true');ticks(g,100);assert(g.run('!player.spider.action&&player.pos.z> -9'));
 const h=game();h.run('domain={id:99,owner:enemy,origin:V(0,.13,0),capturedIds:[player.id,enemy.id],t:1};camera.lookAt(V(0,-.08,-100))');assert(!h.run('findSpiderAnchor(player)'));h.run('camera.lookAt(V(0,-.08,-10))');assert(h.run('!!findSpiderAnchor(player)'));
});
check('Destroyed building anchors and vanished rooftop support are handled during a slide',()=>{
 const g=game();building(g);g.down('Digit4');g.run('player.spider.action.sliding=player.grounded=true;player.spider.action.launch.set(0,0,0);wall.alive=false');ticks(g,1);assert(g.run('!player.spider.action'));
 const h=game();building(h);h.run('globalThis.roof=piece(V(0,5,0),V(12,.4,16),0x557788,true);roof.solid=true;player.pos.set(0,5.2,4);camera.position.set(0,9,8);camera.lookAt(V(8,55,-72));');h.down('Digit4');h.run('player.spider.action.sliding=player.grounded=true;player.spider.action.launch.set(0,0,0);player.spider.action.t=1;roof.alive=false;');ticks(h,15);assert(h.run('player.spider.action&&!player.spider.action.sliding&&!player.grounded&&Math.abs(player.pos.y-5.2)>.1'));
});
check('Letting go releases the ground web without a jump; Jump releases into the existing regular jump',()=>{
 const g=game();g.down('Digit4');ticks(g,40);g.run('globalThis.velocity=player.vel.clone()');g.up('Digit4');assert(g.run('!player.spider.action&&player.grounded&&player.vel.distanceTo(velocity)===0&&player.vel.y===0'));
 const h=game();h.down('Digit4');ticks(h,40);const stamina=h.run('player.stamina');h.down('Space');assert(h.run('!player.spider.action&&!player.grounded&&player.vel.y===9&&player.spider.momentum>0'));assert.equal(h.run('player.stamina'),stamina);ticks(h,10);assert(h.run('!player.spider.action'));
});
check('Slide pose blends low, articulates legs and ankle joints, aims the arm, and emits pooled dust',()=>{
 const g=game();g.down('Digit4');g.run('globalThis.maxBobStep=0;globalThis.oldBob=player.body.position.y;for(let i=0;i<60;i++){updateSpider(1/60);animateFighter(player,1/60);maxBobStep=Math.max(maxBobStep,Math.abs(player.body.position.y-oldBob));oldBob=player.body.position.y;updateSpiderVisuals(1/60);}');slide(g);assert(g.run('player.body.position.y<-.35&&maxBobStep<.08&&player.legs[0].rotation.x<-.9&&player.knees[1].rotation.x>1.4&&player.blockRig.feet[0].rotation.x>.15'));assert(g.run('narutoVisuals.particles.cursor>0&&spiderVisuals[0].dustClock<SPIDER_SLIDE.dustInterval'));
 g.run('globalThis.buffer=spiderVisuals[0].data;globalThis.pool=narutoVisuals.particles;globalThis.pose=player.spider.visual.flow;');ticks(g,10);assert(g.run('buffer===spiderVisuals[0].data&&pool===narutoVisuals.particles&&pose===player.spider.visual.flow'));assert(g.run('[189,381,573].every(i=>V(...buffer.slice(i,i+3)).distanceTo(player.spider.action.anchor)<.0001)'));
});
check('Ground slide trajectory is consistent at 30/60/120Hz and never moves faster than the speed cap',()=>{
 const paths=[];for(const hz of [30,60,120]){const g=game();g.down('Digit4');g.ctx.hz=hz;g.run('globalThis.maxStep=0;globalThis.old=player.pos.clone();for(let i=0;i<hz*1.5;i++){old.copy(player.pos);updateSpider(1/hz);maxStep=Math.max(maxStep,old.distanceTo(player.pos));}');slide(g);assert(g.run('maxStep<=SPIDER.swingSpeed/hz+.002&&player.vel.length()<=SPIDER.swingSpeed'));paths.push(JSON.parse(g.run('JSON.stringify(player.pos.toArray())')));}
 for(const p of paths)assert(Math.hypot(...p.map((n,i)=>n-paths[1][i]))<.02);
});
check('Private-room snapshots carry slide state and guests render it; forged slide flags are rejected',()=>{
 const h=game();h.down('Digit4');ticks(h,40);const g=createGame();setupReplica(h,g);g.ctx.packet=JSON.parse(h.run('JSON.stringify(onlineSnapshot())'));assert(g.run('validState(packet)'));g.run('receiveState(packet);for(let i=0;i<30;i++){updateReplica(1/60);animateFighter(enemy,1/60);updateSpiderVisuals(1/60);}');assert(g.run('enemy.spider.action.sliding&&enemy.grounded&&enemy.body.position.y<-.3'));
 g.ctx.packet.actors[0].spider.a.sliding='true';assert(!g.run('validState(packet)'));g.ctx.packet.actors[0].spider.a.sliding=true;g.ctx.packet.actors[0].spider.a.kind=2;assert(!g.run('validState(packet)'));
 h.up('Digit4');g.ctx.packet=JSON.parse(h.run('JSON.stringify(onlineSnapshot())'));assert(g.run('validState(packet)'));g.run('receiveState(packet)');assert(g.run('!enemy.spider.action'));
});
check('Remote ground shots use the captured camera ray and held-input reconciliation releases the slide',()=>{
 const g=game();g.run('mode="online";net.role="host";ensureActorRig(enemy,"spiderman");enemy.bot=false;enemy.stun=0;enemy.pos.copy(player.pos);enemy.grounded=true;enemy.energy=100;player.pos.x=100;globalThis.packet={held:["special4"],edges:[["special4",true,captureSpiderView()]],yaw:0,pitch:.12,move:[0,0]};receiveInput(packet,enemy.id)');assert(g.run('enemy.spider.action?.sliding&&enemy.grounded'));g.run('updateSpider(.1);receiveInput({...packet,held:[],edges:[]},enemy.id)');assert(g.run('!enemy.spider.action'));
});
check('Complete frame loop slides through the original streets on all four maps',()=>{
 for(const map of ['district','harbor','sanctuary','metro']){const g=game(map,false);g.down('Digit4');slide(g);g.advance(.8);slide(g);assert(g.run('player.pos.z< -8&&player.pos.y<.5&&player.pos.toArray().every(Number.isFinite)'));g.up('Digit4');g.advance(.2);assert(g.run('!player.spider.action&&player.grounded'));}
});
console.log(JSON.stringify({scope:'Build 38 Three.js geometry and simulation checks, synthetic input and private-room snapshots; no browser/GPU/device QA.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
