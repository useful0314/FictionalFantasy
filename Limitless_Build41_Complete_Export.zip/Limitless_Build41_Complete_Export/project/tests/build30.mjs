import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(){const g=createGame();g.run('selectedCharacter="mahito";selectedMap="harbor";resetMatch("duel");for(const p of pieces)p.alive=p.m.visible=false;player.pos.set(0,30,0);enemy.pos.set(0,30,-2);enemy.stun=999;player.ult=100;yaw=pitch=0;activateDomain(player);');return g;}
check('Reference design: ivory layered giant palms/fists fill upper and lower sphere at both budgets',()=>{
 const g=game();for(const budget of [500,1800]){g.ctx.budget=budget;g.run('{particleBudget=budget;domain.t=2;animateDomainVisual();const h=domainVisual.userData.mahitoHands;globalThis.stats={low:Infinity,high:-Infinity,minScale:Infinity,maxScale:0};const m=new THREE.Matrix4(),p=V(),q=new THREE.Quaternion(),s=V();for(let i=0;i<h.palm.count;i++){h.palm.getMatrixAt(i,m);m.decompose(p,q,s);stats.low=Math.min(stats.low,p.y);stats.high=Math.max(stats.high,p.y);stats.minScale=Math.min(stats.minScale,s.x);stats.maxScale=Math.max(stats.maxScale,s.x);}}');assert(g.run('stats.low< -30&&stats.high>30&&stats.minScale>2.5&&stats.maxScale>5'));assert.equal(g.run('domainVisual.userData.mahitoHands.palm.count'),budget<1000?96:224);assert(g.run('domainVisual.userData.dome.material.color.getHex()===MAHITO_REALM.void'));}
});
check('Touch holds HP until pop, locks actions, prevents duplicate damage and then defeats',()=>{
 const g=game();g.run('enemy.stun=0;enemy.block=true;enemy.blockTime=1;hurt(enemy,12,player,"light");');assert(g.run('enemy.hp===MAX_HEALTH&&soulExecutionPending(enemy)&&mahitoSouls.length===1'));
 g.run('hurt(enemy,200,player,"special");updateMahitoSouls(.7);enemy.input.keys.add("KeyW");enemy.input.keys.add("Space");updateControlled(enemy,.1);startCharge(1,enemy);');assert(g.run('enemy.hp===MAX_HEALTH&&enemy.pos.y===30&&enemy.pos.z===-2&&!chargeFor(enemy)'));
 g.run('updateMahitoSouls(.49);applyMahitoSoulPose(enemy)');assert(g.run('enemy.hp===0&&phase==="finish"&&!enemy.root.visible&&mahitoSouls[0].popped'));assert.equal(g.run('player.score'),1000);
});
check('Dodge, impossible AI, practice immunity, noncontact attacks and barriers retain rules',()=>{
 for(const condition of ['dodge','impossible','practice','shot','outside']){const g=game();g.ctx.condition=condition;g.run('if(condition==="dodge")enemy.dodge=.3;if(condition==="impossible")enemy.difficulty="impossible";if(condition==="practice")mode="practice";if(condition==="outside"){domain.capturedIds=[];domain.captured=false;enemy.pos.x=90;}hurt(enemy,12,player,condition==="shot"?"mahito-shot":"light");');assert.equal(g.run('mahitoSouls.length'),0);if(condition==='practice')assert.equal(g.run('enemy.hp'),1);}
});
check('All four rigs deform with finite transforms and restore before the next frame/reset',()=>{
 for(const character of ['gojo','sukuna','naruto','mahito']){const g=game();g.ctx.char=character;g.run('ensureActorRig(enemy,char);animateFighter(enemy,.016);animateMahitoDetail(enemy,.016);hurt(enemy,1,player,"light");');
 for(const t of [.1,.4,.75,1.1]){g.ctx.age=t;g.run('restoreMahitoSoulPose(enemy);animateFighter(enemy,.016);animateMahitoDetail(enemy,.016);mahitoSouls[0].t=age;applyMahitoSoulPose(enemy);enemy.root.updateMatrixWorld(true);globalThis.finite=true;enemy.root.traverse(o=>{if(!o.matrixWorld.elements.every(Number.isFinite))finite=false;});');assert(g.run('finite&&enemy.mahitoSoulPose.applied'));}
 g.run('restoreMahitoSoulPose(enemy);globalThis.clean=enemy.body.scale.toArray();applyMahitoSoulPose(enemy);resetMahitoSouls()');assert(g.run('enemy.body.scale.toArray().every((x,i)=>Math.abs(x-clean[i])<1e-8)&&mahitoSouls.length===0'));
 }
});
check('Three-way fight keeps running through one transfiguration; domain ending does not cancel committed hit',()=>{
 const g=game();g.run('matchSetup.bots=["gojo","sukuna"];resetMatch("duel");for(const f of bodies){f.pos.set(f.slot,30,0);f.stun=999;}player.stun=0;activateDomain(player);hurt(enemy,12,player,"light");endActiveDomain(domain);updateMahitoSouls(1.18);applyMahitoSoulPose(enemy);');assert(g.run('phase==="play"&&enemy.hp===0&&bodies[2].hp===1000&&!enemy.root.visible&&!domain'));
});
check('Host snapshots synchronize deformation/pop, reject invalid ages/owners and restore on removal',()=>{
 const host=game();host.run('net.role="host";mode="online";hurt(enemy,12,player,"light");updateMahitoSouls(.55)');const guest=createGame();setupReplica(host,guest);guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);animateFighter(player,.016);applyMahitoSoulPose(player)');assert(guest.run('player.hp===1000&&mahitoSouls.length===1&&player.mahitoSoulPose.applied'));
 guest.run('packet.mahito.souls[0].t=-1');assert(!guest.run('validState(packet)'));guest.run('packet.mahito.souls[0].t=.55;packet.mahito.souls[0].owner=player.id');assert(!guest.run('validState(packet)'));
 host.run('updateMahitoSouls(.64)');guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);applyMahitoSoulPose(player);globalThis.cursor=narutoVisuals.particles.cursor;applyMahitoSoulPose(player)');assert(guest.run('!player.root.visible&&player.hp===0&&cursor===narutoVisuals.particles.cursor'));
 guest.run('resetMatch("duel")');assert(guest.run('mahitoSouls.length===0&&bodies.every(f=>f.body.visible&&f.root.visible)'));
});
check('30/60/120 Hz reach the pop at the same time and full frame loop renders it',()=>{
 for(const hz of [30,60,120]){const g=game();g.ctx.hz=hz;g.run('hurt(enemy,1,player,"light");for(let i=0;i<Math.floor(1.17*hz);i++)updateMahitoSouls(1/hz)');assert(g.run('enemy.hp>0'));g.run('updateMahitoSouls(2/hz)');assert.equal(g.run('enemy.hp'),0);}
 const g=game();g.run('hurt(enemy,1,player,"light")');g.advance(.5);assert(g.run('enemy.hp>0&&enemy.mahitoSoulPose.applied'));g.advance(1);assert(g.run('enemy.hp===0&&!enemy.root.visible'));
});
console.log(JSON.stringify({scope:'Real Three.js geometry, simulation and host/guest state; no browser/FPS claim.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
