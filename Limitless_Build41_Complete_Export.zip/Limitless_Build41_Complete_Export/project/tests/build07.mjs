import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const g=createGame(),results=[];
const near=(a,b,tol=1e-6)=>assert(Math.abs(a-b)<tol,`${a} != ${b}`);
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function reset(character='gojo'){g.debug.select(character);g.reset('practice');g.debug.setup({player:{pos:[0,.13,8],stun:0},enemy:{pos:[0,.13,-30],stun:999},yaw:0,pitch:0});}

check('Sukuna repeatedly jumps on the existing jump binding without spending stamina',()=>{
 reset('sukuna');g.down('Space');g.up('Space');near(g.state().player.stamina,150);g.advance(.25);
 for(let i=0;i<12;i++){const y=g.state().player.pos[1];g.down('Space');g.up('Space');near(g.state().player.stamina,150);g.advance(.25);assert(g.state().player.pos[1]>y);}
 assert.equal(g.run('jumpFighter(player)'),true);near(g.state().player.stamina,150);
 g.advance(4);assert(g.run('player.grounded'));assert(g.state().player.stamina>1);
});
check('Air jump rejects spam, hitstun, charge and Void suppression, but accepts zero stamina',()=>{
 reset('sukuna');g.run('jumpFighter(player)');assert.equal(g.run('jumpFighter(player)'),false);near(g.state().player.stamina,150);g.advance(.25);
 for(const state of ['player.stun=.2','player.recovery=.2','startCharge(1)','enemy.pos.set(0,.13,0);activateDomain(enemy)']){
  reset('sukuna');g.run('player.grounded=false;player.pos.y=5;'+state);const before=g.state().player.stamina;assert.equal(g.run('jumpFighter(player)'),false);near(g.state().player.stamina,before);
 }
 reset('sukuna');g.run('player.grounded=false;player.stamina=0');assert.equal(g.run('jumpFighter(player)'),true);
});
check('Gojo retains ground jump and levitation without receiving Sukuna air jumps',()=>{
 reset();g.down('Space');g.up('Space');g.advance(.25);assert.equal(g.run('jumpFighter(player)'),false);g.down('KeyF');g.up('KeyF');assert(g.run('player.flying'));
});
check('A heavy hit launches more than 25 metres with a full forward tumble before landing and recovery',()=>{
 reset();g.run("player.pos.set(0,.13,80);hurt(player,1,enemy,'special',V(0,8,-36));");g.advance(1);
 assert(g.state().player.pos[2]<55);assert(g.state().player.pos[1]>1);assert(g.run('player.ragdollPitch')< -3.5);assert(g.run('player.body.rotation.x')< -3);assert(!g.run('player.flying'));
 g.advance(3.5);assert(g.run('player.grounded'));assert.equal(g.run('player.ragdollT'),0);assert.equal(g.run('player.recovery'),0);assert(Math.abs(g.run('player.body.rotation.x'))<.1);
});
check('High-speed launch into a building destroys its contacted section',()=>{
 reset();g.run("const launchBuilding=buildings.find(b=>b.x===22&&b.z===22);player.pos.set(launchBuilding.x-launchBuilding.w/2-2,.13,launchBuilding.z);scene.updateMatrixWorld(true);hurt(player,1,enemy,'special',V(40,6,0));");g.advance(.2);
 assert(g.run('buildings.find(b=>b.x===22&&b.z===22).parts.some(p=>!p.alive)'));assert(g.run("effects.some(e=>e.m.name==='impact-launchImpact')"));
});
check('Charged Red stays at the fingertip; firing keeps sparks at the muzzle for a second',()=>{
 reset();g.debug.setup({enemy:{pos:[0,.13,0]}});g.down('Digit2');g.advance(1.8);
 assert(g.run("techniqueRigs.get('charge0').kind==='red'"));assert.equal(g.run('charge.orb.g.visible'),false);
 assert(g.run("techniqueRigs.get('charge0').g.position.distanceTo(redMuzzlePosition(player))")<.01);
 assert(g.run('player.limbs[1].fingers[0].rotation.x')>-.1);assert(g.run('player.limbs[1].fingers[2].rotation.x')< -1);
 g.up('Digit2');near(g.state().enemy.hp,860);assert(g.run('player.redRecoil')>0);assert(g.run("effects.some(e=>e.m.name==='impact-redMuzzle')"));
 g.advance(1);assert(g.run("effects.some(e=>e.m.name==='impact-redMuzzle')"));assert(!g.run("effects.some(e=>e.m.name==='impact-red')"));g.advance(.25);assert(!g.run("effects.some(e=>e.m.name==='impact-redMuzzle')"));
});
check('Red can still fuse an anchored Blue with its new muzzle and narrow shot',()=>{
 reset();g.run('createBlue(player,1,forward());blue.p.set(0,1.6,0);anchorBlue()');g.down('Digit2');g.advance(.8);g.up('Digit2');assert(g.state().bomb);assert.equal(g.state().blue,null);
});
check('Domains remain active after 8.5 seconds and finish at 12 with unchanged totals',()=>{
 for(const character of ['gojo','sukuna']){
  reset(character);g.debug.setup({enemy:{pos:[0,.13,0]}});g.run('activateDomain(player);updateDomains(8.5)');assert(g.state().domain);near(g.run('domainVisual.userData.uniforms.uEnd.value'),1);assert(g.state().enemy.hp>(character==='gojo'?450:400));
  g.run('updateDomains(3.499)');assert(g.state().domain);g.run('updateDomains(.01)');assert.equal(g.state().domain,null);near(g.state().enemy.hp,character==='gojo'?450:400);
 }
});
check('Host validates remote air jumps and guests receive airborne pose and Red muzzle effects',()=>{
 reset('gojo');g.run("mode='online';enemy.stun=0;enemy.grounded=false;enemy.pos.y=5;enemy.stamina=50;actionFor(enemy,'jump',true)");near(g.run('enemy.stamina'),50);assert(g.run('enemy.jumpPose')>0);
 const guest=createGame();setupReplica(g,guest);
 g.run("mode='online';net.role='host';playCombatFX('redMuzzle',V(0,2,0),1,1,V(0,0,-1))");guest.ctx.packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));
 guest.run('receiveState(packet);updateReplica(.016);animateFighter(player,.016)');near(guest.state().player.stamina,50);assert(guest.run('player.jumpPose')>0);assert(guest.run("effects.some(e=>e.m.name==='impact-redMuzzle')"));
 g.run("hurt(enemy,1,player,'special',V(25,6,0));updateCombatTimers(enemy,.2)");guest.ctx.packet=JSON.parse(g.run('JSON.stringify(onlineSnapshot())'));guest.run('receiveState(packet);updateReplica(.016);animateFighter(player,.016)');
 near(guest.run('player.ragdollPitch'),g.run('enemy.ragdollPitch'),.001);assert(guest.run('player.ragdollT')>0);assert(guest.run('player.body.matrix.elements.every(Number.isFinite)'));
});
console.log(JSON.stringify({scope:'Build 07 gameplay and two-client simulation; no physical device or live Internet session.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
