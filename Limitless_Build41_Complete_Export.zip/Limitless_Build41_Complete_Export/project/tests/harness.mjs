// Pure simulation harness: no claim of browser rendering or actual device testing.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {webcrypto} from 'node:crypto';
import * as RealThree from '../vendor/three.module.js';
export class Element {
 constructor(tag='div'){this.tagName=tag.toUpperCase();this.style={setProperty(k,v){this[k]=v;}};this.children=[];this.listeners={};this.classes=new Set();this.dataset={};this.value='';this.checked=false;this.disabled=false;this.classList={add:(...x)=>x.forEach(c=>this.classes.add(c)),remove:(...x)=>x.forEach(c=>this.classes.delete(c)),contains:c=>this.classes.has(c),toggle:(c,on)=>{if(on??!this.classes.has(c))this.classes.add(c);else this.classes.delete(c);}};}
 append(...x){for(const c of x)c.parentElement=this;this.children.push(...x);}
 replaceChildren(...x){this.children=[];this.append(...x);}
 remove(){if(this.parentElement)this.parentElement.children=this.parentElement.children.filter(c=>c!==this);this.parentElement=null;}setAttribute(k,v){this[k]=v;if(k.startsWith('data-'))this.dataset[k.slice(5)]=v;}
 closest(selector){if(selector.includes('button')&&this.tagName==='BUTTON')return this;if(selector.includes('input')&&this.tagName==='INPUT')return this;if(selector.includes('select')&&this.tagName==='SELECT')return this;if(selector.includes('.hidden')&&this.classes.has('hidden'))return this;return this.parentElement?.closest(selector)||null;}
 addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);}
 dispatchEvent(e){e.target??=this;for(const fn of this.listeners[e.type]??[])fn(e);this['on'+e.type]?.(e);}
 click(){this.onclick?.({target:this});}focus(){this.ownerDocument.activeElement=this;}
 querySelectorAll(selector){const all=[];const walk=e=>{for(const c of e.children){if(selector.split(',').includes(c.tagName.toLowerCase()))all.push(c);walk(c);}};walk(this);return all;}
 getContext(){return {createRadialGradient:()=>({addColorStop(){}}),fillRect(){}};}
 getClientRects(){return [{width:100,height:50}];}getBoundingClientRect(){return {left:0,top:0,width:100,height:100};}
 setPointerCapture(){}requestPointerLock(){return Promise.resolve();}
}
export function createGame({Peer,storage=new Map(),audioContext}={}){
 const elements=new Map(),all=[];
 const html=fs.readFileSync(new URL('../src/index.html',import.meta.url),'utf8');
 const win=new Element(),document=new Element();document.body=new Element('body');document.body.ownerDocument=document;
 document.createElement=tag=>{const e=new Element(tag);e.ownerDocument=document;return e;};
 for(const m of html.matchAll(/<([a-z][a-z0-9]*)\b([^>]*?)>/g)){
  const attrs=m[2],id=/\bid="([^"]+)"/.exec(attrs)?.[1],cl=/\bclass="([^"]+)"/.exec(attrs)?.[1];
  const e=document.createElement(m[1]);if(id){e.id=id;assert(!elements.has(id),'Duplicate id '+id);elements.set(id,e);}if(cl)e.classList.add(...cl.split(' '));
  for(const a of attrs.matchAll(/data-([\w-]+)="([^"]+)"/g))e.dataset[a[1]]=a[2];
  e.checked=/\bchecked\b/.test(attrs);e.value=/\bvalue="([^"]+)"/.exec(attrs)?.[1]||'';e.type=/\btype="([^"]+)"/.exec(attrs)?.[1]||'';all.push(e);
 }
 document.getElementById=id=>{assert(elements.has(id),'Unknown UI element: '+id);return elements.get(id);};
 document.querySelectorAll=selector=>selector==='[data-bind]'?all.filter(e=>e.dataset.bind):selector==='[data-action]'?all.filter(e=>e.dataset.action):selector==='.panel'?all.filter(e=>e.classes.has('panel')):[];
 document.exitPointerLock=()=>{};win.matchMedia=()=>({matches:false});win.Peer=Peer;win.AudioContext=audioContext;
 const pads=[],clock={now:0},timers=[];
 class Renderer{constructor(){this.domElement=document.createElement('canvas');this.shadowMap={};this.info={render:{calls:0,triangles:0}};}setPixelRatio(x){this.ratio=x;}getPixelRatio(){return this.ratio;}setSize(){}render(scene,camera){scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);}}
 const ctx=vm.createContext({THREE:{...RealThree,WebGLRenderer:Renderer},window:win,document,navigator:{maxTouchPoints:0,getGamepads:()=>pads},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},innerWidth:1440,innerHeight:900,devicePixelRatio:1,location:{search:'?test=1'},URLSearchParams,performance:{now:()=>clock.now},crypto:webcrypto,requestAnimationFrame(){},setTimeout:(fn,ms)=>{timers.push({fn,ms});return timers.length;},clearTimeout(){},console,atob,Uint8Array,Event:class{constructor(type){this.type=type;}}});
 for(const name of ['audio','controls','network'])vm.runInContext(fs.readFileSync(new URL('../src/'+name+'.js',import.meta.url),'utf8'),ctx,{filename:name+'.js'});
 let source=fs.readFileSync(new URL('../src/game.js',import.meta.url),'utf8').replace(/^import[^\n]+/,'const THREE=globalThis.THREE;').replace('/*FINISHERS*/',fs.readFileSync(new URL('../src/finishers.js',import.meta.url),'utf8')).replace('/*ANIMATION*/',['air-combat','light-combo','animation-polish','animation'].map(n=>fs.readFileSync(new URL('../src/'+n+'.js',import.meta.url),'utf8')).join('\n')).replace('/*MAPS*/',['maps','map-metro'].map(n=>fs.readFileSync(new URL('../src/'+n+'.js',import.meta.url),'utf8')).join('\n')).replace('/*CITY*/',fs.readFileSync(new URL('../src/city.js',import.meta.url),'utf8')).replace('/*COMBAT_SYSTEM*/',['combat-system','combat-response','sukuna-world-cut','sukuna-world-cut-vfx'].map(n=>fs.readFileSync(new URL('../src/'+n+'.js',import.meta.url),'utf8')).join('\n')).replace('/*BARRIERS*/',fs.readFileSync(new URL('../src/barriers.js',import.meta.url),'utf8')).replace('/*DOMAINS*/',fs.readFileSync(new URL('../src/domains.js',import.meta.url),'utf8')+'\n'+['mindscape','mindscape-vfx','kurama-model','kurama-domain','domain-cinematics','domain-mixed','domain-burnout','mindscape-sphere','mindscape-clones'].map(n=>fs.readFileSync(new URL('../src/'+n+'.js',import.meta.url),'utf8')).join('\n')).replace('/*COMBAT_VFX*/',fs.readFileSync(new URL('../src/combat-vfx.js',import.meta.url),'utf8')).replace('/*TECHNIQUE_STARTUP*/',fs.readFileSync(new URL('../src/technique-startup.js',import.meta.url),'utf8')).replace('/*ROSTER*/',['roster','roster-health'].map(n=>fs.readFileSync(new URL('../src/'+n+'.js',import.meta.url),'utf8')).join('\n')).replace('/*CUTOUTS*/',fs.readFileSync(new URL('../src/cutouts.js',import.meta.url),'utf8')).replace('/*PRESENTATION*/',['presentation','combat-feel','battle-readability'].map(n=>fs.readFileSync(new URL('../src/'+n+'.js',import.meta.url),'utf8')).join('\n')).replace('/*SESSION*/',fs.readFileSync(new URL('../src/session.js',import.meta.url),'utf8'));
 source=source.replace('/*BLOCK_MODELS*/',fs.readFileSync(new URL('../src/block-models.js',import.meta.url),'utf8'));
 source=source.replace('/*NARUTO*/',['spiderman','spiderman-model','spiderman-animation','spiderman-vfx','mahito','mahito-model','mahito-animation','mahito-hands','mahito-domain','mahito-transfiguration','mahito-amalgamation','mahito-vfx','naruto','naruto-model','naruto-animation','naruto-vfx','naruto-mobility','wall-motion','naruto-speedlines','naruto-substitution'].map(name=>fs.readFileSync(new URL('../src/'+name+'.js',import.meta.url),'utf8')).join('\n'));
 vm.runInContext(source,ctx,{filename:'game.js'});
 const api=win.arena,state=()=>api.snapshot(),debug=api.debug;
 function event(type,props={}){for(const fn of win.listeners[type]??[])fn({preventDefault(){},repeat:false,target:document.createElement('div'),...props});}
 const down=code=>event('keydown',{code}),up=code=>event('keyup',{code});
 function advance(seconds){for(let i=0;i<Math.ceil(seconds*60);i++){clock.now+=1000/60;debug.step(1/60);}}
 function reset(mode='duel'){vm.runInContext("matchSetup.bots=[selectedCharacter==='gojo'?'sukuna':'gojo']",ctx);if(mode==='online')vm.runInContext("net.role='host';net.localId='p0';net.roster=[{id:'p0',character:selectedCharacter,bot:false},{id:'p1',character:matchSetup.bots[0],bot:false}];net.arena=selectedMap",ctx);debug.start(mode);debug.setup({enemy:{pos:[40,.13,0],stun:999,nextSlash:999,nextFire:999},pitch:0});advance(.02);}
 return {api,state,debug,ctx,elements,document,win,event,down,up,advance,reset,pads,clock,timers,storage,run:code=>vm.runInContext(code,ctx)};
}

export function setupReplica(host,guest){
 guest.ctx.testRoster=JSON.parse(host.run('JSON.stringify(bodies.map(f=>({id:f.id,character:f.character,bot:f.bot,difficulty:f.difficulty})))'));
 guest.ctx.testLocalId=host.run('enemy.id');guest.ctx.testArena=host.run('activeMap');
 guest.run('net.role="guest";net.localId=testLocalId;net.roster=testRoster;net.arena=testArena;beginOnline(testRoster.find(f=>f.id===testLocalId).character,testArena);countdown=0');
}
