// Combat simulation checks with real Three.js math/scene objects.
// DOM and renderer are mocked: this does NOT verify WebGL, audio, or browser input.
import assert from 'node:assert/strict';
import {createGame,Element} from './harness.mjs';
import vm from 'node:vm';
const {api,state,debug,ctx,elements,event,down,up,advance,reset}=createGame();
function cast(key,seconds){down(key);advance(seconds);up(key);}
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.message});}}

check('Walking moves in camera direction; stamina recovers',()=>{
  reset();debug.setup({player:{stamina:40}});const z=state().player.pos[2];down('KeyW');advance(.5);up('KeyW');
  assert(state().player.pos[2]<z-2);assert(state().player.stamina>50);
});
check('Minimum-energy Blue can form without gaining free power',()=>{
  reset();debug.setup({player:{energy:5}});cast('Digit1',.5);
  assert(state().blue);assert.equal(state().blue.q,0);assert.equal(state().player.energy,0);
});
check('Blue bends through its faster extended path, remains controllable for six seconds, anchors, and expires',()=>{
  reset();cast('Digit1',1);advance(.4);debug.setup({yaw:.4});advance(.5);
  assert(state().blue.pos[0]<-.1);assert.equal(state().blue.phase,'travel');
  advance(.65);assert.equal(state().blue.phase,'sweep');advance(6.1);assert.equal(state().blue.phase,'hold');advance(3.1);assert.equal(state().blue,null);
});
check('Red + anchored Blue creates 3-second damaging fusion; caster is unharmed; terrain restores together',()=>{
  reset();debug.setup({player:{energy:100}});cast('Digit1',1);advance(.35);down('Digit1');up('Digit1');
  assert.equal(state().blue.phase,'hold');const p=state().blue.pos;
  debug.setup({enemy:{pos:[p[0]+6,.13,p[2]],hp:1000}});advance(.21);cast('Digit2',.7);
  assert(state().bomb,'Fusion did not trigger');const hp=state().player.hp;advance(1);
  assert(state().enemy.hp<1000,'Fusion must deal damage before burst');assert(state().bomb);
  advance(2.1);assert.equal(state().bomb,null);assert(state().enemy.hp<900);assert.equal(state().player.hp,hp);
  assert(state().destroyed>0);debug.setup({restoreTimer:.05});advance(.1);assert.equal(state().destroyed,0);
});
check('Teleport cancels charged Blue, preserves its spent cost, and moves toward aim',()=>{
  reset();down('Digit1');advance(.5);const energy=state().player.energy;down('Digit4');up('Digit1');
  assert.equal(state().charge.kind,4);assert(state().player.energy<energy);advance(1);const z=state().player.pos[2];up('Digit4');
  assert(state().player.pos[2]<z-10);assert.equal(state().blue,null);
});
check('Vulnerable resource charging is independent from Blue charging',()=>{
  reset();debug.setup({player:{energy:10}});down('KeyC');advance(3);up('KeyC');
  assert(state().player.energy>20);assert.equal(state().blue,null);assert.equal(state().charge,null);
});
check('Landed light attack adds energy',()=>{
  reset();debug.setup({player:{energy:30},enemy:{pos:[0,.13,10.3],stun:0,nextSlash:999,nextFire:999,brain:999,block:false,blockTimer:999}});
  event('mousedown',{button:0});event('mouseup',{button:0});advance(.2);
  assert(state().enemy.hp<1000);assert.equal(state().player.energy,34);
});
check('Perfect dodge heals 15 HP and briefly staggers attacker; later dodge does not heal',()=>{
  reset();debug.setup({player:{hp:70},enemy:{stun:0}});down('KeyE');debug.hurt('player',12);
  assert.equal(state().player.hp,85);assert(state().enemy.stun>0&&state().enemy.stun<=.3);
  advance(.23);debug.hurt('player',12);assert.equal(state().player.hp,85);up('KeyE');
});
check('Counter within 1.5 seconds starts clash; landed attacks award winning domain',()=>{
  reset('practice');debug.setup({enemy:{pos:[0,.13,4],stun:0}});debug.clash();advance(.6);down('KeyQ');up('KeyQ');
  assert(state().clash);for(let i=0;i<12;i++)debug.hurt('enemy',1,'light');advance(1.1);
  assert.equal(state().clash,null);assert.equal(state().domain.owner,'player');assert(state().domain.captured);
});
check('Interrupting vulnerable domain startup spends meter',()=>{
  reset();debug.setup({player:{ult:100}});down('KeyQ');up('KeyQ');assert(state().playerCast);debug.hurt('player',3,'special');
  assert.equal(state().playerCast,null);assert(state().player.ult<5);
});
check('Emergency ultimate is available once below 5 HP',()=>{
  reset();debug.setup({player:{hp:4,ult:0}});down('KeyQ');up('KeyQ');assert(state().player.emergency);assert(state().playerCast);
  advance(10.2);debug.setup({player:{hp:4,ult:0}});down('KeyQ');up('KeyQ');assert.equal(state().playerCast,null);
});
check('Duel ends when health reaches zero',()=>{
  reset();debug.hurt('enemy',1500,'ultimate');assert.equal(state().phase,'finish');advance(3.5);assert.equal(state().phase,'result');
});

check('Selecting Sukuna swaps the rigs, opponent, HUD, and four technique labels',()=>{
  debug.select('sukuna');reset();assert.equal(state().player.character,'sukuna');assert.equal(state().enemy.character,'gojo');
  assert.equal(elements.get('pname').textContent,'RYOMEN SUKUNA');assert.equal(elements.get('abilityName3').textContent,'FURNACE');assert.equal(elements.get('abilityNameQ').textContent,'MALEVOLENT SHRINE');
  const root=vm.runInContext('player.root',ctx),opponent=vm.runInContext('enemy.root',ctx);assert.notEqual(root,opponent);
});
check('Sukuna charges and fires Dismantle; the projectile hits Gojo without self-damage',()=>{
  debug.select('sukuna');reset();debug.setup({enemy:{pos:[0,.13,4],hp:100},player:{energy:100}});const hp=state().player.hp;
  cast('Digit1',.9);assert(state().projectiles.includes('slash'));advance(.45);assert(state().enemy.hp<100);assert.equal(state().player.hp,hp);assert(state().player.energy<100);
});
check('Cleave performs a close barrage and misses outside its stated range',()=>{
  debug.select('sukuna');reset();debug.setup({enemy:{pos:[0,.13,9.5]},player:{energy:100}});cast('Digit2',.8);advance(.8);assert(state().enemy.hp<985);
  reset();cast('Digit2',.8);advance(.8);assert.equal(state().enemy.hp,1000);assert.equal(state().techniques.length,0);
});
check('Furnace hits the opponent, destroys terrain, and leaves a temporary burn area',()=>{
  debug.select('sukuna');reset();debug.setup({enemy:{pos:[0,.13,3]},player:{energy:100}});cast('Digit3',1.3);advance(.5);assert(state().enemy.hp<980);assert(state().techniques.includes('burn'));assert(state().destroyed>0);advance(2.2);assert(!state().techniques.includes('burn'));
});
check('Cursed Rush moves Sukuna forward and hits along the swept path',()=>{
  debug.select('sukuna');reset();debug.setup({enemy:{pos:[0,.13,8]},player:{energy:100}});const z=state().player.pos[2];cast('Digit4',.8);advance(.35);assert(state().player.pos[2]<z-5);assert(state().enemy.hp<1000);
});
check('Malevolent Shrine damages Gojo without suppressing his ability to attack',()=>{
  debug.select('sukuna');reset('practice');debug.setup({enemy:{pos:[0,.13,2],stun:0,nextSlash:999,nextFire:999,brain:999}});down('KeyQ');up('KeyQ');advance(1.7);assert.equal(state().domain.kind,'sukuna');assert.equal(vm.runInContext('trappedByVoid(enemy)',ctx),false);const hp=state().enemy.hp;advance(.7);assert(state().enemy.hp<hp);
});
check('Gojo CPU uses his own techniques and Blue attracts Sukuna, not Gojo',()=>{
  debug.select('sukuna');reset('practice');debug.setup({player:{pos:[0,.13,10]},enemy:{pos:[0,.13,0],stun:0}});vm.runInContext('enemy.input.yaw=Math.PI;enemy.input.pitch=0',ctx);debug.technique('enemy',1,.5);assert.equal(state().blue.owner,'enemy');const hp=state().player.hp;advance(.8);assert(state().player.hp<hp);assert.equal(state().enemy.hp,1000);
});
check('The active Gojo CPU chooses and releases a Gojo technique',()=>{
  debug.select('sukuna');reset();debug.setup({enemy:{pos:[0,.13,-5],stun:0,nextSlash:0,nextFire:0,energy:100,brain:999,domainCD:999}});advance(.5);assert(state().cpuCharge);assert([1,2,3,4].includes(state().cpuCharge.kind));advance(1.3);assert(state().blue||state().projectiles.length||state().player.hp<1000||state().enemy.pos[2]>-5);
});
check('Gojo CPU Void suppresses Sukuna, while a Sukuna clash win establishes Shrine',()=>{
  debug.select('sukuna');reset('practice');debug.setup({enemy:{pos:[0,.13,4],stun:0}});debug.clash();advance(1.7);assert.equal(state().domain.owner,'enemy');assert.equal(state().domain.kind,'gojo');assert.equal(vm.runInContext('trappedByVoid(player)',ctx),true);down('Digit1');assert.equal(state().charge,null);up('Digit1');
  reset('practice');debug.setup({enemy:{pos:[0,.13,4],stun:0}});debug.clash();advance(.5);down('KeyQ');up('KeyQ');assert(state().clash);for(let i=0;i<12;i++)debug.hurt('enemy',1,'light');advance(1.1);assert.equal(state().domain.kind,'sukuna');assert.equal(state().domain.owner,'player');
});

check('Low-energy CPU stops to charge and can recover past the cost of a special',()=>{
  debug.select('sukuna');reset();debug.setup({enemy:{pos:[0,.13,-5],stun:0,nextSlash:0,nextFire:999,energy:11,brain:999,domainCD:999}});const pos=state().enemy.pos.slice();advance(5);assert(state().enemy.pos.every((x,i)=>Math.abs(x-pos[i])<.05));assert(state().enemy.hp===1000);assert(vm.runInContext('enemy.energy',ctx)>35);assert.equal(state().cpuCharge,null);
});
check('Switching back to Gojo restores the Gojo kit and clears the previous match',()=>{
  debug.select('gojo');reset();assert.equal(state().player.character,'gojo');assert.equal(elements.get('abilityName1').textContent,'LAPSE: BLUE');assert.equal(state().domain,null);assert.equal(state().blue,null);assert.equal(state().techniques.length,0);assert.equal(state().projectiles.length,0);
});
console.log(JSON.stringify({scope:'Combat simulation only. WebGL, audio, and real browser input are not tested.',results},null,2));
if(results.some(x=>!x.pass))process.exitCode=1;
