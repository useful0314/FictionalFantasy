import assert from 'node:assert/strict';
import {createGame} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function setup(){const g=createGame();g.reset('practice');g.run('cursorFree=true;options.freeOrbit=false;lockOn=true;player.pos.set(0,.13,0);enemy.pos.set(60,.13,60);yaw=0;pitch=0;cinematic=null;animateFighter(player,.02)');return g;}
function drag(g,id=1){g.run('renderer.domElement').dispatchEvent({type:'pointerdown',pointerType:'mouse',button:0,pointerId:id,clientX:100,clientY:300,preventDefault(){}});g.event('pointermove',{pointerId:id,clientX:600,clientY:300,movementX:0,movementY:0});g.event('pointerup',{pointerId:id});}
check('Repeated cursor drags keep their angle between strokes and reach the character front without V',()=>{
 const g=setup(),facing=g.run('player.root.rotation.y');for(let i=0;i<3;i++){drag(g);const angle=g.run('cameraOrbit.yaw');g.run('updateCamera(.5);animateFighter(player,.02)');assert.equal(g.run('cameraOrbit.yaw'),angle);}
 assert(g.run('camera.position.z')<-5);assert.equal(g.run('player.root.rotation.y'),facing);assert.equal(g.run('yaw'),0);assert(!g.run('options.freeOrbit'));assert.equal(g.run('pendingHits.length'),0);
 g.event('wheel',{deltaY:-100,deltaMode:0});assert(g.run('options.camDistance')<7);g.run('setCursorMode(false,false);lockOn=false;updateCamera(.5)');assert(Math.abs(g.run('cameraOrbit.yaw'))<.02);
});
check('Drag ignores other pointers, avoids duplicate mouse motion, and stops on capture loss',()=>{
 const g=setup(),canvas=g.run('renderer.domElement');canvas.dispatchEvent({type:'pointerdown',pointerType:'mouse',button:0,pointerId:5,clientX:100,clientY:100,preventDefault(){}});
 g.event('pointermove',{pointerId:6,clientX:900,clientY:100});assert.equal(g.run('cameraOrbit.yaw'),0);
 g.event('pointermove',{pointerId:5,clientX:600,clientY:100});const angle=g.run('cameraOrbit.yaw');g.event('mousemove',{movementX:500,movementY:0});assert.equal(g.run('cameraOrbit.yaw'),angle);
 canvas.dispatchEvent({type:'lostpointercapture'});g.event('pointermove',{pointerId:5,clientX:900,clientY:100});assert.equal(g.run('cameraOrbit.yaw'),angle);assert(!g.run('dragLook'));
});
check('Character view also drags without mouse lock and normal captured combat aiming still turns',()=>{
 const g=setup();g.run('cursorFree=false;options.freeOrbit=true;globalThis.lockCalls=0;renderer.domElement.requestPointerLock=()=>{lockCalls++}');drag(g);assert(g.run('cameraOrbit.yaw')<-1);assert.equal(g.run('lockCalls'),0);
 g.run('options.freeOrbit=false;lockOn=false;document.pointerLockElement=renderer.domElement');g.event('mousemove',{movementX:100,movementY:0});assert(g.run('yaw')<0);
});
console.log(JSON.stringify({scope:'Build 12 simulated pointer drag, angle persistence and combat camera regression. Browser pointer capture remains unverified.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
