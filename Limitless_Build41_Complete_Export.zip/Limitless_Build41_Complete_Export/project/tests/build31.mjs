import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[];
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(){const g=createGame();g.run('selectedCharacter="mahito";selectedMap="harbor";resetMatch("duel");for(const p of pieces)p.alive=p.m.visible=false;player.pos.set(0,25,0);enemy.pos.set(0,25,-30);enemy.stun=999;player.ult=100;yaw=pitch=0;');return g;}
check('Hands unfurl during startup behind every facing direction, with linked branching forearms',()=>{
 for(const angle of [0,Math.PI/2,Math.PI,Math.PI*1.5]){const g=game();g.ctx.angle=angle;g.run('yaw=angle;castDomain(player);castFor(player).t=.25;updateMahitoVisuals(0);globalThis.r=mahitoAmalgams[0];const m=new THREE.Matrix4();r.hands.palm.getMatrixAt(0,m);globalThis.early=new THREE.Vector3().setFromMatrixScale(m).length();castFor(player).t=1.5;updateMahitoVisuals(0);r.hands.palm.getMatrixAt(0,m);globalThis.late=new THREE.Vector3().setFromMatrixScale(m).length();r.g.updateMatrixWorld(true);globalThis.behind=r.g.localToWorld(V(0,MAHITO_AMALGAM.hubHeight,-MAHITO_AMALGAM.rear)).sub(player.pos).dot(aimFor(player));');assert(g.run('r.g.visible&&!domain&&early<late*.3&&behind<-10&&r.hands.palm.count===24&&r.branches.count===55&&r.seals.every(s=>s.visible)'));
 }
});
check('Formation survives sealing at its original position; walking and turning do not drag the realm',()=>{
 const g=game();g.run('castDomain(player);castFor(player).t=1.5;updateMahitoVisuals(0);globalThis.r=mahitoAmalgams[0];globalThis.id=r.g.id;globalThis.anchor=r.g.position.clone();activateDomain(player);domain.t=.02;updateMahitoVisuals(.016);player.pos.x+=12;yaw=1.2;updateMahitoVisuals(.016);');assert(g.run('r.g.id===id&&r.age>=1.55&&r.g.position.distanceTo(anchor)===0&&r.g.visible&&r.seals.every(s=>!s.visible)&&r.axis.z===-1'));
});
check('Interrupted casts retract, pause freezes retraction, and reset reuses geometry without ghost hands',()=>{
 const g=game();g.run('castDomain(player);castFor(player).t=.8;updateMahitoVisuals(0);globalThis.r=mahitoAmalgams[0];globalThis.geoId=r.hands.palm.geometry.id;hurt(player,12,enemy,"special");updateMahitoVisuals(.15);phase="pause";globalThis.fade=r.exit;updateMahitoVisuals(1);');assert(g.run('!castFor(player)&&r.exit===fade&&r.g.visible'));
 g.run('phase="play";updateMahitoVisuals(.4);');assert(g.run('!r.g.visible&&!r.active'));g.run('resetMatch("duel");player.ult=100;castDomain(player);updateMahitoVisuals(0)');assert(g.run('mahitoAmalgams[0].hands.palm.geometry.id===geoId&&mahitoFormationAnchors.size===1'));
});
check('Elevated and boundary casts use enclosure clipping; outsiders do not see interior formations',()=>{
 const g=game();g.run('player.pos.set(0,60,0);castDomain(player);castFor(player).t=1;updateMahitoVisuals(0);activateDomain(player);updateMahitoVisuals(.016);globalThis.r=mahitoAmalgams[0];');assert(g.run('r.g.position.y===60&&r.materials.every(m=>m.userData.domainClip.center.y===61.45&&m.userData.domainClip.radius<54)'));
 g.run('domain.capturedIds=domain.capturedIds.filter(id=>id!==player.id);updateMahitoVisuals(.016)');assert(!g.run('r.g.visible'));
});
check('Three Mahitos keep separate formations in clashes; only the winner remains after resolution',()=>{
 const g=game();g.run('matchSetup.bots=["mahito","mahito"];resetMatch("duel");for(const f of bodies){f.pos.set(f.slot*8,25,0);f.ult=100;f.stun=0;f.input.yaw=f.slot;}castDomain(player);castDomain(enemy);castDomain(bodies[2]);clash.t=.8;for(const f of bodies)f.castVoiceAge=.8;updateMahitoVisuals(0);');assert(g.run('clash.participants.length===3&&mahitoAmalgams.slice(0,3).every(r=>r.active&&r.g.visible)&&new Set(mahitoAmalgams.slice(0,3).map(r=>r.origin.x)).size===3'));
 g.run('activateDomain(bodies[2]);updateMahitoVisuals(.4)');assert(g.run('mahitoAmalgams[2].g.visible&&!mahitoAmalgams[0].g.visible&&!mahitoAmalgams[1].g.visible'));
});
check('Host/guest retain the same cast anchor even after aim and position change; malformed formation packets fail',()=>{
 const host=game();host.run('net.role="host";mode="online";yaw=.7;castDomain(player);castFor(player).t=1;updateMahitoVisuals(0);activateDomain(player);player.pos.x=18;yaw=2;');const guest=createGame();setupReplica(host,guest);guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);updateMahitoVisuals(0);globalThis.r=mahitoAmalgams.find(r=>r?.owner===enemy.id);');assert(guest.run('r.origin.x===0&&Math.abs(r.axis.x+Math.sin(.7))<.001&&r.g.visible'));
 guest.run('packet.mahito.formations[0].dir=[0,0,0]');assert(!guest.run('validState(packet)'));guest.run('packet.mahito.formations[0].dir=[0,0,1];packet.mahito.formations[0].owner="bad"');assert(!guest.run('validState(packet)'));
});
check('Geometry and appearance are deterministic at 30/60/120 Hz, with no new scene nodes per frame',()=>{
 const poses=[];for(const hz of [30,60,120]){const g=game();g.ctx.hz=hz;g.run('castDomain(player);for(let i=0;i<hz;i++){castFor(player).t=(i+1)/hz;updateMahitoVisuals(1/hz);}globalThis.r=mahitoAmalgams[0];globalThis.ids=[];r.g.traverse(o=>ids.push(o.id));globalThis.mat=Array.from(r.hands.palm.instanceMatrix.array);for(let i=0;i<60;i++)updateMahitoVisuals(1/60);globalThis.next=[];r.g.traverse(o=>next.push(o.id));');assert(g.run('ids.length===next.length&&ids.every((id,i)=>id===next[i])'));poses.push(g.run('mat'));}
 for(let i=1;i<poses.length;i++)assert(poses[0].every((x,k)=>Math.abs(x-poses[i][k])<1e-5));
});
check('Complete frame path shows formation without changing damage and keeps the existing private cast camera',()=>{
 const g=game();g.run('castDomain(player)');g.advance(.8);assert(g.run('mahitoAmalgams[0].g.visible&&!!castFor(player)&&domainOrbitVisible()&&enemy.hp===1000'));g.advance(.9);assert(g.run('domain.owner===player&&mahitoAmalgams[0].g.visible&&enemy.hp===1000'));g.run('resetMatch("duel");ensureActorRig(enemy,"mahito");enemy.ult=100;enemy.stun=0;castDomain(enemy);updateMahitoVisuals(.1);');assert(g.run('mahitoAmalgams[1].g.visible&&!domainOrbitVisible()'));
});
console.log(JSON.stringify({scope:'Actual Three.js transforms, simulation and host/guest snapshots. No browser/FPS measurement.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
