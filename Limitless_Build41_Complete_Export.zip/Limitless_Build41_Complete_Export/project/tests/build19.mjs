import assert from 'node:assert/strict';
import {createGame,setupReplica} from './harness.mjs';
const results=[],near=(a,b,t=.015)=>assert(Math.abs(a-b)<t,`${a} != ${b}`);
function check(name,fn){try{fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.stack});}}
function game(){const g=createGame();g.run('selectedCharacter="naruto";matchSetup.bots=["gojo"];resetMatch("duel");countdown=0;player.pos.set(0,.12,0);enemy.pos.set(80,.12,80);enemy.stun=999;player.energy=100;player.stamina=100;yaw=0;pitch=0;');return g;}
function step(g,n,dt=1/60){g.ctx.n=n;g.ctx.dt=dt;g.run('for(let i=0;i<n;i++){updateControlled(player,dt);animateFighter(player,dt);updateNarutoVisuals(dt);}');}
function wall(g){g.run('globalThis.wall=pieces.find(p=>p.solid&&p.alive&&p.size.y>3&&p.size.x>2&&p.size.z>2);player.pos.set(wall.pos.x+wall.size.x/2+.46,wall.pos.y-wall.size.y/2+1.5,wall.pos.z);player.grounded=false;player.vel.set(0,0,0);narutoMobility(player).wasGrounded=false;yaw=Math.PI/2;keys.add("KeyW");keys.add("ShiftLeft");');}
check('Free first jump; chakra-limited paid boosts with no cooldown and landing reset',()=>{
 const g=game();g.run('globalThis.dustCount=0;const originalFX=narutoFX;narutoFX=(kind,...args)=>{if(kind==="dust")dustCount++;originalFX(kind,...args);};');assert(g.run('jumpFighter(player)'));near(g.run('player.energy'),100);near(g.run('player.stamina'),100);step(g,12);
 for(let i=0;i<7;i++){assert(g.run('jumpFighter(player)'));near(g.run('player.energy'),95-i*5);step(g,34);assert.equal(g.run('player.narutoMobility.uses'),i+1);}
 step(g,240);assert(g.run('player.grounded'));near(g.run('player.narutoMobility.uses'),0);near(g.run('player.narutoMobility.wallSpent'),0);near(g.run('player.energy'),65);assert(g.run('dustCount>0'));
});
check('Rejected boost spends nothing; hit interruption cannot refund the airtime budget',()=>{
 const g=game();g.run('player.grounded=false;player.pos.y=8;player.energy=4');assert(!g.run('jumpFighter(player)'));near(g.run('player.energy'),4);near(g.run('player.narutoMobility.uses'),0);
 g.run('player.energy=100;player.pos.y=WORLD.ceiling-1');assert(!g.run('jumpFighter(player)'));near(g.run('player.energy'),100);
 g.run('player.pos.y=8;jumpFighter(player);hurt(player,1,enemy,"special")');near(g.run('player.narutoMobility.kind'),0);near(g.run('player.narutoMobility.uses'),1);near(g.run('player.energy'),95);step(g,20);near(g.run('player.narutoMobility.uses'),1);
});
check('Anticipation delays kickoff and all inputs share the existing jump action',()=>{
 const g=game();g.run('player.pos.y=10;player.grounded=false;actionFor(player,"jump",true);actionFor(player,"jump",false);');step(g,4);assert(g.run('player.vel.y<0'));near(g.run('player.narutoMobility.t'),4/60);step(g,3);assert(g.run('player.vel.y>8&&player.vel.y<AIR_STEP.impulse'));assert(g.run('narutoVisuals.clones.some(c=>c.active&&c.pose.boost)'));step(g,18);assert(g.run('narutoVisuals.clones.every(c=>!c.active)'));
 const touch=g.document.querySelectorAll('[data-action]').find(e=>e.dataset.action==='jump');assert(touch);assert.equal(touch.textContent,'JUMP / BOOST');assert(g.elements.get('flightHint').innerHTML.includes('Wall Run'));
});
check('Sprint boost keeps full lift and travels along the committed input into empty space',()=>{
 const g=game();g.run('player.pos.y=10;player.grounded=false;keys.add("KeyD");keys.add("ShiftLeft");jumpFighter(player);keys.clear();');step(g,34);near(g.run('player.pos.x'),15.08);near(g.run('player.pos.z'),0);assert(g.run('player.pos.y>12'));near(g.run('enemy.hp'),1000);near(g.run('player.narutoMobility.kind'),0);
});
check('Chakra Dash uses the original dodge action, exact costs and shared 1.5s cooldown',()=>{
 const g=game();g.run('keys.add("KeyW");actionFor(player,"dodge",true);actionFor(player,"dodge",false);keys.clear();');near(g.run('player.energy'),96);near(g.run('player.stamina'),86);near(g.run('player.dodge'),.34);near(g.run('player.dodgeWindow'),.2);step(g,4);near(g.run('player.pos.z'),0);step(g,17);near(g.run('player.pos.z'),-7.5);assert(!g.run('dodge(player)'));step(g,71);assert(g.run('dodge(player)'));near(g.run('player.energy'),92);
 const h=game();h.run('player.energy=3;dodge(player)');near(h.run('player.stamina'),100);near(h.run('player.dodge'),0);
});
check('Ground and air dashes are timestep-stable; air dashes never add lift or reset boosts',()=>{
 for(const hz of [30,60,120]){const g=game();g.run('player.pos.y=10;player.grounded=false;player.vel.y=-1;narutoMobility(player).uses=3;narutoMobility(player).wasGrounded=false;dodge(player)');step(g,Math.round(.4*hz),1/hz);near(g.run('player.pos.z'),7.5);assert(g.run('player.pos.y<10&&player.vel.y<0'));near(g.run('player.narutoMobility.uses'),3);}
});
check('Shared perfect-dodge and immunity rules apply, and mobility prevents overlapping moves',()=>{
 const g=game();g.run('player.hp=900;dodge(player);startCharge(3);lightAttack(player);castDomain(player);');assert.equal(g.run('chargeFor(player)'),null);assert.equal(g.run('castFor(player)'),null);near(g.run('pendingHits.length'),0);g.run('hurt(player,100,enemy,"light")');near(g.run('player.hp'),915);assert(g.run('enemy.stun>0'));step(g,15);g.run('hurt(player,100,enemy,"special")');near(g.run('player.hp'),915);step(g,7);g.run('hurt(player,10,enemy,"special")');near(g.run('player.hp'),905);
});
check('Swept dash and directional boost cannot tunnel through thin scenery or the white barrier',()=>{
 for(const boost of [false,true]){const g=game();g.ctx.boost=boost;g.run('globalThis.wall=pieces.find(p=>p.solid&&p.alive&&p.size.y>3);player.pos.set(wall.pos.x+wall.size.x/2+1,wall.pos.y-wall.size.y/2+1.5,wall.pos.z);player.grounded=false;yaw=Math.PI/2;keys.add("KeyW");if(boost){keys.add("ShiftLeft");jumpFighter(player);}else dodge(player);keys.clear();');step(g,20,1/30);assert(g.run('player.pos.x>=wall.pos.x+wall.size.x/2+.42'));}
 const g=game();g.run('player.pos.set(0,.12,56);enemy.pos.set(0,.12,0);activateDomain(enemy);keys.add("KeyW");dodge(player);keys.clear();');step(g,24);assert(g.run('player.pos.z>=54.6'));
});
check('Wall attachment needs a real vertical surface and held sprint, with a smooth climbing ramp',()=>{
 const g=game();wall(g);g.run('keys.delete("ShiftLeft")');step(g,1);near(g.run('player.narutoMobility.kind'),0);g.run('keys.add("ShiftLeft");globalThis.y0=player.pos.y');step(g,1);near(g.run('player.narutoMobility.kind'),3);assert(g.run('player.vel.y<1'));step(g,25);assert(g.run('player.pos.y>y0+.7'));near(g.run('player.pos.x-wall.pos.x-wall.size.x/2'),.46,.04);near(g.run('player.energy'),100);assert(g.run('player.stamina<97'));assert(g.run('player.narutoMobility.wallSpent>.4'));
});
check('Wall run moves tangentially; releasing and reattaching does not restore spent stamina',()=>{
 const g=game();wall(g);step(g,2);g.run('keys.delete("KeyW");keys.add("KeyD");globalThis.z0=player.pos.z');step(g,18);assert(g.run('Math.abs(player.pos.z-z0)>2'));const spent=g.run('player.narutoMobility.wallSpent');g.run('keys.clear()');step(g,1);near(g.run('player.narutoMobility.kind'),0);near(g.run('player.narutoMobility.wallSpent'),spent);step(g,16);
 wall(g);step(g,2);assert(g.run('player.narutoMobility.wallSpent>0.3'));const stamina=g.run('player.stamina');step(g,70);assert(g.run('player.narutoMobility.wallSpent>1.1'));assert(g.run('player.stamina')<stamina);
});
check('Wall run drops on destroyed terrain, attacks, stamina exhaustion, ground contact and Void',()=>{
 for(const cancel of ['wall.alive=false','startCharge(3)','player.stamina=0','player.grounded=true','player.stun=1']){const g=game();wall(g);step(g,3);near(g.run('player.narutoMobility.kind'),3);g.run(cancel);step(g,1);near(g.run('player.narutoMobility.kind'),0);}
 const g=game();wall(g);step(g,3);g.run('player.pos.set(0,4,0);enemy.pos.set(0,.12,0);activateDomain(enemy)');step(g,1);near(g.run('player.narutoMobility.kind'),0);assert(!g.run('jumpFighter(player)'));
});
check('A regular wall jump leaves the face without consuming a boost and preserves wall time',()=>{
 const g=game();wall(g);step(g,12);const spent=g.run('player.narutoMobility.wallSpent');g.run('yaw=-Math.PI/2');assert(g.run('jumpFighter(player)'));g.run('keys.clear()');step(g,30);near(g.run('player.narutoMobility.uses'),0);near(g.run('player.narutoMobility.wallSpent'),spent);assert(g.run('player.pos.x>wall.pos.x+wall.size.x/2+2'));
});
check('The same wall query works with vertical collision pieces on all three maps',()=>{
 for(const map of ['district','harbor','sanctuary']){const g=game();g.ctx.arena=map;g.run('selectedMap=arena;resetMatch("duel");enemy.stun=999;player.energy=100;');wall(g);step(g,5);assert.equal(g.run('player.narutoMobility.kind'),3,map);}
});
check('Gojo flight remains 2 energy/s and Sukuna retains stronger unlimited 3-energy air steps',()=>{
 const g=game();g.run('selectedCharacter="gojo";resetMatch("duel");player.pos.set(0,20,0);player.flying=true;player.grounded=false;player.energy=100;player.stamina=100;');step(g,60);near(g.run('player.energy'),98);near(g.run('player.stamina'),100);
 g.run('selectedCharacter="sukuna";resetMatch("duel");player.energy=100;player.pos.set(0,10,0);player.grounded=false;');for(let i=0;i<7;i++){assert(g.run('jumpFighter(player)'));g.run('player.airJumpCooldown=0');}near(g.run('player.energy'),79);near(g.run('player.vel.y'),12.5);assert(g.run('NARUTO_MOBILITY.boost.impulse<AIR_STEP.impulse'));
});
check('Online state reconstructs clone, dash and wall animation without guest authority',()=>{
 const host=game();host.run('net.role="host";net.localId="p0";net.roster=[{id:"p0",character:"naruto",bot:false},{id:"p1",character:"naruto",bot:false}];beginOnline("naruto");countdown=0;for(const f of bodies){f.pos.set(0,10,0);f.grounded=false;f.stun=0;f.energy=100;}receiveInput({held:["jump"],edges:[["jump",true]],yaw:0,pitch:0,move:[0,0],mobility:{uses:0}},"p1");updateControlled(enemy,.1);');near(host.run('enemy.narutoMobility.uses'),1);near(host.run('narutoMobility(player).uses'),0);near(host.run('enemy.energy'),95);
 const guest=createGame();setupReplica(host,guest);
 function sync(){guest.ctx.packet=JSON.parse(host.run('JSON.stringify(onlineSnapshot())'));assert(guest.run('validState(packet)'));guest.run('receiveState(packet);updateReplica(.016);updateNarutoVisuals(.016);animateNaruto(player,.016);');}
 sync();near(guest.run('player.narutoMobility.uses'),1);assert(guest.run('narutoVisuals.clones.some(c=>c.active&&c.pose.boost)'));
 host.run('cancelNarutoMobility(enemy);enemy.airJumpCooldown=0;dodge(enemy);updateControlled(enemy,.1);');sync();near(guest.run('player.narutoMobility.kind'),2);near(guest.run('player.narutoMobility.dashCD'),host.run('enemy.narutoMobility.dashCD'));
 host.run('cancelNarutoMobility(player);player.dodge=0;');wall(host);step(host,3);sync();near(guest.run('enemy.narutoMobility.kind'),3);near(guest.run('enemy.narutoMobility.wallSpent'),host.run('player.narutoMobility.wallSpent'));
 guest.ctx.packet.actors[0].mobility.uses=-1;assert(!guest.run('validState(packet)'));sync();guest.ctx.packet.actors[0].mobility.wallSpent=-1;assert(!guest.run('validState(packet)'));sync();guest.ctx.packet.actors[0].mobility.dir=[Infinity,0,0];assert(!guest.run('validState(packet)'));
});
check('Pooled boost clones have no gameplay body or clash bonus and clean up on interruption/reset',()=>{
 const g=game();g.run('matchSetup.bots=["naruto","naruto","naruto","naruto","naruto"];resetMatch("duel");for(const f of bodies){f.pos.set(f.slot*4,10,0);f.grounded=false;f.energy=100;f.stun=0;jumpFighter(f);updateControlled(f,.1);}updateNarutoVisuals(.016);');near(g.run('bodies.length'),6);near(g.run('narutoVisuals.clones.filter(c=>c.active).length'),6);assert(g.run('narutoVisuals.cloneBatches.length<30'));assert(g.run('narutoVisuals.clones.filter(c=>c.active).every(c=>c.entries.every(e=>e.node.matrixWorld.elements.every(Number.isFinite)))'));g.run('for(const f of bodies)interruptNaruto(f);updateNarutoVisuals(.016);');near(g.run('narutoVisuals.clones.filter(c=>c.active).length'),0);g.run('resetMatch("duel")');assert(g.run('bodies.every(f=>!f.narutoMobility||f.narutoMobility.uses===0&&f.narutoMobility.kind===0)'));near(g.run('narutoVisuals.particles.life.length'),900);
});
check('Pause freezes mobility presentation; finish clears it; HUD exposes remaining resources',()=>{
 const g=game();g.run('player.pos.y=10;player.grounded=false;jumpFighter(player);');g.advance(.12);const t=g.run('player.narutoMobility.t');g.run('phase="pause"');g.advance(1);near(g.run('player.narutoMobility.t'),t);g.run('updateHUD()');assert(g.elements.get('narutoMobilityStatus').textContent.includes('CLONE BOOST · 5 CHAKRA'));g.run('phase="finish";finishNarutoPresentation(.016);updateNarutoVisuals(.016)');near(g.run('player.narutoMobility.kind'),0);near(g.run('narutoVisuals.clones.filter(c=>c.active).length'),0);
});
console.log(JSON.stringify({scope:'Build 19 actual movement/collision, real Three.js rigs/pools, simulated inputs and host/guest state. No browser/device FPS or Internet WebRTC claim.',results},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
