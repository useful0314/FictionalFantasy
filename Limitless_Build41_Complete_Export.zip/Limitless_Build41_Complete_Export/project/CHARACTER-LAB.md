# Limitless character lab

A separate concept page at `/character-lab.html`. The playable game's fighters, networking, maps, combat rules, balance and models are unchanged.

Six selectable articulated block models: Spider-Man, Levi Ackerman, Monkey D. Luffy, Son Goku, Ichigo Kurosaki and Toji Fushiguro. Each has three signature move studies and a mobility study on a reusable training target. These are proposed game kits, not finalized balance or full character integrations.

## Use

- Select a fighter from the six cards.
- Drag the 3D stage to orbit; scroll to zoom. Orbit and Reset View buttons also control the camera.
- Click a move or press 1–4. Space replays the last move; arrow keys change candidates.
- Play Full Kit cycles all four demonstrations.
- Sound is opt-in and synthesized locally. Reduced Motion removes shake and afterimages.
- Pick a fighter to save the choice in this browser. Copy My Pick copies a request to paste into chat; it does not send a message or modify the playable roster.

## Source

`src/lab/characters.js`: proposed kits, descriptions, colors and playstyle ratings.

`src/lab/models.js`: independently articulated model parts, costumes, hair, weapons and accessories, with proportions matching the current blocky roster.

`src/lab/animation.js`: eased wind-up/action/recovery poses and character-specific move effects.

`src/lab/engine.js`: camera/input, animation blending, effects and particle pools, synthesized audio, target reactions and selection.

`src/lab/index.html`: responsive page and controls.

The only hook into the existing build is an additive output in `build.py --site`. It assembles the lab and embeds the same vendored Three.js library. No third-party image/video service or new paid plugin is used.

## Validation

`node tests/character-lab.mjs` exercises all 24 move demos, verifies finite model/effect transforms, bounded particles, mobility, selection, copying and the kit tour. Model silhouettes were also inspected using a static projection of the actual geometry.

Full browser rendering, touch hardware and on-device frame rate were not verified in this environment. The model projection is not a browser screenshot.
