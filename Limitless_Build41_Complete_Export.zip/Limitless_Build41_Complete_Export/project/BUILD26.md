# Build 26 — Mahito polish and shared dodges

Published game: https://limitless.useful0314.chatgpt.site

Refresh every player in a private room. This build uses `limitless-26.0` / `limitless26-` so older clients cannot join with incompatible hand/cooldown snapshots.

## What changed

Mahito has a clean bevelled-block body with independently jointed arms, elbows, hands, fingers, legs and knees. His sewn tunic, face stitches, mismatched eyes and layered blue hair remain visible. Blades have a curved silhouette; guns have distinct receivers, barrels and muzzle openings; hammers have broad striking faces; wings use a continuous membrane. Morphed humans use matching block parts, and the serpent has overlapping armour segments, an open toothed jaw and segment orientation along its actual traveled path.

Weapon swings and all six techniques have distinct anticipation, action and settling poses. Shared animation blending is 90ms for Mahito, with eased motion and slight impact overshoot. Hair and tunic hems lag the body. The serpent pose raises Mahito onto the creature. Existing running, falling, guarding, dodging, hit reactions, wall movement and ragdolls retain priority through the same animator. Form/weapon size changes blend over the existing 100ms transition.

## Pursuing domain hands

The enclosing sphere has **224 articulated background hands**, or **96 on low quality**, plus **four pursuing hands per captured opponent**, bounded at **20** in a six-player match. Each hand has a shaped palm, wrist, forearm, four three-segment fingers, a two-segment thumb and stitched palm lines. The pursuing hands grow into view, reach toward the opponent, curl on contact, then withdraw before returning from another angle.

Attack values come directly from `src/mahito-domain.js`:

```js
handsPerEnemy:4,maxHunters:20,damage:24,windup:.55,stagger:.16,
chaseSpeed:23,turnSpeed:7,chaseTime:2.4,recovery:.70,
spawnRadius:8.5,hitRadius:1.32,knockback:3,handScale:.72
```

A hit deals **24 damage** through the existing domain damage path. Guard's existing 45% reduction makes that **13.2 damage**. A dodge avoids the contact; Naruto's successful substitution still uses its existing effect. A hand attempts damage once per contact, then recovers. Hands chase in three dimensions, target only captured rivals, and never target Mahito himself. They cannot damage anyone outside the barrier. They stop on domain end, owner death, victim elimination or match reset. Domain clashes display the surrounding hands but do not spawn these attacks until Mahito wins and his domain activates.

The pursuing hands do **ordinary damage**. Mahito's own successful melee/Cursed Touch inside his domain still uses the existing lethal-touch mechanic. Practice immunity, Impossible AI immunity, domain meter costs, 12-second duration, clash rules and 15-second burnout are unchanged. The earlier optional balance proposals remain unapplied.

## Dodge changes for all four characters

`src/game.js` now defines:

```js
const DODGE={cooldown:1.5,impulse:36,duration:.34,perfect:.20};
```

All dodges/dashes use a **1.5-second cooldown measured from activation**. Gojo, Sukuna and Mahito's impulse rises from 22 to 36, adding approximately two world units of travel during the active dodge window (about 2.15 units in the 60Hz simulation). Naruto's existing eased chakra dash changes from **5.5m to 7.5m**, with `cooldown:DODGE.cooldown` in `src/naruto-mobility.js`.

The original **0.34-second invulnerability** and **0.20-second perfect-dodge** windows remain, as do resource costs. The new cooldown is reset with the match and replicated to guests. Desktop/mobile HUD labels show remaining time. Longer normal dodges reuse the existing swept city-collision helper to avoid passing through thin walls. This changes the bound Dodge action; Gojo's teleport and Sukuna's Cursed Rush remain separate techniques.

## Source hooks

| Source | Purpose / connection |
| --- | --- |
| `src/mahito-model.js` | Existing Mahito factory contract; shared bevelled block geometry; weapons, wings, face and secondary motion. |
| `src/mahito-animation.js` | New Mahito pose helper, called by the existing `animateFighter` before guard/hit/wall/ragdoll overrides. |
| `src/mahito-hands.js` | New reusable instanced hand builder: palm/forearm, finger segments and details use three draws per batch. |
| `src/mahito-domain.js` | New Mahito-only host simulation, contact damage, state validation and smooth guest display. Called by the existing Mahito branch in `updateDomains`. |
| `src/mahito-vfx.js` | Existing backdrop/clash integration, new hand batches, block summons and armoured serpent. |
| `src/mahito.js`, `src/session.js` | Hand snapshots through existing host/guest packets; shared dodge cooldown replication. |
| `src/game.js`, `src/naruto-mobility.js` | Shared cooldown/dodge travel tuning, HUD and swept collision hook. |
| `build.py`, `tests/harness.mjs` | Register the three new Mahito helper files alongside the existing kit. |

No manual input registrations, paid assets or plugins are needed. The hand meshes and per-hand simulation state are bounded and reused. Low quality reduces decorative hands only; it does not remove attacks.

## Verification

**63 check groups passed**: Build 26 (10), Build 25 (14), Build 14 (16), Build 23 (18), Build 24 (5). Build 26 covers all four cooldowns, extra travel, thin-wall/barrier collision at 30/60/120Hz, per-opponent hand assignment, airborne pursuit, one contact per recovery, guard/dodge behavior, clash/end/death cleanup, bounded six-fighter pools, finite/blended animation states and host/guest validation.

Native OpenGL geometry previews were inspected for the model, face, all arm forms, wings, hands, the serpent and hammer anticipation/impact/recovery. These are isolated scene previews, not browser screenshots. Browser play, phone/controller hardware and actual 60fps performance have not been verified in this environment.
