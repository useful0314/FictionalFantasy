# Build 32 — Maximum Output Limitless effects

This pass uses the supplied Blue animation as a timing and motion reference. Its defining idea is a controlled moving gravity well: energy converges into a bright core, debris and motes move inward while orbiting, the caster continues guiding it after release, and the finish leaves a readable flash and aftermath. The supplied clip contains Blue only, so Red and Purple extend the same visual grammar: Red reverses the flow into repulsion, while Purple braids Blue and Red around a white-violet core.

## Blue control

Blue now responds to aim with a `10.5` exponential steering rate immediately after release. Its guided path is `22–34m`, based on charge, at the original `12m/s`. Path length is accumulated directly, so sharp curves cannot keep the first phase alive forever. At the end of that path, Blue enters a `1.25s` sweep/lift phase with a `14.5` steering rate and `14–18m/s` movement. A second Blue press still anchors it immediately; the anchored field still lasts three seconds.

Gojo keeps an open-palm guidance pose while the released Blue travels and lifts his leading arm through the sweep phase. The pose uses the existing animation blend and aim pitch, including remote fighters. Blue can rise to the arena ceiling instead of being clamped at 25m.

The following gameplay values are unchanged:

- Blue costs, charge/startup timing, `24` maximum center DPS, `4–9m` attraction radius, `1.2–3.7m` inner lock and three-second anchor.
- Red's `140` maximum damage, hitscan/terrain rules, `2.6–7m` hit radius and Red-to-owned-Blue fusion priority.
- Purple's `280` maximum damage, `29m/s` speed, `2.8s` life, `1.4–3.2m` hit radius, barrier stop and ability to hit several different fighters once each.
- Hollow Bomb's three-second warning, damage, `60–115m` radius and caster knockback.

## Presentation

`src/combat-vfx.js` groups the new tuning in `LIMITLESS_OUTPUT`. Blue, Red and Purple now each use a stable technique rig with layered emissive shells, near-white cores, orbit ribbons, deep-color contrast halos, electric line fields and a shader-driven particle pool. Full-quality pools use 160 Blue motes, 132 Red motes and 180 Purple motes; Performance mode uses smaller pools/draw ranges. These points are allocated once per stable technique ID and animated in the vertex shader.

- **Blue:** cyan/white motes spiral inward, navy haze frames the core, multiple ribbons turn at different speeds, and the field pulses more strongly while anchored. Release gets a separate convergence flash.
- **Red:** the hand charge is larger and denser. Release creates a white-hot beam, expanding rings and an outward particle wave. The impact presentation grows beyond the gameplay hit sphere without changing collision.
- **Purple:** separate red and blue lobes orbit its white-violet core. A long braided wake follows the projectile. Release and first contact each have dedicated flashes, crossed shock planes, rings, bolts and a lingering violet afterimage.

The dense travel fields do not call the ordinary `particles()` or `trail()` allocator per mote. Host and guest reuse the same keyed rigs. One-shot release/impact events are whitelisted for network replay and cannot change guest health.

## Files and networking

- `src/game.js`: Blue guidance, persistent hand pose hooks, Red beam calls, Purple release/contact calls and updated player instructions.
- `src/combat-vfx.js`: grouped tuning, pooled shader particles, larger persistent rigs and one-shot effects.
- `src/technique-startup.js`: released-Blue guidance pose.
- `src/session.js`: Blue control fields and new replay-safe VFX names.
- `src/network.js`: Build 32 protocol, `limitless-32.0` / `limitless32-`.
- `tests/build32.mjs`: focused control, balance, VFX pooling, online continuity and cleanup checks.

All private-room players must refresh to Build 32.

## Validation

- Build 32: 8 focused checks pass.
- Technique VFX: 9 checks pass, including finite geometry, host/guest replay and cleanup.
- Builds 31, 30, 26 and 25: 39 retained checks pass.
- All three new particle shader variants compile and link with headless Mesa GLES.
- The standalone Site bundle rebuilds successfully.

The automated checks cover simulation, scene state, shader compilation and networking. Sustained device frame rate and live Internet WebRTC remain device-dependent.
