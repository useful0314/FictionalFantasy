from pathlib import Path
import base64
import sys
root=Path(__file__).parent
html=(root/'src/index.html').read_text()
css=(root/'src/style.css').read_text()+'\n'+(root/'src/cutouts.css').read_text()+'\n'+(root/'src/naruto.css').read_text()+'\n'+(root/'src/mahito.css').read_text()+'\n'+(root/'src/presentation.css').read_text()+'\n'+(root/'src/combat-feel.css').read_text()
js=(root/'src/game.js').read_text()
js=js.replace('/*BLOCK_MODELS*/',(root/'src/block-models.js').read_text())
js=js.replace('/*NARUTO*/','\n'.join((root/('src/'+name+'.js')).read_text() for name in ['spiderman','spiderman-model','spiderman-animation','spiderman-vfx','mahito','mahito-model','mahito-animation','mahito-hands','mahito-domain','mahito-transfiguration','mahito-amalgamation','mahito-vfx','naruto','naruto-model','naruto-animation','naruto-vfx','naruto-mobility','wall-motion','naruto-speedlines','naruto-substitution']))
js=js.replace('/*FINISHERS*/',(root/'src/finishers.js').read_text())
js=js.replace('/*ANIMATION*/','\n'.join((root/('src/'+n+'.js')).read_text() for n in ['air-combat','light-combo','animation-polish','animation']))
js=js.replace('/*MAPS*/',(root/'src/maps.js').read_text()+'\n'+(root/'src/map-metro.js').read_text())
js=js.replace('/*CITY*/',(root/'src/city.js').read_text())
js=js.replace('/*COMBAT_SYSTEM*/','\n'.join((root/('src/'+name+'.js')).read_text() for name in ['combat-system','combat-response','sukuna-world-cut','sukuna-world-cut-vfx']))
js=js.replace('/*DOMAINS*/', (root/'src/domains.js').read_text()+'\n'+'\n'.join((root/('src/'+n+'.js')).read_text() for n in ['mindscape','mindscape-vfx','kurama-model','kurama-domain','domain-cinematics','domain-mixed','domain-burnout','mindscape-sphere','mindscape-clones']))
js=js.replace('/*BARRIERS*/', (root/'src/barriers.js').read_text())
js=js.replace('/*COMBAT_VFX*/', (root/'src/combat-vfx.js').read_text())
js=js.replace('/*TECHNIQUE_STARTUP*/', (root/'src/technique-startup.js').read_text())
js=js.replace('/*ROSTER*/',(root/'src/roster.js').read_text()+'\n'+(root/'src/roster-health.js').read_text())
js=js.replace('/*CUTOUTS*/',(root/'src/cutouts.js').read_text())
js=js.replace('/*PRESENTATION*/',(root/'src/presentation.js').read_text()+'\n'+(root/'src/combat-feel.js').read_text()+'\n'+(root/'src/battle-readability.js').read_text())
js=js.replace('/*SESSION*/', (root/'src/session.js').read_text())
three=base64.b64encode((root/'vendor/three.module.js').read_bytes()).decode()
js=js.replace("'../vendor/three.module.js'", "'data:text/javascript;base64,"+three+"'")
out=root/'Limitless-Arena.html'
notice=(root/'THIRD-PARTY-NOTICES.txt').read_text()
content=html.replace('/*STYLE*/',css).replace('/*SCRIPT*/',js)
import json
assets={key:'data:'+mime+';base64,'+base64.b64encode((root/path).read_bytes()).decode() for key,path,mime in [
    ('clash','assets/audio/domain-clash.mp3','audio/mpeg'),
    ('sukunaDomain','assets/audio/sukuna-domain.mp3','audio/mpeg'),
    ('hollowNuke','assets/audio/hollow-nuke.mp3','audio/mpeg'),
    ('gojoCast','assets/audio/gojo-cast.mp3','audio/mpeg'),
    ('sukunaCast','assets/audio/sukuna-cast.mp3','audio/mpeg'),
    ('gojoTheme','assets/audio/gojo-theme.mp3','audio/mpeg'),
    ('stone','assets/textures/stone.png','image/png'),
    ('fabric','assets/textures/fabric.png','image/png')]}
helpers='window.ARENA_ASSETS='+json.dumps(assets)+';\n'
for name in ['vendor/peerjs.min.js','src/audio.js','src/controls.js','src/network.js']:
    helpers+=(root/name).read_text()+'\n;\n'
content=content.replace('/*HELPERS*/',helpers.replace('</script','<\\/script'))
content=content.replace('<head>', '<head><!--\n'+notice+'\n-->')
out.write_text(content)
if '--site' in sys.argv:
    (root/'dist').mkdir(exist_ok=True)
    (root/'dist/index.html').write_text(content)
    lab_js=(root/'src/lab/engine.js').read_text().replace('/*LAB_CHARACTERS*/',(root/'src/lab/characters.js').read_text()).replace('/*LAB_MODELS*/',(root/'src/lab/models.js').read_text()).replace('/*LAB_ANIMATION*/',(root/'src/lab/animation.js').read_text())
    lab_js=lab_js.replace("'../../vendor/three.module.js'", "'data:text/javascript;base64,"+three+"'")
    (root/'dist/character-lab.html').write_text((root/'src/lab/index.html').read_text().replace('/*LAB_SCRIPT*/',lab_js))
print(str(out),out.stat().st_size)
