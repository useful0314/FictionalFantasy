# Naruto mobility — Build 24

The complete implementation lives in `src/naruto-mobility.js`. It uses the existing jump/dodge actions, `updateControlled`, `moveFighter`, energy/stamina bars, shared damage/dodge rules, map collision pieces, barrier constraints, animation joints and Naruto particle/clone pools. All three characters share the wall-run cost and aimed jump-off; Gojo flight and Sukuna air-step tuning are unchanged.

## Controls and tuning

All values below are grouped in `NARUTO_MOBILITY` at the top of the helper. Times are seconds; distances are metres. Controls respect existing saved remaps, mobile buttons and gamepad actions.

| Movement | Existing control | Limits and cost | Timing / movement |
| --- | --- | --- | --- |
| Ground jump | Jump / Space / mobile Jump–Boost | Free | Existing 9 m/s vertical impulse and gravity 22 m/s² |
| Clone Boost | Press Jump again while airborne; hold up to 1.2 s, release to launch | 5 chakra; no cooldown or airtime cap | 0.08 s anticipation, 0.36–0.52 s action according to charge, 0.10 s recovery; 12 m/s upward impulse; 1.6–4.2 m stationary nudge or 4.6–8.5 m active travel while moving |
| Directional Clone Boost | Sprint + a direction + airborne Jump | Shares the same chakra cost; no cooldown | Full 12 m/s upward impulse; retains 26 m/s approach speed, with 10.4–15.9 m active travel according to hold charge; approach speed continues while gathering |
| Chakra Dash | Dodge / E / existing mobile dodge button | 14 stamina + 4 chakra; 0.85 s cooldown | 5.5 m; 0.07 s anticipation, 0.18 s action, 0.10 s recovery; existing 0.34 s dodge immunity and 0.20 s perfect window |
| Wall Run (all three characters) | Airborne Sprint toward a wall, then hold a direction along it or into it | 8 stamina/s total; no fixed duration, entry cost or chakra drain; 0.12 s collision reattach debounce | 0.12 s attachment blend; target 26 m/s along the wall + 3 m/s lift, or 11 m/s climb when pushing into it |

A new Jump press after launch can chain the next boost immediately; one press during the brief anticipation can buffer for 0.16 s. Holding Jump charges one boost and automatically releases at 1.2 s; it never repeatedly spends clones. Damage clears pending presses. Sprint boosts carry approach speed during anticipation and recovery; an eased speed pulse supplies the extra travel without braking to zero. The maximum open-space horizontal speed is about 35.2 m/s at full charge, below Gojo’s 36 m/s flying sprint.

Clone Boost spends only 5 chakra and no stamina, including while Sprint is held; it also works with empty stamina. Ordinary sprint and wall running retain their stamina drain. Practice keeps its existing unlimited energy refill, but stamina drain and the Chakra Dash cooldown remain enforced. A dash with no movement input goes backward, matching the original dodge. Camera/movement input, rather than nearby enemies, chooses the boost/dash direction. Launch direction is committed at startup.

Landing on arena ground or an existing platform clears the diagnostic use counter; it is no longer a gameplay limit. Touching a wall, switching to another intact floor, releasing Sprint, reattaching, taking a hit or using Chakra Dash does not reset them. Cooldowns continue after landing. An interrupted boost still consumes its chakra. Wall jumps use a separate regular-jump state: no clone, no boost use, no energy or stamina charge. They do not restore spent stamina. The shared jump follows the camera direction, including pitch. Along-wall or inward aim is redirected to preserve the run direction with a minimum .18 outward horizontal share; anticipation preserves run speed, and steep pitch retains existing horizontal speed. Level aim gives 13.5 m/s lift; vertical aim adds up to 20 m/s before clamping lift to −9…22 m/s. Horizontal push scales with the aim direction and peaks at about 27.9 m/s for level aim, then settles into current movement input. Its 8.5 m distance tuning shapes the push speed; exact travel also depends on approach and recovery input. It has 0.12 s anticipation, 0.42 s action and 0.16 s recovery; reattachment is blocked through those phases. A tangible, intact attached wall is required.

Gravity continues during dash startup, action and recovery. Chakra Dash adds no vertical lift. Clone Boost sets its upward impulse only after the anticipation pose. Wall Run cannot attach to the domain sphere: it uses the same solid map boxes as existing character collision. It stops on broken scenery, a missing face, release of Sprint, exhausted stamina, a charge/attack/guard/recharge, damage, ragdoll, knockout or Infinite Void suppression. Intact adjacent floor pieces can continue the same run while continuing the same stamina drain.

These are finite extensions of ordinary movement: 12 m/s boosts at 5 chakra each versus Sukuna’s stronger 12.5 m/s air steps at 3 energy; no hovering or flight toggle; a short 5.5 m dodge rather than sustained Gojo flight. Existing Gojo flight still drains 2 cursed energy/s; Sukuna air steps still cost 3 energy. This is an initial balance configuration, not a claim of competitive playtest results.

`src/wall-motion.js` supplies the shared wall velocity blend and swept jump-off motion. Gojo and Sukuna reuse the existing wall states, input and stamina bar; their wall poses blend through `src/animation.js`, including Sukuna’s lower arms. Gojo cannot attach while flight is active.

## Animation and VFX

`NARUTO_MOBILITY_POSES` defines the gather, kickoff, supporting-clone and dash poses. It uses the existing `narutoEase`, `narutoBack` and `animateNaruto` joint blending. `NARUTO.blend = 0.052` is the exponential time constant: about 120 ms to cover 90% of a pose transition. Existing secondary hair, jacket and headband-tail motion and landing compression/dust apply normally.

The clone appears in smoke under Naruto, crouches with raised arms, stretches into the kick and stays beneath him during the hold, then poofs 0.26 s into the release. It is a visual member of the existing 48-clone pool, never an extra fighter or a source of damage/clash points. Barrage and mobility cannot overlap on the same Naruto. The pool also reserves room for up to 30 Mindscape assault clones, with active draw counts.

Chakra Dash leaves a single existing `afterImage` plus blue/gold chakra and smoke emitted at a 0.03 s interval. Wall footsteps emit blue/gold particles at the feet. Trails reuse the 900-slot typed particle pool; pose arrays, vectors and instanced clone meshes are reused. White speed lines from `src/naruto-speedlines.js` stream opposite the actual wall motion or launch direction, fading in and out with the pose. One reused line mesh supports up to 12 streaks per fighter (6 on Low), with reusable position/opacity arrays and vector scratch space. No speed-line buffers or meshes are allocated per frame. There is no second animation loop. Event effects, snapshots and the pre-existing engine still allocate objects. Browser/device profiling is required to establish sustained 60 FPS.

## Narrow integration hooks

| Existing file | Hook added |
| --- | --- |
| `build.py`, `tests/harness.mjs` | Insert `naruto-mobility`, `wall-motion` and `naruto-speedlines` after the existing Naruto modules |
| `src/combat-system.js` | Route Naruto’s airborne `jumpFighter` to `requestNarutoAirJump`; its shared busy/status guards select a regular wall jump, boost or buffered press |
| `src/game.js` | Route Naruto’s dodge to `startNarutoChakraDash`; call `updateNarutoMobility` before ordinary walking and `finishNarutoMobilityStep` after shared physics; keep guarding disabled during a committed boost/dash; update the small resource readout |
| `src/naruto.js` | Include boost/dash in the existing busy gate; cancel on damage/finish and reset on match reset; extend the existing help text |
| `src/naruto-animation.js` | Apply movement poses through existing joint blending, wall-facing yaw and a support-clone pose; retain higher-priority hit/ragdoll/knockout reactions |
| `src/naruto-speedlines.js` | Separate pooled white streak helper, called by `updateNarutoVisuals` before Naruto-specific effects and hidden on reset |
| `src/naruto-vfx.js` | Fill unused instanced clone slots with boost clones and emit pooled mobility trails |
| `src/session.js` | Existing control hints plus host snapshot packing, validation and guest presentation state |
| `src/network.js` | Protocol/prefix `limitless-24.0` / `limitless24-` to prevent mixed-version rooms |
| `src/roster.js` | Let Naruto AI use the existing elevated-target jump decision; dodge and sprint already use shared actions |
| `src/index.html`, `src/naruto.css` | Build label and remaining boost/dash/wall readout inside the existing movable resource HUD |

No additional input registration, imported model, animation clip, audio file or paid plugin is needed. Online guests continue sending only input. The host owns movement, energy, counts and collision; snapshots carry the current mobility state so guests animate the same clone, dash and wall run. Timers pause with gameplay and cleanup follows the existing reset/finish paths.

## Verification

Run `node tests/build22.mjs` for shared walls, smoothing, chakra-only longer charge and online state, then `node tests/build23.mjs` for cooldown-free chaining, aimed wall jumps and the cheaper total wall drain, and `node tests/build21.mjs` for stamina/charged-input checks, `node tests/build20.mjs` for 16 reported-issue/city/mixed-realm checks and `node tests/build19.mjs` for the existing mobility suite (updated to the new distances and free wall jump). Its 17 scenarios cover chakra-only chaining, reset/cost/dash cooldown, anticipation and directional travel, three timestep sizes, perfect dodge, interruption, swept scenery/domain collision, all maps, wall attachment/release/seams/budgets, remote input and invalid snapshots, six pooled clones, pause/finish cleanup and preserved Gojo flight/Sukuna air-step costs. Existing `build17.mjs`, `build18.mjs` and `build14.mjs` cover the earlier Naruto attacks, domains/cameras and free-for-all/network systems.

The simulation uses real Three.js geometry and joints with a simulated DOM/renderer. Isolated native scene previews check pose composition. Neither is a browser gameplay test or a measurement of phone/controller behavior, Internet WebRTC latency or sustained frame rate.
