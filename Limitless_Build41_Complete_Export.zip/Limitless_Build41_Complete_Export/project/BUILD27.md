# Build 27 — block roster and animation polish

Game: https://limitless.useful0314.chatgpt.site

Refresh the game to see **BUILD 27**. All four playable characters use the same softly bevelled block style. No new controls, paid assets, plugins or manual registrations are required. The existing gameplay rules and `limitless-26.0` network packet format are preserved.

## Models

- **Gojo:** navy high-collar jacket, tailored coat panels, white block spikes, blindfold with knot/tails and visible blue eyes during domain casting.
- **Sukuna:** broader Heian torso, four independently jointed arms, chest/arm tattoos, four eyes, asymmetric face plate, abdominal mouth, light trousers and a dark sash.
- **Naruto:** orange/black raised-collar jacket, blond spikes, whiskers, engraved Leaf protector, articulated headband tails, back spiral, leg pouch and blue open-toe sandals. His pooled clones use this same model and joint contract.
- **Mahito:** retains the block model, stitches, hair, arm weapons, wings and body forms from Build 26. Ankles now have independent joints as well.

Heads, shoulders, elbows, hands, fingers, hips, knees and ankles remain separately animated. Mesh geometry is created in code; there are no external character-model or animation files to download. Shared block geometry is protected from afterimage cleanup.

## Animation coverage

| Path | Changes in this build |
| --- | --- |
| Idle / walking / sprinting | Character-specific ready stances, breathing, torso counter-rotation, weight shift, ankle roll, subtle squash/stretch, lagging hair and clothing. Naruto keeps his arms-back sprint. |
| Ground jump / air jump / falling / flight | Rise-to-fall pose transitions, flight lean that responds to speed, articulated feet and smoother shared blending. Existing jump/flight mechanics remain authoritative. |
| Landing / wall movement / dodge | Landing compression and pooled dust; softer transitions into existing wall-run, wall-jump, clone-boost and dash poses; revised shared dodge crouch/leg poses. |
| Light chain / counter / directional attacks | Distinct jab, cross, hook and finishing strike; readable chambers for side kick, uppercut, sweep and aerial slam; anticipation, contact hold and eased recovery use existing hit timers. |
| Gojo Blue / Red / Purple / Teleport | Reworked reach, point, convergence, recoil and release settling; charge particles remain attached to the existing hand anchors. |
| Sukuna Dismantle / Cleave / Furnace / Cursed Rush | Stronger wind-up and torso twist, crossed-arm opening, clearer bow draw/release, forward rush pose and settling. Upper/lower technique slots use separate cached pose buffers. |
| World Cutting Slash | Existing four-arm anticipation/strike/recovery track runs through the new block rig, shared blend and secondary-motion pass. Hitbox and timing are unchanged. |
| Naruto Clone Barrage / Uzumaki Combo | Matching clone rigs; earlier target poses account for the longer blend, with the spin occurring before the kick contact; punch, kick, uppercut and axe-kick retain their original damage events. |
| Naruto Rasengan / Rasenshuriken / Tailed Beast Bomb | Existing pose tracks gain the 85ms blend and new joints; throw/fire target poses are timed earlier for a cleaner release. Palm/hand-sign IK remains intact. Existing cinematic camera and VFX stay connected. |
| Mahito six moves / arm weapons / forms | Existing anticipation/action/recovery tracks are retained on the preferred block design. Shared locomotion, ankle motion, trails, domain hand placement and knockout polish apply to him too. |
| Domain casting | Cached two-bone IK brings Sukuna's upper/lower signs and Mahito's hands together; Gojo's raised fingers cross. Naruto keeps his existing sign IK. Hands ease into place over 140ms and release smoothly. Caster-only orbit and clash split-screen rules are unchanged. |
| Guard / energy charge / hit / ragdoll / knockout | More grounded guard and charging stances, existing recoil priorities, smoother blending, and centred knockout pivots so bodies lie down instead of rotating below the floor. |
| Afterimages / finishers | Ghosts snapshot the actual posed block limbs, including Sukuna's four arms. Finisher fragments use matching block geometry. Existing finisher timing and cameras remain intact. |

Motion trails sample moving hands and feet into the existing bounded Naruto particle pool. No new gameplay clone bodies, network messages, damage events or hit-stop rules are introduced.

## Exact visual tuning and source hooks

From `src/animation-polish.js`:

```js
const ROSTER_MOTION={blend:.085,sealBlend:.14,secondaryBlend:.13,
 landTime:.24,landSquash:.055,breath:.018,trailInterval:.045,
 trailMinDistance:.12,trailMaxDistance:2.6,ghostLife:.32};
```

The shared body blend is **85ms**, hand-sign entry **140ms**, secondary-motion blend **130ms**, and landing settling **240ms**. Mahito retains his existing 90ms main blend. Naruto's `NARUTO.blend` is now `.085`; his existing secondary blend stays `.12`.

From `src/technique-startup.js`:

```js
const TECHNIQUE_MOTION={snapTime:.09,settleStart:.48,breathe:.012};
```

Release targets snap over **90ms**, then settle during the latter portion of each existing release animation. These are visual constants, not attack startup, cooldown or damage changes.

| File | Hook |
| --- | --- |
| `src/block-models.js` | New shared geometry and Gojo/Sukuna/Naruto factory. Existing `fighterModel` and `fighterModelNaruto` wrappers call it. |
| `src/animation-polish.js` | New cached pose library, movement/light targets, secondary motion, limb trails, domain hand IK and posed afterimages. Called by existing animators. |
| `src/animation.js` | Existing Gojo/Sukuna/Mahito animator; preserves technique, wall, hit and ragdoll priorities. |
| `src/naruto-animation.js` | Existing Naruto/clone animator, action tracks, sign/palm IK and body/limb blending. |
| `src/mahito-model.js` / `src/mahito-animation.js` | Shared block geometry, articulated ankles and landing/casting integration; existing kit remains. |
| `src/technique-startup.js` | Cached per-slot charge/release pose targets; original startup/charge handling remains. |
| `src/naruto-vfx.js` | Existing instanced clone pool uses the replacement model. |
| `src/finishers.js` | Existing fragment effect uses shared blocks. |
| `build.py` / `tests/harness.mjs` | Register the two new helper files in the established concatenation workflow. |

The ordinary dodge definition is still:

```js
const DODGE={cooldown:1.5,impulse:36,duration:.34,perfect:.20};
```

Naruto's dash still travels 7.5m. Damage, resource costs, ultimate costs, cooldowns, collision shapes, movement speeds, hit-stop, wall momentum, domain damage, burnout, AI and player inputs are unchanged.

## Verification

**110 automated check groups passed:** Build 27 (10), Build 26 (10), Build 25 (14), Build 24 (5), Build 23 (18), Build 19 (17), Build 17 (20), Build 14 (16). The two old Build 19 dash expectations were updated to the already-shipped Build 26 values: 7.5m and a 1.5s cooldown.

The new checks exercise character switching, all light-chain/directional poses, charge/release anchors, simultaneous Sukuna techniques, Naruto hand-sign reach and clone instances, movement/defense/hit/knockout states, actual-pose ghosts and geometry cleanup, buffer/pool reuse, duplicate-character host/guest snapshots, and domain-hand contact/release. The retained suites cover combat damage, costs, domains, wall movement, dodges, Mahito's kit and Naruto's five techniques.

Native OpenGL previews were inspected for the roster, facial/outfit details, casting signs, bow draw, charged moves, combo poses and knockouts. The bundled HTML builds and its module passes syntax checking. These previews use the actual Three.js geometry and pose transforms, but they are isolated renders: full browser play, phone/controller hardware and a sustained 60fps target have not been verified in this environment.
