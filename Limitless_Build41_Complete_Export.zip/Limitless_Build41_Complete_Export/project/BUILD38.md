# Build 38 — Ground webs and sliding

**Aim at the ground and hold Web Swing (default 4) to slide toward your web.** The same saved binding, touch button and controller chord work. The ability hint reads: “Hold to swing or slide · let go to release”. The reticle shows SLIDE for a reachable surface below you and SLIDING while sliding.

Landing during a held building swing keeps the same web, timer, energy drain and horizontal velocity. Spider-Man blends into a low pose, with one leg extended, the other folded and his firing hand aimed at the anchor. He turns with his travel direction and leaves a pooled dust trail. Slide acceleration eases in, steering turns progressively and braking slows him near the attachment point. Existing speed lines and camera response remain active.

Let go to detach. Jump releases the web and uses the existing regular jump when grounded. Sliding off a rooftop resumes airborne web physics; contacting a supported surface returns to sliding. Destroyed anchors release the web, destroyed support returns him to airborne movement, and walls and domain barriers still constrain travel. A held slide stops on a blocking wall.

## Tuning

`SPIDER_SLIDE` is grouped at the top of `src/spiderman.js`.

| Constant | Value | Purpose |
| --- | ---: | --- |
| minReach | 2m | Minimum attachment distance for upward-facing surfaces |
| acceleration | 58m/s² | Maximum forward slide acceleration |
| brake | 95m/s² | Approach braking and target-speed calculation |
| steer | 24m/s² | Lateral steering acceleration |
| response | 160ms | Speed response |
| sideDrag | 1.6/s | Lateral damping |
| arrival | 1.6m | Target stopping gap |
| settle | 9/s | Damping close to the anchor |
| contactGap | 0.18m | Support tolerance during sliding |
| blend | 120ms | Slide-pose blend |
| dustInterval | 75ms | Minimum interval between dust emissions |
| dustColor | 0xb6b2a6 | Dust tint |

Existing Web Swing values remain: 125m maximum attachment reach, 68m/s speed cap, 4 energy to attach, 4 energy/s while held, 0.25s attachment cooldown and a 9s continuous attachment limit. Existing swing physics use steps of at most 1/120s. Wall attachments retain their 4m minimum reach.

## Source hooks

- `src/spiderman.js`: exact rendered ground/paving ray hits, cached static paving, `updateSpiderSlide`, surface-contact transitions, reticle/manual copy and serialized slide state. Destructible paving remains in the existing piece query. Invisible scenery and out-of-bounds ground cannot be selected.
- `src/spiderman-animation.js`: slide pose, smooth swing-to-slide blend, travel-facing orientation and ankle articulation. The existing arm aiming code keeps the hand directed toward the web.
- `src/spiderman-vfx.js`: dust uses the existing `narutoEmit` particle pool and cached vectors; existing web buffers are reused. Each local client renders its dust from replicated motion.
- `src/animation.js`: an active slide suppresses walking cycles and footsteps.
- `src/combat-system.js`: Jump detaches and continues through the existing grounded jump path during a slide.
- `src/game.js`, `src/session.js` and `src/index.html`: control hints and Build 38 labels.
- `src/network.js`: protocol `limitless-38.0`; everyone in a private room must refresh. `sliding` is validated as a boolean and allowed only for Web Swing actions. Existing captured camera rays and held-input reconciliation handle ground shots and release.

No additional dependencies, assets, inputs or particle pools are required.

## Verification

104 check groups passed: `build38` (16), `build37` (16), `build36` (11), `build35` (13), `online-controls` (15), `mechanics` (23) and `build27` (10).

New checks cover exact ground aiming on all four maps; too-close, distant, out-of-bounds and sky misses; ground launch without a hop; acceleration, braking and steering; continuous building-to-ground attachment; rooftop departure and street contact; immediate airborne ground contact; destroyed anchors and support; wall and domain constraints; release and Jump; pose blending, ankle motion and pooled dust; matching 30/60/120Hz trajectories; private-room snapshots and remote input; and complete frame-loop movement through the original streets.

The previous empty-scenery miss test now aims into open sky because visible ground is a valid anchor in this build. Rooftop tests account for web tension lifting the player after support disappears.

Browser/GPU/device visual QA was unavailable. These checks use real Three.js geometry and simulation state with synthetic input. They do not certify frame rate, subjective animation quality or public-network WebRTC performance.
