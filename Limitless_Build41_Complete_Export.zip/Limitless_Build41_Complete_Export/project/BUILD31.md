# Build 31 — Mahito's casting amalgamation

Reference: the uploaded `RPReplay_Final1791942660(1).mov` (11.63 seconds). Around 0–3 seconds the hand sign glows violet; around 7–9 seconds the arms unfurl; around 9–11 seconds a large curled hand and intertwined palms loom behind Mahito. This revision adapts that composition to the game's existing blocky models.

The formation starts during the existing 1.55-second vulnerable cast. Twenty-four jointed hands open in staggered waves from a joined core, connected by branching forearms. The silhouette has uneven spacing, depth, and a large curled palm above the caster. It is placed behind the direction Mahito faced when casting. Small violet rings track the actual hands during the sign. The realm now has darker violet background hands, with the brighter formation as its focal point.

The mass remains at the cast location when the domain seals and Mahito moves away. It follows an airborne cast's height. Interrupted casts retract over 0.38 seconds. During clashes, each Mahito has an independent formation; losing formations retract and the winner's stays. Existing sphere clipping confines the mass, and players outside the domain see the existing white exterior.

The prior touch transfiguration, pursuing-hand damage, domain capture, clash rules, startup vulnerability and costs remain unchanged. No new controls, assets, paid plugins or dependencies are required.

## Code and tuning

The separate helper is `src/mahito-amalgamation.js`. Its top-level tuning includes:

```js
const MAHITO_AMALGAM={hands:24,rear:12,hubHeight:6.4,spread:7.4,delay:.10,unfurl:1.05,stagger:.30,fade:.38,
 skin:0xaa8caa,ink:0x382d47,emissive:0x372340,glow:0xb990f3,breath:.10};
```

`rear` places the mass behind the original caster facing; the helper preserves that anchor instead of attaching the domain scenery to a walking character. `poseMahitoAmalgam` animates existing instanced articulated hands and the connecting forearms with eased growth/curl. The materials and scratch transforms are cached. At most six formations exist and their geometry is reused on subsequent casts.

Integration points:

- `src/barriers.js`: `beginCastVoice` records Mahito's formation origin and direction with his existing cast ID.
- `src/mahito-vfx.js`: `updateMahitoVisuals` calls `updateMahitoAmalgams`; the realm lighting is tuned here.
- `src/mahito-hands.js`: the existing shared background-hand material becomes muted violet. Pursuing hands retain their bright tint.
- `src/mahito.js`: existing Mahito snapshots include a bounded, validated `formations` list; match reset clears the anchors and hides cached geometry.
- `src/session.js`: receives those anchors so guests reconstruct the same formation even if the caster has since moved or turned.
- `build.py` and `tests/harness.mjs`: include the new helper beside the existing Mahito files.

Private rooms use `limitless-31.0`; all players should refresh before joining.

## Verification

39 automated groups passed: Build 31 (8), Build 30 (7), Build 26 (10), Build 25 (14). Coverage includes all facing directions, growth during startup, original-position persistence, interrupted/paused casts, aerial clipping, independent three-Mahito clash formations, winner/loser cleanup, late snapshot reconstruction, invalid snapshot rejection, stable scene-node counts, 30/60/120 Hz transform agreement, the complete game loop and retained combat rules.

Native Mesa geometry previews were inspected at early/middle/full cast and inside the domain. They approximate material shading; they are not browser captures. Browser playtesting, measured FPS, actual Internet multiplayer and phone/controller testing remain unverified.
