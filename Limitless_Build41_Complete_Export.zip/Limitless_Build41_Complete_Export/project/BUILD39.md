# Build 39 — Combat and presentation polish

This pass keeps the existing characters, block models, combat rules, inputs, maps and project layout. Its main addition is `src/presentation.js` with `src/presentation.css`; small hooks connect it to the existing systems. No paid plugins, assets or dependencies are added.

## What changed

| Area | Result | Source |
| --- | --- | --- |
| Menus | Consistent roster cards for all five fighters, arena silhouettes, responsive layouts, clearer primary action and a selected-character move list showing actual saved bindings | `src/index.html`, `src/presentation.css`, `updateSelectionPresentation` |
| Health | Correct character colors, a delayed trail showing recent damage, low-health emphasis and accessible current-health values; trails also appear on every FFA opponent | `healthTrail`, `src/roster-health.js` |
| Combat feedback | Outgoing hit confirmation, stronger confirmation for hits of at least 80, incoming damage vignette, BLOCKED / GUARD / PERFECT DODGE cues; host/guest feedback is assigned to the correct player | `combatCue`, `hurt`, `replayEvent` |
| Damage numbers | A fixed pool of 28 elements, short-window aggregation and positions anchored in the world as the camera moves; numbers behind the camera are hidden | `showDamageNumber`, `updatePresentation` |
| Ability hints | Shared/per-move cooldowns, insufficient energy/chakra, ultimate requirements, full health, soul seals and burnout are shown on desktop and touch; follow-up hints include ANCHOR, DETONATE and CHASE | `abilityReadiness`, `updateAbilityReadiness` |
| Movement animation | All five characters gain smoothed forward/backward stride weighting, lateral step/sway and acceleration/braking lean. Existing attacks, airborne movement, wall running and web actions retain their dedicated poses | `polishLocomotion`, `src/animation-polish.js`, `src/naruto-animation.js` |
| Camera | Cached collision-query objects and box rejection before mesh tests; the interpolated camera is also constrained so it cannot linger behind a blocking wall | `cameraSurfaceDistance`, `positionGameplayCamera` |
| Camera shake | Smooth oscillating shake with an adjustable intensity; shake no longer advances the gameplay random-number generator | `presentationShake` |
| Arena lighting | The detailed directional-shadow region follows the player in normal arena combat, retaining each map's original light direction; longer shadow depth includes tall buildings | `updateArenaLighting`, `src/maps.js` |
| Auto graphics | Render resolution drops only after sustained slow frames and restores gradually after sustained recovery; manual quality choices are respected | `sampleAdaptiveQuality` |
| Results | Damage dealt/taken, match duration, remaining HP and per-fighter damage totals, with the winner first; repeated guest snapshots reuse the result display | `presentResults` |
| Reliability | Afterimages no longer dispose geometry borrowed from the live character model. Newly spawned Mahito AI can animate normal-arm attacks before its first transformation | `poseAfterImage`, `removeObject`, `sampleLightCombo` |
| Instructions | Updated build labels, Blue steering time, Gojo teleport charge time, Naruto's unlimited chakra-funded boosts and 1.5-second dodge cooldown / 7.5m chakra dash | `src/game.js`, `src/session.js`, `src/naruto.js` |

The ability hints report resource and cooldown state; execution still uses the existing cast checks, including range, target selection, obstruction and interruptions.

## Settings and controls

The settings panel now includes **COMBAT FEEDBACK** with these exact labels:

> Camera shake strength

> Hit confirmation & guard cues

> Floating damage numbers

All save to the existing device-local settings record. The camera Shake toggle still disables camera shake entirely. The new strength control defaults to 80%.

The existing Graphics option is now labeled:

> Auto · adapts during play

It retains the existing device-based shadow, bloom and particle choices, then adjusts render resolution during combat. Quality and Performance retain manual control. Existing touch-layout positions remain in use.

## Tuning

Presentation constants are grouped at the top of `src/presentation.js`.

| Setting | Value |
| --- | ---: |
| Damage-number pool | 28 elements |
| Number lifetime / merge window | 780ms / 120ms |
| Health damage-trail delay | 320ms |
| Health trail catch-up rate | 3.8/s |
| Hit confirmation duration | 190ms |
| Guard / perfect-dodge cue duration | 550ms |
| Low-health threshold | 22% |
| Locomotion response | 120ms |
| Camera collision clearance | 0.4m |
| Auto warmup | 3 seconds of valid combat samples |
| Auto sample window | 1.2 seconds |
| Downscale threshold | Below 48 FPS for 3 consecutive windows |
| Restore threshold | Above 58 FPS for 7 consecutive windows |
| Resolution change per adjustment | 10 percentage points |
| Minimum relative render resolution | 65% of the selected device base |

Pause, hidden tabs, invalid samples and single frame gaps longer than 150ms do not count toward resolution changes. Render scaling does not change simulation time, combat values or movement speeds. This is a load-management feature, not a guaranteed frame-rate target.

## Integration

`build.py` inserts the presentation module before the existing session module and appends the stylesheet after the existing character styles. `initPresentation` initializes the controls once; `updatePresentation` updates transient feedback and health trails each frame. The existing options setter resets adaptive sampling after a quality change or window resize.

The shared animation hooks only alter visual pose targets. The camera hook replaces the existing gameplay camera obstruction calculation. Directional-light updates are suspended during domain enclosures. Existing domain/clash rendering and cinematic camera paths remain in place.

Private rooms use `limitless-39.0`. Hit/guard events now include the attacker ID, and a perfect-dodge presentation event was added. No host authority or transport topology changed. Every participant must refresh before joining a Build 39 room.

## Verification

154 automated check groups passed:

| Suite | Groups |
| --- | ---: |
| Build 39 presentation, camera, settings, adaptive quality and private-room feedback | 23 |
| Build 38 ground webs / slide | 16 |
| Build 37 held swing / input / animation | 16 |
| Build 36 exact web aiming / city | 11 |
| Build 35 Spider-Man combat | 13 |
| Build 27 models / animation | 10 |
| Build 29 ground / aerial combo | 8 |
| Shared mechanics | 23 |
| Online controls | 15 |
| Build 34 domain scenery / Blue guidance | 7 |
| Build 09 arenas / movement | 12 |

The new suite checks all five loadouts, rebinding and settings persistence, damage pool reuse/projection/expiry, actual guarded and dodged hit outcomes, correct-player network feedback, health trails and target changes, all FFA bars, resource and cooldown labels, result caching, thin-wall camera collision, hidden geometry, camera-shake random-seed isolation, all-character movement poses, borrowed geometry lifetime, adaptive-resolution hysteresis, arena light direction and complete six-fighter frame loops on every map.

Browser/GPU/device visual QA was unavailable. These tests exercise actual Three.js geometry and scene state with synthetic input and host/guest snapshots. They do not verify visual composition on real screens, subjective animation feel, device frame rate or Internet WebRTC performance.
