# Build 35 — Spider-Man joins Limitless

Spider-Man is playable in solo, practice, FFA and private rooms, including duplicate character choices. Uses the existing block skeleton, input actions, energy/stamina, damage and dodge rules, city collisions, light attack chains, hit feedback and host authority. No new dependencies or paid assets.

## Controls

| Input | Action |
|---|---|
| 1 — Web Yank | Pull the aimed opponent in, rising kick, then jump alongside. A higher airborne opponent instead makes Spider-Man zip to them. Recently thrown opponents remain available for this chase. |
| Light attack after launch | Continue the existing aerial combo. Aim down to kick them toward the ground. |
| 2 — Spider Combo | Step-in right cross, left hook, elbow, spinning left kick. In the air, downward heel kick and ground slam. |
| 3 — Web Cocoon | Catch the aimed opponent. Aim to steer them around you through a full circle, up or down. Collisions with scenery or a downward ground slam cause damage. Tap 3 again to throw along your aim. Jump tosses upward; 1 follows. |
| 4 — Web Swing | Aim toward an intact building above you and tap to attach. Aim/move to steer. Tap 4 or Jump to release with momentum. Automatic release on collision, destroyed/displaced anchor, depleted energy or 9s limit. |
| Charge energy | Replenish web energy through the existing Charge input; light hits also restore energy. |

Try **Skyline City** for swinging. Anchors are real solid scenery, so domains with hidden buildings provide no phantom swing anchors. Spider-Man does not have a Domain Expansion; Q and extra move slots are hidden for this kit. Other characters retain their existing domains and ultimates.

## Initial tuning

| Move | Damage | Energy | Cooldown / timing |
|---|---:|---:|---|
| Yank → launch | 22 + 36 | 10 | 2.8s; web contact .18s, kick .70s, follow complete 1.15s |
| Spider Combo | 18 + 22 + 26 + 38 | 14 | 4.5s; contacts .24/.47/.73/1.04s, recovery ends 1.38s |
| Aerial heel kick | 55 + 30 ground impact | 14 | Shares move 2; contact .34s, recovery .65s |
| Cocoon | 8 catch + 85 collision | 18 | 6s; catch .28s, control up to 4s; 13m aim radius; 57m/s throw |
| Swing | None | 4 attach + 4/s | .25s reattach; up to 68m/s, 95m anchor search |

The air-link window lasts 2.8s; linked chase can bypass the yank cooldown but still spends energy. The default dodge remains 1.5s. No changes to other characters' damage values. Ordinary existing special guard/dodge rules apply; the combo is a special move rather than the normal light-chain opener.

## Additive implementation

- `src/spiderman.js`: kit, per-actor actions/cooldowns, swept target movement, cocoon throws, pendulum/reel swing, snapshot validation, HUD/manual.
- `src/spiderman-model.js`: suit/mask/emblem on the existing articulated block rig.
- `src/spiderman-animation.js`: keyed anticipation, contact and recovery tracks; web-shooting hand pose.
- `src/spiderman-vfx.js`: six reusable strand/cocoon buffers. Thrown cocoons remain wrapped on host and guest.
- Small registration hooks in roster, build assembly, input dispatch, hit interruption, movement, animation, HUD and host snapshots. The existing fixed white-speed-line pool now also follows swing/release velocity; camera FOV eases with speed.

Tuning is grouped in `SPIDER` at the top of `src/spiderman.js`. Animation keys are in `SPIDER_TRACKS`. Existing particle/impact and limb trail systems are reused. No generated videos or raster models.

## Verification

`node tests/build35.mjs`: 13 scenario groups, including yank/light links, actual four-hit combo, 180-degree cocoon control, wall/ground damage, toss/chase/slam, interruptions, destroyed anchors, full Skyline City frame loop at 30/60/120Hz, duplicates, host/guest state, malformed packet rejection and reset cleanup.

Regression suites: core mechanics, online controls, domains, builds 27, 29, 33 and 34 (84 groups). Isolated geometry/pose renders reviewed for all special strikes and the swing pose. This is not browser gameplay or real-device performance testing; the browser QA capability was unavailable. A 60fps guarantee has not been measured on target hardware.

Private rooms use `limitless-35.0`. Refresh every participant to Build 35.
