# Skyline Boroughs — Build 20

Choose **Skyline Boroughs** in the existing arena picker. It works in CPU, practice and private-room free-for-alls. The other three arenas remain available. All room participants need Build 20.

The new `src/map-metro.js` helper uses `piece()` for the same destructible floors, solid walls, landable platforms and lower-floor collapse behavior already used by Night District. It plugs into `applyArenaMap()` through map ID `metro`. `src/maps.js` supplies the menu description, daylight palette, fog and existing cache/restoration path; `src/network.js` accepts the map ID. `build.py` and `tests/harness.mjs` append the helper after `maps.js`.

| Area | Buildings | Roof height | Movement features |
| --- | --- | --- | --- |
| North skyline | 8 | 44–64 m | Ten-metre gaps between rows, twelve-metre side alleys, wall faces, water towers and elevated crossings |
| Central brick blocks | 12 | 16–32 m | Staggered roof heights, twelve-metre alleys and six crossings between blocks |
| South brownstones | 16 | 8–12 m | Close roofs, short alleys and stoops for low routes |
| Outer homes | 4 | 8 m | Detached houses, small gardens and low terraces |

Fire-escape landing platforms start at 4 m and repeat every 8 m. They have no new input: wall sprint or jump up, steer onto a landing, and touch down to reset the existing boost/wall budget. Four northern crossings sit at 28 m; six block crossings sit at 12 m. The central avenue and plaza leave normal fighter spawns clear. Tall building roofs remain below the existing 72 m flight ceiling.

`METRO_MAP` groups the deterministic seed, tower floor counts, building colors and landing interval. Floors are four metres high, following the existing city convention. Windows and decorations use instanced/static batches with shared geometry and materials. Breakable pieces keep their own scene nodes, so hiding a destroyed floor also hides its facade and props. There is no per-frame map generation. Map pieces restore through the existing arena timer/reset. Private-room snapshots still carry destroyed-piece state using the same deterministic piece order.

The environment provides real walls and landing surfaces for future mobility characters. Web-swinging, grapple anchors and ODM movement are separate future features.

`node tests/build20.mjs` verifies selection/persistence, building counts/heights, clear spawns, wall attachment, platform landings/refills, floor collapse/restoration, retained scene nodes, deterministic host/guest geometry and replicated destruction. Isolated GPU previews inspect the skyline, avenue and neighborhood. These checks do not measure browser/device frame rate.
