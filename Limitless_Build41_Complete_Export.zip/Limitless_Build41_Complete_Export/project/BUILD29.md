# Build 29 — unified ground combo and aerial combat

Play: https://limitless.useful0314.chatgpt.site

Refresh until **BUILD 29** appears. All private-room players should refresh; this release uses `limitless-29.0` to prevent mixing old directional-attack clients with the new rules.

## Ground attacks

The in-game manual (`src/index.html`) now says:

> Ground combo stays the same while moving in any direction.

W/A/S/D, diagonals, sprinting, phone sticks and controller sticks all retain **right punch → left punch → right roundhouse → spinning left kick**. Movement still moves the fighter but no longer selects a different ground attack. Counters keep their faster contact time and use the same combo animation.

## Air attacks

| Aim at attack start | Animation |
| --- | --- |
| Level | Right/left punches with tucked legs, then a right aerial roundhouse and spinning left kick. The other leg folds instead of planting. |
| Up | Alternating rising punches with a compressed wind-up, extended striking arm and stretched follow-through. |
| Down | Alternating right/left heel strikes with a raised-leg wind-up and downward extension. The fourth connected hit uses a two-foot stomp. |

The style stays fixed for that swing; aim is sampled again on the next attack. Landing fades the air pose into the existing grounded stance over 120ms. Guard, damage reactions, dodges, techniques and ragdolls keep priority. Sukuna's lower arms balance the strikes. Mahito's weapon multipliers remain, and gun arms still fire projectiles.

## Exact tuning and gameplay

From `src/air-combat.js`:

```js
const AIR_COMBAT={downAim:-.35,upAim:.35,landBlend:.12,contactHold:.065,downKnock:3,downFinish:10,upKnock:3,upFinish:10};
```

Up/down selection requires an aim vertical component beyond ±0.35, approximately 20.5° above or below level. The existing `attackKind` and `attackAir` fields carry the selection: ground/level = 0, air up = 2, air down = 3.

From `src/combat-system.js`:

```js
const kind=lightAttackKind(f);
const duration=f.attackCounter?.32:.34;
```

Ordinary lights use **0.34s duration, 0.12s contact and 3 stamina**. Counters retain **0.32s / 0.09s**. Mahito applies his existing weapon tempo. The removed directional ground variants no longer provide their different startup or extended side-kick range.

Damage remains 12 / 16 / 20 / 27, or Sukuna's 10 / 14 / 17 / 23, before existing Mahito multipliers. Confirmed hits advance the chain; misses and blocked openers break it. Standard melee range is 3.3 world units; Mahito keeps his weapon ranges.

Air melee now uses 3D aim so nearby opponents above or below can be hit. Ground melee stays horizontal. Downward hits apply −3 vertical velocity, or −10 on the finisher; rising hits apply +3, or +10 on the finisher. These are knockback components, not bonus damage. Existing guard, dodge, barriers, hit-stop and combat resolvers remain authoritative. No self-dive, hovering, extra jumps or new mobility costs are added.

## Source hooks

- `src/air-combat.js`: new helper for selection, attack direction, vertical knockback, cached poses and landing blending.
- `src/combat-system.js`: removes movement-key variants and enables 3D airborne melee through the existing resolver.
- `src/mahito.js`: records air state and uses the shared melee helpers; Cursed Touch and gun projectiles retain their targeting.
- `src/light-combo.js`: samples air poses inside the established entry blend and disables aerial foot planting.
- `src/animation.js`: lower-arm balance for Sukuna's air attacks.
- `src/index.html`, `src/controls.js`: updated instructions.
- `src/network.js`: compatible-client version gate; packet layout stays the same.
- `build.py`, `tests/harness.mjs`: register the helper alongside existing animation files.

No manual hookups or new assets are needed. Pose arrays are cached, and trails reuse the existing bounded particle pool.

## Verification

58 automated groups: Build 29 (8), retained Build 28 (10), Build 27 (10), Build 25 (14), Build 14 (16). Build 29 replaces the obsolete directional-input assertion with checks for unified inputs and aerial behavior.

Checks cover all ground directions and characters, analog/remote inputs, counters, air selection, actual hand/foot positions, kick support legs, above/below damage, vertical finishers, range misses, landing at 30/60/120 Hz, physics isolation, host/guest packets, previous ground animations, Mahito's kit and multiplayer mechanics.

Native OpenGL previews use the real geometry and pose transforms. Browser gameplay, physical phone/controller testing, live Internet latency and sustained device FPS remain unverified.
