# Build 41 — response, readability and battle sound

Continues Build 40 in the same flat source assembly and authoritative combat/movement systems. No paid assets or plugins. No character damage, technique costs, cooldown lengths, hitboxes, guard rules, or domain rules were changed.

## The selected upgrades

| Selection | Implemented behavior | Tuning / hook |
|---|---|---|
| 1 | A 140ms edge buffer for light attacks, dodge, jump and special inputs near recovery/cooldown completion. Tap-release is retained; pauses, focus loss, incoming hits and stale network input clear pending actions. Hold-to-swing remains hold-to-swing. | `RESPONSE`, `actionFor`, `updateControlled`, existing input packets |
| 2 | 100ms ground coyote time, 120ms grace after a real wall contact, and early wall-jump input that waits for actual wall attachment. Grace jumps remain regular jumps; Naruto/Sukuna subsequent air costs stay unchanged. | `combat-response.js`, `jumpFighter`, existing wall movement helpers |
| 3 | Existing follow-up alignment is eased over 100ms, capped at 0.85m, and swept against scenery and domain barriers. It cannot select targets through barriers. | `beginMeleeAlignment`, `moveFighter` |
| 4 | Confirmed hit, block, miss and evade drive distinct follow-through pose accents. They do not change recovery, damage or combo progression. Outcome state is validated and replicated. | `applyLightOutcomePose`, existing `hurt` and light resolvers |
| 5 | Continuous walk/run stride and arm blending from measured speed, with existing forward/backward/strafe direction handling. Existing airborne, wall, hit and ability animators retain priority. | `continuousGait`, existing roster and Naruto animators |
| 7 | Gojo orbital cyan, Sukuna crimson slash strokes, Naruto golden spirals, Mahito mint soul contours, and Spider-Man pale web spokes on confirmed impacts. White hit cores and blue guard cues remain readable. | `CHARACTER_EFFECTS`, existing 18-entry contact pool |
| 8 | Pooled 3D attack-volume guides for all concurrent Blue/fusion fields, Purple, Furnace detonation/burn, Naruto wind zones and projected projectile contacts, plus World Cut startup slabs. Air spheres have geometric floor cross-sections only when they touch the floor. Dotted guides denote forecasts. | `updateDangerVolumes`, existing damage constants; burn snapshots added for guests |
| 9 | Directional camera impulses decay with distance and recheck camera collision after the displacement. They do not modify aim or gameplay RNG. Contact events and large technique impacts use the pool. | `BATTLE_VISUAL`, `cameraImpulse`, existing `shakeIt` event |
| 10 | FOV and camera follow speed respond to actual displacement, smoothly relax when stopping, and ignore teleport-sized position jumps. Cinematic and free-orbit priorities are preserved. | `speedFov`, `speedFollowRate`, existing camera functions |
| 13 | Ordinary effects duck under spoken cast clips and priority impact/parry/domain cues. Separate reserved transient budgets prevent ordinary effects from exhausting priority voices. | `BATTLE_AUDIO`, existing audio class/buses |
| 14 | Four original, locally synthesized music stems share a phase-aligned loop: ambient bed, combat rhythm, low-health tension and clash/ultimate intensity. Existing supplied domain/clash recordings take precedence. Pausing/muting/disabling stops the new stems. | `mixBattle`, `syncBattleAudio`, existing music slider |
| 18 | Reused generic particle objects, near/far particle density and a reserved close-combat capacity. Naruto's existing typed-array pool reserves nearby slots. Technique cloud draw counts scale by distance/quality while core shapes and warning geometry remain. RNG draws stay identical across the new density choices. | `visualDensity`, generic particle emitter, Naruto emitter, technique-cloud draw range |

New helpers: `src/combat-response.js` is assembled immediately after combat-system; `src/battle-readability.js` is assembled after presentation/combat-feel. The build script and test harness both include them. Everything uses the existing input, timer, collision, replication, animation and VFX entry points.

Settings add **Attack ranges**, **Speed-responsive camera**, and **Adaptive battle music**, all saved with existing preferences. The audio slider is now labelled **Battle & domain music**. Protocol is `limitless-41.0`; all room clients must refresh together.

## Validation

- `node tests/build41.mjs`: 28 focused groups covering buffers and tap-release at 30/60/120Hz, landing/wall grace, cost preservation, swept alignment, combat outcomes, guest replication, held swing semantics, all five rigs, airborne/overlapping/overflow warnings, camera behavior, RNG consistency, pool reuse and all four maps.
- Existing regression suites: build40, build39, build38, build29, build27, mechanics, online-controls, domains.
- `node tests/audio.mjs`: existing recordings and buses plus adaptive stem synchronization/reuse, speech and priority ducking, protected voices, and pause/mute cleanup.
- Standalone build and generated script syntax checks.

The harness uses real Three.js geometry/math with a mocked renderer and mocked Web Audio. Browser/device playtesting and listening were unavailable in this environment; these checks do not establish a 60fps guarantee or subjective audio/animation quality. VFX budget constants can be tuned after testing on the target phones.

Projected projectile markers are forecasts based on the current direction, terrain and opponent positions; moving opponents can change the eventual impact. Furnace shows where an immediate manual detonation would reach. Large-volume guides are intentionally translucent, with nearby dangerous events prioritized if the fixed pool fills.

## Research carried forward

- Input forgiveness: https://www.mattmakesgames.com/articles/celeste_and_forgiveness/index.html
- Animation blending: https://docs.unity3d.com/6000.2/Documentation/Manual/class-BlendTree.html
- Bounded attack alignment: https://dev.epicgames.com/documentation/unreal-engine/motion-warping-in-unreal-engine
- VFX identity/readability: https://www.riotgames.com/en/artedu/visual-effects
- Gameplay clarity: https://www.riotgames.com/en/news/valorant-shaders-and-gameplay-clarity
- Camera feedback: https://dev.epicgames.com/documentation/unreal-engine/camera-shakes-in-unreal-engine
- VFX scalability: https://dev.epicgames.com/community/learning/knowledge-base/LJnb/unreal-engine-niagara-scalability-effect-types
- Audio concurrency: https://dev.epicgames.com/documentation/unreal-engine/sound-concurrency-reference-guide
- Pooling: https://gameprogrammingpatterns.com/object-pool.html
