# Build 21 — exact values and source guide

This is an update to the existing game. All new hooks are already wired into its build, input, shared cooldown, energy, ultimate, damage, physics, particle and host/guest systems. No paid assets or plugins are needed.

## Controls and movement

| Change | Current behavior | Source |
| --- | --- | --- |
| Airborne view | Downward aim up to 1.52 radians / 87.1° in flight or jumps; mouse, touch and controller share the limit. Target lock still follows its target; toggle it off to freely aim | `src/session.js: cameraLook`, `src/game.js: updateCamera` |
| Extra health bars | Three-to-six fighter matches show every opponent, including duplicate characters and AI. Rows persist through knockout. The opponent group is movable in the phone layout editor | `src/roster-health.js`, `src/controls.js` |
| Naruto wall run | 22 stamina/s plus existing 4.5/s sprint drain = 26.5/s total. No chakra cost or fixed duration; stops at depleted stamina or lost wall contact | `NARUTO_MOBILITY.wall` in `src/naruto-mobility.js` |
| Charged Clone Boost | While airborne, press and hold Jump, then release. Charges up to 0.55 s and auto-releases; five uses/airtime, 5 chakra/use, 0.54 s cooldown. Landing resets uses | `NARUTO_MOBILITY.boost`, `releaseNarutoBoost` |
| Boost travel | Tap→full charge: moving 4.6→8.5 m; sprinting 10.4→15.9 m during the active pulse; stationary 1.6→4.2 m. Approach speed continues during the hold and recovery. Active duration 0.36→0.52 s; lift 12 m/s | `narutoBoostTravel`, `narutoBoostActive` |
| Free wall jump | 13.5 m/s up, 8.5 m outward; no clone, chakra or stamina activation charge | `startNarutoWallJump` |

The charged sprint pulse peaks near 35.2 m/s, below Gojo's 36 m/s flying sprint. It is still a finite boost, with existing terrain, gravity, ceiling and barrier collision. Holding does not auto-spam boosts. Brief wall reattachment debounce prevents collision chatter; it is not a wall-run duration limit.

Exact excerpts from `src/naruto-mobility.js`:

```js
function narutoBoostActive(m){return lerp(NARUTO_MOBILITY.boost.active,NARUTO_MOBILITY.boost.chargedActive,m.power||0);}
```

```js
m.power=clamp(m.chargeTime/NARUTO_MOBILITY.boost.maxHold,0,1);
```

## Domain damage and Kurama

Guard multiplies domain damage by 0.55 — **45% less damage**. It applies to Shrine, Void, Kurama's stomps and his final slam. Void retains the existing 0.38 s guard delay; ordinary specials remain guard-penetrating. This uses the original `hurt()` function, whose new tuning constant is exactly:

```js
const DOMAIN_GUARD_MULTIPLIER=.55;
```

Kurama's complete procedural model is in `src/kurama-domain.js`: full torso, neck/head, four independent paws, nine jointed tails, claws, teeth and glowing eyes. The gate opens after Naruto establishes the domain. The fox follows a deterministic route, lifts the next paw over a warning ring and stomps the same position used by the host's hitbox. He rears up before his final slam; Naruto's existing golden cloak appears during it.

| Attack | Damage | Time | Hitbox / defense |
| --- | --- | --- | --- |
| Eight stomps | 35 each; 19.25 guarded | 1.50, 2.65, 3.80, 4.95, 6.10, 7.25, 8.40, 9.55 s | 5.5 m horizontal radius under the paw; victims above 7.5 m are safe. Can move out or dodge. Knockback 9 outward + 5 upward |
| Final slam | 360; 198 guarded | 11.35 s into the 12 s domain | Every living captured opponent, including high airborne/dodging opponents. No outsiders or owner damage |

All eight footfalls plus the final slam can deal **640 damage**, but only the final 360 is unavoidable by movement/dodge. Clash damage remains off; the cage, staged clash bonuses, mixed Void/Shrine environment and local/split cameras remain intact. Existing Impossible AI immunity still applies.

The finisher time comes from this exact function in `src/mindscape.js`:

```js
function mindscapeFinisherAt(){return mindscapeDuration()-MINDSCAPE.finisherDelay;}
```

## Meter attacks

| Move | Resources paid upfront | Damage / timing | Defense |
| --- | --- | --- | --- |
| Naruto Tailed Beast Bomb / 5 | 45 chakra + 30% ultimate | Existing 520 direct hit, 2.1 s startup, 12 s shared cooldown, 120 m projectile range, 18 m explosion radius | Startup interruptible; spent resources stay spent. Released projectile remains active. Dodge avoids it; ordinary guard does not |
| Sukuna World Cutting Slash / 5 | 60 cursed energy + 50% ultimate | 420 per target once, 1.45 s / 87 f startup, 0.30 s / 18 f release, 0.50 s / 30 f recovery; 16 s shared cooldown | Startup interruptible, no refund. Dodge avoids it; ordinary guard does not. Released blade survives a nonlethal interruption |

World Cutting Slash moves at **180 m/s**, with **140 m** travel and a swept, aim-oriented **9 m wide × 22 m high** blade volume. Fighter allowances add 0.6 m sideways, 1.1 m vertically and 0.85 m along travel. It pierces multiple opponents once each and destroys intersected existing scenery. The shared ragdoll receives 28 along aim + 8 upward; for a stationary target with horizontal aim that becomes approximately 35 horizontal / 12.66 upward after the inherited ragdoll adjustments.

Domain barriers stop the blade and keep their capture boundaries. Shallow shots skim the floor; steep downward shots impact it. A jagged dark fissure with raised broken-stone rims marks the floor, up to the traveled range. The floor collision remains solid; this adds no falling hole. Twelve crater slots are reused, fade at 35 s and clear with the existing arena restoration. Six cast and six blade visual slots are reused. Impacts use 65 ms hit-stop and shake strength 1.05.

`WORLD_CUT` at the top of `src/sukuna-world-cut.js` begins with the exact fields:

```js
cost:60,ultCost:50,damage:420,cooldown:16,startup:1.45,active:.30,recovery:.50,speed:180,range:140,halfWidth:4.5,halfHeight:11
```

Naruto's new `ultCost:30` is beside `cost:45` in `NARUTO.moves[5]` in `src/naruto.js`. Existing damage-based ultimate gains still apply after either attack lands. Practice still refills energy/ultimate each simulation step.

## Applied hooks

| New helper | Existing integration |
| --- | --- |
| `src/kurama-domain.js` | Appended at the existing domain insertion marker. `makeMindscapePool` creates the model once; `updateMindscapePresentation` poses it; `updateMindscapeDomain` applies footfalls |
| `src/sukuna-world-cut.js` | Appended beside `combat-system`. Existing slot 5, `updateTechniques`, `updateProjectiles`, `hurt`, interruption, shared cooldown and reset dispatch call it |
| `src/sukuna-world-cut-vfx.js` | Pooled blade/charge/crater presentation called from the current frame loop. Existing Sukuna animation reads the four-arm pose |
| `src/roster-health.js` | Appended beside `roster`; its cached rows update from the current HUD loop |

Existing `naruto-mobility.js` handles the new hold/release state and stamina drain. `session.js` passes Jump-up edges and validated new snapshots. `network.js` uses `limitless-21.0` / `limitless21-`; everyone in a private room must refresh to Build 21. Both new source helpers and their hooks are inserted by `build.py` and the simulation harness. No manual hookup is needed.

## Verification

103 scenarios pass across `tests/build14.mjs`, `build17.mjs`, `build18.mjs`, `build19.mjs`, `build20.mjs` and `build21.mjs`. They use real Three.js geometry/math with simulated DOM, renderer, control events and host/guest packets. New coverage includes atomic resource gates, interruption, precise paw contacts, capture-only slam, guard reduction, multi-target swept hits at 30/60/120 Hz, barriers/scenery, steep and shallow aim, charged Jump release/auto-release, wall stamina, pooled cleanup, duplicate-character health bars and snapshot validation.

The blade and crater shaders compile/link on native Mesa GLES. Six isolated fox/attack scene previews were inspected. These previews omit the browser's full lighting/postprocessing pipeline. Live browser play, physical touch/controller behavior, Internet WebRTC, audio output and sustained 60 FPS on a target device remain unverified in this environment.
