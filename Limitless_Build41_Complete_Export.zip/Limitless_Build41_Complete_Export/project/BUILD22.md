# Build 22 — shared smooth wall movement and Kurama redesign

This update extends the existing game. The same input router, movement step, map collision, stamina/energy bars, character rigs and host-authoritative snapshots remain in use.

## Controls and values

| Change | Current behavior |
| --- | --- |
| Wall Run | Naruto, Gojo and Sukuna: jump near an intact wall and hold Sprint into it; steer along the face. Gojo must leave flight first. |
| Wall speed / cost | Target 26 m/s along the wall, 3 m/s lift; pushing directly into the wall climbs at 11 m/s. 22 stamina/s plus existing 4.5 sprint stamina/s. No chakra cost or fixed wall-time budget. |
| Wall smoothing | Preserve approach velocity along the wall, smoothly steer and change climb speed, ease wall attachment and ease back to ordinary movement on release. Shared gravity and collision still resolve every frame. |
| Jump off | Jump while attached: free for every character. No clone use, chakra charge or stamina drain during the committed jump. 0.12 s planted-foot anticipation, 0.42 s push, 0.16 s recovery. Lift builds to 13.5 m/s, then gravity takes over. Peak push target is about 27.9 m/s; recovery blends into the current movement input. |
| Naruto Clone Boost | Hold airborne Jump up to **1.2 seconds**, then release; reaching the cap releases automatically. **5 chakra**, **0 stamina**, including while Sprint is held. Works with empty stamina. Five boosts per airtime, reset on landing; 0.54 s cooldown. |
| Clone distance | Longer charge increases active travel. Sprint boost remains below Gojo's 36 m/s flying sprint; maximum is about 35.2 m/s. Holding preserves approach movement, so total distance includes the gathering phase. |
| Kurama | Long tapered muzzle; angular head and cheek fur; narrowed red eyes; tall pointed ears; prominent curved fangs and claws; leaner torso; independently opening jaw during the final rear/slam. Both cage and roaming models use the new fox head. Nine tails and four paws remain articulated. |

Wall jumps use the same swept scenery query as Clone Boost and Chakra Dash, including at the maximum simulation timestep. Damage, destroyed walls, exhausted stamina and other existing interruption rules still end a wall run. Enabling Gojo flight clears wall movement velocity to avoid stacking wall speed on flying sprint.

Kurama's combat is unchanged: eight localized 35-damage footfalls, then the 360-damage final slam at 11.35 seconds. Domain clash stages and guard reductions still use their existing logic.

## Exact source excerpts

From `src/naruto-mobility.js`, the Clone Boost tuning contains:

```js
boost:{uses:5,cooldown:.54,cost:5,startup:.08,active:.36,recovery:.10,impulse:12,dashDistance:10.4,distance:4.6,nudge:1.6,cloneLife:.26,buffer:.16,maxHold:1.2,chargedActive:.52,chargedDashDistance:15.9,chargedDistance:8.5,chargedNudge:4.2},
```

`src/game.js` excludes committed clone boosts and wall jumps from sprint stamina drain:

```js
f.pos.addScaledVector(move,speed*dt);if(sprint&&move.lengthSq()>0&&!freeMobility&&f.narutoMobility?.kind!==1&&f.narutoMobility?.kind!==4)f.stamina=Math.max(0,f.stamina-4.5*dt);
```

`src/combat-system.js` checks for an attached wall before choosing any character's airborne jump:

```js
if(f.narutoMobility?.kind===3)return startNarutoWallJump(f);
```

The reusable fox model's tunable values in `src/kurama-model.js` are:

```js
const KURAMA_LOOK={headScale:.62,torsoHeight:8.8,neckHeight:3.9,fangLength:4.3,clawLength:3.8,jawRest:-.12,jawRoar:-.72,eyeTilt:.27};
```

## Two new helpers and where they plug in

- `src/wall-motion.js`: shared velocity blending, swept wall movement, jump-off motion and Gojo/Sukuna wall poses. Called by the existing mobility update and character animation. The legacy `narutoMobility` state name is retained; wall states 3 and 4 now apply to all characters. Boost/dash states 1 and 2 remain Naruto-only. Existing snapshot validation enforces this distinction.
- `src/kurama-model.js`: creates shared tapered head/muzzle/fang geometry and articulated jaws. Called by `makeMindscapePool()` and `createKuramaAvatar()`. The two heads reuse geometry and materials; the animation loop creates no new geometry.

Both helpers are already included in `build.py` and `tests/harness.mjs`. All keyboard, mobile and gamepad controls use the existing Jump/Sprint actions and saved keybinds. No additional assets, paid plugins, registrations or manual hookups are needed. Everyone in a private room must refresh to **Build 22**, protocol `limitless-22.0`.

## Verification

**114 checks pass**: 11 in `tests/build22.mjs`, plus 103 across Builds 14 and 17–21. The new suite exercises all-character wall movement, smooth release/jumps, maximum-timestep thin-wall collision, resource use, interruptions, flight transitions, longer clone charge, five-use limits, host/guest synchronization, non-Naruto clone-state rejection, paused/reset pooled effects and reusable fox geometry. Historical timing assertions were updated only for the deliberately changed charge/jump timings and smoother steering.

Nine isolated native GPU previews were inspected: Kurama emerging, stomping, rearing for the slam, head close-up, profile, cage head, and wall poses for Gojo, Sukuna and Naruto. These inspect actual mesh/pose data with approximate lighting, not the full browser renderer. Browser play, Internet WebRTC latency and device frame rate have not been measured in this environment.
