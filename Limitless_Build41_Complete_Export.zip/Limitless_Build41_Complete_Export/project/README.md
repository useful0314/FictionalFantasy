Build 40 is the current combat-feedback pass: white character hit flashes, directional recoil, pooled contact bursts, distinct impact sounds, incoming-hit direction and weighted landing accents. See [BUILD40.md](BUILD40.md) for sources, tuning, integration and verification.

# Build 39 — Combat and presentation polish

A consistent five-fighter roster, selected-character move list, health damage trails, hit/guard feedback, cooldown and resource hints, and match statistics. All fighters gain smoother strafe/braking poses; camera collision, shake, shadow coverage and Auto render resolution are refined. Read [BUILD39.md](BUILD39.md) for exact changes, tuning and verification. Refresh everyone in private rooms to Build 39 (`limitless-39.0`).

# Build 38 — Ground webs and sliding

Aim at the ground and hold Web Swing (default 4) to pull into a slide. Landing while holding a building web keeps the attachment and horizontal momentum, with a low sliding pose and pooled dust. Let go to release; Jump releases and jumps out of a ground slide. See [BUILD38.md](BUILD38.md) for controls, tuning and checks. Refresh every private-room player to Build 38 (`limitless-38.0`).

# Build 37 — Hold-to-swing and Spider-Man motion

Hold the Web Swing input (default 4); let go to release. Eased launch, damped web tension, smooth turning, banked dive/rise poses and a tuck-to-open release preserve momentum. See [BUILD37.md](BUILD37.md) for controls, tuning and checks. Refresh every private-room player to Build 37 (`limitless-37.0`).

# Build 36 — Bigger Skyline Boroughs and exact web aiming

Skyline Boroughs is now 520m across, with 24 additional high rises (32 total), eight new mid-rise blocks and a 124m flight ceiling. Spider-Man attaches to the actual surface under the crosshair up to 125m away, including in private rooms. See [BUILD36.md](BUILD36.md) for tuning and checks. Refresh every player to Build 36 (`limitless-36.0`).

# Build 35 — Playable Spider-Man

Web yank into an aerial combo, four distinct martial-arts strikes, aim-controlled cocoon throws and high-speed building swings. See [BUILD35.md](BUILD35.md) for controls, tuning and verification. Refresh every private-room player to Build 35 (`limitless-35.0`).

# Build 34 — Clear domain interiors and full-circle Blue control

Domains now remove intersecting arena buildings and their collisions, restoring scenery afterward. Blue follows your aim around the caster, with a six-second steering window and faster repositioning for 180-degree reversals and full-circle sweeps. See [BUILD34.md](BUILD34.md) for tuning and verification. Refresh all private-room players to Build 34 (`limitless-34.0`).

# Build 33 — Blue pursuit and airborne casts

Blue now travels 26–40m at 24m/s, with a smooth trailing aim response and 50% more saturated blue particles. Blue and Red have distinct hand/torso casting animations and hover during airborne charge and release. Red’s white charging sphere is removed; its beam and impact remain. See [BUILD33.md](BUILD33.md) for tuning, source hooks and validation. Refresh private-room players to Build 33 (`limitless-33.0`).

# Build 32 — Maximum Output Limitless effects

Blue is now a longer, quickly steerable moving gravity field with a second sweep/lift phase and a persistent hand-guidance pose. Blue, Red and Purple use larger layered cores, dense reusable particle fields, stronger glow, dedicated release effects and heavier impacts. Damage, energy costs and hitboxes remain unchanged. See [BUILD32.md](BUILD32.md) for exact tuning, source hooks and validation. Refresh all private-room players to Build 32 (`limitless-32.0`).

# Build 31 — Mahito casting amalgamation

A connected mass of arms and palms now unfurls behind Mahito during domain startup, using the uploaded video as the composition reference. See [BUILD31.md](BUILD31.md) for source hooks, tuning and verification.

# Build 30 — Mahito domain reference and transfiguration

Giant ivory palms and fists surround the sphere against a black void. Successful domain contact stretches and twists the victim for 1.18 seconds, then bursts and defeats them. See [BUILD30.md](BUILD30.md) for implementation hooks and verification.

# Limitless — Unified ground combo and aerial combat / Build 29

A stylized 3D fan fighting prototype with playable Gojo, Heian-era Sukuna, Naruto Uzumaki and Mahito, CPU/practice free-for-alls, and private online rooms for up to six fighters. The standalone HTML bundles the engine, textures, sound generator, six supplied recordings, and connection library. Solo play works without a network after download; private rooms require the Internet.

## Build 29 — unified ground combo and aerial combat

All ground movement directions retain right punch → left punch → right roundhouse → spinning left kick. In the air, aim level for a tucked-leg aerial combo, up for rising punches, or down for heel strikes ending in a two-foot stomp. Air melee targets in 3D, with downward finishers pushing down. Read [BUILD29.md](BUILD29.md) for tuning and verification. Refresh all private-room players to Build 29 (`limitless-29.0`).

## Build 28 — linked punches and spinning kicks

The neutral light chain is **right punch → left punch → right roundhouse → spinning left kick** for Gojo, Sukuna, Naruto and Mahito. Each punch keeps the other hand near the face; the kicks pivot on the opposite foot, carry the body turn across the combo link, and settle into the character’s stance. Sukuna’s lower arms guard and counterbalance. Mahito’s blades/hammers retain their original combat multipliers and tempo; gun form still shoots.

The shared animation pass also tightens side kicks, uppercuts, sweeps, aerial slams and counters to their existing contact times, with captured-pose entry blends, stronger footwork, curled fists, eased recovery, shorter limb-trail intervals and smooth guest playback between snapshots. Read [BUILD28.md](BUILD28.md) for exact constants, source hooks and checks. Refresh to **Build 28**. Damage, hitboxes, costs, cooldowns, controls and the `limitless-26.0` packet format are unchanged.

## Build 27 — matching block models and animation polish

Gojo, four-armed Heian Sukuna and Naruto now match Mahito's bevelled block style, with independently animated elbows, hands, fingers, knees and ankles. New ready stances, eased light chains, directional attacks, charge/release poses, landing compression, hair/clothing follow-through and pose-correct afterimages feed the existing animation systems. Naruto's clones use the same model; domain hand signs meet through cached IK. Mahito retains his design, with ankle articulation and the shared movement polish.

Read [BUILD27.md](BUILD27.md) for the complete animation coverage, tuning constants, source hooks and validation. Refresh to see Build 27. Gameplay values, input bindings and the `limitless-26.0` network protocol are unchanged.

## Build 26 — Mahito polish and shared dodges

Mahito now uses a bevelled block rig with sewn clothing, layered hair, distinct arm weapons, wing membranes, cleaner morphed allies and a continuous armoured serpent. New eased anticipation/strike/recovery poses feed the existing animation system; secondary hair and clothing motion lag the body. The domain surrounds the sphere with 224 articulated hands (96 on low quality), plus four pursuing hands per caught rival, up to 20. Each pursuer deals 24 contact damage, reduced to 13.2 by guard, and respects dodge. Own melee/touch execution remains separate.

Every character's dodge/dash now has a 1.5-second cooldown. Gojo/Sukuna/Mahito gain about two metres of active dodge travel; Naruto's chakra dash increases from 5.5m to 7.5m. The invulnerability/perfect-dodge windows stay 0.34s/0.20s. HUD and mobile show the cooldown. Refresh all private-room clients to **Build 26**, protocol `limitless-26.0`. See [BUILD26.md](BUILD26.md) for exact tuning, hooks and validation.

## Build 25 — Mahito

Six moves, three arm weapons, four morphed-human allies, a steerable serpent ride, interruptible healing, temporary Big/Small/Winged forms, and Cursed Touch for 20% ultimate. His domain surrounds the sphere with expanding hands, changes movement speed and makes his own landed contact attacks lethal. Keyboard, mobile, controller, AI and private-room registrations are included. Optional balance recommendations remain documentation only. See [MAHITO.md](MAHITO.md) for controls, current functional defaults, source hooks, limits and proposed balancing. Private-room clients must refresh to **Build 25**, protocol `limitless-25.0`.

## Build 24 — smooth wall jump-offs

Wall jumps preserve incoming wall-run speed during anticipation. Aiming along or into the attached face redirects the inward component into an along-wall launch with a small outward clearance. Directly facing the wall retains the current run direction; a stationary climb pushes clear of the wall. Clear outward aim and camera pitch are retained, and steep pitch no longer removes existing horizontal run speed. Shared collisions, free jump cost and all three characters remain supported.

The narrow fix is in `src/wall-motion.js`, called once by `startNarutoWallJump` in `src/naruto-mobility.js`. Tuning: `jumpClearance:.18` is the minimum outward share of the horizontal launch direction. No per-frame objects, new inputs, models or assets are added. Refresh private rooms to **Build 24**, protocol `limitless-24.0`.

`tests/build24.mjs` covers all characters, both wall faces, parallel/slightly inward/directly inward aim, upward/downward pitch, speed preservation, 30/60/120 Hz, thin obstacles and host/guest state. Builds 22 and 23 retain their wall/domain regressions. Browser play and device FPS remain unmeasured.

## Build 23 — spherical realms, clone sure-hit and technique burnout

Domain effects surround both hemispheres at the cast height. Mindscape becomes a spherical sewer vault; its reflective water remains at ground level, and Kurama stays behind the cage. Six clones attack each captured rival in four staggered waves, using combos, Rasengan, Rasenshuriken and small Tailed Beast Bombs. Red chakra tethers link them to Kurama. The sure-hit totals **600 damage**, or **330 while guarding**. The old stomps and final slam are retired.

A domain ending gives its caster **15 seconds of technique burnout**; losing a clash starts it immediately. Movement, guard and light attacks remain available. Naruto's successful dodges leave smoke and a substitution log. Clone Boost costs **5 chakra**, with **no cooldown or five-use limit**; hold up to **1.2 seconds**. Wall running costs **8 stamina/s total** for all three characters. Free wall jumps launch along camera aim, including pitch.

See [BUILD23.md](BUILD23.md) for tuning, exact source excerpts, helper hookups and verification. Refresh every private-room client to **Build 23**, protocol `limitless-23.0`. Earlier sections are historical.

## Build 22 — shared wall movement, longer clone charge and fox redesign

All three characters can wall-run and jump off walls. Attachment, steering, lift and jump recovery now blend velocity smoothly; wall jumps remain free. Naruto can hold Clone Boost for **1.2 seconds** and spends **5 chakra with no stamina drain**, including while sprinting. Five boosts reset on landing. The new Kurama model has a long fox muzzle, narrowed red eyes, sharp ears, large fangs/claws, a leaner body and an opening roar jaw, both behind the cage and while roaming.

See [BUILD22.md](BUILD22.md) for exact values, source excerpts, new helper hookups and verification. **114 simulation checks pass**; nine isolated model/pose previews were inspected. Browser play and device FPS remain unmeasured. All private-room players must refresh to **Build 22**, protocol `limitless-22.0`. Earlier sections below record historical behavior.

## Build 21 — Kurama, World Cutting Slash and charged mobility

- Look down to 1.52 radians (87.1°) while flying or airborne; the same input router covers mouse, touch and controller.
- Every opponent has an individual health bar in matches with more than two fighters, with fighter ID, character, player/AI label, current HP, target highlight and OUT state. The group can be moved with the existing phone HUD editor.
- Naruto wall running consumes 22 stamina/s plus normal sprint drain (26.5 total), with no fixed airtime budget or chakra cost. Wall jumps remain free.
- Hold airborne Jump for up to 0.55 s to charge one Clone Boost; release launches and the cap auto-releases. Five uses, 5 chakra/use and the existing landing reset remain. Charged sprint boost active travel grows from 10.4 to 15.9 m.
- Kurama emerges as a full fox, roams and performs eight localized 35-damage stomps. A 360-damage final slam at 11.35 s hits all captured opponents. Clash stages and mixed-realm presentation remain.
- Holding guard reduces domain damage by 45%. Void retains its short guard delay. Normal special attacks still penetrate guard.
- Tailed Beast Bomb costs 45 chakra **and 30% ultimate** upfront.
- Sukuna's **5 / D-pad right / WORLD CUT** casts World Cutting Slash: 60 energy + 50% ultimate, 420 damage, 1.45 s vulnerable startup, 140 m range, 180 m/s blade and 16 s shared cooldown. It pierces foes/scenery, is stopped by domain barriers and leaves a large jagged ground scar. The arena floor stays solid.

See [BUILD21.md](BUILD21.md) for exact timing, hitboxes, implementation quotes, helper hooks and verification. All private-room players must refresh to **Build 21**, protocol `limitless-21.0`. The sections below retain the chronological build history; current values in this section supersede earlier releases.

Validation: 103 checks across Builds 14 and 17–21 pass. The new custom blade/crater shaders compile and link on Mesa GLES; six isolated fox/slash scene previews were inspected. Live browser play, Internet WebRTC and device frame rate remain unmeasured.

## Build 20 — faster mobility, visible clashes and Skyline Boroughs

Wall sprint now reaches 26 m/s, matching ground sprint, with an 11 m/s climb. Jumping off an attached, intact wall uses a free regular wall jump: 13.5 m/s upward impulse and 8.5 m outward travel, with no clone, energy charge or boost count consumed. The wall-time budget stays finite. Smooth pooled white streaks move against the launch/run direction.

Clone Boost works while sprinting, preserves approach speed through anticipation, gives the full 12 m/s lift and travels 15.08 m over a committed sprint boost in open space. Five uses and 5 chakra per use remain. Cooldown is 0.54 s; a late press buffers for up to 0.16 s, while holding Jump cannot repeatedly spend clones. [NARUTO-MOBILITY.md](NARUTO-MOBILITY.md) gives all tuning and hooks.

Mindscape clashes now compose Kurama’s cage/water with the actual Void vortex and/or Malevolent Shrine. Late entrants rebuild the host and guest scene; each split camera faces Void correctly. The complete sewer returns if Naruto wins. Domain damage, meters, sure-hit and clash-point rules are unchanged. The new `src/domain-mixed.js` helper is presentation only.

**Skyline Boroughs** is the fourth selectable arena: 8 towers (44–64 m), 12 mid-rise blocks (16–32 m), 16 brownstones (8–12 m) and 4 detached homes (8 m). Narrow alleys, real fire-escape landings and 10 elevated crossings give wall-running routes from street to roof. All 40 buildings use the existing breakable floor/platform collision and restoration; generation is deterministic for private rooms. Scenery/window batches reuse existing geometry. The map offers surfaces for future movement characters; ODM gear and web-swinging are not implemented by this update. See [SKYLINE-BOROUGHS.md](SKYLINE-BOROUGHS.md).

No assets or plugins need buying. The three new helpers are `src/naruto-speedlines.js`, `src/domain-mixed.js`, and `src/map-metro.js`; `build.py` and the simulation harness insert them beside their existing modules. Everyone in a private room must refresh to **Build 20**, protocol `limitless-20.0`.

Validation: 16 new scenarios plus 70 current mobility/Naruto/domain/FFA regressions; custom speed-line and mixed-water shaders compile/link on Mesa GLES. Isolated city, realm and movement scene previews are inspected. Browser-native gameplay, live Internet WebRTC and device FPS remain unmeasured here.

## Build 19 — Clone Boost, Chakra Dash and Wall Run

Naruto now gets five Clone Boosts per airtime on the existing jump control: 5 chakra each, 0.42 s cooldown, and less lift than Sukuna’s air step. Hold Sprint plus a movement direction while boosting for a short 3.2 m air dash. The dodge control becomes a 5.5 m Chakra Dash with a 0.85 s cooldown, 14 stamina + 4 chakra cost, blue/gold pooled particles and an afterimage; existing perfect-dodge timing applies. Sprint into a wall while airborne to climb; steer along it to run sideways. Wall movement costs 2 chakra to attach plus 8/s, with one 1.1-second budget per airtime. Landing resets boost uses and wall time.

Anticipation, kickoff/dash poses and recovery use the existing eased joint animation, secondary motion and landing dust. Boost clones reuse the existing 18-slot instanced pool. Walls use the map’s destructible collision pieces, including intact floor seams; movement stays inside sealed domain barriers. Gojo’s flight and Sukuna’s jumps keep their values.

The separate `src/naruto-mobility.js` helper holds all movement tuning, animation targets, VFX and snapshot helpers. [NARUTO-MOBILITY.md](NARUTO-MOBILITY.md) documents every integration hook. No new assets, plugins or input actions are required. Everyone in a private room must refresh to **Build 19**, protocol `limitless-19.0`.

Seventeen focused mobility checks and 53 existing Naruto/domain/free-for-all regressions pass. Isolated scene poses were inspected; browser-native rendering, physical controls, live Internet WebRTC and sustained device FPS have not been measured in this environment.

## Build 18 — Kurama’s Cage and local domain cameras

Naruto’s **Q** now expands **Mindscape: Kurama’s Cage**, using the existing full ultimate meter, 1.55-second vulnerable cast, white 54 m barrier, 1.5-second clash counter window and 12-point clash. Three four-second seal stages increase Kurama’s glow, water ripples, rumbling, claw reach and Naruto’s clash point multiplier: 0.65×, 1.10×, 1.55×. Optional surviving barrage clones add up to 0.30×. The domain deals 40 early + 100 mid + 360 sure-hit finisher damage. Gojo and Sukuna retain their existing domain rules and values.

Only a local caster sees their 360° expansion camera. Clash participants see each other in equal halves or thirds; portrait phones use stacked panels. Four to six participants use a grid. The intro lasts 2.35 seconds and does not pause combat. Existing free camera/cursor and Cinematic camera settings take precedence. Portrait cut-ins stay disabled.

Tailed Beast Bomb moves to **5** (D-pad right or the new mobile button): 45 chakra, 12-second shared cooldown, unchanged 520 direct-hit damage and 2.1-second startup. The ultimate meter is untouched. Shadow Clone Barrage commits to the player’s facing direction, including into empty space; rear and side opponents cannot redirect it.

[MINDSCAPE.md](MINDSCAPE.md) documents stage tuning and all narrow integration hooks; [NARUTO.md](NARUTO.md) contains the complete current character/move guide. All code, models and effects are included in the source download. Private-room participants must refresh to **Build 18**, protocol `limitless-18.0`.

The release has 17 new feature checks, 20 updated Naruto checks and 16 free-for-all/network regressions. New custom shaders compile/link on Mesa GLES; isolated scene previews were inspected. Browser-native rendering, sustained device FPS, physical controls/audio and live Internet WebRTC remain unverified in this environment.

## Build 17 — Naruto and the original domain presentation

Naruto joins every existing character-selection mode with an articulated orange/black model, Shadow Clone Barrage, Uzumaki Combo, Rasengan, Rasenshuriken, and a Nine-Tails Chakra Mode / Tailed Beast Bomb ultimate. His complete code, exact move statistics, timing, hitbox/knockback details, animation/VFX tuning and integration checklist are documented in [NARUTO.md](NARUTO.md). All source modules are included in the download.

Domain cut-in portraits are disabled. World-space domain effects, barriers, audio and camera presentation remain. The new character uses the existing input, charge, shared cooldown, damage, meter and host-authoritative networking systems. Protocol `limitless-17.0` requires everyone in a private room to refresh to Build 17. Existing Gojo/Sukuna balance values remain unchanged.

Twenty focused Naruto checks and sixteen existing free-for-all/network checks pass. Isolated model/effect previews were inspected; browser/device performance and live Internet multiplayer remain unverified. No paid assets are needed.

## Build 16 — faster Spatial Shift

Gojo’s teleport now has a 0.06-second startup (previously 0.14), no post-teleport cooldown (previously 0.06), and a starting cost of 2 cursed energy (previously 4). Full distance charges in 0.45 seconds instead of 0.9. Holding still spends 10 cursed energy/second until fully charged, so a full-distance cast costs 6.5. Range stays 8–36 m, with the existing warp effects and collision rules.

## Build 15 — animated domain cutouts

Domain portraits now ease into view, settle into a readable hold with separate portrait and text motion, then sweep out before removal. Casts last 1.8 seconds; clash compositions last 2.35 seconds. A 0.22-second crossfade connects changing clash rosters, including the three-way Y composition. Character-specific lighting, energy lines, typography and hand-sign poses use the existing procedural models; no purchased assets or generated video are required.

The game clock drives the presentation: pausing freezes it and online snapshots seek to the current animation time. Reduced-motion preferences use stationary fades. Seven focused checks cover entry/exit, interrupted compositions, pause/reset, guest synchronization, reduced motion, one to six panels, and isolation of portrait posing from live fighters. All sixteen Build 14 regression checks also pass. Model previews and the Figma motion study were inspected; live browser playback remains unverified in this environment.

## Current balance, combat and district

All fighters have 1,000 HP. Proposal B is implemented, with the user's overrides: Infinite Void totals 550 and Malevolent Shrine totals 600 over an uninterrupted 12-second capture. These are damage totals, separate from the cinematic presentation. Charge-dependent moves scale linearly from 35% to 100% of the listed maximum, with separate spatial falloff where applicable.

| Move | Maximum damage |
|---|---:|
| Gojo four-hit light chain, any directional variant | 12 + 16 + 20 + 27 = 75 |
| Sukuna four-hit light chain, any directional variant | 10 + 14 + 17 + 23 = 64 |
| Blue | 24 per second at its center |
| Red | 140 |
| Hollow Purple | 280 |
| Nuke formation / burst | 45 over three seconds / 380 |
| Teleport | 0 |
| Infinite Void | 550 |
| Dismantle | 80 central + 40 + 40 side cuts = 160 |
| Cleave | 180 across all eight full-charge cuts |
| Furnace explosion / lingering burn | 240 / 60 across five ticks |
| Cursed Rush | 100 |
| Malevolent Shrine | 600 |

A confirmed opener starts a four-hit chain. Timely light follow-ups keep the opponent vulnerable; the fourth hit knocks away and ends the chain. Missing does not advance it. Switching to a special releases the light-chain hitstun. Blocking the opener gives a 0.44-second counter-input window and staggers the attacker for 0.32 seconds; the counter has a separate deflection/riposte pose. Neutral chain hits, side kick, rising strike, sweep and aerial slam have distinct joint animation.

Perfect dodges restore 15 HP. Ultimate gain is 0.085 meter per point dealt and 0.062 per point taken; the emergency ultimate remains once below 5 HP. Strong launches and Hollow Nuke animate a procedural tumbling ragdoll with a recovery period. The caster is knocked back by their Nuke without damage. Furnace's charge has a drawn flame bow, moving bowstring, opposing arm poses and a release follow-through.

The playable district is 352 m across with 32 destructible buildings, elevated crossings, floating slabs, streets, lights and benches. Building floors support collision and rooftop standing; breaking a lower floor collapses its upper floors. All destructible sections restore together every 35 seconds. Sprint is 26 m/s, walk 6.4 m/s; sprint animation, CPU obstacle steering and camera obstruction handling support the expanded space. The ground always remains, with no fall damage. Lane markings and skyline boxes use instanced batches.

Domain kills play distinct non-graphic executions: Void surrounds the defeated fighter with overwhelming information before a bright silhouette dissolves into energy; Shrine focuses a barrage of black cuts on the opponent, followed by a collapse and dissolving fragments. No gore or anatomical dismemberment is shown. The timelines are 6.4 and 6.2 seconds, respectively. A lethal light or special in the caster's established, captured domain can trigger the same ending. Online snapshots carry the execution identity, age and actors, preventing presentation from applying extra damage. The Cinematic camera setting controls camera cuts.

## Play

Open the published Site or `Limitless-Arena.html` in a browser supporting WebGL 2. Choose Gojo, Sukuna or Naruto, then a CPU duel, practice, or a private online room. The menu and FPS readout identify **Build 17**.

- **Controls & Audio** opens the remapping screen. Every keyboard/mouse action can be rebound; controller combat and menu actions can be reassigned. Duplicate bindings swap. Settings persist on the current browser/device.
- The existing camera/effects panel controls mouse sensitivity, camera distance, sound, shake, full flashes, bloom, and cinematic close-ups.
- Graphics **Auto** uses the lighter profile on small/coarse-pointer devices. **Performance** reduces particles and resolution, disables dynamic shadows/bloom, and hides ambient dust.

| Default input | Action |
| --- | --- |
| WASD / mouse | Move / aim |
| Shift / Space | Sprint / jump |
| F / Space / Ctrl | Gojo: levitate / ascend / descend |
| Left Alt | Release / capture the cursor without pausing; toggle or hold in Settings |
| V | Toggle character view; mouse orbits, wheel zooms |
| Left mouse | Light combo; movement modifies the attack |
| Right mouse / E | Block light attacks / dodge; first 0.2 seconds can parry |
| C | Hold to replenish energy; recharge ramps up |
| 1–4 | Hold a special, release to execute |
| 5 | Naruto: Tailed Beast Bomb (45 chakra + 30% ultimate); Sukuna: World Cutting Slash (60 energy + 50% ultimate) |
| Q | Domain / ultimate |
| Tab / H / Esc | Target lock / field manual / menu |

### Controller and touch

Standard-mapped gamepads use the left stick for movement and right stick for aiming. A/Cross jumps, B/Circle dodges, X/Square attacks, Y/Triangle charges energy. LB guards, RB sprints. Hold LT/L2 with X, Y, B, or A for specials 1, 2, 3, or 4. D-pad up opens the domain, left toggles levitation, down descends, right activates Naruto’s bomb or Sukuna’s World Cutting Slash, and right-stick click locks on. Menu/Options opens the menu; View/Share opens help. D-pad navigates menus, A selects, B returns. Adjust aim sensitivity, deadzone, inversion, and action mappings in Controls & Audio.

Touch controls appear automatically on coarse-pointer/touch devices; they can be forced on or hidden. The left stick moves, the open right area aims, and buttons provide light/guard/dodge/jump, energy charging, flight/sprint/descend, four hold-to-charge specials, target lock, and the domain. The layout adapts to landscape and portrait. Pointer cancellation and focus loss release held actions.

## Private online rooms — beta

1. Choose a character and map. For solo or practice, set **AI fighters** (1–5), pick each AI character, and choose Easy, Normal, Hard, or Impossible.
2. For online play, open **Private Free-for-all → Create Private Room**. Friends join using the eight-character code. Each person chooses their own character; duplicates are allowed.
3. The host can add AI to fill the remaining slots, up to six total fighters. AI targets other AI as well as humans. All humans press **I'm Ready** to begin the synchronized countdown.
4. Eliminated fighters spectate. Last fighter standing wins. A departing guest forfeits; remaining fighters continue. Host disconnection stops the match.
5. A rematch requires every connected human to request it. All players should refresh to Build 18 for Mindscape and move 5. The wire protocol is `limitless-18.0`.

**Impossible** deliberately ignores human damage and regenerates resources. AI can still damage other AI. The setting is explicitly labeled in the menu; Easy, Normal and Hard remain beatable.

The host browser simulates movement, hit detection, health, resources, projectiles, destructible terrain, and domain outcomes. The guest sends validated inputs only and renders interpolated host snapshots at 20 updates/second. The transport rejects mismatched builds, occupants beyond six, stale inputs, invalid controls, and malformed snapshots. Guest inputs cannot assign health or damage. This is a host-authoritative prototype, without rollback, dedicated servers, matchmaking, accounts, reconnect/resume, or anti-cheat protection against a dishonest host.

PeerJS 1.5.5 provides WebRTC signaling/transport through its default cloud service, with the STUN/TURN defaults bundled in that version. Some NATs, firewalls, or service outages may prevent a connection. Status messages, timeout handling, a latency readout, and clean disconnects are provided. Keep the host tab visible: hiding it ends the match to avoid a stalled simulation. Opening the in-game menu releases controls but does not pause shared combat.

The Site's existing audience is preserved. Private room codes control who joins a match; they do not change Site access.

## Domain design from the supplied references

The user supplied `RPReplay_Final1791097110.mov` and `RPReplay_Final1791098079.mov` as visual references. The first supplies Gojo’s purple rush and luminous void; the second supplies the crimson environment and cutting imagery. The videos were inspected as contact sheets and selected frames; they are not bundled or played in the game.

The design follows the requested “purple like tunnel then turn to a void” and “slashes like black lines everywhere that causes constant damage”:

- **Unlimited Void:** magenta/violet tunnel streaks projected onto the inside of the domain sphere for 1.35 seconds, dissolving into the void by 2.05 seconds. The realm contains a black center, blue-white turbulent cloud corona, distant particles, and dark blue arena surfaces. Gojo’s eyes remain revealed while his domain is active. With cinematic cameras enabled, a brief field-of-view expansion emphasizes the entrance.
- **Malevolent Shrine:** a crimson storm, enlarged shrine, pooled black slash ribbons across the air, and dark incisions across the ground. Normal alpha blending preserves the black centers instead of adding light. The field uses up to 320 airborne cuts and 96 ground incisions, reduced to 128/40 in Performance mode. Air cuts renew every 0.28 seconds (previously 0.62), ground cuts every 0.55 seconds, and the spatial slash rhythm is 9 beats/second. The visual density is independent of gameplay damage.
- **Steady damage:** captured opponents receive 5 HP every 0.1 second, totaling 600 over 12 seconds before dodges or other match events. Guard cannot stop it; the caster is immune. Slashes progressively break scenery around the domain and the captured opponent.
- **Clashes:** both realms appear. Winning territory pushes back the opposing visuals. Automatic domain damage begins only after a winner establishes their domain. Both online clients receive the same origin, orientation, and domain age.
- A domain phase/countdown indicator, restrained spatial cutting sounds, a Void arrival cue, and exact material restoration on collapse complete the transition. Collision and damage remain host-authoritative.

## Build 06 — technique effects and supplied audio

- **Hollow Bomb / Nuke:** Red and Blue satellites orbit and compress around the fusion core during the existing three-second windup. Detonation expands a transparent violet shock front with branching lightning and layered shock rings. Formation and burst use the accepted damage table; charged radius, caster knockback, and caster damage immunity are preserved.
- **Furnace:** a formed flame bow and incandescent arrow replace the generic fire sphere. A procedural turbulent tail follows its orientation. The arrow now collides with scenery along its swept path. Impact produces a fire column, a spreading ring, and a scorched, burning area that fades with the effect.
- **Other techniques:** animated gravitational contours for Blue, interwoven energy ribbons for Purple, a red shock front for Red, black cutting planes for Dismantle and Cleave, and spatial ripples for teleportation. Sukuna has a bow-drawing charge pose.
- **Domain polish:** orbital filaments around the Void corona and a black/crimson cut pattern beneath Shrine. Shrine appears behind its caster, facing the fight, so it does not sit inside the opponent's camera. The purple tunnel-to-void transition and continuous black slashes from the preceding update are included.
- **Exact supplied recordings:** `Sukuna domain.mp3` and `Hollow nuke.mp3` are copied without modification into the build. Sukuna's recording starts when Malevolent Shrine is established, including when he wins a clash; it fades at the end of the 12-second domain. The longer recording does not extend gameplay. Hollow Nuke's recording starts at detonation and plays through its tail unless another detonation replaces it or the match is paused, reset, left, or ends.
- **Mix and lifecycle:** a separate Technique recordings volume slider preserves the existing clash and effects sliders. Repeated snapshots do not restart cues. Late decoding seeks to an active domain's age, and canceled cues cannot start later. Pause, reset, leaving a room, and page exit fade recordings out.
- **Online presentation:** stable projectile IDs, direction, and age replicate the arrow and energy effects without replacing their scene objects each update. Impact effects are presentation events; they cannot apply extra damage on a guest. This build uses protocol version 6, so both players should refresh to Build 06.

## Sound and visual upgrade

- The user's exact 22.125714-second MP3 is bundled as `assets/audio/domain-clash.mp3`. It starts at a clash, overlaps successive loops by 0.65 seconds, and fades when the clash ends. A late audio decode cannot restart an already-ended clash.
- Separate master, combat-effects, clash-recording, and technique-recording sliders. All sound starts only after a user interaction. Positional effects use stereo panning and distance attenuation, with a shared compressor and short reverberation.
- Layered synthesized light swishes, impacts, guards, perfect-dodge chimes, stone footsteps, teleportation, charged techniques, fire, blasts, and domain tones. A continuous charge drone follows charge strength.
- Generated slate and woven-fabric albedo textures on arena architecture and clothing. Texture wrapping mirrors repeated tiles.
- More detailed hands with articulated fingers and domain hand poses, garment seams and hems, cuffs, layered fringe, and shoe soles/laces.
- A shaded, animated infinity barrier on successful blocks; persistent field contours show Blue's attraction radius and Hollow Bomb's large fusion radius. Existing layered energy shaders, bloom, shock fronts, slashes, afterimages, debris, and domain environments remain.

## Combat retained

| Special | Gojo | Sukuna |
| --- | --- | --- |
| 1 | Blue: steer, sweep, anchor | Dismantle: cutting wave and charged spread |
| 2 | Red: fast explosive repulsion | Cleave: close cutting barrage |
| 3 | Hollow Purple | Furnace: fire arrow, explosion, burn area |
| 4 | Aimed, chargeable teleport | Cursed Rush: forward contact strike |
| Ultimate | Unlimited Void | Malevolent Shrine |

Blue and resource charging are separate. Fire Red into anchored Blue to start a three-second Hollow Bomb: chip damage during formation, a powerful burst, and knockback. Its caster takes no self-damage. All destructible terrain restores together every 35 seconds. Specials penetrate guard; holding guard reduces domain damage by 45%. Perfect dodge heals 15 HP and opens a short light counter. Walking recovers stamina; landed lights restore energy. Ultimate meter grows from damage dealt/taken; one emergency ultimate is available below 5 HP.

Counter a domain within **1.5 seconds** to clash. A clash has no fixed duration: first to 12 attack points wins. The winning domain lasts **12 seconds**. Domain startup takes 1.55 seconds and can be interrupted.

## Verification and remaining limitations

Run:

```
node tests/mechanics.mjs
node tests/online-controls.mjs
node tests/audio.mjs
node tests/domains.mjs
node tests/technique-vfx.mjs
node tests/health.mjs
node tests/build06.mjs
node tests/build07.mjs
node tests/build08.mjs
node tests/build09.mjs
node tests/build10.mjs
node tests/build11.mjs
node tests/build12.mjs
node tests/build14.mjs
node tests/build15.mjs
python3 build.py --site
```

The 23 combat simulations, 15 online/control checks, 12 focused domain checks, and 9 technique-presentation checks passed, using real Three.js scene/math objects, a mocked renderer/DOM, and an in-memory two-client transport. Online checks cover readiness/countdown, guest movement and techniques, host authority, charge/dodge, clashes and ownership, terrain restoration, results/rematches, disconnects, invalid input/state, persisted remapping, gamepad chords, and touch pointer lifecycles. Audio lifecycle checks cover decoding, overlap scheduling, fade-out, volume/mute, effect construction, drones, and late decode cancellation.

Domain checks also cover tunnel/reveal timing, black slash geometry, damage cadence at 30/60/120 Hz, capture and immunity, 600 HP total Shrine damage, clash territory, guest transition timing, material cleanup, and the reduced graphics budget. All six exported domain shader programs compiled and linked successfully on headless Mesa GLES using `tests/compile-domain-shaders.py`. This validates shader compilation; it does not show the complete browser-rendered game.

Isolated effects were additionally rendered on native Mesa GLES from their actual geometry and shader sources, with an approximate display transform. Those previews were visually inspected for fusion, Furnace, Hollow Nuke, the tunnel, Void, and Shrine. They exclude the full scene lighting, browser bloom pipeline, UI, and audio playback.

These are **simulation tests and isolated shader previews**, not a browser or device playtest. The current static Site has no supported supervised browser preview in this environment; the prior Chromium attempt could not launch. WebGL appearance/performance, actual audio playback, public signaling/NAT traversal, real touch devices, and physical controllers have not been verified here. Private multiplayer and device support are beta. Goku, final production animation assets, and final balance remain unfinished. Naruto is implemented in Build 17 as documented above.

## Source and third-party components

- `src/game.js`: combat, procedural models, scene, and VFX.
- `src/combat-vfx.js`: persistent technique rigs, flame/energy shaders, impact sequences, and domain accent layers.
- `src/domains.js`: staged domain visuals, shaders, slash pools, domain damage cadence, and material lifecycle.
- `src/session.js`: input integration, rooms, state replication, settings, and frame loop (inserted by the build).
- `src/controls.js`, `src/audio.js`, `src/network.js`: standalone subsystems.
- `src/index.html`, `src/style.css`: interface and responsive layouts.
- `build.py`: produces the self-contained HTML, and `dist/index.html` with `--site`.
- Three.js r170 and PeerJS 1.5.5 are vendored under MIT licenses; see `THIRD-PARTY-NOTICES.txt`.
- PeerJS documentation: https://peerjs.com/client/getting-started and https://peerjs.com/client/faq . Actual STUN/TURN settings come from the pinned vendor bundle.

Build 06 validation adds exact domain totals at 30/60/120 Hz, 75-damage chains, blocked-opener counters, 425 maximum Nuke damage, recovery, accepted special values, building collapse/restoration/collision, sprint distance, unique poses, finisher lifecycle and guest synchronization. The GPU inspection renders isolated scene geometry and shaders with an approximate display transform; it is not full-browser or real-device QA. Private online play remains a beta and has not been verified with two live devices in this workspace.

New implementation modules: `src/city.js`, `src/combat-system.js`, `src/animation.js`, and `src/finishers.js`. `src/game.js` owns the accepted balance constants; `src/domains.js` owns domain tick totals.


## Build 07 movement and impact polish

Sukuna can air-jump repeatedly with the jump binding. Each midair step costs 12 stamina, has a 0.22-second repeat cooldown and supplies an 11 m/s upward impulse. Ground jumps cost 5. No jump-count limit; no stamina regeneration in midair. All keyboard, controller, touch and guest inputs use the same host-validated jump action.

Heavy launches retain horizontal momentum through the air, tumble about the torso, break building sections on high-speed contact, bounce once on landing, then recover. Gojo remains immune to his own Hollow Bomb health damage. Sprint speed remains 26 m/s.

Red charges at Gojo’s extended fingertip, fires a narrow tracer with recoil and leaves sparks at the muzzle for 1.2 seconds. Its bright impact is compact; the existing 140 maximum damage and gameplay falloff radius are unchanged.

The four-hit light chain now totals 75 (12, 16, 20, 27). Both domains last 12 seconds. Void deals 20 ticks of 27.5 = 550; Shrine deals 120 ticks of 5 = 600. Tick accumulation handles variable frame times and the final partial frame.

Build 07 validation: all 82 combat, domain, controls, technique and two-client simulation checks pass, plus health and audio lifecycle checks. Six isolated GPU previews inspect the Red charge, muzzle, compact impact, air-step pose, airborne tumble and landing pose. These previews are not a full browser playtest. Live Internet matches and physical input devices remain unverified here.

## Build 08 — Heian Sukuna, larger Nuke, domain barriers and voices

- Hollow Nuke's charged radius is now **60–115 metres**. A ground ring marks the blast area throughout the three-second formation. At full charge the radius exceeds the 78 metres covered by three seconds of unobstructed sprinting. Formation and burst damage remain 45 / 380, with existing falloff and caster immunity.
- Sukuna has **150 stamina**, compared with Gojo's 100. His procedural Heian form has a broader bare torso, tattoos, four eyes, an abdominal mouth and four articulated arms. The lower arms have separate movement, guard, light attack, technique, domain, launch and recovery poses. Midair jumps still cost 12 stamina and do not regenerate stamina in flight.
- Domains form a visible **27-metre physical shell** at their fixed cast origin during the **1.55-second vulnerable startup**. The HUD reports whether the target is inside. Fighters can escape before sealing; captured fighters and the caster are contained afterward, including movement, launches and teleportation. Outsiders cannot pass through the shell or deal damage across it. Rays and projectiles hit the wall. A viewer outside sees the closed shell in the normal city. Interrupted casts remove the shell. Clashes share a sealed enclosure.
- The supplied Gojo and Sukuna callouts start with casting, continue into a successful expansion or clash, and stop if casting is interrupted. Gojo's supplied theme starts when Void is established, including a clash win, and fades with its 12-second domain. Domain music ducks under speech. Voice and domain music volumes are separate; repeated online snapshots do not restart clips.
- `assets/audio/sukuna-cast.mp3` and `gojo-theme.mp3` preserve the supplied MP3 files. `gojo-cast.mp3` is a browser-compatible MP3 conversion of the supplied M4A. All three are embedded in the standalone build. The original uploads are unchanged.
- Network protocol is now `limitless-8.0`; both players must refresh to Build 08. Cast origins, barrier progress, callout identities, resource totals and the enlarged Nuke radius are synchronized from the host.

All **94 combat, domain, animation, control, effect and two-client simulation checks** pass, plus health and audio lifecycle checks. Six isolated GPU previews were inspected for the Heian model, domain and Furnace poses, forming/sealed barriers and city-scale Nuke boundary. These validate simulation behavior and isolated geometry/shaders, not full browser gameplay. Actual audio playback, live Internet matches and physical mobile/controller input remain unverified in this environment.

`src/barriers.js` owns enclosure collision, cast voice identities and the forming/sealed barrier visuals. It is included by `build.py` before the domain and combat presentation modules.


## Build 09 — white domain shells, animated quick casts and arena selection

The new reference video was inspected across its Red gathering, Purple fusion, white domain formation, purple tunnel and Void reveal. It is a visual reference, not a bundled playback asset.

- Domains now have a **54-metre radius / 108-metre diameter**, double the previous radius. The rising exterior is a solid, depth-writing white sphere; the forming interior is white too. Once sealed, the realm appears inside. The domain sky, tunnel, corona, shrine, glows and instanced cuts are bounded by the physical shell. The camera stays on the player's side of the wall, including close-ups. Startup remains interruptible at 1.55 seconds, the clash response window remains 1.5 seconds, and domain damage/duration are unchanged.
- A quick special tap queues a low-power release after its startup animation. It no longer cancels for being held too briefly. Blue gathers at the hand, Red draws streams into the fingertip, Purple brings Blue and Red together, and Spatial Shift wraps the caster in bands. Dismantle gathers cutting lines, Cleave crosses its cutting planes, Furnace forms its bow and draws the arrow, and Cursed Rush coils into a forward strike. All have anticipation and follow-through, with additional Sukuna arm poses.
- Holding still increases power at the existing rates and energy costs. After **three seconds at full charge**, the host releases the technique automatically. The HUD displays the countdown. Exhausting the available energy also starts this countdown, preventing indefinitely held partial charges. Releasing during startup locks the power already paid for and completes the animation without spending further energy. Damage can interrupt the queued startup.
- Startup times: Gojo's Blue / Red / Purple / Shift are 0.42 / 0.48 / 0.90 / 0.32 seconds; Sukuna's Dismantle / Cleave / Furnace / Rush are 0.36 / 0.44 / 0.85 / 0.32 seconds. The CPU uses the same presentation and its existing attack preparation timing.

| Arena | Layout |
|---|---|
| Night District | Original nighttime city, 32 buildings, rooftops and raised crossings. |
| Sunlit Harbor | Daylight, open promenade and plazas, 14 coastal buildings, container stacks, trees, a lighthouse and surrounding water. |
| Shattered Sanctuary | Dark stone highlands, glowing crystal ruins, radial broken bridges, floating slabs and an eclipsed moon. |

All maps retain continuous ground, scenery destruction and whole-arena restoration. Arena choice is saved on the device. Selecting a map while a match is paused applies it to the next match. The host selects the online arena before creating the room; the handshake and rematches carry that choice. Both clients build the same deterministic layout. Protocol `limitless-9.0` requires both players to refresh to Build 09.

`src/maps.js` owns the arena layouts, environment restoration and selection. `src/technique-startup.js` owns queued releases, the full-charge timer, convergent particle rigs and special body poses.

Validation: **106 simulation checks** pass, plus health and mocked audio lifecycle checks. Coverage includes quick taps and timed automatic releases for all eight specials, interruptions, resource exhaustion, startup pose/particle matrices, larger capture range, bounded realm materials, map selection/destruction/restoration, and guest arena/charge synchronization. Isolated GPU scene previews inspect the eight move startups, all three arenas, forming/sealed white barriers, tunnel, Void and Shrine. These are not a full browser or physical-device playtest; live Internet connections, actual audio output and final browser appearance/performance remain unverified here.


## Build 10 — dual techniques, movement, camera and phone layout

- **Free jumps:** both ground jumps and every Sukuna air step cost zero stamina. Sukuna launches upward at 10.2 m/s from the ground and 12.5 m/s in midair, with a 0.18-second repeat interval and a slightly stronger directional step. Jump restrictions during hitstun, charging and domain suppression still apply. Gojo ground jump remains 9 m/s.
- **Four hands, two casts:** Sukuna can charge two distinct specials at once. Each arm pair has independent anticipation, energy spending, release input and the three-second full-charge limit. An interruption cancels both. Releasing one preserves the other, including its pose and power. CPU Sukuna can overlap a secondary cut with another technique. The light chain is now 10 + 14 + 17 + 23 = 64; Gojo stays at 75.
- **Furnace:** a larger recurved bow has a white-gold spine, flame tongues, a drawn string and a bright spear-like arrow. Arrows travel at 90–120 m/s according to charge, versus 35 previously. Tap the Furnace binding again during flight to detonate at the current position without additional energy cost. Keyboard, controller and touch share this action; the ability changes to **DETONATE** while armed. Swept contact selects the first target, ground, terrain or barrier hit. The 12–22 m blast uses Hollow Nuke-style expanding energy and shockwaves in orange, destroys scenery, ragdolls opponents and leaves a short burning area. Damage remains charge-scaled 240 plus up to 60 burn, with distance falloff.
- **Movement:** Gojo's flying sprint is 36 m/s (ground sprint stays 26). Dodge impulse rises from 20 to 22. Cursed Rush travels at 48–76 m/s for about 0.46 seconds, approximately 22–35 m, with a strong tumbling launch on contact and terrain/barrier collision.
- **Spatial Shift:** 8–36 m range, 0.14-second tap startup, 0.9-second full charge, and 0.06-second recovery between casts. Quick casts can be repeated while energy lasts. Contracting rings, converging rails and compressed energy lenses visualize space collapsing along the route. Terrain and domains constrain the destination.
- **Camera Control:** opt into mouse-wheel control in Settings. Choose camera angle or distance; Alt + wheel uses the other adjustment. Hold the middle mouse button and move to swivel around the fighter without changing combat aim, then release to return. The option reserves middle mouse while enabled. View preferences persist on the device.
- **Phone UI:** Settings → **Edit Phone UI Layout** opens a drag editor for individual combat/utility buttons, the movement stick, health bars and resource bars. Positions are bounded to the viewport, saved on the device, and stored independently for portrait and landscape. **Reset** restores the current orientation. Editing suppresses combat inputs; online matches continue while their menu is open.
- **Shattered Sanctuary:** golden sunset sky, low amber sun, warm sandstone ruins, gold crystals and luminous paths. The original Night District and Sunlit Harbor remain available. Domain endings restore the selected map's lighting.

Protocol `limitless-10.0` carries both casting slots and their separate animation states; both online players should refresh to Build 10. The 18 new focused checks bring the gameplay/control simulation suite to **124 passing scenarios**, plus the health and audio lifecycle scripts. Six isolated GPU scenes cover both arm-pair bow placements, the miniature blast, spatial compression and the sunset. These checks use a simulated DOM/renderer and isolated actual GLSL rendering; full browser, physical phone/controller, audio audition and public Internet multiplayer playtests remain unverified here.

## Build 11 — cursor, character view and movement costs

- **Free cursor:** Left Alt releases the mouse while the match keeps running, so practice buttons such as Domain Clash Drill can be clicked. Press it again to return to aim. Settings → Camera Control offers toggle or hold behavior. Controls & Audio can rebind it, including to Ctrl; duplicate bindings swap so descent remains available. Existing custom bindings are preserved when the new actions are added.
- **Character view:** V toggles a persistent 360° orbit without turning the fighter or changing combat aim. Move the captured mouse to orbit, or drag the arena while the cursor is free. The wheel zooms. The same option is available in Camera Control; disabling it returns smoothly to the combat camera. Mouse attacks are suppressed while inspecting or clicking UI. The optional wheel-camera control now uses **Shift + wheel** for its alternate adjustment, freeing Alt for the cursor.
- **Jump costs:** the first ground jump remains free for both fighters. Each additional Sukuna air jump costs **3 cursed energy** and no stamina; insufficient cursed energy prevents another air step. The existing height, speed and 0.18-second repeat interval remain. Practice mode replenishes resources as before.
- **Gojo flight:** normal levitation costs **5 stamina per second**, down from 12. Moving while sprinting adds the existing 4.5 stamina per second, for **9.5 total**. Flight speeds are unchanged.

The nine focused checks cover pointer-lock lifecycle, practice clicks, toggle/hold input, remapping and saved settings, full camera orbit, local-only online camera actions, and exact movement costs. They use the simulated DOM/renderer; browser-native pointer lock and physical-device playtests remain unverified here. The network schema is unchanged at `limitless-10.0`; both players should refresh to Build 11 for the same movement balance.

## Build 12 — persistent cursor dragging and source guide

Free-cursor dragging now retains its angle between strokes, so repeated drags can reach the front of the fighter without enabling V separately. Unlocked dragging reads pointer coordinates, captures the pointer until release, and avoids applying the companion mouse event twice. Target lock and cinematic close-ups no longer override the free-cursor view. The wheel zooms while the cursor is free; returning to combat aim recenters smoothly. Three focused pointer lifecycle/geometry simulations and the nine Build 11 checks pass; browser-native pointer capture remains unverified.

`START-HERE.md` maps the full source and procedural models, explains editing/rebuilding, and quotes the model constructor. All Build 11 resource costs are retained.

## Build 13 — cursed energy flight

Gojo levitation now costs **2 cursed energy per second** and no stamina. It can start with zero stamina when cursed energy is available, and ends when cursed energy runs out. Moving while sprinting still costs 4.5 stamina per second in addition to the flight energy drain. Local and host-simulated remote Gojo use the same rules. Practice retains its unlimited-energy refill. The field manual and source guide reflect the new cost. Focused simulations verify steady drain, sprint separation, zero-stamina activation, empty-energy rejection, depletion/gravity and remote flight.

## Build 14 — free-for-all and multi-player clashes

- Six independent fighter slots support any human/AI mix, duplicate characters, independent charge slots, Blue fields, Hollow Nukes, projectiles and resources. Solo setup persists in the browser.
- AI difficulty controls reaction time, attack cadence, charging, guarding and dodging. Every bot targets live opponents; there are no teams.
- A domain can capture multiple enemies. Each timely counter within the first cast's 1.5-second window joins the same clash. Every participant has a separate attack-point bar. The first to 12 points wins once the join window closes; sure-hit damage affects every captured enemy.
- Domain-expansion cutouts use the game's own model portraits. A diagonal cast strip follows the supplied October 3 reference; three-way clashes use a Y-shaped composition. Four through six participants use a panel grid.
- Cast sound channels and portraits identify individual fighters. The last survivor wins, eliminated humans spectate, and a disconnected clash participant forfeits without stalling the other fighters.

Validation uses real Three.js scene/math objects with a simulated DOM, renderer and in-memory networking. Isolated GPU previews inspect the model portrait framing. Live browser rendering, Internet WebRTC sessions and physical input devices have not been playtested here.
