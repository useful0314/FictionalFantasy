# Mahito — Build 26

Mahito is selectable in solo/practice free-for-alls and private rooms. Duplicate Mahitos work independently. This is a playable prototype of the requested kit, not an applied balance pass. The shared dodge change in Build 26 applies to every character. Other kit tuning remains as before. No paid assets or plugins are required.

## Controls and implemented behavior

| Input | Move | Behavior |
| --- | --- | --- |
| 1 | Shapeshifting Arms | Cycles Blade → Gun → Hammer. Normal attack uses the selected arm form. |
| 2 | Morphed Humans | Expels four autonomous allies. They attack other fighters, including other Mahitos, and never target their owner. Recasting replaces the owner's prior wave. |
| 3 | Serpent Express | Summons a large segmented creature beneath Mahito. Ride it and steer continuously with aim or movement, including a 180-degree turn and vertical aim. Its visible trail follows the traveled route. Scenery and domain barriers stop the ride. |
| 4 | Soul Regeneration | Holds a stationary healing pose; enemy damage interrupts it. Full health cannot start a heal. |
| 5 | Body Transformations | Cycles Big → Small → Winged. Forms expire back to normal. Winged automatically starts flight; Jump/Descend move vertically. |
| 6 | Cursed Touch | Spends 20 percentage points of ultimate on the attempt. A successful touch slightly distorts the opponent and seals one technique temporarily. A miss does not damage, deform or seal anyone; the attempted cast still spends its meter. |
| Q | Self-Embodiment of Perfection | Uses the existing domain meter, vulnerable startup, capture sphere, multi-way clash and burnout. A mass of hands expands through every hemisphere. Mahito moves faster; captured rivals move slower. His own landed melee/touch attacks execute a captured opponent. Four pursuing hands per caught rival deal contact damage; these do not execute. Summons, gun shots, the serpent and the decorative surrounding hands do not execute. |

Keyboard bindings remain rebindable. The new sixth action defaults to **6** and **RT/R2** on a standard controller. Mobile gets a sixth movable button. All existing movement, guard, dodge, energy recharge, camera and wall-running controls remain available outside action locks. While Winged, flight uses the existing **2 energy/second** rule.

Cursed Touch seals slots 1–4 for Gojo, 1–5 for Sukuna/Naruto and 1–6 for Mahito. The host rotates the chosen slot on successful touches. A seal cancels a held charge for that slot and blocks starting/releasing it until the timer expires. It does not disable movement, guard, dodge, energy recharge or Q. The affected HUD card dims and a countdown identifies the sealed slot. No new stun is added by the seal itself.

Existing practice mode keeps fighters at 1 HP, and Impossible AI retains its immunity to human damage. Those shared rules also apply to Mahito's domain. Existing domains are otherwise unchanged.

## Current functional defaults — not the proposed balance pass

The numerical values below make the requested behaviors testable. They are grouped at the top of `src/mahito.js`. There are **no newly imposed long cooldowns or energy costs for moves 1–5**. Actions occupy their startup/active/recovery animation and use the existing short shared recovery lock. The optional recommendations below are documentation only.

| Property | Current value |
| --- | --- |
| Base HP / stamina / maximum energy | Existing 1000 / 100 / 100 |
| Normal hands | Existing 12 / 16 / 20 / 27 light damage |
| Blade arms | 5.8m reach, 70% light damage, 72% normal swing duration |
| Gun arms | A small morphed-human projectile; 12 damage per shot, 48m/s, 1.25s life / 60m travel |
| Hammer arms | 4.4m reach, 240% light damage, 180% swing duration; heavy arcing knockback |
| Summons | Four; 8s lifetime; 14m/s pursuit; 12 damage per hit at 0.8s intervals after arrival; 0.65s summon startup + 0.35s recovery |
| Serpent | 0.55s startup, 2.4s ride, 0.4s recovery; 48m/s; 100 damage once per rival per ride; 2.3m swept contact radius |
| Regeneration | 0.65s startup, 3s healing at 50 HP/s, 0.35s recovery; 150 HP maximum per uninterrupted use |
| Big form | 175% model scale, 65% movement speed, 175% normal-attack damage |
| Small form | 55% model scale, 135% movement speed, 55% normal-attack damage |
| Winged form | Normal scale/damage, flight through the shared flight system |
| Form lifetime / transition action | 12s / 0.38s; using 5 again selects the next form and refreshes lifetime |
| Cursed Touch | 20% ultimate; 0.32s startup + 0.16s contact window + 0.32s recovery; 2.8m reach, 0.9m target test; 8s technique seal; no ordinary HP damage outside the domain |
| Domain | Existing 12s duration, 54m sphere, 1.55s vulnerable startup, 1.5s clash entry window, 12 clash points, 15s post-domain burnout |
| Pursuing domain hands | Four per caught rival, max 20; 24 damage per contact, 13.2 guarded; 0.55s wind-up, 23m/s chase, 2.4s chase timeout, 0.70s recovery; dodgeable |
| Surrounding hands | 224 (96 low quality); articulated fingers and thumb; visual only |
| Shared dodge | 1.5s cooldown; extra travel; original 0.34s immunity / 0.20s perfect window |
| Domain movement | Mahito 120% movement speed; captured rivals 65% |

Blade/hammer attacks use the existing blockable light-hit path. Gun and summon attacks use the existing special-hit behavior and currently penetrate guard. Dodge can avoid contact, including an attempted domain execution. Guard's ordinary domain reduction does not make an execution survivable. Merely standing near Mahito is not contact: he must land an attack.

The form scale is visual; the existing fighter collision capsule remains unchanged. Summons are temporary attack agents rather than additional roster fighters, so they do not add player health bars or clash participants. They currently expire or disappear with their owner; killable summon HP is a recommendation below, not active behavior.

## Balance suggestions — NOT implemented

These are candidates for playtesting, not claims of proven balance. The current engine has a shared special recovery timer, so independent per-move cooldowns would need a small separate Mahito timer helper before these could be enabled.

| Move | Suggested cooldown / resource cost | Suggested counterplay |
| --- | --- | --- |
| Arm cycling | 0.5s between switches; no ultimate cost | Block blades, make gun shots blockable, punish the hammer's readable wind-up. |
| Morphed Humans | 12s; 20 energy | Give each summon about 60 HP so opponents can clear them; no meter farming from hitting summons. |
| Serpent | 10s; 25 energy | Keep the visible track and startup; allow lateral dodges and punish the landing. |
| Soul Regeneration | 18s; 30 energy | Keep damage interruption and stationary healing; prevent repeated free sustain. |
| Body Transformations | 10s; 15 energy; consider 8s forms | Big should remain punishable at range; Small trades damage for speed; Winged remains visibly airborne and limited by energy. |
| Cursed Touch | 6s; retain your fixed 20% ultimate cost | Keep the short range and readable reaching pose. Consider preventing repeat seals from extending the same lock indefinitely. |
| Domain | Full meter; consider **8s** instead of the inherited 12s | Give the touch a conspicuous tell; dodge and maintain distance. Escape before the existing 1.55s seal, clash during the 1.5s entry window, or defeat Mahito. A breakable barrier would be a separate new mechanic, not something currently supported. |

No recommended cooldown, extra energy cost, summon HP, shorter domain/form duration or breakable-barrier feature above is enabled.

## Source and integration

The user specification fixes the meter requirement: **“This costs 20% of the ultimate meter.”** The implementation matches with `touchMeter:20`. Domain lethality follows **“Anyone he touches inside the domain dies.”** The `mahitoExecution` helper applies it only to Mahito's direct light/touch contacts against captured rivals.

Exact code anchors:

```js
touchMeter:20,disableTime:8
domainHaste:1.2,domainSlow:.65
```

The first excerpt appears within the touch tuning row of `src/mahito.js`; the second within its domain/projectile row. Shared timing remains `duration:12` in `src/domains.js` and `duration:15` in `src/domain-burnout.js`.

| File | Where it plugs in |
| --- | --- |
| `src/mahito.js` | Tuning, move actions, normal-attack forms, summons, projectiles, touch seal, host snapshot data and HUD status. Narrow hooks in the existing attack/input/update/damage functions. |
| `src/mahito-model.js` | Same articulated rig contract as the other characters. Rig selection in `ensureActorRig`; model detail animation after the existing fighter animation. |
| `src/mahito-animation.js` | Eased target poses, blended by the shared animator; existing damage, guard, wall, dodge and ragdoll priorities remain. |
| `src/mahito-hands.js` | Instanced palm/forearm, 14 finger segments and stitched details; reused for background and attacking hands. |
| `src/mahito-domain.js` | Host-owned chasing hands, contact damage, network validation and interpolated guest display. |
| `src/mahito-vfx.js` | Reusable creature/track meshes, instanced domain hands, full-sphere clipping and mixed-clash presentation. Uses existing pooled smoke/impact effects. |
| `src/mahito.css` | Character card and sealed-technique presentation. |
| `src/controls.js`, `src/session.js`, `src/network.js`, `src/index.html` | Sixth action, selector, mobile button, controller binding and validated host/guest replication. |
| `build.py`, `tests/harness.mjs` | Load the new helpers into the existing bundle and simulation harness. |

No manual input registrations or asset downloads are required. Everyone in a private room must refresh to **Build 26**, protocol `limitless-26.0`.

## Verification

**63 check groups passed**: Build 26 (10), Build 25 (14), Build 14 (16), Build 23 (18), Build 24 (5). Build 26 adds pursuit, contact/guard/dodge, FFA ownership, elevated targets, cleanup, bounded instancing, animation continuity, shared dodge distance/cooldowns/collision and packet validation.

`tests/build25.mjs` exercises real Three.js rigs and simulation, keyboard/touch/controller registrations, all six moves, 180-degree steering at 30/60/120 Hz, thin-wall/domain collisions, interrupted healing, form expiry, touch hit/miss/expiry, lethal domain contact, elevated multi-way clashes, six-Mahito ownership and validated host/guest packets. Existing Build 14, 23 and 24 regression suites cover multiplayer/combat, domains and wall jumps. Native OpenGL previews inspect models, hands and the serpent; these do not measure browser/device performance. Browser play, physical controller/mobile use and 60fps performance have not been verified in this environment.
