# Build 28 — linked punches and spinning kicks

Play: https://limitless.useful0314.chatgpt.site

Refresh until the menu says **BUILD 28**. Keep the movement controls neutral when pressing light attack for the four-hit sequence below; the existing movement-direction modifiers still select the side kick, uppercut, sweep or aerial slam.

| Hit | Animation |
| --- | --- |
| 1 | Right punch: shoulder chambers, right fist extends, left hand protects the face. |
| 2 | Left punch: weight and torso rotate the other way, left fist extends, right hand guards. |
| 3 | Right roundhouse: knee chambers, supporting left foot pivots, right leg sweeps across the opponent, then folds into the turn. |
| 4 | Spinning left kick: continues the roundhouse turn, switches support to the right foot, extends the left leg, then settles back into stance. |

These are the fighter’s anatomical sides. The inherited rig’s index 0 is the right limb at local −X, and index 1 is the left limb at local +X. Existing model names and joint contracts are preserved.

The sequence runs on Gojo, four-armed Sukuna, Naruto and Mahito. Sukuna’s lower arms guard and counterbalance instead of replacing the kicks with extra punches. Mahito’s blade and hammer forms follow the sequence at their existing tempos; gun form retains its projectile firing animation. Naruto’s technique-specific Uzumaki Combo and clone move tracks remain separate from this ordinary light chain.

## Animation changes

- Each attack blends from the actual current pose, then follows eased anticipation, contact, and recovery phases. Straight punches have a small capped snap overshoot; kicks carry an unwrapped body turn through both hits.
- The contact pose lands on the existing damage event rather than trailing it through a second full-body blend. Directional side kicks, uppercuts, sweeps, aerial slams and counters use the same entry and recovery treatment.
- Support-foot compensation acts on the visual body only, with bounded lateral correction. Ankles, knees, torso twist, head spotting, fist closure and squash/stretch remain independently animated.
- The third hit briefly holds a linked recovery when it connected. If the chain stops, the turn settles cleanly. A delayed fourth hit continues forward from the displayed angle. Guard, hit reactions, dodges, ragdolls, wall movement and techniques keep their existing animation priorities.
- Fast hands and feet sample the existing bounded particle pool more frequently during the chain. Existing hair, jacket and headband secondary motion stays active. Mahito’s hair sway remains bounded through repeated full turns.
- Guests advance the visual attack clock between snapshots using the existing replica age. No new packet fields or gameplay prediction are introduced.

## Exact tuning

From `src/light-combo.js`:

```js
const LIGHT_COMBO_MOTION={rightLimb:0,leftLimb:1,entryBlend:.08,windupFraction:.27,linkHold:.12,linkSettle:.22,plantLimit:.38,contactHold:.055,punchOvershoot:1.045,trailInterval:.025};
```

Entry blending lasts up to **80ms**, shortened only when necessary for an existing fast contact time. Wind-up occupies **27%** of startup. Contact holds **55ms**, scaled for Mahito’s weapon tempo. The roundhouse link holds for **120ms**, then settles over **220ms**. Support-foot correction is limited to **0.38 world units** per horizontal axis. Trail sampling uses a **25ms** interval while the shared clip is active.

Pose templates are grouped immediately below those constants. Their authored local sides are mirrored once on initialization; no per-frame pose arrays, vectors or matrices are created by the new helper.

## Preserved combat

| Rule | Value / behavior |
| --- | --- |
| Standard light damage | 12 / 16 / 20 / 27 |
| Sukuna light damage | 10 / 14 / 17 / 23 |
| Light attack stamina | 3 per accepted attack |
| Neutral attack duration / contact | 0.34s / 0.12s; Mahito keeps his existing arm-tempo multiplier |
| Counter duration / contact | 0.32s / 0.09s; existing Mahito scaling preserved |
| Directional contact | Side kick 0.14s; uppercut, sweep and aerial slam 0.12s |
| Combo advancement | Confirmed hits only; whiffs and blocked openers still break the chain |
| Finisher | Existing damage, launch, knockback, recovery and cooldown |
| Other gameplay | Existing hitboxes, ranges, targeting, technique damage, costs, cooldowns, hit-stop, movement, domain rules and inputs |
| Networking | Existing host authority and `limitless-26.0` packet format |

This is an animation update. It does not rebalance Mahito’s weapon or body-form multipliers, introduce hit events, or change attack reach.

## Source hooks

| File | Purpose |
| --- | --- |
| `src/light-combo.js` | New visual-only helper: shared chain, directional contact sampling, entry capture, linked turn, foot compensation, replica-age sampling and tuning. |
| `src/animation-polish.js` | Existing `rosterLightPose` calls the helper; shared detail pass applies foot compensation, ankles and pooled trails. Uppercut chamber is slightly raised for a smoother strike arc. |
| `src/animation.js` | Existing shared animator consumes the sampled pose, keeps the spin continuous, curls fists and assigns Sukuna’s lower-arm guard. |
| `src/naruto-animation.js` | Existing Naruto animator consumes the same light clip, linked recovery and body turn; technique/clone tracks retain priority. |
| `src/mahito-animation.js` | Gives the shared melee clip priority while retaining gun and special-action poses. |
| `src/mahito-model.js` | Ankle targets follow the clip; hair sway stays bounded through full spins. |
| `build.py` / `tests/harness.mjs` | Register `light-combo.js` beside the existing animation helpers. |
| `tests/build28.mjs` | New anatomical-side, contact, continuity, delayed-link, combat, override, weapon, replica and pool checks. |

No assets, registrations or inputs need to be connected manually. The existing build script includes the helper automatically.

## Verification

**65 automated groups passed:** Build 28 (11), Build 27 (10), Build 26 (10), Build 25 (14), Build 17 (20). The new checks inspect actual Three.js hand/foot positions and joint rotations, test linked kicks at 30/60/120 Hz and delayed fourth inputs, execute the real combat resolver, preserve damage/stamina/guard/whiff behavior, exercise Mahito’s forms and Sukuna’s lower hands, check guest playback between snapshots, and verify reuse of animation buffers and particle pools.

Native OpenGL previews were inspected for all four characters’ contact poses and Naruto’s kick anticipation, transition and recovery. The standalone HTML and hosted build pass module syntax and whitespace checks. Browser play, phone/controller hardware, live Internet latency and sustained device FPS were not verified here.
