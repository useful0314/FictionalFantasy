# Build 40 — Readable, satisfying combat feedback

Implemented in the existing Limitless project. This is a cosmetic combat pass: damage, hitboxes, range, meter costs, cooldowns, attack startup, hit-stop timing, movement and multiplayer authority retain their existing rules.

## Research → implementation

These are primary teaching/developer sources read for this pass. Their principles were adapted to our Three.js game; their example projects and assets were not imported.

| Source | Short quotation | Application in Limitless |
| --- | --- | --- |
| [GDQuest — Juicing up your game attacks](https://www.gdquest.com/library/juicy_attack/) | “briefly turns the sprite white” | A short white flash on the damaged character, eased directional recoil, and layered contact accents. Existing anticipation, trails and hit-stop remain in use. |
| [Riot Games — Visual Effects](https://www.riotgames.com/en/artedu/visual-effects) | “balance satisfaction and gameplay clarity” | Different visual shapes/colors for damage, blocks, dodges and landings; short lifetimes; restrained chip-damage feedback. |
| [Robert Nystrom — Object Pool, Game Programming Patterns](https://gameprogrammingpatterns.com/object-pool.html) | “reusing objects from a fixed pool” | Eighteen reusable contact effects with shared geometry, cached per-rig state, and four reusable incoming-hit indicators. |

The exact durations, thresholds, colors and sizes below are implementation choices for Limitless, not values prescribed by those sources.

## What players see and hear

- **White hit flashes:** the damaged character flashes white, then returns smoothly to its normal materials. This works across all five playable characters, including duplicate-character rooms and Mahito's weapons/forms. A block, dodge, missed hit or invulnerable target does not receive a damage flash.
- **Directional recoil:** the torso/head react away from the impact direction, with a small squash and an eased return. The effect changes visual pose targets, not fighter position or velocity. Ragdolls, soul executions and domain finishers retain their own presentation.
- **Contact bursts:** a compact bright center, sharp outward streaks and an expanding ring. Heavier hits and the fourth light hit get stronger accents. Blocks use blue sparks; perfect dodges use mint accents. Effects respect scene depth and are not visible through buildings.
- **Distinct impact audio:** separate synthesized kick, finishing-hit, heavy-hit and landing envelopes use the existing sound system and spatial audio path. No new audio files or paid services are required.
- **Incoming-hit direction:** up to four short-lived arcs show where damage came from and turn correctly with the camera. They use the source position at contact, without following an opponent after that moment.
- **Weighted landing accents:** sufficiently fast falls create a soft expanding ring and a short landing sound at the actual landing height, including rooftops. Existing dust remains in use.
- **Finishing-hit confirmation:** the fourth light hit receives a warmer, heavier confirmation mark. Its damage and existing 35ms hit-stop are unchanged.

## Settings

Under **COMBAT FEEDBACK**:

- `Character hit flashes`
- `Contact sparks & landing rings`
- `Incoming damage direction`

These save with the existing device-local settings. Character flashes are independent of the existing `Full flashes` option, so full-screen flashes can remain off while white character confirmation stays on. The existing sound toggle and volume controls govern the new impact sounds.

## Tuning

Constants are grouped in `COMBAT_FEEL` at the top of `src/combat-feel.js`.

| Parameter | Value |
| --- | ---: |
| Normal / heavy character flash | 105ms / 140ms |
| Initial flash hold | 18ms |
| Minimum interval between flash restarts | 240ms |
| Chip-damage flash strength | 30% |
| Recoil envelope / peak | 240ms / 35ms |
| Maximum cosmetic squash | 4.5% before impact strength weighting |
| Normal / heavy contact burst | 240ms / 340ms |
| Contact pool | 18 entries, 3 shared geometries |
| Contact-effect visibility range | 95 world units from the local fighter |
| Incoming-hit indicators | 4, lasting 900ms each |
| Landing speed threshold / full-strength speed | 6 / 24 world units per second |

The existing per-target hit-feedback cadence also applies. Repeated low damage does not keep a character permanently white. Hit feedback uses no gameplay random draws. Contact effects reuse geometry/materials and do not allocate a new mesh on each hit.

## Code and hooks

| File | Purpose |
| --- | --- |
| `src/combat-feel.js` | All new flash, recoil, contact pool, landing and incoming-direction logic |
| `src/combat-feel.css` | Incoming-hit arcs and finishing-hit marker |
| `src/game.js` | Confirmed damage/block/dodge hooks, impact sound selection and initialization |
| `src/animation.js`, `src/naruto-animation.js` | Directional reaction targets in the existing animators |
| `src/animation-polish.js` | Existing landing event connects to the new accent |
| `src/roster.js` | Prepare material uniforms when an existing rig is selected |
| `src/session.js` | Replay authoritative hit context and update cosmetic lifetimes |
| `src/presentation.js`, `src/index.html` | Match cleanup, build label and settings controls |
| `src/audio.js` | Four impact/landing envelopes in the existing audio class |
| `build.py`, `tests/harness.mjs` | Include the separate module using the existing build insertion point |
| `tests/build40.mjs`, `tests/audio.mjs` | New outcome/lifecycle checks and impact-audio validation |

The material hook adds a per-rig uniform after the existing material's opaque color output. Normal textures, lighting, fog, clipping and material references remain intact. Material restoration after domain finishers was specifically checked. No renderer, scene hierarchy, character factory or transport rewrite was needed.

Private-room messages now carry impact style and direction on the existing confirmed-hit event. Room compatibility is `limitless-40.0`; every participant should refresh before joining.

## Verification

**127 automated check groups passed**, plus the audio lifecycle/envelope suite:

| Suite | Groups |
| --- | ---: |
| Build 40 feedback, material isolation, recoil, pools, settings and host/guest playback | 20 |
| Build 39 presentation and camera | 23 |
| Build 27 models and animation | 10 |
| Build 29 ground/air combos | 8 |
| Build 38 ground webs and sliding | 16 |
| Shared mechanics | 23 |
| Online controls | 15 |
| Domains and transitions | 12 |

The tests exercise actual Three.js math, geometry and scene state with synthetic input and host/guest snapshots. Material hooks are checked against the bundled Three.js r170 shaders. Coverage includes duplicate characters, material restoration after finishers, 30/120Hz timing, repeated chip damage, six-fighter matches on every map, pause/reset cleanup and pooled-object reuse. Audio checks validate scheduling, distinct envelopes and mute behavior.

Browser/GPU visual QA and listening tests were unavailable. Shader hooks were inspected, not GPU-rendered; sound was mocked, not auditioned. Device frame rate, subjective feel and Internet multiplayer performance still need live playtesting.
