# Build 36 — Bigger Skyline Boroughs and exact web aiming

Skyline Boroughs keeps its original blocks, parks, houses and spawn plaza, with new northern skyscraper rows, outer avenues and southern mid-rise blocks. Roads, lamps, ground and the arena edge extend into the new space. The decorative horizon moves outside the expanded playable boundary.

| Setting | Previous | Build 36 |
|---|---:|---:|
| Playable diameter | 352m | 520m |
| High rises | 8 | 32 |
| Total buildings | 40 | 72 |
| Tallest occupied roof | 64m | 96m |
| Map height limit | 72m | 124m |
| Web attachment range | 95m | 125m |
| Web reeling speed | 28m/s | 44m/s |

The playable area is about 2.18 times its previous size. Other maps retain their original bounds and height limits. Map tuning is in `METRO_MAP` at the top of `src/map-metro.js`; `applyArenaMap()` applies and restores the bounds and ground scales when switching maps.

## Web controls

Point the crosshair at an intact wall, roof or ledge, then press the existing Web Swing input (default **4**). A blue crosshair with **WEB · distance** confirms a reachable surface. **NO ANCHOR** means there is no valid point; pressing Swing in that state spends no energy and starts no cooldown. Press **4** or **Jump** again to release with momentum.

Attachment now uses the actual camera-center ray and rendered triangles, including windows, roof details and awnings. It accounts for camera shoulder offset, zoom and camera motion. There is no nearby-building ranking or direction snapping. After firing, the world-space attachment point stays fixed as you turn the camera. The visible strand ends at that same point.

Webs cannot pass through an intervening wall or domain barrier. Destroyed or domain-hidden scenery cannot provide anchors; losing the attached surface releases the swing. Existing energy costs, swing speed, steering, combat moves and release momentum remain. Reeling is faster to support longer street-level attachments.

## Small integration hooks

- `src/spiderman.js`: reusable aim scratch state, `captureSpiderView()`, rendered-surface query, exact `findSpiderAnchor()`, crosshair feedback and swing tuning.
- `src/session.js`, `src/game.js`: pass the optional captured view with the existing special input. Other inputs keep their existing behavior.
- `src/network.js`: a Swing press may include its camera origin and unit direction. The host validates the view and computes the actual collision point itself, using the existing authoritative action and snapshot systems. Guests cannot supply an anchor position. Snapshot vectors retain the existing millimetre rounding.
- `src/style.css`: blue valid-anchor reticle and compact distance/miss label.
- Existing mesh batching, instanced windows, destructible floors, wall-running surfaces and web strand pools are reused. No new dependencies or paid assets.

## Verification

108 simulation/check groups passed across `build36`, `build35`, `build34`, `build33`, `build29`, `build27`, `mechanics`, `online-controls` and `domains`.

The new checks cover building counts and non-overlapping footprints, boundary/height changes, switching back to every old map, deterministic private-room terrain, exact projected crosshair hits at multiple camera positions/FOVs, narrow misses without spending resources, roof/window/awning geometry, nearest-surface selection, range, occluded shots, domain barriers, fixed strand endpoints, destroyed anchors, guest view capture and malformed input rejection. Existing Spider-Man frame-loop swing/release checks pass at 30/60/120Hz.

Browser/GPU/device visual QA was unavailable. These checks use the real Three.js math and geometry in the existing simulation harness; they do not certify frame rate or WebRTC over a public network.

Private rooms use `limitless-36.0`. Every participant should refresh to Build 36 before joining.
