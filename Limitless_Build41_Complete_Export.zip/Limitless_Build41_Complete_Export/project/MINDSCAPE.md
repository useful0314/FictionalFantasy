# Mindscape: Kurama’s Cage — Build 23

Naruto’s **Q** uses the existing domain input and ultimate meter. **5** now activates Nine-Tails Chakra Mode into Tailed Beast Bomb for 45 chakra + 30% ultimate, with a 12-second shared special cooldown. Its 520 direct-hit damage, 2.1-second startup, projectile, transformation, cinematic and interruption behavior remain; both costs are paid upfront and are lost if interrupted. Controller default: D-pad right. Mobile has a fifth technique button. All bindings remain configurable.

## Domain and seal values

The existing `castDomain()` entry, full-meter gate (threshold 99, then consumed), once-per-match emergency exception below 5 HP, 1.55-second vulnerable cast, 54 m white spherical enclosure, capture list, 1.5-second counter/join window, 12-point clash, domain cooldown handling and host-authoritative outcomes remain in use. Damage interrupts the vulnerable cast with no refund. No sure-hit occurs during the clash.

`MINDSCAPE` at the top of `src/mindscape.js` contains the complete tunable stage and clash values:

| Stage | Active-domain age | Sure-hit damage | Naruto clash point multiplier | Presentation |
| --- | --- | --- | --- | --- |
| 1: The seal holds | 0–4 s | First clone wave | 0.65× | Low red glow; chakra links connect the cage to the attacking clones |
| 2: Kurama stirs | 4–8 s | Continuing clone waves | 1.10× | Brighter eyes, reaching claws, stronger ripples and pipe shake |
| 3: Seal fracture | 8–12 s | Remaining waves; final clone bomb hits at 11.35 s | 1.55× | Seal crack, Kurama roar, golden cloak; the fox stays behind the gate |

The sure-hit is now **six clones per captured rival**, up to 30 visible domain clones, in four staggered waves. Each wave deals 12 + 12 combo damage, 18 + 18 Rasengan damage, 30 Rasenshuriken damage and 60 small Tailed Beast Bomb damage: **150 per wave, 600 total**. The first wave begins at 1.45 seconds, repeats every 3 seconds, and staggers its six strikes by 0, .13, .26, .39, .60 and .90 seconds. The last strike is at 11.35 seconds. Guard reduces the total to **330**; domain sure-hit bypasses dodge at all heights. The old stomps and final slam are no longer called. Impossible AI keeps its existing immunity.

`MINDSCAPE_ASSAULT` in `src/mindscape-clones.js` contains all assault timing, damage, technique, formation and tether tuning. These are smaller domain variants of Naruto's techniques, with damage delivered once through the existing `hurt(..., 'ultimate')` path. They do not spend extra energy or ultimate, create fighters/health bars, or grant clash points. Active domains only attack their captured living rivals; no sure-hit runs during clashes. Changing the domain duration clips the configured wave schedule at that duration.

Clash stage age comes from the existing `clash.t`. Naruto starts at `clashBase: .65`, plus stage bonuses `0`, `.45`, `.90`. This scales the existing attack-point gain; the contest still requires 12 points and the normal join window. Gojo and Sukuna retain their original point gains. When the winner establishes their domain, the existing active-domain clock starts at zero, with a full 12-second lifetime. Stage durations can be tuned separately; the domain lifetime is their sum. The Stage 3 cloak/roar presentation uses the total domain duration minus `finisherDelay`; the clone hit schedule has its own top-level tuning.

`MINDSCAPE.clones.enabled` toggles the optional bonus. Each unspent Shadow Clone Barrage clone adds 0.10× to Naruto’s point multiplier, capped at 0.30×. Clones poof after their existing timed strike; damage to Naruto cancels his pending barrage and removes its bonus. These are the existing temporary attack clones, not separate AI fighters or a new clash input. There is no extra input or resource system.

Winning triggers a chakra shockwave with 48 pooled shattering fragments. Losers receive 15 seconds of technique burnout when the clash resolves, with no added stun. The winner receives the same burnout when their active domain ends. Only special techniques and Q are locked; movement, light combat and guarding remain available. If Naruto loses, the cage collapses into the winner’s sure-hit: his dodge cannot avoid those domain ticks. This applies only to a Naruto who lost that clash; ordinary attacks and other characters’ existing dodge rules are unchanged. Gojo’s suppression and both original domains’ base damage/timing remain unchanged. Guard now reduces domain damage by 45% across all characters; Void keeps its existing 0.38-second guard delay.

## Camera behavior

`DOMAIN_CAMERA` at the top of `src/domain-cinematics.js` controls orbit radius, height, one full turn, the 0.10-second blend, 2.35-second clash intro and split-view field of view.

- A player sees the expansion orbit only while their own fighter is casting. Other fighters keep their normal cameras and can act during the vulnerable window.
- Only clash participants see the split intro. Two participants receive equal halves; three receive equal thirds. Wide screens use columns; portrait screens use rows. Four to six use a two-row grid. These are actual 3D views of the fighters in the arena, not portrait cutouts.
- Each panel follows and orbits its fighter. Framing widens enough for Sukuna’s four arms. Idle participants hold their existing hand-sign pose during the intro; attacking, taking damage or charging uses the corresponding live combat animation. No input or combat timers are frozen.
- Cameras respect **Cinematic camera**, free cursor and character-view overrides. A spectator or nonparticipant does not receive the split. The renderer restores the full viewport afterward.
- The existing domain arrival environments remain visible to captured opponents; camera locality does not hide the domain itself. Gojo’s entrance field-of-view emphasis is now local to its owner.

## Mixed-domain visibility (Build 21)

`src/domain-mixed.js` composes the existing Void/Shrine backdrop with a smaller Kurama cage chamber in a separate sector. Two-way clashes show the cage beside the opposing realm; three-way clashes position the cage, vortex and shrine separately. The spherical sewer dome is hidden in mixed presentation so it cannot occlude the other domains. The cage alcove stays separate; broad flat corridor walls and ceilings are hidden in all presentations. Reflective water stays at the arena floor, on the cage side. Duplicate Naruto-only clashes retain the spherical sewer. Winning restores Naruto’s full spherical vault; losing uses the existing collapse into the winner’s realm.

`MIXED_DOMAIN` at the helper’s top tunes cage scale/opacity and the other realm positions. `src/domains.js` dispatches the mixed backdrop; `src/roster.js` rebuilds it when someone joins; the `src/session.js` presentation key includes the participant list for guests. `src/domain-cinematics.js` faces the Void vortex to each split camera and restores its regular orientation afterward. No combat or clash values are modified.

## Model, environment and effects

The sewer uses a procedural spherical stone vault with pipe/rib lines, red chakra currents and rippling water across the lower hemisphere. The reflective water plane remains at world-floor height, clipped to the sphere, so an airborne domain has no floating floor through its players. The cage alcove contains 37 iron bars, a paper seal, an articulated fox head/jaw and reaching claws. `src/kurama-model.js` retains the angular head, long tapered muzzle, narrow eyes, pointed ears and fang-filled jaw. Kurama remains behind the bars and powers the attacking clones through red-orange tethers. The retained full-body model in `src/kurama-domain.js` is hidden, and its old roam/stomp functions are no longer used by the active domain.

Clone joints sample Naruto's existing combo, Rasengan, throw and bomb tracks. All clones, sphere effects and tether buffers are pooled. The shared clone pool has 48 slots (up to 18 ordinary barrage clones plus 30 domain clones); only active instances draw. Guest clients reconstruct the visual timeline from the existing domain age, origin, capture list and fighter positions. Only the host applies hits. The water uses analytic cage/eye reflections without a planar-reflection render pass.

The realm fades in with the forming white barrier and out over its final 0.65 seconds. The active realm dims the map lighting and recolors existing terrain as sewer stone, preserving terrain collision/destruction. Material, lighting and decoration state restore on exit. Realm meshes are clipped to the shared physical sphere; outside players see the white exterior and their arena. The separate pool is reused across casts rather than disposed with temporary domain layers.

Dust and chakra use Naruto’s existing 900-slot particle pool. Pipes and shattering fragments use instancing. Five rumble/roar/seal/outcome sounds are synthesized through the existing audio engine; no new recording, plugin or paid asset is needed. Current pool sizes, stage lighting/shake and durations are tunable in `MINDSCAPE`, `NARUTO` and `NARUTO_VFX`.

## Existing-system hooks

All hooks below are already applied in this source tree. No manual hookup is needed to play the bundled HTML.

| File | Narrow integration |
| --- | --- |
| `src/mindscape.js` | New Naruto-only domain timing/damage, clash multiplier, result flags and shared presentation context |
| `src/kurama-model.js` | Shared procedural fox head, muzzle, ears, fangs, claws and jaw tuning |
| `src/kurama-domain.js` | Retained full fox model; roaming/stomp functions are inactive |
| `src/mindscape-vfx.js` | New pooled sewer/cage, Kurama animation, water/seal shaders, environmental transitions and stage HUD |
| `src/domain-cinematics.js` | New local camera eligibility, orbit, equal-panel geometry, scene render views and presentation-only hand-sign helper |
| `src/roster.js` | Naruto uses the existing domain path; selects Mindscape backdrop, result effect and AI fifth move |
| `src/domains.js` | Naruto-only update/backdrop dispatch and pool cleanup; original domain update branches retained |
| `src/game.js` | Existing `hurt()` point-gain hook and targeted sure-hit rule; camera/render/slot-5/HUD/reset hooks |
| `src/naruto.js` | Bomb is `castNarutoBomb()` on slot 5; directional clone spawn/lane selection using existing hit tests |
| `src/naruto-animation.js`, `src/animation.js` | Presentation-only domain hand signs; Naruto’s seal-finisher eyes |
| `src/naruto-vfx.js` | Facing-aligned clone presentation and brief Mindscape golden cloak |
| `src/session.js`, `src/network.js` | `special5`, new validated outcome event/loser list, stage presentation, cleanup and protocol `limitless-23.0` |
| `src/controls.js`, `src/index.html`, `src/naruto.css` | Fifth key/touch/controller action, correct kit labels and split-panel captions |
| `src/audio.js` | Five synthesized Kurama and domain outcome cues |
| `build.py`, `tests/harness.mjs` | Append Mindscape, its VFX, local domain cameras and the mixed-realm helper at the existing domain insertion marker |

## Verification

`node tests/build22.mjs` checks the redesigned model, jaw and geometry reuse. `node tests/build23.mjs` covers spherical realms, clone sure-hit, burnout and replication. `node tests/build21.mjs` covers authoritative clone hits, guard, model reuse and costs. `node tests/build18.mjs` covers current sure-hit totals, tuned durations, interrupted casts, original-domain totals, point multipliers, fragile clone bonus, win/loss rules, lethal cleanup, forward-only clones, walls/barriers, fifth-move input/cost, orbit locality, equal-panel layout/render-state restoration, synchronized host/guest state and pooled realm cleanup. `node tests/build17.mjs` retains 20 updated Naruto regressions; `node tests/build14.mjs` retains 16 free-for-all/network regressions.

New seal and water GLSL compile and link on Mesa GLES. Isolated procedural scene and camera previews were inspected. This environment has no supported browser QA surface, so live browser rendering/audio, sustained 60 FPS on a target device, physical controller/touch input and live Internet WebRTC have not been verified. The implementation reuses bounded pools but does not claim a zero-allocation engine or a measured device frame rate.
