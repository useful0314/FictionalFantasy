// Build 41: presentation helpers. Damage volumes and authority remain in existing combat code.
const BATTLE_VISUAL={near:30,far:150,farDensity:.18,particleReserve:.38,warningPool:72,impulsePool:8,impulseLife:.32,impulseRange:95,maxOffset:.18,baseFov:62,maxFov:76,speedBlend:.15};
const CHARACTER_EFFECTS={gojo:{color:0x75cfff,shape:'orbit'},sukuna:{color:0xff7189,shape:'slashes'},naruto:{color:0xffca60,shape:'spiral'},mahito:{color:0xa7f5d5,shape:'soul'},spiderman:{color:0xe5f5ff,shape:'web'}};
const battleVisual={warnings:null,used:0,particles:[],free:[],point:V(),dir:V(),up:V(),right:V(),axis:V(),basis:new THREE.Matrix4(),camera:{last:V(),ready:false,speed:0,offset:V()},impulses:[],cursor:0,activity:0};
function initBattleReadability(){
 for(const key of ['dangerVolumes','speedCamera','adaptiveMusic']){if(typeof options[key]!=='boolean')options[key]=true;$(key).checked=options[key];$(key).onchange=e=>{options[key]=e.target.checked;saveOptions();};}
 for(let i=0;i<maxParticles;i++){const p={p:V(),v:V(),c:new THREE.Color(),t:0,max:1,size:0};battleVisual.particles.push(p);battleVisual.free.push(p);}
 for(let i=0;i<BATTLE_VISUAL.impulsePool;i++)battleVisual.impulses.push({dir:V(),age:99,power:0});ensureDangerPool();
}
function resetBattleReadability(){const b=battleVisual;b.camera.ready=false;b.camera.speed=0;b.camera.offset.set(0,0,0);b.activity=0;for(const i of b.impulses)i.age=99;if(b.warnings)for(const e of b.warnings)e.g.visible=false;}
function resetBattleParticles(){particleData.length=0;battleVisual.free.length=0;for(const p of battleVisual.particles)battleVisual.free.push(p);}
function visualDensity(pos,important=false,radius=0){const c=BATTLE_VISUAL,dist=Math.max(0,player.pos.distanceTo(pos)-radius),quality=options.quality==='performance'?.65:options.quality==='auto'?clamp(presentation.auto.scale,.65,1):1;if(important)return 1;if(dist<c.near)return Math.max(.7,quality);return lerp(quality,c.farDensity,THREE.MathUtils.smoothstep(dist,c.near,c.far))*quality;}
function emitBattleParticles(pos,color,count,speed,life,size){
 const b=battleVisual,density=visualDensity(pos),near=player.pos.distanceToSquared(pos)<BATTLE_VISUAL.near**2,cap=near?particleBudget:Math.floor(particleBudget*(1-BATTLE_VISUAL.particleReserve));
 for(let i=0;i<count;i++){
  // Keep exactly six RNG draws even when decorative particles are skipped: AI uses the same seeded generator.
  const x=rr(-1,1),y=rr(-.4,1),z=rr(-1,1),v=rr(speed*.15,speed),t=rr(life*.5,life),s=rr(size*.5,size*1.5);
  if(Math.floor((i+1)*density)===Math.floor(i*density)||particleData.length>=cap||!b.free.length)continue;
  const p=b.free.pop();p.p.copy(pos);p.v.set(x,y,z).normalize().multiplyScalar(v);p.c.set(color);p.t=t;p.max=life;p.size=s;particleData.push(p);
 }
}
function makeCharacterAccent(parent,accent){
 const material=new THREE.LineBasicMaterial({color:accent.color,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,toneMapped:false}),result={};parent.userData.characterLineMaterial=material;
 for(const shape of ['orbit','slashes','spiral','soul','web']){const a=[];const seg=(x,y,u,v)=>a.push(x,y,.03,u,v,.03);
  if(shape==='slashes')for(let i=-1;i<=1;i++)seg(-.7+i*.2,-.6,.5+i*.2,.65);
  else if(shape==='web'){for(let i=0;i<6;i++){const t=i*Math.PI/3,u=(i+1)*Math.PI/3;seg(0,0,Math.cos(t),Math.sin(t));for(const r of [.5,.9])seg(Math.cos(t)*r,Math.sin(t)*r,Math.cos(u)*r,Math.sin(u)*r);}}
  else for(let i=0;i<48;i++){const t=i/48*Math.PI*(shape==='spiral'?4:2),u=(i+1)/48*Math.PI*(shape==='spiral'?4:2),r=shape==='spiral'?.2+i/60:shape==='soul'?.75+Math.sin(t*3)*.2:.85,s=shape==='spiral'?.2+(i+1)/60:shape==='soul'?.75+Math.sin(u*3)*.2:.85;seg(Math.cos(t)*r,Math.sin(t)*r,Math.cos(u)*s,Math.sin(u)*s);}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(a,3));const line=new THREE.LineSegments(geo,material);parent.add(line);line.visible=false;result[shape]=line;
 }return result;
}
function cameraImpulse(pos,dir,power){if(!options.shake||!battleVisual.impulses.length)return;const falloff=(1-THREE.MathUtils.smoothstep(player.pos.distanceTo(pos),8,BATTLE_VISUAL.impulseRange))**2;if(falloff<=0)return;const b=battleVisual,i=b.impulses[b.cursor++%b.impulses.length];i.dir.copy(dir||b.dir.copy(player.pos).sub(pos));if(i.dir.lengthSq()<.001)i.dir.set(0,1,0);i.dir.normalize();i.power=clamp(power,0,1.6)*falloff;i.age=0;}
function updateBattleCamera(dt){const b=battleVisual,c=b.camera;if(c.ready&&dt>0){const d=c.last.distanceTo(player.pos),speed=d<Math.max(4,dt*145)?Math.min(100,d/dt):0;c.speed=lerp(c.speed,phase==='play'?speed:0,1-Math.exp(-dt/BATTLE_VISUAL.speedBlend));}c.last.copy(player.pos);c.ready=true;c.offset.set(0,0,0);for(const i of b.impulses){i.age+=dt;const u=i.age/BATTLE_VISUAL.impulseLife;if(u<1)c.offset.addScaledVector(i.dir,Math.sin(u*Math.PI*3)*Math.exp(-4*u)*i.power*.16);}c.offset.clampLength(0,BATTLE_VISUAL.maxOffset);}
function speedFov(){return options.speedCamera?lerp(BATTLE_VISUAL.baseFov,BATTLE_VISUAL.maxFov,THREE.MathUtils.smoothstep(battleVisual.camera.speed,6,68)):BATTLE_VISUAL.baseFov;}
function speedFollowRate(){return options.speedCamera?lerp(11,8,clamp(battleVisual.camera.speed/68,0,1)):11;}
function applyDirectionalCamera(){if(!options.shake||menuOpen||options.freeOrbit||cursorFree)return;camera.position.addScaledVector(battleVisual.camera.offset,options.shakeStrength);const c=presentation.camera;c.head.copy(player.pos);c.head.y+=1.45;c.direction.copy(camera.position).sub(c.head);const d=c.direction.length();if(d>.01){c.direction.divideScalar(d);const hit=cameraSurfaceDistance(c.head,c.direction,d);if(hit<d)camera.position.copy(c.head).addScaledVector(c.direction,Math.max(.2,hit-PRESENTATION.cameraSkin));}}
function ensureDangerPool(){if(battleVisual.warnings)return;const points=[];for(let i=0;i<96;i++)points.push(V(Math.cos(i/96*Math.PI*2),Math.sin(i/96*Math.PI*2),0));const circle=new THREE.BufferGeometry().setFromPoints(points),edges=new THREE.EdgesGeometry(new THREE.BoxGeometry(1,1,1));battleVisual.warnings=Array.from({length:BATTLE_VISUAL.warningPool},()=>{const g=new THREE.Group();g.name='attack-volume';scene.add(g);g.visible=false;const solid=new THREE.LineBasicMaterial({transparent:true,depthWrite:false}),dashed=new THREE.LineDashedMaterial({transparent:true,depthWrite:false,dashSize:.045,gapSize:.035}),rings=[];for(let i=0;i<4;i++){const ring=new THREE.LineLoop(circle,solid);ring.computeLineDistances();g.add(ring);rings.push(ring);}rings[1].rotation.y=Math.PI/2;rings[2].rotation.x=Math.PI/2;rings[3].rotation.x=Math.PI/2;const box=new THREE.LineSegments(edges,dashed);box.computeLineDistances();g.add(box);return {g,solid,dashed,rings,box,priority:0,kind:'',radius:0,owner:''};});}
function dangerSlot(owner,pos,radius,kind,color,progress=0){
 if(!options.dangerVolumes||!owner||barrierSeparates(owner,player))return null;const b=battleVisual,priority=(kind==='fusion'?1100:kind==='world-cut'?900:kind==='blue'?200:500)+300/(1+Math.max(0,player.pos.distanceTo(pos)-radius)*.04);let e;
 if(b.used<b.warnings.length)e=b.warnings[b.used++];else{e=b.warnings[0];for(const x of b.warnings)if(x.priority<e.priority)e=x;if(e.priority>=priority)return null;}
 e.priority=priority;e.kind=kind;e.radius=radius;e.owner=owner.id;e.g.position.copy(pos);e.g.quaternion.identity();e.g.visible=true;e.box.visible=false;const mat=kind==='projected-impact'||kind==='world-cut'?e.dashed:e.solid;mat.color.set(color);mat.opacity=(owner===player?.14:.24)+clamp(progress,0,1)*.12;
 for(let i=0;i<4;i++){e.rings[i].material=mat;e.rings[i].visible=i<3;e.rings[i].position.set(0,0,0);e.rings[i].scale.setScalar(radius);}
 const h=groundHeight(pos,pos.y)+.025,dy=h-pos.y;if(radius>Math.abs(dy)){e.rings[3].visible=true;e.rings[3].position.y=dy;e.rings[3].scale.setScalar(Math.sqrt(radius*radius-dy*dy));}return e;
}
function dangerLane(owner,pos,dir,length,halfWidth,halfHeight,progress=0){const b=battleVisual,e=dangerSlot(owner,pos,0,'world-cut',WORLD_CUT.colors.edge,progress);if(!e)return;for(const r of e.rings)r.visible=false;worldCutBasis(dir,b.right,b.up);b.axis.copy(dir).negate();b.basis.makeBasis(b.right,b.up,b.axis);e.g.quaternion.setFromRotationMatrix(b.basis);e.box.visible=true;e.box.material=e.dashed;e.box.scale.set(halfWidth*2,halfHeight*2,length);e.box.position.set(0,0,-length/2);}
function updateDangerVolumes(){
 const b=battleVisual;for(const e of b.warnings)e.g.visible=false;b.used=0;if(!options.dangerVolumes||!['play','finish','pause'].includes(phase))return;
 const guest=mode==='online'&&net?.role==='guest',state=guest?replicaState:null;
 for(const a of state?.bombs||bombs)dangerSlot(guest?actorById(a.owner):a.owner,guest?b.point.fromArray(a.p):a.p,a.radius,'fusion',C.purple,a.t/3);
 for(const a of state?.blues||blues)dangerSlot(guest?actorById(a.owner):a.owner,guest?b.point.fromArray(a.p):a.p,lerp(4,9,a.q),'blue',C.blue);
 for(const a of guest?narutoReplicas.values():techniques)if(a.type==='naruto-wind')dangerSlot(a.owner,a.p,a.radius,'wind',NARUTO.colors.chakra,a.t/1.2);
 for(const a of guest?state?.burns||[]:techniques)if(guest||a.type==='burn')dangerSlot(guest?actorById(a.owner):a.owner,guest?b.point.fromArray(a.p):a.p,a.radius,'burn',0xff9a30);
 for(const f of bodies){const a=f.worldCut;if(!a||a.launched)continue;b.point.copy(f.pos);b.point.y+=1.45;b.point.addScaledVector(a.dir,1.8);const floor=a.dir.y<-.001?Math.max(0,(.2-b.point.y)/a.dir.y):Infinity;const horizontal=a.dir.x*a.dir.x+a.dir.z*a.dir.z,along=b.point.x*a.dir.x+b.point.z*a.dir.z,edge=b.point.x*b.point.x+b.point.z*b.point.z-WORLD.radius*WORLD.radius,exit=horizontal>.000001?Math.max(0,(-along+Math.sqrt(Math.max(0,along*along-horizontal*edge)))/horizontal):Infinity;dangerLane(f,b.point,a.dir,Math.min(WORLD_CUT.range,barrierRayDistance(b.point,a.dir,WORLD_CUT.range),floor,exit),WORLD_CUT.halfWidth+.6,WORLD_CUT.halfHeight+1.1,a.t/WORLD_CUT.startup);}
 for(const p of state?.projectiles||projectiles){const owner=guest?actorById(p.owner):p.owner;guest?b.point.fromArray(p.p):b.point.copy(p.p);guest?b.dir.fromArray(p.dir):b.dir.copy(p.dir);
  if(p.type==='fire')dangerSlot(owner,b.point,lerp(12,22,p.q),'furnace',0xffa14c);
  else if(p.type==='purple')dangerSlot(owner,b.point,lerp(1.4,3.2,p.q)+.8,'purple',C.purple);
  else if(p.type==='naruto-bomb'||p.type==='naruto-shuriken'){const kind=p.type==='naruto-bomb'?5:4,c=NARUTO.moves[kind];let travel=narutoWallDistance(b.point,b.dir,Math.max(0,c.range-p.t*c.speed));for(const f of bodies){if(f===owner||f.hp<=0||barrierSeparates(owner,f))continue;b.up.copy(f.pos);b.up.y+=1.45;travel=Math.min(travel,raySphere(b.point,b.dir,b.up,c.radius+.8));}b.point.addScaledVector(b.dir,travel);dangerSlot(owner,b.point,kind===5?c.zoneRadius:lerp(4.5,c.zoneRadius,p.q),'projected-impact',kind===5?0xffb566:NARUTO.colors.chakra);}
 }
}
