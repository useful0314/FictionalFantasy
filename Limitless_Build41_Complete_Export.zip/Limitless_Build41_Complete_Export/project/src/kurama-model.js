// Reusable fox anatomy for the cage and roaming avatar. Geometry is built once,
// shared by both heads, and never allocated by the animation loop.
const KURAMA_LOOK={headScale:.62,torsoHeight:8.8,neckHeight:3.9,fangLength:4.3,clawLength:3.8,jawRest:-.12,jawRoar:-.72,eyeTilt:.27};
let kuramaGeometry=null;
function kuramaWedge(backWidth,frontWidth,backHeight,frontHeight,length,rise=0){
 const p=[-backWidth,-backHeight,0,backWidth,-backHeight,0,backWidth,backHeight,0,-backWidth,backHeight,0,-frontWidth,rise-frontHeight,-length,frontWidth,rise-frontHeight,-length,frontWidth,rise+frontHeight,-length,-frontWidth,rise+frontHeight,-length];
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setIndex([0,1,2,0,2,3,5,4,7,5,7,6,4,0,3,4,3,7,1,5,6,1,6,2,3,2,6,3,6,7,4,5,1,4,1,0]);g.computeVertexNormals();return g;
}
function kuramaModelGeometry(){
 if(kuramaGeometry)return kuramaGeometry;
 const vertices=[],indices=[],sides=7;
 for(let ring=0;ring<5;ring++){const t=ring/4,r=(1-t)**.7;for(let i=0;i<sides;i++){const a=i/sides*Math.PI*2;vertices.push(Math.cos(a)*r,t,Math.sin(a)*r+t*t*.55);}}
 for(let ring=0;ring<4;ring++)for(let i=0;i<sides;i++){const a=ring*sides+i,b=ring*sides+(i+1)%sides;indices.push(a,b,a+sides,b,b+sides,a+sides);}
 const fang=new THREE.BufferGeometry();fang.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));fang.setIndex(indices);fang.computeVertexNormals();
 const eye=new THREE.Shape();eye.moveTo(-1,-.02);eye.lineTo(-.38,-.36);eye.lineTo(.72,-.24);eye.lineTo(1,.02);eye.lineTo(.3,.31);eye.lineTo(-.76,.22);eye.closePath();
 return kuramaGeometry={muzzle:kuramaWedge(4.6,1.65,2.15,.72,10.7,-.55),jaw:kuramaWedge(4.4,1.55,.95,.55,10.2,-.15),ear:kuramaWedge(2.7,.04,1.4,.02,10.5),eye:new THREE.ShapeGeometry(eye),fang};
}
function createKuramaHead(fox,black,teeth,glow){
 const g=kuramaModelGeometry(),head=new THREE.Group();head.name='Kurama-angular-fox-head';
 mesh(geo.lowSphere,fox,head,V(0,.4,1.1),V(8.1,5.4,6.9));
 mesh(geo.lowSphere,fox,head,V(0,2.1,-3),V(6.7,3.4,4.4));
 mesh(g.muzzle,fox,head,V(0,-.15,-5));
 mesh(geo.lowSphere,black,head,V(0,-.65,-15.9),V(1.85,1.0,1.12));
 mesh(g.jaw,black,head,V(0,-2.4,-5.1),V(.99,1.7,.96));
 const eyes=[],ears=[];
 for(const side of [-1,1]){
  const ear=new THREE.Group();head.add(ear);ear.position.set(side*6,3.5,1.8);ear.rotation.set(Math.PI/2,0,-side*.21);mesh(g.ear,fox,ear);mesh(g.ear,black,ear,V(0,.2,-.8),V(.59,.66,.79));ears.push(ear);
  const socket=new THREE.Group();head.add(socket);socket.position.set(side*4.6,1,-6.75);socket.rotation.set(0,Math.PI,side*KURAMA_LOOK.eyeTilt);
  mesh(g.eye,black,socket,V(0,0,-.035),V(3.25,2.3,1));const eye=mesh(g.eye,glow,socket,V(0,0,.025),V(2.8,1.25,1));eyes.push(eye);
  mesh(geo.box,black,socket,V(0,0,.09),V(.18,.8,.07));
  const brow=mesh(geo.lowSphere,fox,head,V(side*4.5,2.3,-6.05),V(3.5,.8,1.4));brow.rotation.z=side*.25;
  for(let i=0;i<4;i++){const tuft=mesh(geo.cone,fox,head,V(side*(7.6+i*.6),-.8-i*.65,1+i*.7),V(3.6,7.3-i*.4,3.4));tuft.rotation.set(.42,side*.28,-side*(1.0+i*.1));}
  for(let i=0;i<3;i++){const mark=mesh(geo.box,black,head,V(side*(6.4+i*.25),-.6-i*1.0,-5.4+i*.22),V(4.1,.24,.35));mark.rotation.set(0,-side*.12,side*(.1+i*.09));}
  for(let i=0;i<2;i++){const fang=mesh(g.fang,teeth,head,V(side*(3.6-i*.9),-1.9,-9.4-i*3.5),V(.65,KURAMA_LOOK.fangLength-i*.85,.7));fang.rotation.set(0,0,Math.PI);}
 }
 const jaw=new THREE.Group();head.add(jaw);jaw.position.set(0,-2.9,-5.2);jaw.rotation.x=KURAMA_LOOK.jawRest;
 mesh(g.jaw,fox,jaw,V(0,-.4,0));mesh(g.jaw,black,jaw,V(0,.45,-.15),V(.86,.18,.96));
 for(const side of [-1,1])for(let i=0;i<3;i++){const fang=mesh(g.fang,teeth,jaw,V(side*(3.6-i*.85),.5,-2.5-i*2.75),V(.42,2.2-i*.3,.46));fang.rotation.z=side*.09;}
 for(let i=0;i<6;i++){const tooth=mesh(g.fang,teeth,head,V((i-2.5)*.49,-1.3,-15.1),V(.25,1.15,.3));tooth.rotation.z=Math.PI;mesh(g.fang,teeth,jaw,V((i-2.5)*.43,.35,-9.5),V(.23,.88,.27));}
 return {head,jaw,eyes,ears};
}
