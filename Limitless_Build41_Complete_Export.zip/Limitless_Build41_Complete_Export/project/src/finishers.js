// Non-graphic domain executions. Authoritative age drives both peers' cameras and effects.
const FINISHER_DURATION={gojo:6.4,sukuna:6.2};
function clearFinisher(){
 if(!finisher)return;for(const item of finisher.originals||[])item.mesh.material=item.material;finisher.loser.body.visible=true;finisher.loser.shadow.visible=true;removeObject(finisher.g);finisher.silhouette.dispose();finisher=null;
}
function beginDomainFinisher(winner,kind,id=++techniqueSerial,age=0,anchor=other(winner).pos.clone(),axis=aimFor(winner).setY(0).normalize(),victim=other(winner)){
 clearFinisher();if(axis.lengthSq()<.5)axis.set(0,0,-1);const loser=victim,g=new THREE.Group();g.name='domain-finisher-'+kind;scene.add(g);g.position.copy(anchor);
 finisher={id,winner,loser,kind,t:age,duration:FINISHER_DURATION[kind],anchor:anchor.clone(),axis:axis.clone(),g,originals:[],panels:[],cuts:[],burst:false,lastBeat:-1,silhouette:new THREE.MeshBasicMaterial({color:kind==='gojo'?0xdbe7ff:0xffd3b7,toneMapped:false})};
 for(const f of bodies){f.vel.set(0,0,0);f.ragdollT=0;f.attack=0;f.block=false;}cinematic=null;
 const infoMaterial=new THREE.ShaderMaterial({transparent:true,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending,uniforms:{uTime:{value:0},uPower:{value:0}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:`
 varying vec2 vUv;uniform float uTime;uniform float uPower;
 float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
 float bar(vec2 p,vec2 c,vec2 size){vec2 d=abs(p-c);return (1.-smoothstep(size.x,size.x+.035,d.x))*(1.-smoothstep(size.y,size.y+.035,d.y));}
 void main(){vec2 uv=vUv*vec2(12.,15.)+vec2(0.,uTime*(3.+uPower*9.));vec2 cell=floor(uv),p=fract(uv);float n=floor(hash(cell)*10.);float glyph=0.;
 glyph+=bar(p,vec2(.5,.18),vec2(.17,.035))*step(.5,mod(n,3.));glyph+=bar(p,vec2(.5,.5),vec2(.17,.035))*step(1.5,n);glyph+=bar(p,vec2(.5,.82),vec2(.17,.035))*step(.5,mod(n+1.,3.));
 glyph+=bar(p,vec2(.29,.34),vec2(.035,.15))*step(3.5,n);glyph+=bar(p,vec2(.71,.34),vec2(.035,.15))*step(.5,n);glyph+=bar(p,vec2(.29,.67),vec2(.035,.15))*step(.5,mod(n,2.));glyph+=bar(p,vec2(.71,.67),vec2(.035,.15));
 float edge=smoothstep(0.,.08,vUv.x)*smoothstep(1.,.9,vUv.x);vec3 color=mix(vec3(.18,.48,1.),vec3(.9,.5,1.),hash(cell));gl_FragColor=vec4(color*(1.+uPower),clamp(glyph,0.,1.)*edge*(.16+uPower*.62));}`});
 if(kind==='gojo'){
  for(let i=0;i<30;i++){const panel=mesh(new THREE.PlaneGeometry(2.3,4.6),infoMaterial,g);panel.userData.index=i;finisher.panels.push(panel);}
  finisher.infoMaterial=infoMaterial;
  finisher.corona=mesh(new THREE.TorusGeometry(1,.014,5,96),new THREE.MeshBasicMaterial({color:0xc9b7ff,transparent:true,opacity:.6,blending:THREE.AdditiveBlending,depthWrite:false}),g,V(0,2.3,0));
 }else{
  infoMaterial.dispose();for(let i=0;i<44;i++){const blade=cutBlade(g,5.5,i*.71);finisher.cuts.push(blade);}
 }
 const count=96,fragments=new THREE.InstancedMesh(blockUnitGeometry(),new THREE.MeshBasicMaterial({color:kind==='gojo'?0xced3ff:0xff897b,transparent:true,opacity:.9,blending:THREE.AdditiveBlending,depthWrite:false}),count);fragments.visible=false;fragments.frustumCulled=false;g.add(fragments);finisher.fragments=fragments;
 const ring=mesh(new THREE.TorusGeometry(1,.028,5,96),new THREE.MeshBasicMaterial({color:kind==='gojo'?C.purple:C.red,transparent:true,opacity:.55,blending:THREE.AdditiveBlending,depthWrite:false}),g,V(0,.2,0));ring.rotation.x=Math.PI/2;finisher.ring=ring;
 sound.play(kind==='gojo'?'voidFinisher':'shrineFinisher',.8);$('domainState').classList.add('hidden');
}
function updateFinisher(dt){
 const f=finisher;if(!f)return;f.t=Math.min(f.duration,f.t+dt);const t=f.t,collapse=f.kind==='gojo'?3.25:3.8;
 if(f.kind==='gojo'){
  const power=THREE.MathUtils.smoothstep(t,0,3.1);f.infoMaterial.uniforms.uTime.value=t;f.infoMaterial.uniforms.uPower.value=power;
  for(let i=0;i<f.panels.length;i++){const p=f.panels[i],a=i*2.399963+t*(.25+power*.8),r=lerp(7,1.1,power)+(i%3)*.6;p.position.set(Math.cos(a)*r,1.6+Math.sin(i*2.8+t)*2.1,Math.sin(a)*r);p.lookAt(f.anchor.clone().add(V(0,2.1,0)));p.visible=t<collapse+.18;p.scale.setScalar(.5+power*.7);}
  f.corona.scale.setScalar(.35+power*1.3);f.corona.rotation.set(t*.6,t*.9,t);f.corona.visible=t<collapse+.25;
 }else{
  const intensity=THREE.MathUtils.smoothstep(t,.1,2.6);
  f.cuts.forEach((b,i)=>{const cycle=(t*(2.8+intensity*5)+i*.173)%1,a=i*2.39996;const length=Math.sin(cycle*Math.PI);b.g.visible=t<3.85;b.g.position.set(Math.cos(a)*.8+(cycle-.5)*2.8,1.3+Math.sin(i*6.13)*1.6,Math.sin(a)*.85);b.g.rotation.set(Math.sin(i)*.7,i*.2,a);b.g.scale.set(Math.max(.001,length*(.5+intensity*.55)),.5+intensity,1);});
  const beat=Math.floor(t*(4+intensity*9));if(t<3.5&&beat!==f.lastBeat){f.lastBeat=beat;sound.play('shrineCut',.7,Math.sin(t*9)*.4);}
 }
 if(t>collapse-.5&&f.originals.length===0){f.loser.body.traverse(o=>{if(o.isMesh){f.originals.push({mesh:o,material:o.material});o.material=f.silhouette;}});}
 if(t>=collapse){
  f.loser.body.visible=false;f.loser.shadow.visible=false;f.fragments.visible=true;
  const life=t-collapse,fade=1-THREE.MathUtils.smoothstep(life,1.25,2.55),matrix=new THREE.Matrix4(),rotation=new THREE.Quaternion();
  for(let i=0;i<f.fragments.count;i++){const a=i*2.39996,h=domainHash(i+19),r=.3+life*(1.3+domainHash(i+77)*4),pos=V(Math.cos(a)*r,Math.max(.08,h*2.6+life*(2.8-h)-life*life*1.6),Math.sin(a)*r),size=(.055+domainHash(i+151)*.14)*fade;rotation.setFromEuler(new THREE.Euler(life*3+i,life*5+i*.7,life));matrix.compose(pos,rotation,V(size,size,size));f.fragments.setMatrixAt(i,matrix);}f.fragments.instanceMatrix.needsUpdate=true;
  if(!f.burst){f.burst=true;flashIt(f.kind==='gojo'?.75:.45);shakeIt(.7);sound.play('burst',.9);}
 }
 f.ring.scale.setScalar(.5+t*2);f.ring.material.opacity=Math.max(0,.5-t*.065);animateDomainVisual();
}
function finisherCamera(){
 const f=finisher,dir=f.axis.clone().normalize(),side=V(-dir.z,0,dir.x),target=f.anchor.clone().add(V(0,f.kind==='gojo'?2.15:1.45,0)),t=f.t;
 if(t<1.2){camPos.copy(target).addScaledVector(dir,-4.8+t*.65).addScaledVector(side,2.3-t*.4).add(V(0,.35,0));camLook.copy(target);}
 else if(t<(f.kind==='gojo'?3.3:3.85)){const q=(t-1.2)/2.6;camPos.copy(target).addScaledVector(dir,-(f.kind==='gojo'?2.2:3.5)).addScaledVector(side,.8-q*.5).add(V(0,f.kind==='gojo'?.12:.4,0));camLook.copy(target);}
 else if(t<4.9){camPos.copy(f.anchor).addScaledVector(dir,-6).addScaledVector(side,3.2).add(V(0,3.5,0));camLook.copy(f.anchor).add(V(0,1.1,0));}
 else{camPos.copy(headPos(f.winner)).addScaledVector(dir,3.6).addScaledVector(side,1.5).add(V(0,.15,0));camLook.copy(f.winner.pos).add(V(0,1.85,0));}
}
