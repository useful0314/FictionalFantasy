(() => {
  const actions={
    forward:['Move forward','KeyW','Movement'],back:['Move backward','KeyS','Movement'],left:['Move left','KeyA','Movement'],right:['Move right','KeyD','Movement'],
    sprint:['Sprint','ShiftLeft','Movement'],jump:['Jump / air jump / ascend','Space','Movement'],fly:['Gojo: levitation','KeyF','Movement'],descend:['Descend','ControlLeft','Movement'],
    light:['Light attack','Mouse0','Combat'],guard:['Guard','Mouse2','Combat'],dodge:['Dodge / perfect dodge','KeyE','Combat'],energy:['Charge energy','KeyC','Combat'],
    special1:['Special 1','Digit1','Techniques'],special2:['Special 2','Digit2','Techniques'],special3:['Special 3','Digit3','Techniques'],special4:['Special 4','Digit4','Techniques'],special5:['Special 5','Digit5','Techniques'],special6:['Mahito: Cursed Touch','Digit6','Techniques'],domain:['Ultimate / domain','KeyQ','Techniques'],
    lock:['Target lock','Tab','Camera & menus'],cursor:['Release mouse cursor','AltLeft','Camera & menus'],orbitView:['Toggle character view','KeyV','Camera & menus'],pause:['Menu / resume','Escape','Camera & menus'],help:['Field manual','KeyH','Camera & menus']
  };
  const defaultPad={sprint:'B5',jump:'B0',fly:'B14',descend:'B13',light:'B2',guard:'B4',dodge:'B1',energy:'B3',special1:'L2+B2',special2:'L2+B3',special3:'L2+B1',special4:'L2+B0',special5:'B15',special6:'B7',domain:'B12',lock:'B11',pause:'B9',help:'B8'};
  const padNames=['A / Cross','B / Circle','X / Square','Y / Triangle','LB / L1','RB / R1','LT / L2','RT / R2','View / Share','Menu / Options','L stick click','R stick click','D-pad up','D-pad down','D-pad left','D-pad right','Home'];
  const label=code=>/^Key/.test(code)?code.slice(3):/^Digit/.test(code)?code.slice(5):({Mouse0:'LMB',Mouse1:'MMB',Mouse2:'RMB',Mouse3:'Mouse 4',Mouse4:'Mouse 5',ShiftLeft:'L Shift',ShiftRight:'R Shift',ControlLeft:'L Ctrl',ControlRight:'R Ctrl',AltLeft:'L Alt',AltRight:'R Alt',Space:'Space',ArrowUp:'↑',ArrowDown:'↓',ArrowLeft:'←',ArrowRight:'→'}[code]||code);
  class ArenaControls {
    constructor(config) {
      this.config=config;this.held=new Set();this.sources=new Map();this.move={x:0,y:0};this.padMove={x:0,y:0};this.touchMove={x:0,y:0};this.padPrevious=new Set();this.touchIds=new Map();this.lastPadButtons=[];this.inputMode='keyboard';
      this.bindings=Object.fromEntries(Object.entries(actions).map(([k,v])=>[k,v[1]]));this.padBindings={...defaultPad};this.prefs={padSensitivity:1.5,touchSensitivity:1,deadzone:.16,invertY:false,touch:'auto'};
      try {const saved=JSON.parse(localStorage.getItem('limitless.controls.v3')||'{}');
        for(const [a,c] of Object.entries(saved.keys||{}))if(actions[a]&&typeof c==='string'&&/^[A-Za-z][A-Za-z0-9]{0,31}$/.test(c))this.bindings[a]=c;
        for(const [a,c]of Object.entries(saved.pad||{}))if(defaultPad[a]&&(/^(B([0-9]|1[0-5])|L2\+B[0-3])$/.test(c)))this.padBindings[a]=c;
        Object.assign(this.prefs,saved.prefs||{});
        // New actions must not shadow a user's existing custom key assignment.
        for(const action of ['cursor','orbitView','special5','special6'])if(!saved.keys?.[action]&&Object.entries(this.bindings).some(([a,c])=>a!==action&&c===this.bindings[action])){
          this.bindings[action]=['ControlRight','Backquote','F8','F9'].find(code=>!Object.values(this.bindings).includes(code))||this.bindings[action];
        }
      }catch{}
      this.prefs.padSensitivity=this.clamp(+this.prefs.padSensitivity||1.5,.3,3);this.prefs.touchSensitivity=this.clamp(+this.prefs.touchSensitivity||1,.3,2);this.prefs.deadzone=this.clamp(+this.prefs.deadzone||.16,.08,.35);
      if(!['auto','on','off'].includes(this.prefs.touch))this.prefs.touch='auto';
      window.addEventListener('keydown',e=>this.key(e,true));window.addEventListener('keyup',e=>this.key(e,false));
      window.addEventListener('mousedown',e=>this.mouse(e,true));window.addEventListener('mouseup',e=>this.mouse(e,false));
      window.addEventListener('blur',()=>this.releaseAll());
      window.addEventListener('wheel',e=>{if(!e.target?.closest?.('button,input,select,.panel')&&this.config.wheel?.(e))e.preventDefault();},{passive:false});
      window.addEventListener('gamepaddisconnected',()=>{this.clearSource('pad');this.padMove={x:0,y:0};this.padPrevious.clear();});
      window.addEventListener('contextmenu',e=>{if(this.config.playing()||this.capture)e.preventDefault();});
      this.buildBindings();this.setupTouch();this.setupLayout();this.syncLabels();
    }
    clamp(v,a,b){return Math.min(b,Math.max(a,v));}
    save(){try{localStorage.setItem('limitless.controls.v3',JSON.stringify({keys:this.bindings,pad:this.padBindings,prefs:this.prefs}));}catch{}this.syncLabels();}
    label(action){return label(this.bindings[action]||'—');}
    bind(action,code){const previous=this.bindings[action],other=Object.keys(this.bindings).find(a=>a!==action&&this.bindings[a]===code);if(other)this.bindings[other]=previous;this.bindings[action]=code;this.releaseAll();this.save();this.buildBindings();}
    set(action,down,source){if(!actions[action])return;const sources=this.sources.get(action)||new Set(),was=sources.size>0;if(down)sources.add(source);else sources.delete(source);this.sources.set(action,sources);const is=sources.size>0;if(is)this.held.add(action);else this.held.delete(action);if(was!==is)this.config.action(action,is,source);}
    clearSource(source){for(const a of this.sources.keys())this.set(a,false,source);}
    releaseAll(except=[]){this.config.orbit?.(false);this.stickId=null;for(const [a,s]of this.sources){if(s.size&&!except.includes(a)){s.clear();this.held.delete(a);this.config.action(a,false,'clear');}}this.touchMove={x:0,y:0};this.padMove={x:0,y:0};this.move={x:0,y:0};}
    key(e,down){
      if(this.capture){if(down&&!e.repeat){e.preventDefault();const a=this.capture;this.capture=null;if(e.code!=='Escape')this.bind(a,e.code);else this.buildBindings();}return;}
      if(e.target?.closest?.('input,select,textarea')&&!['Escape'].includes(e.code))return;
      const action=Object.keys(this.bindings).find(a=>this.bindings[a]===e.code);
      if(!action)return;if(down&&e.repeat)return;
      if(!down){this.set(action,false,'key');return;}
      if(this.config.playing()||['pause','help'].includes(action)){e.preventDefault();this.inputMode='keyboard';this.config.unlock?.();this.set(action,true,'key');}
    }
    mouse(e,down){
      if(e.sourceCapabilities?.firesTouchEvents)return;
      const code='Mouse'+e.button;
      if(this.capture){if(down){e.preventDefault();const a=this.capture;this.capture=null;this.bind(a,code);}return;}
      if(e.button===1&&(!down||this.config.playing()&&!e.target?.closest?.('button,input,select,.panel,#touchControls'))&&this.config.orbit?.(down)){e.preventDefault();return;}
      const action=Object.keys(this.bindings).find(a=>this.bindings[a]===code);if(!action)return;
      if(!down){this.set(action,false,'mouse');return;}
      if(this.config.mouseEnabled?.()===false&&!['cursor','orbitView'].includes(action))return;
      if(this.config.playing()&&!e.target?.closest?.('button,input,select,.panel,#touchControls')){e.preventDefault();this.inputMode='keyboard';this.config.unlock?.();this.set(action,true,'mouse');}
    }
    buildBindings(){
      const list=document.getElementById('bindingsList');if(!list)return;list.replaceChildren();
      let group='';for(const [a,[name,,section]]of Object.entries(actions)){
        if(section!==group){const h=document.createElement('h3');h.textContent=group=section;list.append(h);}
        const row=document.createElement('div');row.className='bindingRow';
        const text=document.createElement('span');text.textContent=name;const button=document.createElement('button');button.className='keyBind';button.textContent=this.capture===a?'Press a key…':this.label(a);button.setAttribute('aria-label','Rebind '+name);button.onclick=()=>{this.releaseAll();this.capture=a;this.buildBindings();document.getElementById('bindStatus').textContent='Press a key or mouse button for '+name+'. Esc cancels. Duplicate bindings swap.';};row.append(text,button);
        if(defaultPad[a]){const select=document.createElement('select');select.setAttribute('aria-label','Controller binding for '+name);
          for(const code of [...Array.from({length:16},(_,i)=>'B'+i),...Array.from({length:4},(_,i)=>'L2+B'+i)]){const option=document.createElement('option');option.value=code;option.textContent=code.startsWith('L2')?'LT + '+padNames[+code.slice(-1)]:padNames[+code.slice(1)];select.append(option);}select.value=this.padBindings[a];
          select.onchange=()=>{const old=this.padBindings[a],other=Object.keys(this.padBindings).find(k=>k!==a&&this.padBindings[k]===select.value);if(other)this.padBindings[other]=old;this.padBindings[a]=select.value;this.releaseAll();this.save();this.buildBindings();};row.append(select);
        }else{const hint=document.createElement('small');hint.textContent=section==='Movement'?'Left stick':'Keyboard / mouse';row.append(hint);}list.append(row);
      }
    }
    syncLabels(){for(const el of document.querySelectorAll('[data-bind]'))el.textContent=this.label(el.dataset.bind);this.config.changed?.();this.showTouch();}
    reset(){this.bindings=Object.fromEntries(Object.entries(actions).map(([k,v])=>[k,v[1]]));this.padBindings={...defaultPad};this.capture=null;this.releaseAll();this.save();this.buildBindings();}
    showTouch(){const auto=(window.matchMedia?.('(pointer: coarse)').matches||navigator.maxTouchPoints>0),active=this.prefs.touch==='on'||(this.prefs.touch==='auto'&&auto);const visible=!!this.layoutEditing||!!active&&this.config.playing(),changed=this.touchActive!==!!active||this.touchVisible!==visible;this.touchVisible=visible;this.touchActive=!!active;document.body.classList.toggle('touch-mode',!!active||!!this.layoutEditing);document.getElementById('touchControls')?.classList.toggle('hidden',!this.layoutEditing&&(!active||!this.config.playing()));if(changed)this.applyLayout();}
    setupTouch(){
      const stick=document.getElementById('moveStick'),knob=document.getElementById('stickKnob'),look=document.getElementById('touchLook');
      if(!stick||!look)return;
      const move=e=>{const b=stick.getBoundingClientRect(),r=b.width*.35,x=this.clamp((e.clientX-b.left-b.width/2)/r,-1,1),y=this.clamp((e.clientY-b.top-b.height/2)/r,-1,1),length=Math.max(1,Math.hypot(x,y));this.touchMove={x:x/length,y:y/length};knob.style.transform=`translate(${x*r/length}px,${y*r/length}px)`;};
      stick.addEventListener('pointerdown',e=>{if(!this.config.playing())return;e.preventDefault();this.inputMode='touch';this.config.unlock?.();stick.setPointerCapture(e.pointerId);this.stickId=e.pointerId;move(e);});
      stick.addEventListener('pointermove',e=>{if(e.pointerId===this.stickId)move(e);});
      const end=e=>{if(e.pointerId===this.stickId){this.stickId=null;this.touchMove={x:0,y:0};knob.style.transform='translate(0,0)';}};for(const type of ['pointerup','pointercancel','lostpointercapture'])stick.addEventListener(type,end);
      let last=null;look.addEventListener('pointerdown',e=>{if(!this.config.playing())return;e.preventDefault();look.setPointerCapture(e.pointerId);last={id:e.pointerId,x:e.clientX,y:e.clientY};this.inputMode='touch';});
      look.addEventListener('pointermove',e=>{if(last?.id!==e.pointerId)return;this.config.look((e.clientX-last.x)*.004*this.prefs.touchSensitivity,(e.clientY-last.y)*.004*this.prefs.touchSensitivity);last={id:e.pointerId,x:e.clientX,y:e.clientY};});
      for(const type of ['pointerup','pointercancel','lostpointercapture'])look.addEventListener(type,e=>{if(last?.id===e.pointerId)last=null;});
      for(const button of document.querySelectorAll('[data-action]')){
        button.addEventListener('pointerdown',e=>{e.preventDefault();if(!this.config.playing())return;button.setPointerCapture(e.pointerId);this.inputMode='touch';this.config.unlock?.();this.set(button.dataset.action,true,'touch'+e.pointerId);button.classList.add('pressed');});
        for(const type of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(type,e=>{this.set(button.dataset.action,false,'touch'+e.pointerId);button.classList.remove('pressed');});
      }
    }
    setupLayout(){
      this.layouts={portrait:{},landscape:{}};try{const saved=JSON.parse(localStorage.getItem('limitless.touch-layout.v1')||'{}');for(const o of ['portrait','landscape'])for(const [k,p]of Object.entries(saved[o]||{}))if(p&&Number.isFinite(p.x)&&Number.isFinite(p.y))this.layouts[o][k]={x:this.clamp(p.x,0,1),y:this.clamp(p.y,0,1)};}catch{}
      this.layoutItems=new Map([['stick',document.getElementById('moveStick')],['health',document.getElementById('healthHUD')],['opponents',document.getElementById('opponentHealthBars')],['resources',document.getElementById('resourceHUD')],...Array.from(document.querySelectorAll('[data-action]')).map(el=>['action-'+el.dataset.action,el])]);
      for(const [key,el]of this.layoutItems){
        if(!el)continue;el.classList.add('layout-item');el.dataset.layout=key;
        el.addEventListener('pointerdown',e=>{if(!this.layoutEditing)return;e.preventDefault();e.stopPropagation?.();if(this.layoutDrag)return;const r=el.getBoundingClientRect();this.layoutDrag={key,id:e.pointerId,x:e.clientX-r.left,y:e.clientY-r.top,w:r.width,h:r.height};el.setPointerCapture(e.pointerId);el.classList.add('layout-dragging');});
        el.addEventListener('pointermove',e=>{const d=this.layoutDrag;if(!this.layoutEditing||d?.id!==e.pointerId||d.key!==key)return;e.preventDefault();const p={x:this.clamp((e.clientX-d.x-12)/Math.max(1,innerWidth-d.w-24),0,1),y:this.clamp((e.clientY-d.y-12)/Math.max(1,innerHeight-d.h-24),0,1)};this.layouts[this.layoutOrientation()][key]=p;this.placeLayout(el,p,d.w,d.h);});
        for(const type of ['pointerup','pointercancel','lostpointercapture'])el.addEventListener(type,e=>{if(this.layoutDrag?.id===e.pointerId){this.layoutDrag=null;el.classList.remove('layout-dragging');}});
      }
      window.addEventListener('resize',()=>{this.layoutDrag=null;this.applyLayout();});
    }
    layoutOrientation(){return innerWidth>innerHeight?'landscape':'portrait';}
    placeLayout(el,p,w,h){
      w=Math.min(w,Math.max(44,innerWidth-24));h=Math.min(h,Math.max(40,innerHeight-24));
      el.style.setProperty('--layout-x',(12+p.x*Math.max(0,innerWidth-w-24))+'px');el.style.setProperty('--layout-y',(12+p.y*Math.max(0,innerHeight-h-24))+'px');el.style.setProperty('--layout-width',w+'px');el.style.setProperty('--layout-height',h+'px');el.classList.add('layout-placed');
    }
    applyLayout(){
      if(!this.layoutItems)return;for(const el of this.layoutItems.values())el?.classList.remove('layout-placed');
      if(!this.touchActive&&!this.layoutEditing)return;
      const positions=this.layouts[this.layoutOrientation()],rects=Array.from(this.layoutItems,([key,el])=>({key,el,r:el.getBoundingClientRect()}));
      for(const {key,el,r}of rects){if(r.width<1||r.height<1)continue;if(this.layoutEditing&&!positions[key])positions[key]={x:this.clamp((r.left-12)/Math.max(1,innerWidth-r.width-24),0,1),y:this.clamp((r.top-12)/Math.max(1,innerHeight-r.height-24),0,1)};if(positions[key])this.placeLayout(el,positions[key],r.width,r.height);}
    }
    editLayout(active){
      this.releaseAll();this.layoutEditing=active;this.layoutDrag=null;document.body.classList.toggle('layout-editing',active);document.getElementById('layoutToolbar').classList.toggle('hidden',!active);this.config.layoutChanged?.(active);this.showTouch();this.applyLayout();
      if(!active){try{localStorage.setItem('limitless.touch-layout.v1',JSON.stringify(this.layouts));}catch{}}
    }
    resetLayout(){this.layouts[this.layoutOrientation()]={};this.applyLayout();}
    menuNavigate(buttons){
      const pressed=i=>buttons[i]&&!this.lastPadButtons[i];
      const panel=Array.from(document.querySelectorAll('.panel')).reverse().find(e=>!e.classList.contains('hidden'));
      if(!panel)return;
      const items=Array.from(panel.querySelectorAll('button,input,select,summary')).filter(e=>!e.disabled&&!e.closest('.hidden')&&e.getClientRects().length);
      let index=items.indexOf(document.activeElement);
      if(pressed(12)||pressed(13)){index=(index+(pressed(13)?1:-1)+items.length)%items.length;items[index]?.focus();}
      if(pressed(0)){if(index<0)items[0]?.focus();else{const el=items[index];if(el.tagName==='SELECT'){el.selectedIndex=(el.selectedIndex+1)%el.options.length;el.dispatchEvent(new Event('change'));}else el.click();}}
      if(pressed(14)||pressed(15)){const el=items[index];if(el?.type==='range'){el.value=this.clamp(+el.value+(pressed(15)?1:-1)*(+el.step||.1),+el.min,+el.max);el.dispatchEvent(new Event('input'));}}
      if(pressed(1)||pressed(9))this.config.back?.();
    }
    poll(dt){
      const pads=navigator.getGamepads?.()||[],pad=Array.from(pads).find(p=>p?.connected&&p.mapping==='standard');
      const status=document.getElementById('controllerStatus');
      if(status)status.textContent=pad?'Connected · '+pad.id.slice(0,65):'Connect a controller and press a button. Standard gamepads supported.';
      if(pad){this.pad=pad;const b=pad.buttons.map(b=>b.pressed||b.value>.5),active=new Set();
        const axis=n=>{const v=pad.axes[n]||0,d=this.prefs.deadzone;return Math.abs(v)<d?0:Math.sign(v)*(Math.abs(v)-d)/(1-d);};
        if(this.config.playing()){
          this.padMove={x:axis(0),y:axis(1)};this.config.look(axis(2)*dt*this.prefs.padSensitivity*1.9,axis(3)*dt*this.prefs.padSensitivity*1.5*(this.prefs.invertY?-1:1));
          this.consumedFaces??=new Set();for(let i=0;i<4;i++){if(!b[i])this.consumedFaces.delete(i);if(b[6]&&b[i])this.consumedFaces.add(i);}
          for(const [a,code]of Object.entries(this.padBindings)){const index=+code.split('B').pop(),chord=code.startsWith('L2');if(b[index]&&(chord?b[6]:index>3||!this.consumedFaces.has(index)))active.add(a);}
          if(b.some(Boolean)||this.padMove.x||this.padMove.y){this.inputMode='gamepad';this.config.unlock?.();}
        }else{this.padMove={x:0,y:0};this.menuNavigate(b);}
        for(const a of new Set([...active,...this.padPrevious]))this.set(a,active.has(a),'pad');this.padPrevious=active;this.lastPadButtons=b;
      }else{this.pad=null;this.clearSource('pad');this.padMove={x:0,y:0};this.padPrevious.clear();this.lastPadButtons=[];}
      this.move=Math.hypot(this.touchMove.x,this.touchMove.y)>.1?this.touchMove:this.padMove;
      // Analog direction supplies movement; light attacks select their own ground/air animation.
      this.set('left',this.move.x<-.25,'stick');this.set('right',this.move.x>.25,'stick');this.set('forward',this.move.y<-.25,'stick');this.set('back',this.move.y>.25,'stick');
      this.showTouch();
    }
    rumble(big=false){const a=this.pad?.vibrationActuator;try{a?.playEffect?.('dual-rumble',{duration:big?280:70,strongMagnitude:big?.6:.16,weakMagnitude:big?.7:.25}).catch?.(()=>{});}catch{}}
  }
  ArenaControls.actions=actions;ArenaControls.defaults=defaultPad;window.ArenaControls=ArenaControls;
})();
