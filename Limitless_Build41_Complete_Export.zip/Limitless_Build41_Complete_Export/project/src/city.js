// A 352 m-wide playable district with breakable floors, roofs, walkways and street furniture.
const stage=new THREE.Group(),sky=new THREE.Group(),domainVisual=new THREE.Group();scene.add(stage,sky,domainVisual);
let pieceParent=stage;
const base=mesh(new THREE.CylinderGeometry(180,184,2.5,96),mats.dark,stage,V(0,-1.7,0));base.receiveShadow=true;
const floor=mesh(new THREE.CircleGeometry(179,96),new THREE.MeshStandardMaterial({color:0x172332,roughness:.91,metalness:.08}),stage,V(0,-.08,0));floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;
const edge=mesh(new THREE.TorusGeometry(177,.075,6,160),new THREE.MeshBasicMaterial({color:0x426783}),stage,V(0,-.02,0));edge.rotation.x=-Math.PI/2;
const grid=new THREE.Group(),arenaAccents=new THREE.Group();stage.add(grid,arenaAccents);
const pieces=[],debris=[],buildings=[];
const districtPalette=[0x46576d,0x526272,0x625d65,0x344754,0x69747c];
const districtMats=new Map();
function piece(pos,size,color=0x8ba2b5,platform=false){
 if(!districtMats.has(color))districtMats.set(color,new THREE.MeshStandardMaterial({color,map:assetTextures.stone||null,bumpMap:assetTextures.stone||null,bumpScale:.035,roughness:.84,metalness:.12}));
 const m=box(pieceParent,pos,size,districtMats.get(color));m.castShadow=true;m.receiveShadow=true;
 const p={m,pos:pos.clone(),size:size.clone(),hp:platform?28:16,max:platform?28:16,alive:true,platform,solid:false};pieces.push(p);return p;
}
const asphalt=new THREE.MeshStandardMaterial({color:0x151e29,roughness:.93}),curb=new THREE.MeshStandardMaterial({color:0x6a7785,roughness:.9}),paint=new THREE.MeshBasicMaterial({color:0x9aafba}),warmWindow=new THREE.MeshBasicMaterial({color:0xffd698}),coolWindow=new THREE.MeshBasicMaterial({color:0x72a9c0});
for(const c of [-132,-88,-44,0,44,88,132]){
 const length=2*Math.sqrt(173*173-c*c);
 box(grid,V(c,-.035,0),V(12,.04,length),asphalt);box(grid,V(0,-.03,c),V(length,.04,12),asphalt);
 for(const side of [-1,1]){box(grid,V(c+side*6.25,.055,0),V(.22,.16,length),curb);box(grid,V(0,.055,c+side*6.25),V(length,.16,.22),curb);}
 for(let n=-length/2+4;n<length/2-4;n+=8){box(grid,V(c,.002,n),V(.12,.014,3),paint);box(grid,V(n,.008,c),V(3,.014,.12),paint);}
}
// Crosswalks and plaza paving establish human scale beside the tall silhouettes.
for(const c of [-88,-44,0,44,88])for(const z of [-88,-44,0,44,88])for(const side of [-1,1])for(let n=-4;n<=4;n+=2){box(grid,V(c+n,.02,z+side*7.8),V(1.1,.02,2.4),paint);}
for(let x=-3;x<=3;x++)for(let z=-3;z<=3;z++)piece(V(x*3.5,.035,z*3.5),V(3.38,.18,3.38),(x+z)%2?0x4b6273:0x607788,false);
const cells=[-110,-66,-22,22,66,110];
for(const x of cells)for(const z of cells){
 if(Math.hypot(x,z)>143)continue;
 const id=buildings.length,w=rr(12,17),d=rr(13,18),floors=3+(id*7%6),building={id,x,z,w,d,floors,parts:[]};buildings.push(building);
 piece(V(x,.08,z),V(w+2,.22,d+2),0x455260,false);
 for(let level=0;level<floors;level++){
  const p=piece(V(x,2+level*4,z),V(w,3.92,d),districtPalette[id%districtPalette.length],true);p.solid=true;p.building=id;p.level=level;p.hp=p.max=46;building.parts.push(p);
  const matrices=[],cols=Math.floor(w/2.6),rows=Math.floor(d/2.6),matrix=new THREE.Matrix4();
  for(const side of [-1,1]){
   for(let c=0;c<cols;c++){const px=(c-(cols-1)/2)*2.6;matrix.compose(V(px/w,.06,side*.502),new THREE.Quaternion(),V(1.12/w,.36,.006));matrices.push(matrix.clone());}
   for(let c=0;c<rows;c++){const pz=(c-(rows-1)/2)*2.6;matrix.compose(V(side*.502,.06,pz/d),new THREE.Quaternion(),V(.006,.36,1.12/d));matrices.push(matrix.clone());}
  }
  const glass=new THREE.InstancedMesh(geo.box,id%3===0?warmWindow:coolWindow,matrices.length);matrices.forEach((m,i)=>glass.setMatrixAt(i,m));p.m.add(glass);
  // Narrow darker floor bands and a roof cap are part of the destructible section.
  const band=box(p.m,V(0,.47,0),V(1.015,.055,1.015),mats.dark);band.castShadow=false;
  if(level===floors-1){box(p.m,V(0,.535,0),V(1.055,.08,1.055),mats.pale);box(p.m,V(.16,.73,-.12),V(.23,.32,.28),mats.dark);box(p.m,V(-.25,.63,.2),V(.2,.14,.2),mats.stone);}
 }
 // Shop awning and a colored sign remain attached to the ground floor.
 const ground=building.parts[0].m;box(ground,V(0,-.2,.53),V(.8,.075,.14),id%2?mats.sukuna:mats.dark);box(ground,V(0,.12,.507),V(.7,.17,.01),id%2?warmWindow:coolWindow);
}
// Elevated crossings and short floating slabs; the ground underneath always remains.
for(const [cx,cz,h] of [[-15,-5,3.3],[15,-9,5.2],[-14,15,3.3]])for(let x=-1;x<=1;x++)for(let z=-1;z<=1;z++)piece(V(cx+x*3.4,h,cz+z*3.4),V(3.25,.65,3.25),0x8494a3,true);
for(const z of [-44,44]){
 for(let x=-4;x<=4;x++)piece(V(x*3,4.4,z),V(2.9,.65,4),0x8195a6,true);
 for(const side of [-1,1])for(let n=0;n<7;n++)piece(V(side*(15+n*1.1),4.4-n*.6,z),V(1.05,.5,3),0x687c8b,true);
}
for(const x of [-88,-44,0,44,88])for(const z of [-66,-22,22,66]){
 for(const side of [-1,1]){const px=x+side*8.2,p=piece(V(px,2.2,z),V(.24,4.4,.24),0x2b3745);const lamp=box(p.m,V(0,.47,0),V(7,.045,4),warmWindow);glow(0xffc18b,2.4,.14,lamp);}
 const p=piece(V(x+9,.48,z+4),V(3,.9,1.1),0x3d4b5a);box(p.m,V(0,.68,-.3),V(1,.18,.1),mats.pale);
}
// A low shrine courtyard anchors the center, surrounded by the district.
const shrine=new THREE.Group();stage.add(shrine);shrine.position.set(0,0,-31);
const cityMaterials=[new THREE.MeshStandardMaterial({color:0x111c2c,roughness:1}),new THREE.MeshStandardMaterial({color:0x1a293a,roughness:1})];
for(let i=0;i<42;i++){const a=i/42*Math.PI*2,r=rr(207,254),h=rr(18,61);box(sky,V(Math.cos(a)*r,h/2-5,Math.sin(a)*r),V(rr(8,17),h,rr(8,17)),cityMaterials[i%2]);}
const moon=mesh(new THREE.SphereGeometry(10,24,16),new THREE.MeshBasicMaterial({color:0xd5e7fb}),sky,V(-170,95,-220));const moonHalo=glow(0x78acfa,44,.3,sky);moonHalo.position.copy(moon.position);
const starPos=[];for(let i=0;i<1000;i++){const p=V(rr(-1,1),rr(.12,1),rr(-1,1)).normalize().multiplyScalar(rr(270,380));starPos.push(p.x,p.y,p.z);}const starsGeo=new THREE.BufferGeometry();starsGeo.setAttribute('position',new THREE.Float32BufferAttribute(starPos,3));const stars=new THREE.Points(starsGeo,new THREE.PointsMaterial({color:0x9ec9f0,size:.22,transparent:true,opacity:.7,depthWrite:false}));sky.add(stars);
const dustGeo=new THREE.BufferGeometry(),dustPositions=[];for(let i=0;i<230;i++)dustPositions.push(rr(-165,165),rr(.5,34),rr(-165,165));dustGeo.setAttribute('position',new THREE.Float32BufferAttribute(dustPositions,3));
const ambientDust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0x8fcbff,size:.08,transparent:true,opacity:.44,depthWrite:false,blending:THREE.AdditiveBlending}));scene.add(ambientDust);
function resolveDistrictCollision(f,previous){
 for(const p of pieces){if(!arenaPieceActive(p)||!p.solid||f.pos.y>=p.pos.y+p.size.y/2-.08||f.pos.y+2.3<=p.pos.y-p.size.y/2)continue;
  const hx=p.size.x/2+.43,hz=p.size.z/2+.43,dx=f.pos.x-p.pos.x,dz=f.pos.z-p.pos.z;
  if(Math.abs(dx)<hx&&Math.abs(dz)<hz){const px=hx-Math.abs(dx),pz=hz-Math.abs(dz);if(px<pz){f.pos.x=p.pos.x+Math.sign(dx||previous.x-p.pos.x||1)*hx;f.vel.x*=.1;}else{f.pos.z=p.pos.z+Math.sign(dz||previous.z-p.pos.z||1)*hz;f.vel.z*=.1;}}
 }
}
// Hundreds of lane markings and skyline blocks share a handful of draw calls.
function batchStaticBoxes(root){
 const groups=new Map();for(const o of [...root.children])if(o.isMesh&&!o.isInstancedMesh&&o.geometry===geo.box&&!o.children.length){if(!groups.has(o.material))groups.set(o.material,[]);groups.get(o.material).push(o);}
 for(const [material,objects]of groups){const batch=new THREE.InstancedMesh(geo.box,material,objects.length);objects.forEach((o,i)=>{o.updateMatrix();batch.setMatrixAt(i,o.matrix);root.remove(o);});batch.receiveShadow=true;root.add(batch);}
}
batchStaticBoxes(grid);batchStaticBoxes(sky);
function districtSegment(a,b,p,margin=.7){
 let enter=0,exit=1;for(const axis of ['x','z']){const half=p.size[axis]/2+margin,lo=p.pos[axis]-half,hi=p.pos[axis]+half,d=b[axis]-a[axis];if(Math.abs(d)<1e-8){if(a[axis]<lo||a[axis]>hi)return null;continue;}let x=(lo-a[axis])/d,y=(hi-a[axis])/d;if(x>y)[x,y]=[y,x];enter=Math.max(enter,x);exit=Math.min(exit,y);if(enter>exit)return null;}return {enter,exit};
}
function districtSteer(f,destination){
 const obstacles=pieces.filter(p=>arenaPieceActive(p)&&p.solid&&f.pos.y<p.pos.y+p.size.y/2-.1&&f.pos.y+2.2>p.pos.y-p.size.y/2),direct=destination.clone().sub(f.pos).setY(0);
 const blocking=obstacles.map(p=>({p,hit:districtSegment(f.pos,destination,p)})).filter(x=>x.hit&&x.hit.enter<.99).sort((a,b)=>a.hit.enter-b.hit.enter)[0];if(!blocking){f.navPoint=null;return direct.normalize();}if(f.navPoint&&f.navGoal?.distanceTo(destination)<6&&f.navPoint.distanceTo(f.pos)>.45)return f.navPoint.clone().sub(f.pos).setY(0).normalize();
 const p=blocking.p,candidates=[];for(const sx of [-1,1])for(const sz of [-1,1]){const corner=V(p.pos.x+sx*(p.size.x/2+1.6),f.pos.y,p.pos.z+sz*(p.size.z/2+1.6));if(corner.distanceTo(f.pos)<.9)continue;const blocked=obstacles.some(w=>{const hit=districtSegment(f.pos,corner,w);return hit&&hit.enter<.995&&!(hit.enter===0&&hit.exit<.2);});if(!blocked)candidates.push({corner,cost:corner.distanceTo(f.pos)+corner.distanceTo(destination)});}
 candidates.sort((a,b)=>a.cost-b.cost);if(candidates.length){f.navPoint=candidates[0].corner;f.navGoal=destination.clone();return f.navPoint.clone().sub(f.pos).setY(0).normalize();}return direct.normalize();
}
