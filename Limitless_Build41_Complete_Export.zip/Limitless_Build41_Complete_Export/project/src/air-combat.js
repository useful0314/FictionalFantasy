// Air attack selection uses the existing replicated attackKind/attackAir fields.
const AIR_COMBAT={downAim:-.35,upAim:.35,landBlend:.12,contactHold:.065,downKnock:3,downFinish:10,upKnock:3,upFinish:10};
function lightAttackKind(f){if(f.grounded||f.character==='mahito'&&f.mahitoArm===2)return 0;const y=aimFor(f).y;return y<AIR_COMBAT.downAim?3:y>AIR_COMBAT.upAim?2:0;}
function lightStrikeDirection(f,kind,air){
 const dir=aimFor(f);if(!air)return dir.setY(0).normalize();
 if(kind===3)dir.y=Math.min(dir.y,AIR_COMBAT.downAim);else if(kind===2)dir.y=Math.max(dir.y,AIR_COMBAT.upAim);else dir.y=clamp(dir.y,AIR_COMBAT.downAim,AIR_COMBAT.upAim);
 return dir.normalize();
}
function airLightKnockback(knock,h){if(!h.air)return;const end=h.combo===3;if(h.kind===3)knock.y=-(end?AIR_COMBAT.downFinish:AIR_COMBAT.downKnock);else if(h.kind===2)knock.y=end?AIR_COMBAT.upFinish:AIR_COMBAT.upKnock;}
let airCombatPoses=null;
function airCombatLibrary(){
 if(airCombatPoses)return airCombatPoses;const p=narutoPoseTemplate;
 const downWind=p({lx:-.95,le:-1.4,lz:.25,rx:-.8,re:-1.5,rz:-.3,ll:-1.65,lk:.75,ls:-.12,rl:-.9,rk:1.8,rs:.19,lean:-.16,twist:-.17,bob:.015,stretch:.965,lc:-1.5,rc:-1.5});
 const downHit=p({lx:.1,le:-1.15,lz:.55,rx:-.55,re:-1.4,rz:-.4,ll:-.34,lk:.06,ls:-.08,lf:.12,rl:-1.4,rk:2,rs:.2,lean:.34,twist:.20,bob:-.045,stretch:1.045,hx:.15,lc:-1.5,rc:-1.5});
 const downBack=p({lx:-.65,le:-1.25,lz:.25,rx:-.65,re:-1.25,rz:-.25,ll:-.5,lk:1.05,rl:-.35,rk:1.1,lean:.11,twist:.08,stretch:.99,lc:-1.2,rc:-1.2});
 const upWind=p({lx:-.25,le:-1.8,lz:.2,rx:-.7,re:-1.9,rz:-.15,ll:-.55,lk:1.25,rl:-.8,rk:1.4,lean:.18,twist:-.28,stretch:.96,lc:-1.5,rc:-1.5});
 const upHit=p({lx:-2.72,le:-.19,lz:-.06,rx:-.55,re:-1.95,rz:-.16,ll:.15,lk:.35,rl:-.8,rk:1.3,lean:-.20,twist:.30,stretch:1.05,hx:-.2,lc:-1.6,rc:-1.4});
 const upBack=p({lx:-.95,le:-1.3,rx:-.65,re:-1.5,ll:-.35,lk:.9,rl:-.65,rk:1.2,lean:-.04,twist:.1,lc:-1.3,rc:-1.3});
 const pair=a=>{const b=a.slice();mirrorCombatPose(b);return [a,b];};
 return airCombatPoses={downWind:pair(downWind),downHit:pair(downHit),downBack:pair(downBack),upWind:pair(upWind),upHit:pair(upHit),upBack:pair(upBack),
 stompWind:p({lx:-1.4,le:-1.3,lz:.4,rx:-1.4,re:-1.3,rz:-.4,ll:-1.25,rl:-1.25,lk:2,rk:2,ls:-.15,rs:.15,lean:-.13,stretch:.94,lc:-1.5,rc:-1.5}),
 stomp:p({lx:.2,le:-.9,lz:.7,rx:.2,re:-.9,rz:-.7,ll:-.24,rl:-.24,lk:.05,rk:.05,ls:-.16,rs:.16,lf:.08,rf:.08,lean:.25,stretch:1.06,hx:.15,lc:-1.5,rc:-1.5})};
}
function sampleAirCombat(f,p,idle,t,duration,hit,dt,n){
 if(!f.attackAir)return;
 const kind=f.attackKind,combo=f.combo||0;
 if(kind===2||kind===3){const L=airCombatLibrary(),side=combo%2,down=kind===3,finish=down&&combo===3,wind=finish?L.stompWind:down?L.downWind[side]:L.upWind[side],strike=finish?L.stomp:down?L.downHit[side]:L.upHit[side],back=down?L.downBack[side]:L.upBack[side],windEnd=hit*.28,hold=Math.min(duration*.6,hit+AIR_COMBAT.contactHold*(duration/.34)),settle=duration*.79;
  if(t<windEnd)lightComboMix(p,idle,wind,t/windEnd);else if(t<hit)lightComboMix(p,wind,strike,(t-windEnd)/(hit-windEnd));else if(t<hold)p.set(strike);else if(t<settle)lightComboMix(p,strike,back,(t-hold)/(settle-hold));else lightComboMix(p,back,idle,(t-settle)/(duration-settle));
 }else{
  // Keep the new four-hit rhythm, with airborne leg chambers instead of planted steps.
  const weight=narutoEase(t/Math.max(.025,hit*.5))*(1-narutoEase((t-duration*.76)/(duration*.24)));
  if(combo<2){p[NP.ll]=lerp(p[NP.ll],combo===0?-.75:.2,weight);p[NP.rl]=lerp(p[NP.rl],combo===0?.2:-.75,weight);p[NP.lk]=lerp(p[NP.lk],combo===0?1.3:.7,weight);p[NP.rk]=lerp(p[NP.rk],combo===0?.7:1.3,weight);}
  else{const left=combo===3;p[left?NP.ll:NP.rl]=lerp(p[left?NP.ll:NP.rl],-.65,weight);p[left?NP.lk:NP.rk]=lerp(p[left?NP.lk:NP.rk],1.4,weight);p[NP.lean]-=.09*weight;}
  p[NP.bob]*=1-weight;
 }
 n.airLand=f.grounded?Math.min(AIR_COMBAT.landBlend,(n.airLand||0)+dt):0;
 if(n.airLand>0){const q=narutoEase(n.airLand/AIR_COMBAT.landBlend),yaw=p[NP.twist];narutoMixPose(p,p,idle,q);p[NP.twist]=yaw+Math.atan2(Math.sin(idle[NP.twist]-yaw),Math.cos(idle[NP.twist]-yaw))*q;}
}
