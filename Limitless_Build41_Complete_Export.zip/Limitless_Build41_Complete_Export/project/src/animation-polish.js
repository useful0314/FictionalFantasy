// Visual-only additions to the existing animators. Hitboxes, timers and movement remain unchanged.
const ROSTER_MOTION={blend:.085,sealBlend:.14,secondaryBlend:.13,landTime:.24,landSquash:.055,breath:.018,trailInterval:.045,trailMinDistance:.12,trailMaxDistance:2.6,ghostLife:.32};
let rosterPoses=null;
function rosterPoseLibrary(){
 if(rosterPoses)return rosterPoses;const p=narutoPoseTemplate;
 return rosterPoses={
 spiderman:p({lx:-.65,rx:-.7,le:-1.1,re:-1.3,ll:-.18,rl:.18,lk:.4,rk:.3,bob:-.08,lean:.12}),
 gojo:p({lx:-.15,rx:-.32,le:-.45,re:-.8,lz:.12,rz:-.14,twist:-.045,ll:-.035,rl:.05,lk:.12,rk:.18}),
 sukuna:p({lx:-.35,rx:-.42,le:-.9,re:-1.05,lz:.25,rz:-.28,twist:.06,ll:-.08,rl:.08,lk:.2,rk:.16}),
 naruto:p({lx:-.46,rx:-.64,le:-1.05,re:-1.2,lz:.16,rz:-.16,twist:-.07,ll:-.09,rl:.09,lk:.23,rk:.18}),
 mahito:p({lx:-.18,rx:-.3,lz:.12,rz:-.16,le:-.42,re:-.62,ll:-.08,rl:.06,lk:.14,rk:.18,twist:-.08}),
 jabWind:p({lx:-.48,ly:-.12,lz:.28,le:-1.6,rx:-.73,re:-1.35,twist:.24,lean:-.025,bob:-.035,lk:.24,rk:.18}),
 jab:p({lx:-1.59,ly:.03,lz:.03,le:-.08,rx:-.68,re:-1.36,twist:-.43,lean:.10,stretch:1.018,ll:-.12,rl:.12,lk:.23,rk:.13,lc:-1.55,rc:-1.4}),
 crossWind:p({lx:-.68,le:-1.3,rx:-.35,ry:-.18,rz:-.34,re:-1.48,twist:-.28,lean:-.045,bob:-.055,lk:.3,rk:.24}),
 cross:p({lx:-.72,le:-1.38,rx:-1.67,ry:-.04,rz:-.04,re:-.05,twist:.66,lean:.20,bob:.025,stretch:1.03,ll:-.16,rl:.26,lk:.28,rk:.14,lc:-1.4,rc:-1.55}),
 hookWind:p({lx:-.62,ly:-.4,lz:.72,le:-1.25,rx:-.76,re:-1.42,twist:.5,bob:-.07,lk:.28,rk:.28}),
 hook:p({lx:-1.36,ly:.47,lz:-.18,le:-1.08,rx:-.73,re:-1.35,twist:-.76,lean:.14,tilt:-.08,stretch:1.02,ll:-.16,rl:.15,lc:-1.55}),
 finishWind:p({lx:-.85,le:-1.2,rx:.18,ry:-.15,rz:-.32,re:-1.25,twist:-.55,lean:-.09,bob:-.11,lk:.42,rk:.32}),
 finish:p({lx:-.68,le:-1.3,rx:-1.64,re:-.035,ry:-.08,rz:-.07,twist:.85,lean:.27,bob:.03,stretch:1.045,ll:-.3,rl:.32,lk:.37,rk:.12,rc:-1.55}),
 kickWind:p({lx:-.8,rx:-.9,le:-1.2,re:-1.1,rl:-.85,rk:1.48,ll:.10,lk:.3,bob:-.08,twist:.32}),
 kick:p({lx:-.74,rx:-.45,le:-1.2,re:-.85,lz:.48,rz:-.45,rl:-1.63,rs:-.48,rk:.07,ll:.08,lk:.22,twist:-.58,tilt:.23,lean:.07,bob:.06,stretch:1.025}),
 upperWind:p({lx:-.82,le:-1.3,rx:-.43,re:-1.62,twist:-.36,lean:.24,bob:-.23,ll:-.28,rl:-.2,lk:.66,rk:.47,stretch:.96}),
 upper:p({lx:-.74,le:-1.3,rx:-2.6,ry:-.08,re:-.48,twist:.48,lean:-.18,bob:.17,ll:-.12,rl:.26,lk:.25,rk:.48,stretch:1.065,rc:-1.55}),
 sweepWind:p({lx:-.75,rx:-.55,le:-1.2,re:-.8,ll:-.35,rl:-.5,lk:1.02,rk:.7,twist:-.45,lean:.24,bob:-.22,stretch:.97}),
 sweep:p({lx:-.4,rx:.2,lz:.76,rz:-.72,le:-.8,re:-.45,ll:-.78,lk:1.3,rl:-.68,rs:-.91,rk:.08,twist:1.2,lean:.29,bob:-.37,stretch:.96}),
 slamWind:p({lx:-2.28,rx:-2.28,le:-.65,re:-.65,ll:-.7,rl:-.6,lk:1.4,rk:1.25,lean:-.15,bob:.08,stretch:1.035}),
 slam:p({lx:-.65,rx:-.65,le:-.3,re:-.3,ll:.12,rl:.18,lk:.18,rk:.12,lean:.5,bob:-.15,stretch:.945})};
}
function rosterAnimationState(f){
 if(f.rosterAnim?.root===f.root)return f.rosterAnim;
 return f.rosterAnim={root:f.root,pose:narutoPoseTemplate(),idle:narutoPoseTemplate(),last:f.pos.clone(),wasGrounded:f.grounded,land:0,landPower:0,fallSpeed:0,speed:0,lean:0,hair:0,cloth:0,tail:0,trailClock:0,trailActive:false,points:Array.from({length:f.limbs.length+2},()=>V()),point:V(),pivot:V(),target:V()};
}
function rosterLightPose(f,out,idle=rosterPoseLibrary()[f.character],dt=1/60){
 if(sampleLightCombo(f,out,idle,dt))return true;
 if(!(f.attackIsLight&&f.attack>0))return false;const L=rosterPoseLibrary();let wind,strike;
 if(f.attackCounter){wind=L.crossWind;strike=L.cross;}
 else if(f.attackKind===1){wind=L.kickWind;strike=L.kick;}
 else if(f.attackKind===2){wind=L.upperWind;strike=L.upper;}
 else if(f.attackKind===3){wind=f.attackAir?L.slamWind:L.sweepWind;strike=f.attackAir?L.slam:L.sweep;}
 else{const i=f.combo||0;wind=i===0?L.jabWind:i===1?L.crossWind:i===2?L.hookWind:L.finishWind;strike=i===0?L.jab:i===1?L.cross:i===2?L.hook:L.finish;}
 const max=f.attackMax||.4,t=clamp(max-f.attack,0,max),hit=f.attackCounter?.09:f.attackKind===1?.14:.12,windEnd=hit*.36,contact=hit*.76,hold=Math.min(max*.61,hit+.072);
 if(t<windEnd)narutoMixPose(out,idle,wind,narutoEase(t/windEnd));else if(t<contact)narutoMixPose(out,wind,strike,narutoBack((t-windEnd)/(contact-windEnd)));else if(t<hold)out.set(strike);else narutoMixPose(out,strike,idle,narutoEase((t-hold)/(max-hold)));return true;
}
function rosterLocomotionPose(f,dt,speed,moving,sprint){
 const n=rosterAnimationState(f),p=n.pose,L=rosterPoseLibrary(),walk=Math.sin(f.walkPhase||0),stride=Math.cos(f.walkPhase||0),breath=Math.sin(time*2.3+(f.slot||0));n.speed=speed;p.set(L[f.character]);p[NP.bob]=breath*ROSTER_MOTION.breath;p[NP.lz]+=breath*.012;p[NP.rz]-=breath*.012;p[NP.hy]=Math.sin(time*.73+(f.slot||0))*.025;
 if(moving){p[NP.ll]=walk*(sprint?1.05:.66);p[NP.rl]=-p[NP.ll];p[NP.lk]=.13+Math.max(0,-walk)*(sprint?1.42:.82);p[NP.rk]=.13+Math.max(0,walk)*(sprint?1.42:.82);p[NP.lx]=-walk*(sprint?.94:.57);p[NP.rx]=-p[NP.lx];p[NP.le]=p[NP.re]=sprint?-1.15:-.55;p[NP.lean]=sprint?.29:.08;p[NP.twist]=stride*(sprint?.13:.075);p[NP.tilt]=walk*(sprint?.025:.017);p[NP.bob]=Math.abs(walk)*(sprint?.10:.055);p[NP.stretch]=1+Math.sin((f.walkPhase||0)*2)*.012;p[NP.hx]=-.035;p[NP.hy]=-p[NP.twist]*.5;}
 if(!f.grounded){const lift=narutoEase((f.vel.y+3)/11),fall=1-lift;p[NP.ll]=lerp(.18,-.65,lift);p[NP.rl]=lerp(-.34,.28,lift);p[NP.lk]=lerp(.42,1.12,lift);p[NP.rk]=lerp(.85,.4,lift);p[NP.lx]=lerp(.15,-.48,lift);p[NP.rx]=lerp(.30,-.73,lift);p[NP.lz]=.35+fall*.14;p[NP.rz]=-.35-fall*.14;p[NP.lean]=lerp(-.07,.12,lift);p[NP.stretch]=lerp(.99,1.035,lift);p[NP.hx]=fall*.065;n.fallSpeed=Math.max(n.fallSpeed,-f.vel.y);}
 if(f.flying){const fast=clamp(speed/32,0,1),drift=Math.sin(time*3.2)*.045;p[NP.ll]=.15+fast*.23;p[NP.rl]=.30+fast*.18;p[NP.lk]=.28;p[NP.rk]=.52;p[NP.lx]=p[NP.rx]=.12+fast*.58;p[NP.lz]=.27+drift;p[NP.rz]=-.27-drift;p[NP.le]=p[NP.re]=-.5;p[NP.lean]=.08+fast*.40;p[NP.bob]=drift;p[NP.hx]=-p[NP.lean]*.35;p[NP.stretch]=1+fast*.02;}
 if(f.grounded&&!n.wasGrounded){n.land=ROSTER_MOTION.landTime;n.landPower=clamp(n.fallSpeed/13,.35,1);if(phase==='play'&&f.hp>0)landingContact(f,n.fallSpeed,n.landPower*.62);n.fallSpeed=0;}n.wasGrounded=f.grounded;n.land=Math.max(0,n.land-dt);
 if(n.land>0){const t=1-n.land/ROSTER_MOTION.landTime,w=Math.sin(Math.PI*narutoEase(t))*n.landPower;p[NP.bob]-=.18*w;p[NP.lk]+=.5*w;p[NP.rk]+=.42*w;p[NP.lean]+=.1*w;p[NP.stretch]-=ROSTER_MOTION.landSquash*w;}
 if(f.jumpPose>0&&!f.flying){const w=narutoEase(f.jumpPose/.3),side=f.jumpSide||0;p[side?NP.rl:NP.ll]=-.7*w;p[side?NP.rk:NP.lk]=1.1*w;p[side?NP.rx:NP.lx]=-.65*w;p[NP.stretch]=1+.04*w;}
 continuousGait(f,p,n,dt,speed);polishLocomotion(f,p,n,dt,moving);blendGait(n,p,dt);n.idle.set(p);rosterLightPose(f,p,n.idle,dt);applyLightOutcomePose(f,p);return p;
}
function animateRosterDetail(f,dt,moving=false,techniquePose=null){
 const n=rosterAnimationState(f),r=f.blockRig,secondary=1-Math.exp(-dt/ROSTER_MOTION.secondaryBlend),speed=n.speed,acceleration=clamp((f.body.rotation.x-n.lean)/Math.max(dt,.001),-7,7);n.lean=f.body.rotation.x;
 if(r&&f.character!=='naruto'){
 n.hair=lerp(n.hair,-acceleration*.024+Math.sin(time*3.2)*.009,secondary);r.hair.rotation.x=n.hair;for(let i=0;i<r.hairLocks.length;i++){const lock=r.hairLocks[i];lock.rotation.x=lock.userData.restX+n.hair*.35+Math.sin(time*4.5+i*.6)*.006;}
 n.cloth=lerp(n.cloth,clamp(speed/26,0,1)*.16-acceleration*.018,secondary);for(let i=0;i<r.hems.length;i++)r.hems[i].rotation.x=n.cloth+Math.sin((f.walkPhase||0)+i*Math.PI)*.025;
 n.tail=lerp(n.tail,clamp(speed/26,0,1)*.8+acceleration*.026,secondary);for(let i=0;i<r.tails.length;i++){r.tails[i].rotation.x=-n.tail+Math.sin(time*6+i)*.065;r.tails[i].rotation.z=Math.sin(time*4+i)*.035;}
 for(let i=0;i<r.feet.length;i++){const w=Math.sin((f.walkPhase||0)+(i?Math.PI:0)),target=f.ragdollT>0?.10:!f.grounded?.18:moving?clamp(-w*.22,-.2,.22):0;r.feet[i].rotation.x=n.comboMotion?.render?n.comboMotion.pose[i?NP.rf:NP.lf]:lerp(r.feet[i].rotation.x,target,1-Math.exp(-dt/ROSTER_MOTION.blend));}

 }
 if(f.character!=='naruto')for(let i=0;i<f.limbs.length;i++){const limb=f.limbs[i],wrist=techniquePose?.wrists?.[i];limb.elbow.rotation.y=lerp(limb.elbow.rotation.y,0,secondary);limb.elbow.rotation.z=lerp(limb.elbow.rotation.z,0,secondary);limb.hand.rotation.x=lerp(limb.hand.rotation.x,wrist?.x||0,secondary);limb.hand.rotation.y=lerp(limb.hand.rotation.y,wrist?.y||0,secondary);limb.hand.rotation.z=lerp(limb.hand.rotation.z,wrist?.z||0,secondary);}
 if(f.character!=='naruto')rosterSealPose(f,dt);
 plantCombatFoot(f);
 const active=phase==='play'&&f.hp>0&&!f.block&&f.ragdollT<=0&&f.hitReact<=0&&(f.attackIsLight&&f.attack>0||f.character==='spiderman'&&f.spider?.action?.kind===2||f.character==='naruto'&&f.narutoAction?.kind<=3||f.character==='sukuna'&&f.specialKind>0&&f.specialKind<3);
 n.trailClock+=dt;f.root.updateMatrixWorld(true);const sample=n.trailClock>=(n.comboMotion?.render?LIGHT_COMBO_MOTION.trailInterval:ROSTER_MOTION.trailInterval);
 if(sample||!active||!n.trailActive){const color=CHARACTER_EFFECTS[f.character].color;for(let i=0;i<n.points.length;i++){const obj=i<f.limbs.length?f.limbs[i].hand:(f.blockRig?.feet||f.narutoRig?.feet||f.mahitoRig?.feet||f.knees)[i-f.limbs.length];obj.getWorldPosition(n.point);const distance=n.points[i].distanceTo(n.point);if(active&&n.trailActive&&sample&&distance>ROSTER_MOTION.trailMinDistance&&distance<ROSTER_MOTION.trailMaxDistance)narutoLimbTrail(n.points[i],n.point,color);n.points[i].copy(n.point);}if(sample)n.trailClock=0;}n.trailActive=active;
}
function poseAfterImage(f,color){
 const g=new THREE.Group(),m=new THREE.MeshBasicMaterial({color,transparent:true,opacity:.25,blending:THREE.AdditiveBlending,depthWrite:false});g.userData.sharedGeometry=true;scene.add(g);f.root.position.copy(f.pos);f.root.updateMatrixWorld(true);
 let parts=f.blockRig?.major;if(!parts){parts=f.mahitoRig.ghostParts;if(!parts){parts=[];f.body.traverse(o=>{if(o.isMesh&&['patchwork-tunic','hips','stitched-face','upper-arm','forearm','palm','baggy-thigh','lower-leg','bare-foot'].includes(o.name))parts.push(o);});f.mahitoRig.ghostParts=parts;}}
 for(const part of parts){if(!part.visible)continue;const copy=new THREE.Mesh(part.geometry,m);copy.matrixAutoUpdate=false;copy.matrix.copy(part.matrixWorld);g.add(copy);}effects.push({m:g,mat:m,t:0,max:ROSTER_MOTION.ghostLife,type:'ghost'});
}
// Domain hand signs meet in torso space on each rig. Cached two-bone IK is presentation-only.
function rosterSealPose(f,dt){
 const cast=domainPresentationCast(f),n=rosterAnimationState(f);if(!cast||f.hitReact>0||f.ragdollT>0||f.hp<=0){n.sealAge=0;return;}
 n.sealAge=Math.min(ROSTER_MOTION.sealBlend,(n.sealAge||0)+dt);const b=narutoEase(n.sealAge/ROSTER_MOTION.sealBlend);n.ik||=f.limbs.map(()=>({delta:V(),bend:V(),joint:V(),foreDir:V(),down:V(0,-1,0),upper:new THREE.Quaternion(),elbow:new THREE.Quaternion(),hand:new THREE.Quaternion(),fore:new THREE.Quaternion(),palm:new THREE.Quaternion(),euler:new THREE.Euler()}));
 for(let i=0;i<f.limbs.length;i++){
  if(f.character==='gojo'&&i!==1)continue;const side=i%2?1:-1,lower=i>1,l=f.limbs[i],k=n.ik[i],a=f.character==='mahito'?.425:.54,c=f.character==='mahito'?.385:.4,x=f.character==='gojo'?.27:side*.063,y=f.character==='gojo'?2.14:lower?1.37:1.90,z=f.character==='gojo'?.47:.52;
  k.delta.set(x,y,z).sub(l.arm.position);const d=clamp(k.delta.length(),.15,a+c-.01),along=(a*a-c*c+d*d)/(2*d);k.delta.normalize();k.bend.set(side,-.85,.12);k.bend.addScaledVector(k.delta,-k.bend.dot(k.delta)).normalize();k.joint.copy(l.arm.position).addScaledVector(k.delta,along).addScaledVector(k.bend,Math.sqrt(Math.max(0,a*a-along*along)));k.foreDir.set(x,y,z).sub(k.joint).normalize();k.delta.copy(k.joint).sub(l.arm.position).normalize();k.upper.setFromUnitVectors(k.down,k.delta);k.fore.setFromUnitVectors(k.down,k.foreDir);k.elbow.copy(k.upper).invert().multiply(k.fore);k.euler.set(0,side*.15,Math.PI-side*.26);k.palm.setFromEuler(k.euler);k.hand.copy(k.fore).invert().multiply(k.palm);
  l.arm.quaternion.slerp(k.upper,b);l.elbow.quaternion.slerp(k.elbow,b);l.hand.quaternion.slerp(k.hand,b);
 }
}
