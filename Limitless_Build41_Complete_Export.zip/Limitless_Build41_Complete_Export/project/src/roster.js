// Six independent fighters. Stable room IDs, per-fighter input, targeting and resources.
const MAX_FIGHTERS=6;
const AI_LEVELS={easy:{reaction:.75,attack:1.1,charge:.2,guard:.08,dodge:0},normal:{reaction:.3,attack:.55,charge:.48,guard:.25,dodge:.12},hard:{reaction:.12,attack:.22,charge:.8,guard:.55,dodge:.5},impossible:{reaction:.03,attack:.12,charge:1,guard:.8,dodge:.9}};
const matchSetup={bots:['sukuna'],difficulty:'normal'};
try{const saved=JSON.parse(localStorage.getItem('limitless.match.v1')||'{}');if(Array.isArray(saved.bots)&&saved.bots.length>=1&&saved.bots.length<=5&&saved.bots.every(c=>KITS[c]))matchSetup.bots=saved.bots;if(AI_LEVELS[saved.difficulty])matchSetup.difficulty=saved.difficulty;}catch{}
const actorPool=[player,enemy];player.id='p0';player.bot=false;enemy.id='b0';enemy.bot=true;enemy.input=remoteInput;
player.rigCache={gojo:rigs.gojo};enemy.rigCache={sukuna:rigs.sukuna};
let winnerId=null,lastEliminated=null;
function ensureActorRig(f,character){
 f.rigCache||={};for(const rig of Object.values(f.rigCache)){rig.root.visible=false;rig.shadow.visible=false;}
 const rig=f.rigCache[character]||(f.rigCache[character]=character==='spiderman'?fighterModelSpider():character==='mahito'?fighterModelMahito():character==='naruto'?fighterModelNaruto():fighterModel(character==='gojo'));Object.assign(f,rig,{character});rig.root.visible=true;rig.shadow.visible=true;prepareCombatFeelRig(f);
}
function actorById(id){return bodies.find(f=>f.id===id);}
function newInput(){return {keys:new Set(),held:new Set(),yaw:0,pitch:0,move:{x:0,y:0},lastAt:performance.now()};}
function configureRoster(nextMode){
 for(const f of actorPool){cancelCharge(f);setCast(f,null);if(f.root)f.root.visible=false;if(f.shadow)f.shadow.visible=false;}
 const localId=nextMode==='online'?net.localId:'p0';
 let roster=nextMode==='online'?net.roster:[{id:'p0',character:selectedCharacter,bot:false},...matchSetup.bots.map((character,i)=>({id:'b'+i,character,bot:true,difficulty:matchSetup.difficulty}))];
 if(!roster?.length)roster=[{id:'p0',character:selectedCharacter,bot:false},{id:'b0',character:'sukuna',bot:true,difficulty:'normal'}];
 const local=roster.find(f=>f.id===localId)||roster[0],ordered=[local,...roster.filter(f=>f.id!==local.id)].slice(0,MAX_FIGHTERS);bodies.length=0;
 ordered.forEach((entry,i)=>{const f=actorPool[i]||(actorPool[i]={pos:V(),vel:V(),rigCache:{}});Object.assign(f,{id:entry.id,bot:!!entry.bot,difficulty:entry.difficulty||'normal',input:i===1?remoteInput:newInput(),targetId:null,slot:roster.findIndex(r=>r.id===entry.id),primaryCharge:null,cast:null,auxCharge:null});Object.assign(f.input,newInput());ensureActorRig(f,entry.character);bodies.push(f);});
 selectedCharacter=player.character;winnerId=null;lastEliminated=null;clearDomainCutouts();
}
function placeRoster(){
 for(const f of bodies){const a=f.slot/bodies.length*Math.PI*2;f.pos.set(Math.sin(a)*18,.13,Math.cos(a)*18);f.vel.set(0,0,0);f.input.yaw=a;f.input.pitch=.03;f.input.lastAt=performance.now();f.input.keys.clear();f.input.held.clear();f.root.visible=f.body.visible=f.shadow.visible=true;}
 if(bodies.length===2){const localHost=mode!=='online'||net.role==='host';player.pos.set(0,.13,localHost?13:-3);enemy.pos.set(0,.13,localHost?-3:13);player.input.yaw=localHost?0:Math.PI;enemy.input.yaw=localHost?Math.PI:0;}
 yaw=player.input.yaw;pitch=.06;
}
function separateFighters(){for(let i=0;i<bodies.length;i++)for(let j=i+1;j<bodies.length;j++){const a=bodies[i],b=bodies[j];if(a.hp<=0||b.hp<=0||barrierSeparates(a,b))continue;const d=a.pos.clone().sub(b.pos);d.y=0;const length=d.length();if(length<.9&&Math.abs(a.pos.y-b.pos.y)<2){if(length<.001)d.set(1,0,0);else d.divideScalar(length);d.multiplyScalar((.9-length)*.5);a.pos.add(d);b.pos.sub(d);}}}
function eliminateFighter(f,attacker,domainKill=false){
 interruptSpider(f);interruptMahito(f);
 if(f.character==='naruto')interruptNaruto(f);
 cancelCharge(f);setCast(f,null);stopCastVoice(f);f.block=f.flying=false;f.input?.keys.clear();f.input?.held.clear();lastEliminated=f;
 if(clash?.participants.includes(f.id)){clash.participants=clash.participants.filter(id=>id!==f.id);delete clash.scores[f.id];if(clash.participants.length===1)activateDomain(actorById(clash.participants[0]));else if(!clash.participants.length){clash=null;clearDomainVisual();}else{syncClashScores();showClashCutouts();}}
 const alive=bodies.filter(b=>b.hp>0);if(alive.length<=1){win(alive[0]||attacker,domainKill&&alive[0]===attacker);return;}
 f.root.visible=f.shadow.visible=false;announce(f.id.toUpperCase()+' · '+kit(f).short+' ELIMINATED',alive.length+' FIGHTERS REMAIN',1.6);if(f===player){controls.releaseAll();setCursorMode(true);toast('YOU ARE ELIMINATED · watching the remaining fighters',5);}
}
function blueFor(f){return blues.find(b=>b.owner===f)||null;}
function refreshFieldAliases(){blue=blueFor(player)||blues[0]||null;bomb=bombs.find(b=>b.owner===player)||bombs[0]||null;}
function removeBlue(b){removeObject(b.o?.g);const i=blues.indexOf(b);if(i>=0)blues.splice(i,1);refreshFieldAliases();}
function removeBomb(b){removeObject(b.o?.g);const i=bombs.indexOf(b);if(i>=0)bombs.splice(i,1);refreshFieldAliases();}
function clearFields(){for(const b of [...blues])removeBlue(b);for(const b of [...bombs])removeBomb(b);blue=bomb=null;}
function updateAI(f,dt){
 const cfg=AI_LEVELS[f.difficulty]||AI_LEVELS.normal,i=f.input;f.aiThink=Math.max(0,(f.aiThink||0)-dt);f.nextSlash-=dt;f.domainCD-=dt;
 if(f.difficulty==='impossible'){f.energy=Math.min(100,f.energy+12*dt);f.stamina=Math.min(maxStamina(f),f.stamina+20*dt);}
 const active=mode!=='practice'||!!clash;
 if(f.aiThink<=0){
  f.aiThink=cfg.reaction;i.keys.clear();i.move={x:0,y:0};f.targetId=null;const target=other(f);f.targetId=target.id;const delta=headPos(target).sub(headPos(f)),distance=delta.length();i.yaw=Math.atan2(-delta.x,-delta.z);i.pitch=clamp(Math.atan2(-delta.y,Math.hypot(delta.x,delta.z)),-1.1,.85);
  if(active&&f.stun<=0&&!castFor(f)&&!trappedByVoid(f)){
   if(!chargeFor(f)){if(distance>3){const d=districtSteer(f,target.pos),dir=aimFor(f).setY(0).normalize(),right=V(-dir.z,0,dir.x);i.move={x:d.dot(right),y:-d.dot(dir)};if(distance>13)i.keys.add('ShiftLeft');}else if(distance<1.6&&!f.comboHits)i.keys.add('KeyS');}
   if(f.energy<15||f.energyCharging&&f.energy<55)i.keys.add('KeyC');
   const threat=target.attack>0||chargeFor(target)||projectiles.some(p=>p.owner!==f&&p.p.distanceTo(headPos(f))<14);
   if(threat&&distance<8&&rand()<cfg.guard)i.keys.add('Mouse2');
   if(threat&&rand()<cfg.dodge)dodge(f);
   const counter=bodies.some(b=>b!==f&&castFor(b)&&headPos(f).distanceTo(castFor(b).origin)<DOMAIN_ENCLOSURE.radius);
   if(f.ult>=99&&!domain&&(counter||clash?.joinRemaining>0||f.domainCD<=0)){castDomain(f);f.domainCD=18;}
   if((f.character==='sukuna'||f.character==='naruto')&&target.pos.y>f.pos.y+2.5&&distance<40)jumpFighter(f);
   if(f.character==='gojo'&&target.pos.y>f.pos.y+4&&!f.flying&&f.energy>15)actionFor(f,'fly',true);
   if(f.flying&&target.pos.y>f.pos.y+1)i.keys.add('Space');else if(f.flying&&target.pos.y<f.pos.y-2)i.keys.add('ControlLeft');
   if(!chargeFor(f)&&!i.keys.has('KeyC')&&!castFor(f)){
    if(distance<3.5&&f.attack<=0){if(f.character==='mahito'&&f.ult>=20&&f.nextSlash<=0&&rand()<.25){startCharge(6,f);f.nextSlash=cfg.attack+1.2;}else lightAttack(f);f.aiThink=Math.max(cfg.reaction,f.comboHits?.15:cfg.attack);}
    else if(f.nextSlash<=0){const ownBlue=blueFor(f);let kind=f.character==='spiderman'?(distance<7?2:f.spider?.linkTime>0?1:rand()<.5?1:3):f.character==='mahito'?(f.hp<700&&distance>12?4:f.ult>=20&&distance<3?6:distance>25?3:!f.mahitoArm||rand()<.2?1:rand()<.5?2:5):f.character==='naruto'?(distance>25&&f.energy>=75&&f.ult>=30&&rand()<.18?5:distance<8?2:distance<18?(rand()<.5?1:3):4):f.character==='gojo'?(ownBlue?.phase==='hold'?2:distance>40?4:rand()<.25?3:rand()<.5?1:2):(f.ult>=50&&f.energy>=60&&distance>12&&rand()<.2?5:distance<5?2:distance>22&&rand()<.4?4:rand()<.3?3:1);startCharge(kind,f);const ch=chargeFor(f,kind);if(ch)ch.aiRelease=ch.max*cfg.charge;f.nextSlash=cfg.attack+1.2;}
   }
   if(f.character==='sukuna'&&chargesFor(f).length===1&&f.difficulty!=='easy'&&f.energy>25&&!chargeFor(f,1)){startCharge(1,f);const ch=chargeFor(f,1);if(ch)ch.aiRelease=ch.max*cfg.charge;}
  }
 }
 if(!active)i.keys.clear();
 const ownBlue=blueFor(f);if(ownBlue&&ownBlue.phase!=='hold'&&headPos(other(f)).distanceTo(ownBlue.p)<4)anchorBlue(ownBlue);
 if(chargeFor(f,2)&&ownBlue?.phase==='hold'&&f.character==='gojo'){const d=ownBlue.p.clone().sub(headPos(f));i.yaw=Math.atan2(-d.x,-d.z);i.pitch=clamp(Math.atan2(-d.y,Math.hypot(d.x,d.z)),-1.1,.85);}
 for(const ch of [...chargesFor(f)])if(ch.t>=(ch.aiRelease??ch.max*cfg.charge))releaseCharge(ch.kind,f);
 updateControlled(f,dt);
}
function clashBackdropKind(){if(clash?.participants.some(id=>actorById(id)?.character==='mahito'))return 'mahito-clash';if(clash?.participants.some(id=>actorById(id)?.character==='naruto'))return 'mindscape-clash';return new Set(clash?.participants.map(id=>actorById(id)?.character)).size===1?actorById(clash.participants[0]).character:'clash';}
function syncClashScores(){if(!clash)return;clash.p=clash.scores[player.id]||0;clash.e=Math.max(0,...clash.participants.filter(id=>id!==player.id).map(id=>clash.scores[id]||0));}
function castDomain(f,force=false){
 if(f.character==='spiderman'){if(f===player)toast('Spider-Man has no Domain Expansion',1.5);return false;}
 if(techniqueBurnedOut(f,true))return false;
 if(narutoBusy(f)||worldCutBusy(f)||mahitoBusy(f))return;
 if(phase!=='play'||f.hp<=0||f.stun>0||f.ragdollT>0||(f.attackIsLight&&f.attack>.08)||domain||castFor(f))return;
 if(clash&&(clash.joinRemaining<=0||clash.participants.includes(f.id)||!insideEnclosure(f)))return;
 const rival=bodies.find(b=>b!==f&&castFor(b));if(rival&&headPos(f).distanceTo(castFor(rival).origin.clone().add(V(0,1.45,0)))>=DOMAIN_ENCLOSURE.radius){if(f===player)toast('Outside the forming domain · wait for this expansion to end');return;}
 if(!force&&!spendUltimate(f)){if(f===player)toast('Build ultimate by dealing/taking damage, or use the clash drill');return;}
 beginCastVoice(f);cancelCharge(f);f.block=false;showDomainCutout(f);
 if(clash){joinClash(f);return;}
 if(rival&&castFor(rival).t<=1.5){beginClash([rival,f],castFor(rival));return;}
 setCast(f,{id:f.castVoiceId,t:0,origin:f.pos.clone()});f.domainCD=25;announce(kit(f).short+' · DOMAIN EXPANSION',kit(f).domain,1.5);sfx('domain',f.pos);cinematicShot(f,'domain',.65);
}
function joinClash(f){
 if(!clash||clash.participants.includes(f.id))return;clash.participants.push(f.id);clash.scores[f.id]=0;setCast(f,null);cancelCharge(f);f.energy=Math.max(f.energy,70);f.stun=0;syncClashScores();showClashCutouts();if(domainVisual.userData.kind&&(domainVisual.userData.kind!==clashBackdropKind()||clashBackdropKind()==='mindscape-clash'))domainBackdrop(clashBackdropKind(),clash.origin,clash.axis);announce(clash.participants.length+'-WAY DOMAIN CLASH','LAND HITS TO CLAIM THE DOMAIN',1.8);
}
function beginClash(fighters=[player,enemy],firstCast=null){
 const origin=(firstCast?.origin||fighters[0].pos.clone().lerp(fighters[1].pos,.5)).clone();
 clash={id:++techniqueSerial,participants:[],scores:{},p:0,e:0,t:0,joinRemaining:Math.max(0,1.5-(firstCast?.t||0)),origin,axis:aimFor(fighters[0]).setY(0).normalize(),capturedIds:bodies.filter(f=>f.hp>0&&headPos(f).distanceTo(origin.clone().add(V(0,1.45,0)))<DOMAIN_ENCLOSURE.radius).map(f=>f.id)};
 for(const f of fighters)joinClash(f);domainBackdrop(clashBackdropKind(),origin,clash.axis);flashIt(.4);shakeIt(.5);$('clashUI').classList.remove('hidden');toast('Clash: first participant to land 12 attack points wins.',4);
}
function activateDomain(owner){
 const casting=castFor(owner),oldClash=clash,origin=(oldClash?.origin||casting?.origin||owner.pos).clone(),capturedIds=oldClash?.capturedIds||bodies.filter(f=>f.hp>0&&headPos(f).distanceTo(origin.clone().add(V(0,1.45,0)))<DOMAIN_ENCLOSURE.radius).map(f=>f.id);
 for(const f of bodies)setCast(f,null);sound.setClash(false);domain={id:++techniqueSerial,owner,t:0,pulse:0,terrainPulse:0,captured:capturedIds.some(id=>id!==owner.id),capturedIds,origin,axis:oldClash?.axis.clone()||aimFor(owner).setY(0).normalize()};clash=null;if(oldClash)for(const id of oldClash.participants)if(id!==owner.id)beginDomainBurnout(actorById(id));mindscapeClashEnding(oldClash,owner);
 for(const f of bodies)constrainBarrier(f,f.pos,f.pos,f.vel);$('clashUI').classList.add('hidden');domainBackdrop(owner.character,origin,domain.axis);announce('BARRIER SEALED · '+capturedIds.filter(id=>id!==owner.id).length+' OPPONENTS CAUGHT',kit(owner).domain,2);shock(headPos(owner),fighterColor(owner),DOMAIN_ENCLOSURE.radius,1);flashIt(.5);
}
function updateRosterHUD(){updateOpponentHealthBars();
 const alive=bodies.filter(f=>f.hp>0),target=other(player);$('ename').textContent=target.id.toUpperCase()+' · '+kit(target).short;$('etitle').textContent=target.hp<=0?'ELIMINATED':target.bot?'AI · '+target.difficulty.toUpperCase():'PLAYER';
 $('rosterStatus').textContent=(player.hp<=0?'ELIMINATED · ':'')+alive.length+' / '+bodies.length+' FIGHTERS ALIVE';
 $('rosterList').textContent=bodies.map(f=>f.id.toUpperCase()+' '+kit(f).short+' '+(f.hp>0?Math.ceil(f.hp)+' HP':'OUT')).join('   ·   ');
 if(clash){const scoreHost=$('clashScores');if(scoreHost.dataset.ids!==clash.participants.join(',')){scoreHost.dataset.ids=clash.participants.join(',');scoreHost.replaceChildren();for(const id of clash.participants){const row=document.createElement('label'),name=document.createElement('span'),bar=document.createElement('progress');name.textContent=id.toUpperCase()+' '+kit(actorById(id)).short;bar.max=12;row.append(name,bar);scoreHost.append(row);}}clash.participants.forEach((id,i)=>{scoreHost.children[i].children[1].value=clash.scores[id]||0;});syncClashScores();$('clashPlayer').style.width=clash.p/12*50+'%';$('clashEnemy').style.width=clash.e/12*50+'%';$('clashText').textContent=clash.participants.map(id=>id.toUpperCase()+': '+Math.floor((clash.scores[id]||0)/12*100)+'%').join(' · ');}
}
function saveMatchSetup(){try{localStorage.setItem('limitless.match.v1',JSON.stringify(matchSetup));}catch{}}
function refreshBotOptions(){
 $('aiCount').value=String(matchSetup.bots.length);$('aiDifficulty').value=matchSetup.difficulty;const list=$('aiRoster');list.replaceChildren();matchSetup.bots.forEach((character,i)=>{const label=document.createElement('label');label.textContent='AI '+(i+1);const select=document.createElement('select');for(const key of Object.keys(KITS)){const option=document.createElement('option');option.value=key;option.textContent=KITS[key].short;select.append(option);}select.value=character;select.onchange=()=>{matchSetup.bots[i]=select.value;saveMatchSetup();};label.append(select);list.append(label);});
 $('difficultyNote').textContent=matchSetup.difficulty==='impossible'?'IMPOSSIBLE: AI ignores human damage and regenerates resources. AI still fights other AI.':'All fighters fight each other. Last fighter standing wins.';
}
