// Domain contact commits on the host. Pose/VFX are local, driven by replicated age.
const MAHITO_SOUL={duration:1.18,linger:.7,blend:.12,stretch:2.15,swell:1.9,twist:1.45,ivory:0xf2eedf,ink:0x25202f,burst:0xd9baff};
const mahitoSouls=[];
function soulExecutionFor(f){return mahitoSouls.find(e=>e.target===f.id)||null;}
function soulExecutionPending(f){const e=soulExecutionFor(f);return !!e&&!e.popped;}
function beginMahitoTransfiguration(attacker,target){
 if(soulExecutionFor(target))return false;
 cancelCharge(target);setCast(target,null);stopCastVoice(target);interruptMahito(target);interruptNaruto(target);cancelNarutoMobility(target);interruptWorldCut(target);
 target.attack=target.dodge=target.ragdollT=target.recovery=0;target.block=target.flying=false;target.vel.set(0,0,0);target.stun=MAHITO_SOUL.duration+.1;
 mahitoSouls.push({id:++techniqueSerial,owner:attacker.id,target:target.id,t:0,p:target.pos.clone(),popped:false});
 hitStop=.05;sfx('hit',target.pos,.7);if(target===player)toast('SOUL TRANSFIGURATION',MAHITO_SOUL.duration);return true;
}
function updateMahitoSouls(dt){
 for(const e of mahitoSouls){if(e.popped){e.t=Math.min(MAHITO_SOUL.duration+MAHITO_SOUL.linger,e.t+dt);continue;}
  const f=actorById(e.target),owner=actorById(e.owner);if(!f||!owner)continue;
  e.t=Math.min(MAHITO_SOUL.duration,e.t+dt);f.pos.copy(e.p);f.vel.set(0,0,0);f.stun=Math.max(f.stun,MAHITO_SOUL.duration-e.t+.1);
  if(e.t>=MAHITO_SOUL.duration){e.popped=true;const damage=f.hp;f.hp=0;f.damageTaken+=damage;owner.score+=damage;owner.ult=clamp(owner.ult+damage*BALANCE.ultDeal,0,100);f.ult=clamp(f.ult+damage*BALANCE.ultTake,0,100);eliminateFighter(f,owner,true);}
 }
}
function cancelPendingMahitoSouls(){for(let i=mahitoSouls.length-1;i>=0;i--)if(!mahitoSouls[i].popped){const f=actorById(mahitoSouls[i].target);if(f){restoreMahitoSoulPose(f);f.stun=Math.min(f.stun,.2);}mahitoSouls.splice(i,1);}}
function packMahitoSouls(){return mahitoSouls.map(e=>({id:e.id,owner:e.owner,target:e.target,t:e.t,p:vec(e.p),popped:e.popped}));}
function validMahitoSouls(list,ids){return Array.isArray(list)&&list.length<=MAX_FIGHTERS&&new Set(list.map(e=>e?.target)).size===list.length&&list.every(e=>e&&Number.isSafeInteger(e.id)&&ids.has(e.owner)&&actorById(e.owner)?.character==='mahito'&&ids.has(e.target)&&e.owner!==e.target&&validVector(e.p)&&Number.isFinite(e.t)&&e.t>=0&&e.t<=MAHITO_SOUL.duration+MAHITO_SOUL.linger+.001&&typeof e.popped==='boolean'&&(e.popped?e.t>=MAHITO_SOUL.duration:e.t<MAHITO_SOUL.duration));}
function receiveMahitoSouls(list){
 for(let i=mahitoSouls.length-1;i>=0;i--)if(!list.some(e=>e.id===mahitoSouls[i].id)){const f=actorById(mahitoSouls[i].target);if(f)restoreMahitoSoulPose(f);mahitoSouls.splice(i,1);}
 for(const e of list){let local=mahitoSouls.find(s=>s.id===e.id);if(!local){local={...e,p:V(...e.p)};mahitoSouls.push(local);}else{local.t=e.t;local.popped=e.popped;local.p.fromArray(e.p);}}
}
function restoreMahitoSoulPose(f){const r=f.mahitoSoulPose;if(!r?.applied)return;for(const a of r.parts){a.o.position.copy(a.p);a.o.quaternion.copy(a.q);a.o.scale.copy(a.s);}r.applied=false;}
function mahitoSoulPoseCache(f){
 if(f.mahitoSoulPose?.body===f.body)return f.mahitoSoulPose;
 const nodes=[f.body,f.headGroup,...f.limbs.flatMap(l=>[l.arm,l.elbow]),...f.legs,...f.knees];
 return f.mahitoSoulPose={body:f.body,applied:false,seen:0,parts:nodes.filter(Boolean).map(o=>({o,p:V(),q:new THREE.Quaternion(),s:V()}))};
}
function applyMahitoSoulPose(f){
 const e=soulExecutionFor(f);if(!e)return;const c=MAHITO_SOUL,r=mahitoSoulPoseCache(f),guest=mode==='online'&&net?.role==='guest',t=e.popped?e.t:Math.min(c.duration-.001,e.t+(guest?Math.min(.1,narutoReplicaAge):0));
 if(e.popped){f.root.visible=f.shadow.visible=false;if(r.seen!==e.id){r.seen=e.id;mahitoScratch.a.copy(e.p).y+=1.5;narutoEmit(mahitoScratch.a,c.ivory,65,.6,10,.18);narutoEmit(mahitoScratch.a,c.ink,30,.65,5,1.0,true);narutoEmit(mahitoScratch.a,c.burst,24,.5,13,.12);narutoFX('impact',mahitoScratch.a,1.65,null,false);shakeIt(.32);sfx('burst',e.p,.8);}return;}
 for(const a of r.parts){a.p.copy(a.o.position);a.q.copy(a.o.quaternion);a.s.copy(a.o.scale);}r.applied=true;
 const entry=narutoEase(t/c.blend),q=t/c.duration,stretch=narutoEase((q-.12)/.3)*(1-narutoEase((q-.55)/.24)),inflate=narutoEase((q-.64)/.29),snap=narutoEase((q-.93)/.07),wave=Math.sin(q*Math.PI*7)*Math.sin(q*Math.PI)*entry;
 f.body.scale.multiply(mahitoScratch.a.set(1-.38*stretch+c.swell*inflate,1+(c.stretch-1)*stretch-.45*inflate,1-.3*stretch+1.35*inflate).multiplyScalar(1-.85*snap));f.body.rotation.y+=wave*c.twist;f.body.rotation.z+=wave*.32;f.body.position.y+=entry*(.28+.35*Math.sin(q*Math.PI));
 f.headGroup.scale.multiply(mahitoScratch.a.set(1+.85*inflate+.22*wave,1+.5*stretch,1+.65*inflate));f.headGroup.rotation.z-=wave*.75;
 for(let i=0;i<f.limbs.length;i++){const l=f.limbs[i],side=i%2?1:-1,pulse=Math.sin(q*18+i*1.7)*entry;l.arm.rotation.z+=side*(.6+1.3*stretch)*entry;l.arm.rotation.x+=pulse*1.05;l.arm.scale.y*=1+stretch*(i%2?.65:1.3);l.elbow.rotation.x+=pulse*.8;l.elbow.scale.x*=1+inflate*.6;}
 for(let i=0;i<f.legs.length;i++){f.legs[i].rotation.z+=(i?1:-1)*(.35*entry+.4*wave);f.knees[i].rotation.x+=Math.abs(wave)*1.2;f.legs[i].scale.y*=1+stretch*(i?.5:-.25);}
}
function resetMahitoSouls(){for(const f of actorPool){restoreMahitoSoulPose(f);f.mahitoSoulPose=null;}mahitoSouls.length=0;}
