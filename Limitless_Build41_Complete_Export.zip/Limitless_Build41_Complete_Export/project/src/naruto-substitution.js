// Visual-only substitution: triggered by an avoided incoming hit, once per chakra dodge.
const NARUTO_SUBSTITUTION={pool:6,life:.95,vanish:.09,poofAt:.78,smokeRadius:.9};
let narutoSubstitutions=null;
function ensureNarutoSubstitutions(){
 if(narutoSubstitutions)return narutoSubstitutions;
 const bark=new THREE.MeshStandardMaterial({color:0x795037,roughness:.96}),end=new THREE.MeshStandardMaterial({color:0xc49761,roughness:.9}),dark=new THREE.MeshBasicMaterial({color:0x49301e});
 const cylinder=new THREE.CylinderGeometry(.27,.3,1.65,12),ring=new THREE.TorusGeometry(1,.025,3,24),slots=[];
 for(let i=0;i<NARUTO_SUBSTITUTION.pool;i++){
  const g=new THREE.Group();g.name='substitution-log';g.visible=false;scene.add(g);mesh(cylinder,[bark,end,end],g);
  for(const side of [-1,1])for(let n=1;n<=3;n++){const r=mesh(ring,dark,g,V(0,side*.828,0),V(n*.069,n*.069,n*.069));r.rotation.x=Math.PI/2;}
  for(let n=0;n<7;n++){const a=n/7*Math.PI*2;mesh(geo.box,dark,g,V(Math.cos(a)*.28,0,Math.sin(a)*.28),V(.012,1.3,.025)).rotation.y=-a;}
  const stub=mesh(geo.cylinder,bark,g,V(.29,.19,0),V(.11,.48,.11));stub.rotation.z=-.95;
  slots.push({g,t:99,body:null,poof:false,pos:V(),floor:0});
 }
 return narutoSubstitutions={slots,cursor:0};
}
function showNarutoSubstitution(f,pos){
 const pool=ensureNarutoSubstitutions(),s=pool.slots[pool.cursor++%pool.slots.length];if(s.body)s.body.visible=true;
 s.t=0;s.poof=false;s.pos.copy(pos);s.g.position.copy(pos);s.g.rotation.set(.12,f.root.rotation.y,.16);s.g.scale.setScalar(1);s.g.visible=true;s.floor=groundHeight(pos,pos.y)+.32;s.body=f.body;s.body.visible=false;
 narutoFX('smoke',pos,NARUTO_SUBSTITUTION.smokeRadius,null,false);
}
function triggerNarutoSubstitution(f){
 if(f.substitutionUsed)return;f.substitutionUsed=true;
 const pos=headPos(f);showNarutoSubstitution(f,pos);netFX('substitution',[f.id,pos.toArray()]);
}
function updateNarutoSubstitutions(dt){
 if(!narutoSubstitutions)return;
 if(!['play','pause','finish'].includes(phase)){clearNarutoSubstitutions();return;}
 if(phase==='pause')dt=0;
 for(const s of narutoSubstitutions.slots){if(!s.g.visible)continue;s.t+=dt;
  if(s.body&&s.t>=NARUTO_SUBSTITUTION.vanish){s.body.visible=true;s.body=null;}
  s.g.position.y=Math.max(s.floor,s.pos.y+.9*s.t-5*s.t*s.t);s.g.rotation.z=.16+narutoEase(s.t/.6)*1.4;s.g.rotation.x=.12+Math.sin(s.t*5)*.22;
  s.g.scale.setScalar(1-narutoEase((s.t-NARUTO_SUBSTITUTION.poofAt)/(NARUTO_SUBSTITUTION.life-NARUTO_SUBSTITUTION.poofAt)));
  if(!s.poof&&s.t>=NARUTO_SUBSTITUTION.poofAt){s.poof=true;narutoFX('smoke',s.g.position,.65,null,false);}
  if(s.t>=NARUTO_SUBSTITUTION.life)s.g.visible=false;
 }
}
function clearNarutoSubstitutions(){if(narutoSubstitutions)for(const s of narutoSubstitutions.slots){s.g.visible=false;if(s.body)s.body.visible=true;s.body=null;}}
