// Spider-Man uses existing resources, hurt(), aimed hit tests, city collision and input edges.
const SPIDER={color:0xf04b54,web:0xe8f7ff,blend:.09,
 costs:[0,10,14,18,4],cooldowns:[0,2.8,4.5,6,.25],range:38,aimRadius:1.35,
 yankDamage:22,launchDamage:36,launchSpeed:14,zipSpeed:66,airLink:2.8,
 comboDamage:[18,22,26,38],comboTimes:[.24,.47,.73,1.04],comboRange:3.65,
 slamDamage:55,cocoonTime:4,cocoonRadius:13,cocoonSpeed:42,throwSpeed:57,collisionDamage:85,
 swingRange:125,swingMinRange:4,viewLeash:36,swingSpeed:68,swingAcceleration:43,swingReel:44,swingDrain:4,swingDuration:9,swingFov:14,releaseCarry:1.6};
const SPIDER_SWING={step:1/120,launchTime:.24,launchForward:32,launchUp:28,catchStart:.09,catchTime:.28,
 steerBlend:.18,turnSpeed:4.8,reelBlend:.18,spring:68,damping:16,maxTension:210,gravity:27,
 minRope:7,clearance:5,poseBlend:.11,facingBlend:.13,releasePose:.60,bank:.48};
const SPIDER_SLIDE={minReach:2,acceleration:58,brake:95,steer:24,response:.16,sideDrag:1.6,
 arrival:1.6,settle:9,contactGap:.18,blend:.12,dustInterval:.075,dustColor:0xb6b2a6};
const SPIDER_KIT={name:'SPIDER-MAN',short:'SPIDER-MAN',title:'FRIENDLY NEIGHBORHOOD · WEB SLINGER',domain:'NO DOMAIN',color:SPIDER.color,
 names:['','WEB YANK','SPIDER COMBO','WEB COCOON','WEB SWING'],
 hints:['','Pull → rising kick · airborne target: zip chase','Punch → hook → elbow → spinning kick · air: slam','Tap to catch · aim to steer · tap again to throw','Hold to swing or slide · let go to release'],
 tags:['','LAUNCH / CHASE','MARTIAL ARTS','AIM / SLING','MOMENTUM'],colors:['','#d9f4ff','#ff737b','#d9f4ff','#82bcff']};
const spiderThrows=[];let spiderThrowReplica=[];
const spiderScratch={a:V(),b:V(),c:V(),d:V(),ray:new THREE.Raycaster(),hits:[],surfaces:[],box:new THREE.Box3(),point:V(),turn:new THREE.Quaternion(),blend:new THREE.Quaternion()};
const spiderAimScratch={origin:V(),direction:V(),head:V(),toward:V(),point:V(),normal:V(),box:new THREE.Box3(),padding:V(6,6,6),ray:new THREE.Raycaster(),hits:[],result:{anchor:V(),piece:null,distance:0,ground:false,up:false}};
const spiderGroundCache=new Map();
function spiderSurfaceVisible(object){for(let o=object;o;o=o.parent)if(!o.visible)return false;return true;}
function spiderGroundMeshes(){
 if(spiderGroundCache.has(activeMap))return spiderGroundCache.get(activeMap);
 const list=[floor],pieceMeshes=new Set(pieces.map(p=>p.m)),bounds=new THREE.Box3();
 // Cache only low, static paving. Destructible surfaces stay in the existing piece query.
 function visit(o){if(pieceMeshes.has(o))return;if(o.isMesh){o.updateWorldMatrix(true,false);bounds.setFromObject(o);if(bounds.min.y>=-.2&&bounds.max.y<=.35)list.push(o);return;}for(const child of o.children)visit(child);}
 for(const root of mapCache.get(activeMap).objects)visit(root);spiderGroundCache.set(activeMap,list);return list;
}
// Capture the actual rendered view on the input edge, including shoulder offset, zoom and camera sway.
function captureSpiderView(){const s=spiderAimScratch;camera.updateMatrixWorld(true);camera.getWorldPosition(s.origin);camera.getWorldDirection(s.direction);return {origin:s.origin.toArray(),direction:s.direction.toArray()};}
function spiderSurfaceRay(origin,direction,range){
 const s=spiderAimScratch,r=s.result;r.piece=null;r.ground=r.up=false;r.distance=Math.min(range,barrierRayDistance(origin,direction,range));s.ray.set(origin,direction);s.ray.near=0;s.ray.far=r.distance;
 for(const object of spiderGroundMeshes()){if(!spiderSurfaceVisible(object))continue;object.updateWorldMatrix(true,false);s.hits.length=0;s.ray.intersectObject(object,false,s.hits);for(const hit of s.hits){if(hit.distance>=r.distance||Math.hypot(hit.point.x,hit.point.z)>WORLD.radius-1)continue;r.distance=hit.distance;r.anchor.copy(hit.point);r.ground=r.up=true;s.ray.far=hit.distance;break;}}
 for(const p of pieces){if(!arenaPieceActive(p)||(!p.solid&&!p.platform&&p.pos.y+p.size.y*.5>.35)||!p.m?.visible)continue;
  // Broad phase includes roof tanks, trim and window overhangs. The final hit uses rendered triangles.
  s.box.min.copy(p.pos).addScaledVector(p.size,-.5).sub(s.padding);s.box.max.copy(p.pos).addScaledVector(p.size,.5).add(s.padding);
  if(!s.ray.ray.intersectBox(s.box,s.point)||origin.distanceTo(s.point)>r.distance&&!s.box.containsPoint(origin))continue;
  p.m.updateWorldMatrix(true,true);s.hits.length=0;s.ray.intersectObject(p.m,true,s.hits);
  for(const hit of s.hits){let visible=true;for(let o=hit.object;o&&o!==p.m.parent;o=o.parent)if(!o.visible){visible=false;break;}
   if(visible&&hit.distance<r.distance){r.distance=hit.distance;r.anchor.copy(hit.point);r.piece=p;r.ground=false;r.up=!!hit.face&&s.normal.copy(hit.face.normal).transformDirection(hit.object.matrixWorld).y>.6;s.ray.far=hit.distance;break;}}
 }
 return r.piece||r.ground?r:null;
}
function spiderState(f){return f.spider||(f.spider={action:null,cd:[0,0,0,0,0],link:null,linkTime:0,momentum:0,releaseTime:0,pose:narutoPoseTemplate(),startPose:narutoPoseTemplate(),poseWeight:0});}
function spiderBusy(f){return f.character==='spiderman'&&!!f.spider?.action;}
function spiderHeld(f){for(const o of bodies){const a=o.spider?.action;if(a?.bound&&a.target===f&&(a.kind===3||a.kind===1&&a.mode==='yank'&&a.t<.72))return true;}return false;}
function spiderCanAct(f){return phase==='play'&&f.hp>0&&f.stun<=0&&f.ragdollT<=0&&f.recovery<=0&&f.dodge<=0&&!castFor(f)&&!chargeFor(f)&&!trappedByVoid(f)&&!techniqueBurnedOut(f,true);}
function spiderRay(origin,dir,range,margin=0){
 const s=spiderScratch;let distance=barrierRayDistance(origin,dir,range),piece=null;s.ray.set(origin,dir);s.box.min.set(0,0,0);
 for(const p of pieces){if(!arenaPieceActive(p)||!p.solid)continue;s.box.min.copy(p.pos).addScaledVector(p.size,-.5).addScalar(-margin);s.box.max.copy(p.pos).addScaledVector(p.size,.5).addScalar(margin);if(s.ray.ray.intersectBox(s.box,s.point)){const d=origin.distanceTo(s.point);if(d<distance&&d<=range){distance=d;piece=p;}}}return {distance:Math.min(distance,range),piece};
}
function spiderTarget(f,range=SPIDER.range){
 const origin=headPos(f),dir=aimFor(f),wall=spiderRay(origin,dir,range).distance;let target=null,near=wall;
 for(const b of opponents(f)){if(barrierSeparates(f,b)||spiderHeld(b))continue;const d=raySphere(origin,dir,headPos(b),SPIDER.aimRadius);if(d<near){target=b;near=d;}}return target;
}
function spiderMoveTo(f,destination){
 const from=f.pos.clone(),delta=destination.clone().sub(from),len=delta.length();if(len<.00001)return false;delta.divideScalar(len);
 const hit=spiderRay(from.clone().add(V(0,1.15,0)),delta,len,.46);f.pos.addScaledVector(delta,Math.max(0,Math.min(len,hit.distance-.025)));f.pos.y=clamp(f.pos.y,.13,WORLD.ceiling-2);resolveDistrictCollision(f,from);constrainBarrier(f,f.pos,from,f.vel);const r=Math.hypot(f.pos.x,f.pos.z);if(r>WORLD.radius-1){f.pos.x*=(WORLD.radius-1)/r;f.pos.z*=(WORLD.radius-1)/r;}f.grounded=false;return hit.distance<len-.001;
}
function stopSpider(f,release=false){const s=f.spider;if(!s)return;const a=s.action;if(a?.bound&&a.target){a.target.stun=Math.min(a.target.stun,.18);a.target.comboLock=0;}if(a?.kind===4&&release){s.momentum=SPIDER.releaseCarry;s.startPose.set(s.pose);s.releaseTime=SPIDER_SWING.releasePose;f.jumpPose=.3;}else if(!release)s.releaseTime=0;s.action=null;}
function interruptSpider(f){stopSpider(f);if(f.spider){f.spider.link=null;f.spider.linkTime=f.spider.momentum=0;}for(const owner of bodies){if(owner===f)continue;const a=owner.spider?.action;if(a?.target===f&&a.bound){a.bound=false;stopSpider(owner);}}}
function spiderHit(f,b,damage,knock=V(),kind='special'){
 if(!b||b.hp<=0||barrierSeparates(f,b))return false;const hit=hurt(b,damage,f,kind,knock,1);if(hit){narutoFX('impact',headPos(b),.55);hitStop=Math.max(hitStop,.045);shakeIt(.13);sfx('hit',b.pos,.7);}return hit;
}
function spiderBind(f,a){const b=a.target;if(!b||b.hp<=0||spiderHeld(b)||barrierSeparates(f,b)||headPos(f).distanceTo(headPos(b))>SPIDER.range+3)return false;
 if(spiderRay(headPos(f),headPos(b).sub(headPos(f)).normalize(),headPos(f).distanceTo(headPos(b))-.7).piece)return false;
 if(!spiderHit(f,b,a.kind===1?SPIDER.yankDamage:8)||b.hp<=0||phase!=='play')return false;
 for(let i=spiderThrows.length-1;i>=0;i--)if(spiderThrows[i].target===b)spiderThrows.splice(i,1);a.bound=true;b.flying=false;b.vel.set(0,0,0);b.ragdollT=b.recovery=0;b.block=false;b.stun=.22;b.attack=0;cancelCharge(b);return true;}
function startSpiderMove(f,kind,webView=null){
 if(f.character!=='spiderman'||kind<1||kind>4||!Number.isInteger(kind))return false;const s=spiderState(f),old=s.action;
 if(old?.kind===4&&kind===4)return true;
 if(old?.kind===3&&old.bound&&kind===3){throwSpiderCocoon(f);return true;}
 if(!spiderCanAct(f)||old||f.attack>.08||soulLocked(f,kind,true))return false;
 const linked=kind===1&&s.linkTime>0&&s.link?.hp>0&&s.link.pos.y>1;
 if(s.cd[kind]>0&&!linked)return false;if(f.energy<SPIDER.costs[kind]){if(f===player)toast('Need web energy · hold Charge to refill');return false;}
 let target=kind===4?null:linked?s.link:spiderTarget(f,kind===2?7:SPIDER.range),anchor=null,piece=null,ground=false,slide=false;
 if(kind===4){const hit=findSpiderAnchor(f,webView);if(!hit){if(f===player)toast('No web anchor · aim the crosshair at a surface within '+SPIDER.swingRange+'m',1.8);return false;}anchor=hit.anchor.clone();piece=hit.piece;ground=hit.ground;slide=f.grounded&&hit.up&&anchor.y<=f.pos.y+.6;}
 if(kind!==4&&!target){if(f===player)toast('Aim at an opponent in web range',1);return false;}
 cancelNarutoMobility(f);if(f.narutoMobility)f.narutoMobility.wallExit=0;f.block=false;f.attackIsLight=false;f.energy-=SPIDER.costs[kind];s.cd[kind]=SPIDER.cooldowns[kind];
 const mode=kind===1&&(linked||target.pos.y>f.pos.y+2)?'zip':kind===1?'yank':kind===2&&!f.grounded?'slam':'normal';
 const a={kind,mode,id:++techniqueSerial,t:0,target,anchor,piece:piece?pieces.indexOf(piece):-1,bound:false,hit:0,dir:aimFor(f),origin:f.pos.clone(),targetOrigin:target?.pos.clone()||V(),guide:target?.pos.clone()||V(),aim:aimFor(f),rope:anchor?anchor.distanceTo(headPos(f)):0,contact:false};s.action=a;s.releaseTime=0;
 if(kind!==4)f.vel.multiplyScalar(.18);else{
  const heading=aimFor(f).setY(0).normalize(),speed=Math.hypot(f.vel.x,f.vel.z);
  a.ground=ground;a.sliding=slide;a.launch=slide?V():heading.clone().multiplyScalar(Math.max(0,SPIDER_SWING.launchForward-speed));a.launch.y=f.grounded&&!slide?Math.max(0,SPIDER_SWING.launchUp-f.vel.y):0;
  a.steerYaw=speed>8?Math.atan2(f.vel.x,f.vel.z):Math.atan2(heading.x,heading.z);a.reelSpeed=0;a.bank=a.load=0;
  a.minRope=ground?SPIDER_SLIDE.arrival:Math.min(a.rope*.82,Math.max(SPIDER_SWING.minRope,a.anchor.y-SPIDER_SWING.clearance));f.grounded=slide;if(slide)f.vel.y=0;s.momentum=0;
 }
 if(mode==='zip'){for(let i=spiderThrows.length-1;i>=0;i--)if(spiderThrows[i].target===target)spiderThrows.splice(i,1);target.ragdollT=target.recovery=0;target.vel.multiplyScalar(.2);target.stun=Math.max(target.stun,.75);}
 sfx(kind===2?'light':'dodge',f.pos,.6);return true;
}
function spiderAirLink(f,b){const s=spiderState(f);s.link=b;s.linkTime=SPIDER.airLink;f.grounded=b.grounded=false;b.ragdollT=b.recovery=0;b.stun=Math.max(b.stun,.65);b.comboLock=.65;f.vel.set(0,2,0);b.vel.set(0,2,0);f.attack=f.cooldown=0;}
function throwSpiderCocoon(f,up=false){
 const s=f.spider,a=s?.action;if(!a||a.kind!==3||!a.bound)return false;const b=a.target,dir=aimFor(f);if(up)dir.y=Math.max(.8,dir.y);dir.normalize();a.bound=false;
 b.stun=.5;b.grounded=false;b.ragdollT=b.recovery=0;b.vel.copy(dir).multiplyScalar(SPIDER.throwSpeed);if(dir.y>-.25)b.vel.y=Math.max(b.vel.y,8);
 spiderThrows.push({owner:f,target:b,t:0,dir:dir.clone(),velocity:b.vel.clone(),old:b.pos.clone()});s.link=b;s.linkTime=SPIDER.airLink;stopSpider(f);f.spiderThrowPose=.42;sfx('dodge',b.pos,.8);return true;
}
function spiderSlam(f,b){
 if(!spiderHit(f,b,SPIDER.slamDamage))return;b.stun=.6;b.ragdollT=b.recovery=0;b.vel.set(aimFor(f).x*9,-SPIDER.throwSpeed,aimFor(f).z*9);b.grounded=false;
 spiderThrows.push({owner:f,target:b,t:0,dir:V(0,-1,0),velocity:b.vel.clone(),old:b.pos.clone(),slam:true});f.vel.y=4;spiderState(f).linkTime=0;
}
function findSpiderAnchor(f,webView=null){
 const s=spiderAimScratch;s.head.copy(f.pos);s.head.y+=1.45;
 if(webView){if(!window.ArenaNet.validWebView(webView))return null;s.origin.fromArray(webView.origin);s.direction.fromArray(webView.direction).normalize();if(s.origin.distanceToSquared(s.head)>SPIDER.viewLeash*SPIDER.viewLeash)return null;}
 else if(f===player){camera.updateMatrixWorld(true);camera.getWorldPosition(s.origin);camera.getWorldDirection(s.direction);}
 else if(f.bot){s.origin.copy(s.head);s.direction.copy(aimFor(f));}
 else return null;
 const hit=spiderSurfaceRay(s.origin,s.direction,SPIDER.swingRange+SPIDER.viewLeash);if(!hit)return null;
 s.toward.copy(hit.anchor).sub(s.head);const reach=s.toward.length();if(reach<(hit.up?SPIDER_SLIDE.minReach:SPIDER.swingMinRange)||reach>SPIDER.swingRange)return null;s.toward.divideScalar(reach);
 // A shoulder camera can see around an edge that the firing hand cannot reach.
 const clearDistance=reach-.2;if(barrierRayDistance(s.head,s.toward,clearDistance)<clearDistance||spiderRay(s.head,s.toward,clearDistance).piece)return null;
 hit.distance=reach;return hit;
}
function updateSpiderSlide(f,a,dt,t){
 const s=spiderScratch,c=SPIDER_SLIDE,previousY=f.pos.y,ground=groundHeight(f.pos,previousY+.04);
 if(f.pos.y>ground+c.contactGap){a.sliding=f.grounded=false;return false;}
 f.pos.y=ground;f.vel.y=0;a.launch.set(0,0,0);
 s.a.copy(a.anchor).sub(f.pos).setY(0);const distance=s.a.length();if(distance>.001)s.a.divideScalar(distance);else s.a.set(0,0,0);
 s.b.set(s.a.z,0,-s.a.x);const near=narutoEase((distance-c.arrival)/3),target=Math.min(SPIDER.swingSpeed,Math.sqrt(2*c.brake*Math.max(0,distance-c.arrival))),pull=clamp((target-f.vel.dot(s.a))/c.response,-c.brake,c.acceleration)*narutoEase(t/SPIDER_SWING.launchTime),side=Math.sin(a.steerYaw)*s.b.x+Math.cos(a.steerYaw)*s.b.z;
 f.vel.addScaledVector(s.a,pull*dt);f.vel.addScaledVector(s.b,(side*c.steer*near-f.vel.dot(s.b)*c.sideDrag)*dt);f.vel.multiplyScalar(Math.exp(-c.settle*(1-near)*dt));f.vel.clampLength(0,SPIDER.swingSpeed);a.load=lerp(a.load,clamp(Math.abs(pull)/c.acceleration,0,1),1-Math.exp(-dt/.1));
 s.c.copy(f.pos).addScaledVector(f.vel,dt);const blocked=spiderMoveTo(f,s.c),support=groundHeight(f.pos,previousY+.04);a.sliding=f.grounded=f.pos.y<=support+c.contactGap;if(a.sliding)f.pos.y=support;
 if(blocked){stopSpider(f,true);f.vel.multiplyScalar(.6);}return true;
}
function updateSpiderSwing(f,a,dt){
 const s=spiderScratch,c=SPIDER_SWING;
 if(!a.ground&&!arenaPieceActive(pieces[a.piece])||a.t>SPIDER.swingDuration||f.energy<=0||!f.bot&&!inputFor(f).has('Digit4')){stopSpider(f,true);return;}
 if(dt<=0)return;f.energy=Math.max(0,f.energy-SPIDER.swingDrain*dt);
 const move=moveDirection(f),desired=move.lengthSq()>.01?move:aimFor(f).setY(0),targetYaw=Math.atan2(desired.x,desired.z),steps=Math.max(1,Math.ceil(dt/c.step)),h=dt/steps;
 // Small deterministic steps, damped web tension and eased reeling avoid position snaps.
 for(let i=0;i<steps;i++){
  const t0=a.t-dt+i*h,t1=t0+h,catchWeight=narutoEase((t1-c.catchStart)/c.catchTime),launch=narutoEase(t1/c.launchTime)-narutoEase(t0/c.launchTime);
  const turn=Math.atan2(Math.sin(targetYaw-a.steerYaw),Math.cos(targetYaw-a.steerYaw)),turnStep=clamp(turn*(1-Math.exp(-h/c.steerBlend)),-c.turnSpeed*h,c.turnSpeed*h);
  a.steerYaw+=turnStep;a.bank=lerp(a.bank,turnStep/(h*c.turnSpeed),1-Math.exp(-h/.16));
  if(a.sliding&&updateSpiderSlide(f,a,h,t1)){if(f.spider.action!==a)return;continue;}
  f.vel.addScaledVector(a.launch,launch);
  a.reelSpeed=lerp(a.reelSpeed,Math.min(SPIDER.swingReel,Math.max(0,a.rope-a.minRope)*5)*catchWeight,1-Math.exp(-h/c.reelBlend));
  const reel=Math.min(a.reelSpeed*h,Math.max(0,a.rope-a.minRope));a.rope-=reel;
  s.a.copy(f.pos);s.a.y+=1.45;s.a.sub(a.anchor);const distance=Math.max(.001,s.a.length());s.a.divideScalar(distance);
  // Take up loose web as the launch approaches the anchor; tension still ramps in gradually.
  a.rope=Math.max(a.minRope,Math.min(a.rope,distance+.35));
  s.b.set(Math.sin(a.steerYaw),0,Math.cos(a.steerYaw));s.b.addScaledVector(s.a,-s.b.dot(s.a));if(s.b.lengthSq()>.025)s.b.normalize();else s.b.set(0,0,0);
  f.vel.addScaledVector(s.b,SPIDER.swingAcceleration*h*narutoEase(t1/c.launchTime));f.vel.y-=c.gravity*h;
  const stretch=distance-a.rope,outward=f.vel.dot(s.a),taut=narutoEase((stretch+.5)/1.2),tension=clamp(stretch*c.spring+(outward+reel/h)*c.damping,0,c.maxTension)*taut*catchWeight;
  f.vel.addScaledVector(s.a,-tension*h);f.vel.clampLength(0,SPIDER.swingSpeed);a.load=lerp(a.load,tension/c.maxTension,1-Math.exp(-h/.1));
  const previousY=f.pos.y;s.c.copy(f.pos).addScaledVector(f.vel,h);const blocked=spiderMoveTo(f,s.c),ground=groundHeight(f.pos,previousY),landed=(t1>c.launchTime||a.launch.y<=0)&&f.vel.y<=0&&f.pos.y<=ground+.01;
  if(landed){f.pos.y=ground;f.vel.y=0;f.grounded=a.sliding=true;a.launch.set(0,0,0);a.reelSpeed=0;}else f.grounded=false;
  if(blocked){stopSpider(f,true);f.vel.multiplyScalar(.6);return;}
 }
}
function updateSpider(dt){
 for(const f of bodies){if(f.character!=='spiderman')continue;const s=spiderState(f);for(let i=1;i<5;i++)s.cd[i]=Math.max(0,s.cd[i]-dt);s.linkTime=Math.max(0,s.linkTime-dt);s.momentum=Math.max(0,s.momentum-dt);s.releaseTime=Math.max(0,s.releaseTime-dt);f.spiderThrowPose=Math.max(0,(f.spiderThrowPose||0)-dt);
  let a=s.action;if(!a){if(s.linkTime>0&&s.link?.hp>0&&!f.grounded&&!spiderThrows.some(t=>t.target===s.link)&&f.pos.distanceTo(s.link.pos)<4.5&&f.stun<=0){f.vel.y=Math.max(f.vel.y,-2);if(s.link.comboLock>0)s.link.vel.y=Math.max(s.link.vel.y,-2);}continue;}
  if(!spiderCanAct(f)){stopSpider(f);continue;}a.t+=dt;const b=a.target;
  if(a.kind===4){updateSpiderSwing(f,a,dt);continue;}
  if(!b||b.hp<=0||barrierSeparates(f,b)||f.pos.distanceTo(b.pos)>SPIDER.range+20){stopSpider(f);continue;}
  if(a.kind===1){
   if(a.mode==='zip'){
    if(a.t>.14){const dest=b.pos.clone().addScaledVector(a.dir,-2.05),d=dest.sub(f.pos),len=d.length();if(len>1e-4)spiderMoveTo(f,f.pos.clone().addScaledVector(d.normalize(),Math.min(len,SPIDER.zipSpeed*dt)));f.vel.set(0,0,0);
     if(f.pos.distanceTo(b.pos)<2.65){spiderAirLink(f,b);stopSpider(f);continue;}}
    if(a.t>1.1)stopSpider(f);continue;
   }
   if(!a.contact&&a.t>=.18){a.contact=true;if(!spiderBind(f,a)){stopSpider(f);continue;}a.targetOrigin.copy(b.pos);}
   if(a.bound&&a.t<.65){const end=f.pos.clone().addScaledVector(a.dir.clone().setY(0).normalize(),2.1);spiderMoveTo(b,a.targetOrigin.clone().lerp(end,narutoEase((a.t-.18)/.40)));b.vel.set(0,0,0);b.stun=Math.max(b.stun,.18);}
   if(a.hit===0&&a.t>=.7){a.bound=false;a.hit=1;if(f.pos.distanceTo(b.pos)<3.2&&spiderHit(f,b,SPIDER.launchDamage,V(0,SPIDER.launchSpeed,0))){b.ragdollT=b.recovery=0;b.vel.set(0,SPIDER.launchSpeed,0);b.stun=.7;b.grounded=false;s.link=b;s.linkTime=SPIDER.airLink;}else{stopSpider(f);continue;}}
   if(a.t>=.8){f.grounded=false;const end=b.pos.clone().addScaledVector(a.dir.clone().setY(0).normalize(),-2.1);spiderMoveTo(f,f.pos.clone().lerp(end,1-Math.exp(-12*dt)));f.vel.set(0,3,0);}
   if(a.t>=1.15){spiderAirLink(f,b);stopSpider(f);}
  }
  if(a.kind===2){
   if(a.mode==='slam'){if(a.t>=.34&&a.hit===0){a.hit=1;if(f.pos.distanceTo(b.pos)<4.2)spiderSlam(f,b);}if(a.t>.65)stopSpider(f);continue;}
   if(a.t>.10&&a.t<.25){const d=b.pos.clone().sub(f.pos).setY(0),len=d.length();if(len>2.05)spiderMoveTo(f,f.pos.clone().addScaledVector(d.normalize(),Math.min(len-2.05,27*dt)));}
   while(a.hit<4&&a.t>=SPIDER.comboTimes[a.hit]){const i=a.hit++;if(f.pos.distanceTo(b.pos)<SPIDER.comboRange){const dir=b.pos.clone().sub(f.pos).normalize();if(spiderHit(f,b,SPIDER.comboDamage[i],dir.multiplyScalar(i===3?10:.5))){b.stun=i===3?.3:.31;b.comboLock=i===3?0:.31;if(i<3)b.vel.multiplyScalar(.25);}}}
   if(a.t>1.38)stopSpider(f);
  }
  if(a.kind===3){
   if(!a.contact&&a.t>=.28){a.contact=true;if(!spiderBind(f,a)){stopSpider(f);continue;}a.guide.copy(b.pos);a.aim.copy(aimFor(f));if(f===player)toast('COCOON · aim to sling · tap 3 to throw · Jump to toss up',3);}
   if(a.bound){const desired=aimFor(f);spiderScratch.turn.setFromUnitVectors(a.aim,desired);spiderScratch.blend.identity().slerp(spiderScratch.turn,1-Math.exp(-dt/.13));a.aim.applyQuaternion(spiderScratch.blend).normalize();const end=headPos(f).addScaledVector(a.aim,SPIDER.cocoonRadius);end.y=clamp(end.y-1.45,.13,WORLD.ceiling-3);const delta=end.sub(b.pos),len=delta.length();
    const old=b.pos.clone();if(len>.001)spiderMoveTo(b,b.pos.clone().addScaledVector(delta.normalize(),Math.min(len*(1-Math.exp(-dt/.09)),SPIDER.cocoonSpeed*dt)));const moved=b.pos.distanceTo(old);b.vel.set(0,0,0);b.stun=Math.max(b.stun,.18);
    if((len>2&&moved<SPIDER.cocoonSpeed*dt*.35&&a.t>.7)||(b.pos.y<=.14&&desired.y<-.4&&a.t>.7)){a.bound=false;spiderCollision(f,b,false);stopSpider(f);continue;}
    if(a.t>SPIDER.cocoonTime)throwSpiderCocoon(f);
   }
  }
 }
 for(let i=spiderThrows.length-1;i>=0;i--){const t=spiderThrows[i],b=t.target;t.t+=dt;if(t.t>2.8||b.hp<=0||t.owner.hp<=0||barrierSeparates(t.owner,b)){spiderThrows.splice(i,1);continue;}
  t.old.copy(b.pos);t.velocity.y-=22*dt;const next=b.pos.clone().addScaledVector(t.velocity,dt),hit=spiderMoveTo(b,next);b.vel.copy(t.velocity);b.stun=Math.max(b.stun,.08);
  if(hit||b.pos.y<=.14){spiderCollision(t.owner,b,!!t.slam);spiderThrows.splice(i,1);}
 }
}
function spiderCollision(f,b,slam){spiderHit(f,b,slam?30:SPIDER.collisionDamage);b.vel.set(0,0,0);b.stun=Math.max(b.stun,.45);narutoFX('ground',b.pos,2.2);destroyAt(headPos(b),2.8,80);shakeIt(.3);sfx('launchImpact',b.pos);}
function spiderPhysicsOwned(f){return spiderHeld(f)||spiderThrows.some(t=>t.target===f)||f.spider?.action?.kind===4;}
function resetSpider(){spiderThrows.length=0;spiderThrowReplica=[];for(const f of actorPool){f.spider=null;f.spiderThrowPose=0;}if(spiderVisuals)for(const v of spiderVisuals)v.g.visible=false;}
function packSpider(f){const s=f.spider;if(f.character!=='spiderman')return null;const a=s?.action;return {cd:s?.cd||[0,0,0,0,0],link:s?.link?.id||null,linkTime:s?.linkTime||0,momentum:s?.momentum||0,releaseTime:s?.releaseTime||0,throwPose:f.spiderThrowPose||0,a:a?{id:a.id,kind:a.kind,mode:a.mode,t:a.t,target:a.target?.id||null,bound:a.bound,anchor:a.anchor?vec(a.anchor):null,dir:vec(a.dir),bank:a.bank||0,load:a.load||0,sliding:!!a.sliding}:null};}
function validSpider(s,character,ids){if(character!=='spiderman')return s===null;if(!s||!Array.isArray(s.cd)||s.cd.length!==5||!s.cd.every(n=>Number.isFinite(n)&&n>=0&&n<=6)||![s.linkTime,s.momentum,s.throwPose].every(n=>Number.isFinite(n)&&n>=0&&n<=3)||!Number.isFinite(s.releaseTime)||s.releaseTime<0||s.releaseTime>SPIDER_SWING.releasePose||s.link!==null&&!ids.has(s.link))return false;const a=s.a;return a===null||!!(a&&Number.isSafeInteger(a.id)&&[1,2,3,4].includes(a.kind)&&['normal','yank','zip','slam'].includes(a.mode)&&Number.isFinite(a.t)&&a.t>=0&&a.t<=10&&Number.isFinite(a.bank)&&Math.abs(a.bank)<=1&&Number.isFinite(a.load)&&a.load>=0&&a.load<=1&&typeof a.sliding==='boolean'&&(!a.sliding||a.kind===4)&&typeof a.bound==='boolean'&&(a.target===null||ids.has(a.target))&&validVector(a.dir)&&(a.anchor===null||validVector(a.anchor))&&(a.kind!==4||a.anchor!==null));}
function receiveSpider(f,p){if(!p){f.spider=null;return;}const s=spiderState(f);if(s.action?.kind===4&&!p.a&&p.releaseTime>0)s.startPose.set(s.pose);s.cd=p.cd.slice();s.link=actorById(p.link);s.linkTime=p.linkTime;s.momentum=p.momentum;s.releaseTime=p.releaseTime;f.spiderThrowPose=p.throwPose;s.action=p.a?{...p.a,target:actorById(p.a.target),anchor:p.a.anchor?V(...p.a.anchor):null,dir:V(...p.a.dir)}:null;}
function spiderManual(){return '<p><kbd>1</kbd> Web Yank: aim at a fighter, pull them in, kick them upward and jump after them. Against a higher airborne target, zip yourself to them instead. Continue with light attacks, or use 2 / aim downward and attack to kick down.<br><kbd>2</kbd> Spider Combo: step-in right cross, left hook, elbow and spinning kick. In the air, use a downward heel kick.<br><kbd>3</kbd> Web Cocoon: catch an aimed target. Move your aim to swing them around you for up to 4 seconds. Slam into a wall or aim down into the floor for impact damage. Tap 3 again to throw along your aim; Jump throws upward. Then use 1 to chase and continue an air combo.<br><kbd>4</kbd> Web Swing: put the crosshair on the ground or an intact wall, roof or ledge within 125m, then hold to attach exactly there. The blue crosshair confirms a reachable surface; NO ANCHOR means the shot will not attach or spend energy. Aim at the ground to pull into a slide. Landing during a building swing keeps the web attached and slides along the surface. Keep holding to continue. Steer with aim and movement; let go to release with momentum. Jump releases the web and jumps out of a ground slide. Try Skyline Boroughs. Hidden domain scenery cannot anchor a web.<br>Uses web energy and existing stamina. Hold Charge to refill energy. Spider-Man has no Domain Expansion.</p>';}
function updateSpiderHUD(){
 const reticle=$('reticle'),isSpider=player.character==='spiderman',s=isSpider?spiderState(player):null,show=isSpider&&phase==='play'&&(!s.action||s.action.kind===4)&&!menuOpen&&!cursorFree&&!options.freeOrbit;
 reticle.classList.toggle('web-aim',show);if(show){const attached=s.action?.kind===4,hit=attached?null:findSpiderAnchor(player);reticle.classList.toggle('web-ready',attached||!!hit);reticle.dataset.web=attached?(s.action.sliding?'SLIDING':'ATTACHED'):hit?(hit.up&&hit.anchor.y<=player.pos.y+.6?'SLIDE · ':'WEB · ')+Math.round(hit.distance)+'m':'NO ANCHOR';}else{reticle.classList.remove('web-ready');reticle.dataset.web='';}
 if(!isSpider)return;for(let i=1;i<=4;i++){$('ability'+i).classList.toggle('active',s.action?.kind===i);$('abilityTag'+i).textContent=s.action?.kind===i?'ACTIVE':s.cd[i]>.05?s.cd[i].toFixed(1)+'s':SPIDER_KIT.tags[i];}if(s.action?.kind===3&&s.action.bound)$('objective').textContent='COCOON · aim to sling · tap 3 to throw · Jump to toss up';else if(s.action?.kind===4)$('objective').textContent=(s.action.sliding?'WEB SLIDE · ':'WEB SWING · ')+Math.round(player.vel.length())+' m/s · keep holding · let go to release';else if(s.linkTime>0)$('objective').textContent='AIR LINK · light attacks to continue · 2 to slam · 1 to chase';}

function packSpiderThrows(){return spiderThrows.map(t=>({owner:t.owner.id,target:t.target.id,t:t.t,slam:!!t.slam}));}
function validSpiderThrows(s,ids){return Array.isArray(s)&&s.length<=MAX_FIGHTERS&&new Set(s.map(t=>t?.target)).size===s.length&&s.every(t=>t&&ids.has(t.owner)&&actorById(t.owner)?.character==='spiderman'&&ids.has(t.target)&&t.target!==t.owner&&Number.isFinite(t.t)&&t.t>=0&&t.t<=2.9&&typeof t.slam==='boolean');}
