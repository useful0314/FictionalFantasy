// Fixed six-actor web pool. Dynamic strand buffers are reused, never rebuilt per frame.
let spiderVisuals=null;
function ensureSpiderVisuals(){if(spiderVisuals)return spiderVisuals;spiderVisuals=Array.from({length:MAX_FIGHTERS},()=>{
 const g=new THREE.Group();scene.add(g);g.visible=false;const data=new Float32Array(3*2*32*3),geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(data,3).setUsage(THREE.DynamicDrawUsage));const web=new THREE.LineSegments(geometry,new THREE.LineBasicMaterial({color:SPIDER.web,transparent:true,opacity:.94}));web.frustumCulled=false;g.add(web);
 const points=[];for(let strand=0;strand<10;strand++)for(let i=0;i<48;i++){for(const j of [i,i+1]){const q=j/48,angle=q*Math.PI*8+strand*Math.PI*.2;points.push(Math.cos(angle)*.68*Math.sin(q*Math.PI),q*2.7-.2,Math.sin(angle)*.55*Math.sin(q*Math.PI));}}
 const cage=new THREE.LineSegments(new THREE.BufferGeometry().setAttribute('position',new THREE.Float32BufferAttribute(points,3)),new THREE.LineBasicMaterial({color:SPIDER.web,transparent:true,opacity:.9}));g.add(cage);return {g,web,cage,data,geometry,dustClock:0,from:V(),to:V(),axis:V(),side:V(),up:V()};});return spiderVisuals;}
function updateSpiderVisuals(dt){
 const thrown=mode==='online'&&net?.role==='guest'?spiderThrowReplica:spiderThrows;
 if(!thrown.length&&!bodies.some(f=>f.character==='spiderman'&&f.spider?.action)){if(spiderVisuals)for(const v of spiderVisuals)v.g.visible=false;return;}
 const pool=ensureSpiderVisuals();for(let i=0;i<pool.length;i++){const v=pool[i],f=bodies[i],a=f?.spider?.action,shot=f&&thrown.find(t=>(typeof t.owner==='string'?t.owner:t.owner.id)===f.id),wrapped=shot?(typeof shot.target==='string'?actorById(shot.target):shot.target):a?.kind===3&&a.bound?a.target:null;v.g.visible=!!(a||wrapped)&&f?.hp>0&&(phase==='play'||phase==='pause');if(!v.g.visible)continue;
  v.cage.visible=!!wrapped;if(v.cage.visible){v.cage.position.copy(wrapped.pos);v.cage.scale.setScalar(1+Math.sin(time*8)*.018);}
  if(a?.sliding&&dt>0&&Math.hypot(f.vel.x,f.vel.z)>5){v.dustClock+=dt;if(v.dustClock>=SPIDER_SLIDE.dustInterval){v.dustClock%=SPIDER_SLIDE.dustInterval;v.from.copy(f.pos);v.from.y+=.10;narutoEmit(v.from,SPIDER_SLIDE.dustColor,particleBudget<1000?2:4,.38,1.8,.32,true);}}else v.dustClock=0;
  v.web.visible=!!a&&(a.kind===4||a.kind===3||a.kind===1&&(a.mode==='zip'||a.t<.58));if(!v.web.visible)continue;
  f.root.updateMatrixWorld(true);f.limbs[1].hand.getWorldPosition(v.from);v.to.copy(a.anchor||a.target?.pos||f.pos);if(!a.anchor)v.to.y+=1.35;const reveal=narutoEase(a.t/.16);v.to.lerpVectors(v.from,v.to,reveal);v.axis.copy(v.to).sub(v.from);v.side.set(-v.axis.z,0,v.axis.x).normalize();v.up.crossVectors(v.axis,v.side).normalize();const swing=a.kind===4,settle=narutoEase(a.t/.4),load=swing?a.load||0:1,flutter=swing?.025+(1-settle)*.18+(1-load)*.025:.025+(a.t<.2?.13:0),sag=swing?(1-load)*(1-settle)*.35:0;let n=0;
  for(let strand=0;strand<3;strand++)for(let j=0;j<32;j++)for(let end=0;end<2;end++){const q=(j+end)/32,phase=q*29+strand*Math.PI*2/3+time*4,wave=Math.sin(q*Math.PI)*flutter,x=Math.cos(phase)*wave,y=Math.sin(phase)*wave;v.data[n++]=lerp(v.from.x,v.to.x,q)+v.side.x*x+v.up.x*y;v.data[n++]=lerp(v.from.y,v.to.y,q)+v.side.y*x+v.up.y*y-Math.sin(q*Math.PI)*sag;v.data[n++]=lerp(v.from.z,v.to.z,q)+v.side.z*x+v.up.z*y;}
  v.geometry.attributes.position.needsUpdate=true;
 }
}
