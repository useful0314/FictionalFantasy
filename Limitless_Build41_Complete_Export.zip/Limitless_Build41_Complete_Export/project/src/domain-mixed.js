// Presentation-only composition. Existing domain rules, scores and sure-hits are untouched.
const MIXED_DOMAIN={cageScale:.72,cageFade:.9,voidAcross:22,voidDepth:22,shrineAcross:23,shrineDepth:-23};
function buildMindscapeClash(origin,axis){
 let gojo=false,sukuna=false;for(const id of clash?.participants||[]){const k=actorById(id)?.character;gojo ||= k==='gojo';sukuna ||= k==='sukuna';}
 if(!gojo&&!sukuna){mindscapeBackdrop('mindscape-clash',origin,axis);return;}
 const forward=axis.clone().setY(0).normalize();if(forward.lengthSq()<.5)forward.set(0,0,-1);const right=V(-forward.z,0,forward.x),both=gojo&&sukuna;
 // The existing Void/Shrine sky and floor continue animating under the cage sector.
 domainBackdrop(both?'clash':gojo?'gojo':'sukuna',origin,both?right:forward);
 const v=domainVisual.userData;if(!v.kind)return;v.mixedMindscape=true;v.mindscapeAxis=right.clone().negate();v.mixedLabel='MINDSCAPE × '+(gojo?'UNLIMITED VOID':'')+(both?' × ':'')+(sukuna?'MALEVOLENT SHRINE':'');
 bindMindscapeRealm(origin,v.mindscapeAxis);
 if(v.hole)v.hole.position.copy(origin).addScaledVector(right,MIXED_DOMAIN.voidAcross).addScaledVector(forward,both?MIXED_DOMAIN.voidDepth:0).add(V(0,14,0));
 if(v.temple){v.temple.position.copy(origin).addScaledVector(right,MIXED_DOMAIN.shrineAcross).addScaledVector(forward,both?MIXED_DOMAIN.shrineDepth:0);v.temple.rotation.y=Math.atan2(-right.x,-right.z);}
 animateDomainVisual();
}
