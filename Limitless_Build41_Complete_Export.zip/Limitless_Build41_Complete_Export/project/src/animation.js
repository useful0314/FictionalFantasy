function animateFighter(f,dt){
 if(f.character==='naruto'){animateNaruto(f,dt);return;}
 const wallFacing=sharedWallFacing(f,dt),wallBlending=(f.narutoMobility?.wallVisualWeight||0)>.001,webFacing=spiderSwingFacing(f,dt);
 f.root.position.copy(f.pos);const launched=f.ragdollT>0,recovering=f.recovery>0&&f.ragdollGround,facing=aimFor(f).setY(0),angle=launched||recovering?f.ragdollYaw:wallFacing??webFacing??Math.atan2(facing.x,facing.z);f.root.rotation.y+=(THREE.MathUtils.euclideanModulo(angle-f.root.rotation.y+Math.PI,Math.PI*2)-Math.PI)*(webFacing!==null?1-Math.exp(-dt/SPIDER_SWING.facingBlend):wallBlending?1-Math.exp(-dt/WALL_MOTION.poseBlend):1);
 const speed=f.lastPos?Math.hypot(f.pos.x-f.lastPos.x,f.pos.z-f.lastPos.z)/Math.max(dt,.001):0;if(f.lastPos)f.lastPos.copy(f.pos);else f.lastPos=f.pos.clone();const sprint=(f.sprinting||speed>11)&&!chargeFor(f)&&!f.block;
 f.walkPhase=(f.walkPhase||0)+Math.min(speed,26)*dt*lerp(2.2,1.1,narutoEase((speed-WORLD.walk)/(WORLD.sprint-WORLD.walk)));const moving=speed>.4&&f.grounded&&!f.spider?.action?.sliding,walk=Math.sin(f.walkPhase);let blend=1-Math.exp(-dt/(f.character==='mahito'?MAHITO_MOTION.blend:ROSTER_MOTION.blend));
 const pose=rosterLocomotionPose(f,dt,speed,moving,sprint),state=rosterAnimationState(f),hitPose=sampleHitRecoil(f);blend=f.spider?.action?.kind===4||f.character==='spiderman'&&f.spider?.releaseTime>0?1-Math.exp(-dt/SPIDER_SWING.poseBlend):spiderBusy(f)?1-Math.exp(-dt/.035):combatPoseBlend(f,blend);
 const arms=state.arms||(state.arms=[V(),V()]),elbows=state.elbows||(state.elbows=[0,0]),legs=state.legs||(state.legs=[0,0]),knees=state.knees||(state.knees=[0,0]),splay=state.splay||(state.splay=[0,0]);
 arms[0].set(pose[NP.lx],pose[NP.ly],pose[NP.lz]);arms[1].set(pose[NP.rx],pose[NP.ry],pose[NP.rz]);elbows[0]=pose[NP.le];elbows[1]=pose[NP.re];legs[0]=pose[NP.ll];legs[1]=pose[NP.rl];knees[0]=pose[NP.lk];knees[1]=pose[NP.rk];splay[0]=pose[NP.ls];splay[1]=pose[NP.rs];
 let lean=pose[NP.lean],twist=pose[NP.twist],tilt=pose[NP.tilt],bob=pose[NP.bob],headTilt=pose[NP.hx],headTurn=pose[NP.hy];
 if(f.block){arms[0].x=-1.08;arms[1].x=-.95;arms[0].z=-.18;arms[1].z=.16;elbows[0]=-1.42;elbows[1]=-1.55;lean=.08;twist=-.1;legs[0]=-.14;legs[1]=.14;knees[0]=.3;knees[1]=.24;bob-=.05;}
 if(f.guardReact>0){const recoil=Math.sin(f.guardReact/.25*Math.PI);arms[0].x=-1.15;arms[0].z=-.45*recoil;arms[1].x=-.85;elbows[0]=-1.2;elbows[1]=-1.55;lean=-.18*recoil;twist=.3*recoil;}
 const ch=chargeInSlot(f,0),cast=domainPresentationCast(f);
 if(ch||f.energyCharging||cast){
  arms[1].x=-1.35;elbows[1]=-.25;
  if(ch?.kind===3){arms[0].x=-1.3;arms[0].z=.3;arms[1].z=-.3;elbows[0]=-.25;
   if(f.character==='sukuna'){
    const draw=THREE.MathUtils.smoothstep(ch.max?ch.t/ch.max:ch.t/ch.duration,0,1);
    twist=-.4;lean=-.06;arms[0].x=-Math.PI/2;arms[0].y=-.32;arms[0].z=.06;elbows[0]=-.04;
    arms[1].x=-1.48+draw*.42;arms[1].y=.5+draw*.55;arms[1].z=-.25-draw*.35;elbows[1]=-.55-draw*1.5;
    legs[0]=-.2;legs[1]=.2;knees[0]=.3;knees[1]=.15;splay[0]=.15;splay[1]=-.15;headTurn=.28;
   }
  }
  if(cast){arms[1].x=-.95;elbows[1]=-1.9;arms[1].z=.22;if(f.character==='sukuna'){arms[0].x=-.95;elbows[0]=-1.9;arms[0].z=-.22;}}
 }
 if(f.energyCharging&&!ch&&!cast){const pulse=Math.sin(time*4)*.016;arms[0].set(-.62,0,.28);arms[1].set(-.62,0,-.28);elbows[0]=elbows[1]=-1.5;lean=-.04;bob=-.08+pulse;knees[0]=knees[1]=.32;headTilt=-.045;}
 if(f.releasePose>0){f.releasePose=Math.max(0,f.releasePose-dt);const pull=f.releasePose/.5;arms[0].x=-1.57;elbows[0]=-.03;arms[1].x=-.8;arms[1].y=1.2;arms[1].z=-.8;elbows[1]=-1.7;twist=-.4+(.5-pull)*.1;}
 const redPose=f.character==='gojo'&&(ch?.kind===2||f.redRecoil>0);
 if(redPose){
  const recoil=f.redRecoil>0?Math.sin(clamp((.42-f.redRecoil)/.42,0,1)*Math.PI):0;
  arms[1].set(-Math.PI/2-Math.asin(clamp(aimFor(f).y,-.95,.95))-.18*recoil,0,-.03);elbows[1]=-.035-.3*recoil;arms[0].set(-.55,0,.12);elbows[0]=-1.1;twist=0;lean=-.07*recoil;headTurn=0;
 }
 const techniquePose=worldCutPose(f)||specialBodyPose(f,ch);if(techniquePose&&!cast){for(let i=0;i<2;i++){arms[i].copy(techniquePose.arms[i]);elbows[i]=techniquePose.elbows[i];knees[i]=techniquePose.knees[i];legs[i]=techniquePose.legs[i];}lean=techniquePose.lean;twist=techniquePose.twist;bob+=techniquePose.bob;headTurn=techniquePose.headTurn;}
 const mahitoPose=spiderPoseTarget(f)||mahitoPoseTarget(f,moving);if(mahitoPose&&!f.block&&!(f.guardReact>0)){const p=mahitoPose;arms[0].set(p[NP.lx],p[NP.ly],p[NP.lz]);arms[1].set(p[NP.rx],p[NP.ry],p[NP.rz]);elbows[0]=p[NP.le];elbows[1]=p[NP.re];legs[0]=p[NP.ll];legs[1]=p[NP.rl];knees[0]=p[NP.lk];knees[1]=p[NP.rk];lean=p[NP.lean];twist=p[NP.twist];tilt=p[NP.tilt];bob=p[NP.bob];headTilt=p[NP.hx];}
 if(mahitoPose&&f.character==='spiderman'){splay[0]=mahitoPose[NP.ls];splay[1]=mahitoPose[NP.rs];headTurn=mahitoPose[NP.hy];}
 const wallPose=sharedWallPose(f);if(wallPose){arms[0].set(wallPose[NP.lx],wallPose[NP.ly],wallPose[NP.lz]);arms[1].set(wallPose[NP.rx],wallPose[NP.ry],wallPose[NP.rz]);elbows[0]=wallPose[NP.le];elbows[1]=wallPose[NP.re];legs[0]=wallPose[NP.ll];legs[1]=wallPose[NP.rl];knees[0]=wallPose[NP.lk];knees[1]=wallPose[NP.rk];lean=wallPose[NP.lean];twist=wallPose[NP.twist];tilt=wallPose[NP.tilt];bob=wallPose[NP.bob];}
 const stretch=lerp(f.body.scale.y,hitPose?hitPose.squash:wallPose?wallPose[NP.stretch]:mahitoPose?mahitoPose[NP.stretch]:techniquePose?techniquePose.stretch||1:pose[NP.stretch],blend);f.body.scale.set(1/Math.sqrt(stretch),stretch,1/Math.sqrt(stretch));
 if(f.dodge>0){const burst=Math.sin(narutoEase(1-f.dodge/DODGE.duration)*Math.PI);lean=.38+.24*burst;bob-=.16+.11*burst;arms[0].x=.55;arms[1].x=.8;legs[0]=-.65;legs[1]=.55;knees[0]=.85;knees[1]=.2;}
 f.hitReact=Math.max(0,(f.hitReact||0)-dt);if(f.hitReact>0){lean=hitPose?hitPose.lean:-.3;tilt=hitPose?hitPose.tilt:Math.sin(f.hitReact*50)*.12;headTilt=hitPose?hitPose.head:-.15;if(hitPose){twist=hitPose.twist;bob+=hitPose.bob;}}
 if(f.hp<=0&&!finisher){tilt=1.45;lean=.1;bob=-.4;arms[0].x=.25;arms[1].x=-.2;arms[0].z=.6;arms[1].z=-.45;elbows[0]=-.25;elbows[1]=-.4;knees[0]=.65;knees[1]=.3;}
 if(f.ragdollT>0){
  const age=f.ragdollAge||0,ground=f.ragdollGround,flop=Math.sin(age*6),speed=Math.hypot(f.vel.x,f.vel.z);
  lean=f.ragdollPitch;tilt=f.ragdollRoll;twist=0;bob=0;
  for(let i=0;i<2;i++){const side=i?1:-1;arms[i].x=ground?-.2:-.45+Math.sin(age*7+side)*.5;arms[i].z=side*(ground?.6:.95);elbows[i]=ground?-.4:-.55-Math.abs(Math.sin(age*6+i))*.8;legs[i]=ground?.12:Math.sin(age*5+i*1.8)*.6;knees[i]=ground?.25:.4+Math.abs(Math.cos(age*4+i))*1.05;}headTilt=ground?.1:clamp(speed/55,0,.4)+.1*flop;
 }else if(recovering){
  const rise=THREE.MathUtils.smoothstep(1-f.recovery/.55,0,1);lean=lerp(-Math.PI/2,0,rise);tilt=0;twist=0;bob=-Math.sin(rise*Math.PI)*.24;knees[0]=knees[1]=Math.sin(rise*Math.PI)*1.15;arms[0].x=arms[1].x=-.75*(1-rise);elbows[0]=elbows[1]=-.5;
 }
 if(finisher?.loser===f){const t=finisher.t;if(finisher.kind==='gojo'){arms[0].x=arms[1].x=-1.4;arms[0].z=-.48;arms[1].z=.48;elbows[0]=elbows[1]=-1.65;headTilt=Math.sin(t*31)*.09;tilt=Math.sin(t*23)*.045;}else{const fall=THREE.MathUtils.smoothstep(t,2.65,3.8);lean=fall*1.25;bob=-fall*.75;knees[0]=knees[1]=fall*1.1;arms[0].x=arms[1].x=fall*.6;headTilt=fall*.5;tilt=Math.sin(t*44)*.045*(1-fall);}}
 f.body.rotation.x=lerp(f.body.rotation.x,lean,blend);f.body.rotation.y=combatBodyYaw(f,twist,blend);f.body.rotation.z=lerp(f.body.rotation.z,tilt,blend);
 // Keep the torso pivot at its centre during tumbling instead of swinging it around the feet.
 const defeated=f.hp<=0&&!finisher,pivoting=(launched||recovering||defeated)&&!finisher,pivot=state.pivot.set(0,1.15,0).applyEuler(f.body.rotation),rise=recovering?THREE.MathUtils.smoothstep(1-f.recovery/.55,0,1):0,center=defeated?.40:launched?(f.ragdollGround?.62:1.15):lerp(.62,1.15,rise);
 f.body.position.lerp(pivoting?state.target.set(-pivot.x,center-pivot.y+(defeated?0:bob),-pivot.z):state.target.set(0,bob,0),blend);
 f.headGroup.rotation.x=lerp(f.headGroup.rotation.x,headTilt,blend);f.headGroup.rotation.y=lerp(f.headGroup.rotation.y,headTurn,blend);
 const webPose=f.character==='spiderman'&&(f.spider?.action?.kind===4||f.spider?.releaseTime>0)?spiderSwingVisual(f):null;
 for(let i=0;i<2;i++){const arm=f.limbs[i].arm;if(webPose){webPose.euler.set(arms[i].x,arms[i].y,arms[i].z);webPose.rotation.setFromEuler(webPose.euler);arm.quaternion.slerp(webPose.rotation,blend);}else{arm.rotation.x=lerp(arm.rotation.x,arms[i].x,blend);arm.rotation.y=lerp(arm.rotation.y,arms[i].y,blend);arm.rotation.z=lerp(arm.rotation.z,arms[i].z,blend);}f.limbs[i].elbow.rotation.x=lerp(f.limbs[i].elbow.rotation.x,elbows[i],blend);f.legs[i].rotation.x=lerp(f.legs[i].rotation.x,legs[i],blend);f.legs[i].rotation.z=lerp(f.legs[i].rotation.z,splay[i],blend);f.knees[i].rotation.x=lerp(f.knees[i].rotation.x,knees[i],blend);}
 if(f.limbs.length>2)animateHeianArms(f,{ch,cast,walk,moving,sprint,launched,recovering,blend:Math.min(blend,1-Math.exp(-dt/ROSTER_MOTION.blend))});
 for(let i=0;i<2;i++)for(let j=0;j<f.limbs[i].fingers.length;j++){const special=techniquePose?.limitless&&!cast,pose=state.comboMotion?.render?state.comboMotion.pose[i?NP.rc:NP.lc]:worldCutBusy(f)?(j<2?-.1:-1.1):cast?(f.character==='gojo'?i===1&&j<2?0:-1.4:-.15):special?(techniquePose.point===i&&j===0?0:techniquePose.grips[i]):redPose&&i===1?(j===0?0:-1.55):ch?-.4:f.attack>0?-1.6:-.3;f.limbs[i].fingers[j].rotation.x=lerp(f.limbs[i].fingers[j].rotation.x,pose,blend);f.limbs[i].fingers[j].rotation.z=lerp(f.limbs[i].fingers[j].rotation.z,cast&&f.character==='gojo'&&i===1&&j<2?(j?-.32:.32):special?(j-1.5)*techniquePose.spread[i]:0,blend);}
 if(moving&&!launched&&!recovering&&speed>1&&(Math.sin(f.walkPhase)>0)!==(f.lastFoot||false)){f.lastFoot=Math.sin(f.walkPhase)>0;sfx('step',f.pos,f===player?sprint?1:.7:.35,false);}
 animateRosterDetail(f,dt,moving,techniquePose?.limitless&&!cast?techniquePose:null);spiderHands(f,dt);
 if(f.band)f.band.visible=!cast&&!(domain?.owner===f&&f.character==='gojo');
 f.shield.material.opacity=Math.max(0,f.shield.material.opacity-dt*2.7);f.shield.rotation.y+=dt;f.shield.material.uniforms.uOpacity.value=f.shield.material.opacity;f.shield.material.uniforms.uTime.value=time;f.shadow.position.set(f.pos.x,.14,f.pos.z);f.shadow.scale.setScalar(clamp(1-f.pos.y*.025,.4,1));
}
function animateHeianArms(f,{ch,cast,walk,moving,sprint,launched,recovering,blend}){
 const lower=chargeInSlot(f,1),lowerPose=specialBodyPose(f,lower,1);
 const progress=1-clamp(f.attack/(f.attackMax||.4),0,1),strike=Math.sin(THREE.MathUtils.smoothstep(progress,.12,.88)*Math.PI);
 for(let i=2;i<4;i++){
  const side=i===2?-1:1,limb=f.limbs[i];let x=-.18,y=side*.12,z=side*.43,elbow=-1.05,fingers=-.6;
  if(moving){x=walk*side*(sprint?.65:.35);z=side*.52;elbow=sprint?-1.45:-.7;}
  if(!f.grounded){x=.4;z=side*.65;elbow=-.75;}
  if(f.attack>0){
   if(f.attackIsLight){x=-.58;elbow=-1.35;z=side*(f.combo>=2?.53:.34);y=-side*.08;if(f.combo>=2){x+=Math.sin(progress*Math.PI)*.16;z+=side*Math.sin(progress*Math.PI)*.16;}}
   else{x=-.6-strike*.55;z=side*(.5+strike*.3);elbow=-1.2+strike*.65;}fingers=-1.5;
  }
  if(f.block||f.guardReact>0){x=-1.05;z=-side*.18;elbow=-1.3;fingers=-1.45;}
  if(ch){
   if(ch.kind===3){x=-.9;y=side*.15;z=-side*.2;elbow=-1.55;fingers=-1.1;}
   else if(ch.kind===2){x=-.8;z=side*.7;elbow=-.65;fingers=-.2;}
   else{x=-.6;y=-side*.3;z=side*.45;elbow=-1.3;fingers=-.3;}
  }
  if(cast){x=-1.02;z=-side*.35;y=side*.15;elbow=-1.5;fingers=-.2;}
  if(f.releasePose>0){x=-.7;z=side*.6;elbow=-1.1;}
  if(!ch&&f.specialKind>0&&f.specialAge<f.specialDuration){const follow=Math.sin(f.specialAge/f.specialDuration*Math.PI);if(f.specialKind===1){x=-.5;z=side*.6;elbow=-1.1;}else if(f.specialKind===2){x=-1-follow*.25;z=side*(.2+follow*.7);elbow=-1.3+follow*.7;}else if(f.specialKind===4){x=i===2?.4:-1.4;z=side*.45;elbow=-1.1+follow*.7;}}
  if(lowerPose&&!cast){const a=lowerPose.arms[i-2];x=a.x;y=a.y;z=a.z;elbow=lowerPose.elbows[i-2];fingers=-.4;}
  const cut=worldCutPose(f);if(cut){x=cut.arms[i].x;y=cut.arms[i].y;z=cut.arms[i].z;elbow=cut.elbows[i];fingers=worldCutAge(f.worldCut)<WORLD_CUT.startup?-.25:-.1;}
  const wall=f.narutoMobility;if(wall?.kind===3||wall?.kind===4){const stride=wall.kind===3?Math.sin(narutoMobilityAge(wall)*27):0;x=-.5+stride*side*.32;z=side*.6;elbow=-1.3;fingers=-.2;}
  if(f.dodge>0){x=.7;z=side*.55;elbow=-.75;}
  if(launched){const a=f.ragdollAge;x=f.ragdollGround?.12:Math.sin(a*6+i)*.75;z=side*(f.ragdollGround?.9:1.25);y=0;elbow=f.ragdollGround?-.35:-.5-Math.abs(Math.sin(a*5+i))*.8;fingers=-.25;}
  if(recovering){x=-.65;z=side*.7;elbow=-.45;}
  if(finisher?.loser===f){x=finisher.kind==='gojo'?-.9:.4;z=side*.6;elbow=-1.2;}
  limb.arm.rotation.x=lerp(limb.arm.rotation.x,x,blend);limb.arm.rotation.y=lerp(limb.arm.rotation.y,y,blend);limb.arm.rotation.z=lerp(limb.arm.rotation.z,z,blend);limb.elbow.rotation.x=lerp(limb.elbow.rotation.x,elbow,blend);
  for(const finger of limb.fingers)finger.rotation.x=lerp(finger.rotation.x,fingers,blend);
 }
}
