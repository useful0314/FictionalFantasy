const ARENA_MAPS={
 district:{name:'Night District',tag:'ORIGINAL CITY',description:'Dense streets, rooftops and elevated crossings.',background:0x091322,fog:0x0c1c2f,density:.0038,floor:0x172332,edge:0x426783,hemi:0x91cbff,ground:0x18202e,sun:0xc2dcff,rim:0x8670ef,light:[2.2,3.1,1.3]},
 harbor:{name:'Sunlit Harbor',tag:'DAYTIME',description:'Open plazas, colorful docks and a lighthouse.',background:0xb3e2f3,fog:0xc5e5ef,density:.0017,floor:0x8d9f9c,edge:0xe1d4ae,hemi:0xc9ecff,ground:0x797d68,sun:0xfff0d2,rim:0xaccbd8,light:[2.8,3.2,.7]},
 sanctuary:{name:'Shattered Sanctuary',tag:'GOLDEN SUNSET',description:'Golden-hour ruins, amber crystals and floating bridges.',background:0xf4bc87,fog:0xedba90,density:.0019,floor:0x857463,edge:0xeac17c,hemi:0xffdcaf,ground:0x7b554a,sun:0xffcb7d,rim:0xf3a780,light:[2.2,3.2,.8]},
 metro:{name:'Skyline Boroughs',tag:'ROOFTOP CITY',description:'A 520m-wide city with 32 high rises up to 96m tall, new outer avenues, brick blocks and rooftop routes.',background:0xa9cfdf,fog:0xbcd1d9,density:.0018,floor:0x899391,edge:0xc9bea3,hemi:0xc7e3ef,ground:0x747b6b,sun:0xffe7c4,rim:0xb6d5e3,light:[2.5,3.1,.8]}
};
let selectedMap='district',activeMap='district';try{const saved=localStorage.getItem('limitless.map');if(ARENA_MAPS[saved])selectedMap=saved;}catch{}
const mapCache=new Map([['district',{objects:stage.children.filter(o=>![base,floor,edge].includes(o)),sky:[...sky.children],pieces:[...pieces],buildings:[...buildings]}]]),mapMaterials=new Map();
base.material=base.material.clone();
function mapMaterial(color,emissive=false){const key=color+'-'+emissive;if(!mapMaterials.has(key))mapMaterials.set(key,emissive?new THREE.MeshBasicMaterial({color}):new THREE.MeshStandardMaterial({color,roughness:.8,metalness:.12}));return mapMaterials.get(key);}
function mapBlock(x,z,w,d,levels,color){
 const id=buildings.length,b={id,x,z,w,d,floors:levels,parts:[]};buildings.push(b);
 for(let level=0;level<levels;level++){
  const p=piece(V(x,2+level*4,z),V(w,3.92,d),color,true);p.solid=true;p.building=id;p.level=level;p.hp=p.max=46;b.parts.push(p);
  for(const side of [-1,1])for(let col=0;col<4;col++)box(p.m,V((col-1.5)*.21,.08,side*.503),V(.105,.4,.007),mapMaterial(0x346276));
  box(p.m,V(0,.49,0),V(1.025,.05,1.025),mapMaterial(0xf2e3c7));
 }
 return b;
}
function buildHarbor(root,horizon){
 const sand=mapMaterial(0xc4bba4),white=mapMaterial(0xf6ebd5),water=mapMaterial(0x378ca2),teal=mapMaterial(0x30646c);
 mesh(new THREE.CircleGeometry(280,96),water,horizon,V(0,-1.1,0)).rotation.x=-Math.PI/2;
 for(const x of [-60,0,60])box(root,V(x,.015,0),V(16,.07,300),sand);
 for(const z of [-65,0,65])box(root,V(0,.02,z),V(300,.07,16),sand);
 for(let i=0;i<4;i++){const ring=mesh(new THREE.TorusGeometry(17+i*8,.07,4,100),white,root,V(0,.09,0));ring.rotation.x=Math.PI/2;}
 const sites=[[-115,-66],[-83,-105],[-38,-106],[38,-106],[83,-105],[115,-66],[-113,-20],[113,-20],[-112,35],[112,35],[-82,96],[-38,109],[38,109],[82,96]];
 sites.forEach(([x,z],i)=>{const b=mapBlock(x,z,15+i%3*2,13,2+i%3,[0xf0d4b7,0x6ba8ad,0xd18576,0xd8ddcb][i%4]);const awning=box(b.parts[0].m,V(0,-.15,.55),V(.95,.08,.23),mapMaterial(i%2?0xbc6f4b:0x397b82));});
 // Accessible warehouse roofs and brightly painted breakable container stacks.
 for(const side of [-1,1])for(let i=0;i<6;i++){const x=side*(77+(i%2)*17),z=15+Math.floor(i/2)*18,p=piece(V(x,2,z),V(13,4,6),[0x287d85,0xa95245,0xc8a248][i%3],true);p.solid=true;for(let n=-4;n<=4;n++)box(p.m,V(n*.1,0,.51),V(.015,.92,.012),teal);if(i%2){const top=piece(V(x+1,6,z),V(13,4,6),0x537b8d,true);top.solid=true;}}
 for(const side of [-1,1])for(let i=0;i<8;i++){const x=side*39,z=-91+i*26,p=piece(V(x,2,z),V(.8,4,.8),0x6b5745);const leaves=mesh(new THREE.IcosahedronGeometry(1,1),mapMaterial(i%2?0x65956a:0x487b61),p.m,V(0,.58,0),V(4.5,.72,4.5));}
 for(const side of [-1,1])for(let i=0;i<5;i++)piece(V(side*27,.6,-56+i*28),V(4,1.2,1.6),0xe1d6bd,true);
 const tower=piece(V(0,13,-129),V(11,26,11),0xf2e5cf,true);tower.solid=true;tower.m.geometry=geo.cylinder;tower.hp=tower.max=110;
 for(const y of [-.3,0,.3])mesh(geo.cylinder,mapMaterial(0xb85d4a),tower.m,V(0,y,0),V(1.01,.07,1.01));
 mesh(geo.cylinder,teal,tower.m,V(0,.57,0),V(1.25,.13,1.25));mesh(geo.cone,mapMaterial(0xb45444),tower.m,V(0,.72,0),V(1.5,.19,1.5));
 const light=glow(0xfff4cf,9,.7,root);light.position.set(0,29,-129);
 for(const side of [-1,1])for(let n=0;n<7;n++)piece(V(side*(5+n*3.4),.3+n*.6,-45),V(3.3,.6,7),0xc8bea9,true);
 const sunDisc=mesh(new THREE.SphereGeometry(13,24,16),mapMaterial(0xfff3cd,true),horizon,V(-145,143,-215));const sunGlow=glow(0xffe8a7,70,.42,horizon);sunGlow.position.copy(sunDisc.position);
 for(let i=0;i<15;i++){const x=-230+i*33,z=-235-rr(0,35),y=75+rr(0,27);for(let n=0;n<3;n++)mesh(new THREE.SphereGeometry(1,12,8),white,horizon,V(x+n*8,y+n%2*3,z),V(14,5,7));}
 for(let i=0;i<12;i++){const a=i/12*Math.PI*2;mesh(new THREE.ConeGeometry(25+rr(0,18),30+rr(0,30),5),mapMaterial(0x6fa0a7),horizon,V(Math.cos(a)*245,8,Math.sin(a)*245));}
}
function buildSanctuary(root,horizon){
 const stone=mapMaterial(0xa18c70),hot=mapMaterial(0xffc464,true),dark=mapMaterial(0x665046);
 for(let i=0;i<6;i++){const a=i*Math.PI/3;
  const path=box(root,V(Math.sin(a)*75,.015,Math.cos(a)*75),V(9,.1,130),mapMaterial(0x9b8368));path.rotation.y=a;
  for(const side of [-1,1]){const seam=box(root,V(Math.sin(a)*75+Math.cos(a)*side*4.2,.08,Math.cos(a)*75-Math.sin(a)*side*4.2),V(.09,.035,128),hot);seam.rotation.y=a;}
  for(let n=0;n<8;n++){const r=35+n*11,h=n<3?1+n*1.6:6+(n%3)*2.1;piece(V(Math.sin(a)*r,h,Math.cos(a)*r),V(8.5,1.1,8.5),0xbca887,true);}
  const r=117,x=Math.sin(a)*r,z=Math.cos(a)*r;
  const island=piece(V(x,17,z),V(22,2.5,22),0x9f8a70,true);mesh(geo.cone,dark,island.m,V(0,-2.8,0),V(1,5.5,1)).rotation.z=Math.PI;
  for(const side of [-1,1]){const p=piece(V(x+side*6,24,z),V(3,12,3),0xc9b491,true);p.solid=true;box(p.m,V(0,.25,.505),V(.18,.33,.008),hot);}
 }
 for(let i=0;i<22;i++){const a=i*2.39996,r=55+(i%5)*20,x=Math.cos(a)*r,z=Math.sin(a)*r,h=7+i%4*3;
  const p=piece(V(x,h*.5,z),V(5+i%3,h,5+i%3),i%2?0xb69a65:0x997d54,true);p.solid=true;p.m.geometry=new THREE.ConeGeometry(.5,1,5);p.m.rotation.y=a;
  const small=mesh(geo.cone,mapMaterial(i%2?0xffd681:0xe9a84e),p.m,V(.3,.02,.2),V(.35,.7,.35));small.rotation.z=.3;
  const g=glow(0xffc26a,7,.14,root);g.position.set(x,2,z);
 }
 for(let i=0;i<5;i++){const ring=mesh(new THREE.TorusGeometry(12+i*6,.04,4,100),i%2?hot:stone,root,V(0,.13,0));ring.rotation.x=-Math.PI/2;}
 const shrineBase=piece(V(0,.5,-84),V(34,1,23),0xa98c6f,true);buildShrine(root,V(0,1,-84),2.15);
 for(const side of [-1,1])for(let i=0;i<4;i++){const p=piece(V(side*(36+i*25),8,-42),V(3,16,3),0xc0a887,true);p.solid=true;piece(V(side*(36+i*25),16,-42),V(14,2,4),0xae936f,true);}
 const skyDome=mesh(new THREE.SphereGeometry(300,48,24),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,uniforms:{},vertexShader:'varying vec3 direction;void main(){direction=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 direction;void main(){vec3 d=normalize(direction);float h=max(0.,d.y);vec3 c=mix(vec3(.98,.60,.31),vec3(.58,.46,.57),smoothstep(.02,.55,h));c=mix(c,vec3(.36,.48,.63),smoothstep(.42,1.,h));float sun=pow(max(0.,dot(d,normalize(vec3(-160.,42.,-250.)))),45.);c+=vec3(.3,.18,.045)*sun;gl_FragColor=vec4(c,1.);}'}),horizon);skyDome.name='golden-sunset-sky';skyDome.renderOrder=-10;
 const sunset=mesh(new THREE.SphereGeometry(18,36,24),mapMaterial(0xffe3a0,true),horizon,V(-160,42,-250));sunset.name='setting-sun';const gleam=glow(0xffb34c,105,.48,horizon);gleam.position.copy(sunset.position);
 for(let i=0;i<8;i++){const cloud=mesh(new THREE.SphereGeometry(1,16,8),mapMaterial(i%2?0xe7a285:0xf1bf93),horizon,V(-210+i*60,60+(i%3)*9,-285));cloud.scale.set(34,2.4,7);}

 for(let i=0;i<26;i++){const a=i/26*Math.PI*2,r=210+rr(0,45),h=rr(24,90);const rock=mesh(new THREE.ConeGeometry(rr(12,25),h,5),mapMaterial(i%2?0xaa7868:0x8f706a),horizon,V(Math.cos(a)*r,h*.3-10,Math.sin(a)*r));rock.rotation.y=a;}
}

function applyArenaMap(id){
 if(!ARENA_MAPS[id])id='district';
 if(!mapCache.has(id)){
  const savedPieces=[...pieces],savedBuildings=[...buildings],savedSeed=seed,root=new THREE.Group(),horizon=new THREE.Group();stage.add(root);sky.add(horizon);pieceParent=root;pieces.length=buildings.length=0;seed=id==='metro'?METRO_MAP.seed:id==='harbor'?91447:25119;
  (id==='metro'?buildMetro:id==='harbor'?buildHarbor:buildSanctuary)(root,horizon);if(id!=='metro')batchStaticBoxes(root);batchStaticBoxes(horizon);
  mapCache.set(id,{objects:[root],sky:[horizon],pieces:[...pieces],buildings:[...buildings]});pieces.splice(0,pieces.length,...savedPieces);buildings.splice(0,buildings.length,...savedBuildings);seed=savedSeed;pieceParent=stage;
 }
 activeMap=id;for(const [key,map]of mapCache){for(const o of map.objects)o.visible=key===id;for(const o of map.sky)o.visible=key===id;}
 const map=mapCache.get(id);pieces.splice(0,pieces.length,...map.pieces);buildings.splice(0,buildings.length,...map.buildings);for(const p of pieces){p.alive=true;p.hp=p.max;p.m.visible=true;}
 WORLD.radius=id==='metro'?METRO_MAP.radius:176;WORLD.ceiling=id==='metro'?METRO_MAP.ceiling:72;
 const scale=WORLD.radius/176;base.scale.set(scale,1,scale);floor.scale.set(scale,scale,1);edge.scale.set(scale,scale,1);camera.far=id==='metro'?800:520;camera.updateProjectionMatrix();
 applyMapEnvironment();syncDomainTerrain();
}
function applyMapEnvironment(){
 const m=ARENA_MAPS[activeMap];scene.background.set(m.background);scene.fog.color.set(m.fog);scene.fog.density=m.density;hemi.color.set(m.hemi);hemi.groundColor.set(m.ground);hemi.intensity=m.light[0];sun.color.set(m.sun);sun.intensity=m.light[1];sun.target.position.set(0,0,0);sun.position.set(...(activeMap==='sanctuary'?[-80,35,-100]:[-15,65,16]));sun.shadow.camera.far=activeMap==='sanctuary'?250:150;sun.shadow.camera.updateProjectionMatrix();rim.color.set(m.rim);rim.intensity=m.light[2];sky.visible=true;shrine.visible=activeMap==='district';stars.visible=activeMap==='district';floor.material.color?.set(m.floor);base.material.color.set(activeMap==='harbor'?0x668a90:0x162232);edge.material.color.set(m.edge);ambientDust.material.color.set(activeMap==='harbor'?0xffe5b2:activeMap==='sanctuary'?0xffca7a:0x8fcbff);
}
function syncMapUI(){for(const id of Object.keys(ARENA_MAPS)){$('map-'+id).classList.toggle('selected',id===selectedMap);$('map-'+id).setAttribute('aria-pressed',String(id===selectedMap));}$('mapDescription').textContent=ARENA_MAPS[selectedMap].description;}
function chooseMap(id){if(!ARENA_MAPS[id])return;selectedMap=id;try{localStorage.setItem('limitless.map',id);}catch{}syncMapUI();if(phase==='menu'){clearDomainVisual();applyArenaMap(id);}else toast('Next match: '+ARENA_MAPS[id].name,2);}
