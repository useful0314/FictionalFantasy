// Explicit keyed anticipation / contact / recovery poses; sampled through existing eased pose channels.
let spiderPoses=null;
function spiderPoseLibrary(){if(spiderPoses)return spiderPoses;const p=narutoPoseTemplate,L=rosterPoseLibrary();return spiderPoses={
 idle:p({lx:-.65,rx:-.7,le:-1.1,re:-1.3,ll:-.18,rl:.18,lk:.4,rk:.3,bob:-.08,lean:.12}),
 shoot:p({rx:-1.55,re:-.06,rz:-.04,rh:-.6,lx:-.6,le:-1.4,twist:.22,lean:.12,rc:-.2,rl:.25}),
 pull:p({lx:-1.1,rx:-1.0,le:-1.8,re:-1.8,twist:-.35,lean:-.25,ll:-.25,rl:.35,lk:.55,bob:-.1}),
 launchWind:p({rx:-.8,lx:-.8,re:-1.3,le:-1.3,rl:-.7,rk:1.8,lean:.14,twist:-.3,lk:.35,bob:-.14,stretch:.96}),
 launch:p({rx:-.6,lx:-.9,re:-1.3,le:-1.1,rl:-2.05,rk:.08,rs:-.12,ll:.1,lk:.12,lean:-.26,twist:.28,stretch:1.04}),
 leap:p({lx:-1.3,rx:-2.5,le:-1.2,re:-.3,ll:-.95,rl:.2,lk:1.5,rk:.65,lean:.1,stretch:1.035}),
 zip:p({lx:-1.6,rx:-1.6,le:-.08,re:-.08,ll:-.65,rl:-.6,lk:1.5,rk:1.4,lean:.72,stretch:1.035}),
 crossWind:L.crossWind,cross:L.cross,hookWind:L.hookWind,hook:L.hook,
 elbowWind:p({rx:-1.2,re:-2.15,ry:-.55,lx:-.9,le:-1.4,twist:-.65,ll:-.22,rl:.28,bob:-.09}),
 elbow:p({rx:-1.25,re:-2.05,ry:.7,rz:.3,lx:-.6,le:-1.3,twist:.8,lean:.22,ll:-.3,rl:.35,stretch:1.025}),
 spinWind:p({lx:-.7,rx:-.8,le:-1.2,re:-1.3,ll:-.9,lk:1.6,rl:.2,rk:.2,twist:1.3,bob:-.07}),
 spin:p({lx:-.7,rx:-.5,lz:.6,rz:-.6,le:-.9,re:-.9,ll:-1.55,ls:.25,lk:.04,rl:.1,rk:.2,twist:5.9,tilt:-.28,lean:.12,stretch:1.04}),
 spinBack:p({lx:-.7,rx:-.6,le:-1.1,re:-1.3,ll:-.3,lk:.5,rl:.2,twist:Math.PI*2,lean:.15,bob:-.09}),
 slamWind:p({lx:-1.3,rx:-1.2,le:-1.3,re:-1.4,ll:-2.6,lk:.25,rl:-.35,rk:1.5,lean:-.2,twist:-.2}),
 slam:p({lx:.3,rx:-.7,le:-.6,re:-1.2,ll:.4,lk:.06,rl:-.6,rk:1.4,lean:.6,twist:.35,stretch:1.05}),
 swing:p({rx:-2.85,re:-.12,rz:-.12,lx:-.8,le:-1.2,ll:-.85,lk:1.5,rl:.3,rk:.65,lean:-.22,twist:.15,stretch:1.035}),
 swingCast:p({rx:-1.65,re:-.15,rh:-.55,lx:-.45,le:-1.05,ll:-.5,lk:.9,rl:.24,rk:.45,lean:.12,twist:.22,bob:-.06,stretch:.97}),
 swingCatch:p({rx:-2.9,re:-.32,lx:-.65,lz:.45,le:-1.05,ll:-.7,lk:1.35,rl:.28,rk:.5,lean:-.18,twist:.16,stretch:1.035}),
 swingFlow:p({rx:-2.85,re:-.16,lx:.14,lz:.55,le:-.65,ll:-.24,lk:.68,rl:.43,rk:.30,ls:.14,rs:-.12,lf:-.20,rf:.27,lean:.22,twist:.10,stretch:1.045}),
 swingDive:p({rx:-2.68,re:-.12,lx:.60,lz:.62,le:-.42,ll:.36,lk:.42,rl:.70,rk:.18,ls:.16,rs:-.13,lf:.30,rf:.36,lean:.50,hx:-.19,stretch:1.055}),
 swingRise:p({rx:-3.02,re:-.46,lx:-.82,lz:.38,le:-1.25,ll:-1.13,lk:1.74,rl:-.45,rk:1.16,ls:.21,rs:-.16,lf:-.31,rf:-.17,lean:-.26,hx:.08,stretch:.98}),
 slide:p({rx:-1.45,re:-.25,lx:.40,lz:.5,le:-.70,ll:-1.10,lk:.30,rl:.60,rk:1.60,ls:.18,rs:-.22,lf:.55,rf:-.35,lean:-.16,twist:-.18,bob:-.40,hx:.08,stretch:.97}),
 releaseTuck:p({rx:-1.8,re:-.70,rz:-.3,lx:-1.1,le:-.85,lz:.38,ll:-1.16,lk:1.8,rl:-.72,rk:1.5,lean:.34,twist:.20,stretch:.96,hx:-.12}),
 releaseOpen:p({rx:.45,re:-.55,rz:-.65,lx:-.38,le:-.7,lz:.72,ll:-.58,lk:1.1,rl:.50,rk:.38,ls:.20,rs:-.18,lf:-.25,rf:.25,lean:.44,twist:-.12,hx:-.16,stretch:1.035}),
 sling:p({lx:-1.05,rx:-1.1,le:-1.2,re:-1.4,twist:-.45,ll:-.25,rl:.35,lk:.5,rk:.25,lean:-.16,bob:-.12}),
 throw:p({rx:-1.65,re:-.05,lx:.6,le:-.7,twist:.72,lean:.4,ll:-.3,rl:.35,lk:.6,rk:.15,stretch:1.04})};}
const SPIDER_TRACKS={yank:[[0,'idle'],[.14,'shoot'],[.25,'shoot'],[.49,'pull'],[.60,'launchWind'],[.70,'launch','snap'],[.77,'launch'],[.94,'leap'],[1.15,'idle']],
 combo:[[0,'idle'],[.12,'crossWind'],[.24,'cross','snap'],[.29,'cross'],[.37,'hookWind'],[.47,'hook','snap'],[.53,'hook'],[.62,'elbowWind'],[.73,'elbow','snap'],[.8,'elbow'],[.9,'spinWind'],[1.04,'spin','snap'],[1.13,'spinBack'],[1.38,'spinBack']],
 slam:[[0,'idle'],[.22,'slamWind'],[.34,'slam','snap'],[.43,'slam'],[.65,'idle']]};
function spiderSwingVisual(f){const s=spiderState(f);return s.visual||(s.visual={weight:0,bank:0,lift:0,load:0,slide:0,target:V(),down:V(0,-1,0),rotation:new THREE.Quaternion(),euler:new THREE.Euler(),flow:narutoPoseTemplate()});}
function spiderSwingFacing(f,dt){
 if(f.character!=='spiderman')return null;
 const s=spiderState(f),a=s.action,v=spiderSwingVisual(f),active=f.hp>0&&f.stun<=0&&f.ragdollT<=0&&f.attack<=0&&f.dodge<=0&&!f.block&&(a?.kind===4||!f.grounded&&!a&&(s.releaseTime>0||s.momentum>0)),blend=1-Math.exp(-dt/SPIDER_SWING.poseBlend);
 v.weight=lerp(v.weight,active?1:0,blend);v.bank=lerp(v.bank,active?(a?.bank||0):0,blend);v.lift=lerp(v.lift,clamp(f.vel.y/26,-1,1),blend);v.load=lerp(v.load,a?.load||0,blend);
 v.slide=lerp(v.slide,a?.kind===4&&a.sliding?1:0,1-Math.exp(-dt/SPIDER_SLIDE.blend));
 if(v.weight<.001||f.stun>0||f.attack>0||f.ragdollT>0||f.hp<=0)return null;
 if(active&&Math.hypot(f.vel.x,f.vel.z)>2)return Math.atan2(f.vel.x,f.vel.z);
 const aim=aimFor(f);return Math.atan2(aim.x,aim.z);
}
function spiderPoseTarget(f){if(f.character!=='spiderman'||f.stun>0||f.ragdollT>0||f.hp<=0)return null;const s=spiderState(f),a=s.action,L=spiderPoseLibrary(),p=s.pose;if(!a){
 if(s.releaseTime>0&&!f.grounded&&f.attack<=0&&f.dodge<=0){const t=SPIDER_SWING.releasePose-s.releaseTime;if(t<.14)narutoMixPose(p,s.startPose,L.releaseTuck,narutoEase(t/.14));else if(t<.35)narutoMixPose(p,L.releaseTuck,L.releaseOpen,narutoEase((t-.14)/.21));else narutoMixPose(p,L.releaseOpen,rosterAnimationState(f).idle,narutoEase((t-.35)/(SPIDER_SWING.releasePose-.35)));return p;}
 if(f.spiderThrowPose>0){narutoMixPose(p,L.idle,L.throw,Math.sin((1-f.spiderThrowPose/.42)*Math.PI));return p;}return null;}
 const t=a.t;if(a.kind===4){const v=spiderSwingVisual(f),flow=v.flow;narutoMixPose(flow,L.swingFlow,v.lift>=0?L.swingRise:L.swingDive,narutoEase(Math.abs(v.lift)));flow[NP.tilt]=-v.bank*SPIDER_SWING.bank;flow[NP.twist]+=v.bank*.22;flow[NP.hy]=-v.bank*.14;flow[NP.le]-=v.load*.25;const flutter=Math.sin(t*5.4)*.045*(1-v.load);flow[NP.ll]+=flutter;flow[NP.rl]-=flutter*.65;
  if(t<.10)narutoMixPose(p,L.idle,L.swingCast,narutoEase(t/.10));else if(t<.30)narutoMixPose(p,L.swingCast,L.swingCatch,narutoEase((t-.10)/.20));else narutoMixPose(p,L.swingCatch,flow,narutoEase((t-.30)/.25));if(v.slide>.001){narutoMixPose(p,p,L.slide,narutoEase(v.slide));p[NP.tilt]-=v.bank*.18*v.slide;p[NP.hy]-=v.bank*.12*v.slide;}return p;}
 if(a.kind===3){narutoMixPose(p,L.shoot,L.sling,narutoEase((t-.23)/.25));p[NP.twist]+=Math.sin(time*2.2)*.08;return p;}
 if(a.mode==='zip'){narutoMixPose(p,L.shoot,L.zip,narutoEase(t/.18));return p;}
 const track=a.kind===1?SPIDER_TRACKS.yank:a.mode==='slam'?SPIDER_TRACKS.slam:SPIDER_TRACKS.combo;let i=1;while(i<track.length-1&&t>track[i][0])i++;const x=track[i-1],y=track[i],q=clamp((t-x[0])/(y[0]-x[0]),0,1);narutoMixPose(p,L[x[1]],L[y[1]],y[2]==='snap'?narutoBack(q):narutoEase(q));return p;
}
function spiderHands(f,dt){
 if(f.character!=='spiderman')return;const s=spiderState(f),a=s.action,b=1-Math.exp(-dt/SPIDER.blend);
 if(a?.kind===4){const v=spiderSwingVisual(f),l=f.limbs[1];l.arm.parent.updateWorldMatrix(true,false);v.target.copy(a.anchor);l.arm.parent.worldToLocal(v.target);v.target.sub(l.arm.position).normalize();v.rotation.setFromUnitVectors(v.down,v.target);l.arm.quaternion.slerp(v.rotation,narutoEase(a.t/.20));l.elbow.rotation.x=lerp(l.elbow.rotation.x,-.08-v.load*.28,b);l.hand.rotation.x=lerp(l.hand.rotation.x,-.15,b);
  const grip=narutoEase((a.t-.15)/.18);for(let i=0;i<2;i++)for(let j=0;j<4;j++){const finger=f.limbs[i].fingers[j],target=i===1?lerp(j===1||j===2?-1.65:-.12,-1.5,grip):-.4;finger.rotation.x=lerp(finger.rotation.x,target,b);}
 }else if(a){for(let i=0;i<2;i++)for(let j=0;j<4;j++){const finger=f.limbs[i].fingers[j],target=a.kind===2||a.kind===1&&a.t>.55?-1.55:j===1||j===2?-1.65:-.12;finger.rotation.x=lerp(finger.rotation.x,target,b);}}
 if((a?.kind===4||s.releaseTime>0&&!f.grounded)&&f.attack<=0&&f.stun<=0&&f.ragdollT<=0)for(let i=0;i<2;i++)f.blockRig.feet[i].rotation.x=lerp(f.blockRig.feet[i].rotation.x,s.pose[i?NP.rf:NP.lf],b);
}
