// Mahito targets enter the shared animator before guard, hit, wall, dodge and ragdoll overrides.
const MAHITO_MOTION={blend:.09,windup:.20,contact:.35,settle:.64,impactOvershoot:1.06};
let mahitoPoses=null;
function mahitoPoseLibrary(){
 if(mahitoPoses)return mahitoPoses;const p=narutoPoseTemplate;
 return mahitoPoses={
 idle:p({lx:-.18,rx:-.3,lz:.12,rz:-.16,le:-.42,re:-.62,ll:-.08,rl:.06,lk:.14,rk:.18,twist:-.08,hx:.015}),
 gather:p({stretch:.96,lx:-1,rx:-1,lz:-.22,rz:.22,le:-1.45,re:-1.45,lean:.10,bob:-.055,ll:-.13,rl:-.13,lk:.26,rk:.26}),
 reveal:p({lx:-.70,rx:-.70,lz:.92,rz:-.92,le:-.35,re:-.35,lean:-.08,twist:.12,bob:.02}),
 expel:p({stretch:1.035,lx:-1.3,rx:-1.3,lz:.55,rz:-.55,le:-.10,re:-.10,lean:.20,bob:-.07}),
 heal:p({lx:-1.04,rx:-.94,lz:-.28,rz:.3,le:-1.6,re:-1.5,lean:.07,bob:-.02,hx:.16}),
 ride:p({lx:.55,rx:.60,lz:.28,rz:-.28,le:-.48,re:-.42,ll:-.52,rl:-.42,lk:1,rk:.9,lean:.29,bob:-.12}),
 touchWind:p({lx:-.55,rx:.35,ly:.15,ry:-.25,lz:.2,rz:-.42,le:-1.05,re:-1.2,twist:-.30,lean:-.08}),
 touch:p({stretch:1.035,lx:-.55,rx:-1.62,ry:.06,le:-1.1,re:-.06,twist:.28,lean:.15,bob:.01}),
 hammerWind:p({stretch:.97,lx:-2.4,rx:-2.4,lz:.25,rz:-.25,le:-.58,re:-.58,lean:-.18,bob:-.07,ll:-.2,rl:-.2,lk:.40,rk:.40}),
 hammer:p({stretch:.945,lx:-.65,rx:-.65,lz:.16,rz:-.16,le:-.12,re:-.12,lean:.38,bob:-.16,ll:-.3,rl:-.3,lk:.48,rk:.48}),
 gunWind:p({lx:-.7,rx:-1.35,lz:.12,rz:-.08,le:-1,re:-.40,twist:-.15,lean:-.04}),
 gun:p({lx:-.7,rx:-1.65,lz:.12,rz:-.06,le:-1,re:-.07,twist:.08,lean:-.09}),
 bladeWind:p({lx:-.45,rx:.3,lz:.24,rz:-1.05,le:-1,re:-.3,ry:-.55,twist:-.42,lean:-.04}),
 blade:p({lx:-.5,rx:-1.5,lz:.3,rz:.50,le:-.9,re:-.12,ry:.7,twist:.50,lean:.17}),
 domain:p({lx:-.9,rx:-.9,lz:-.20,rz:.20,le:-1.75,re:-1.75,lean:-.04,hx:-.06})};
}
function mahitoMotionMix(out,a,b,t,back=false){let q=narutoEase(t);if(back){const x=clamp(t,0,1)-1;q=Math.min(MAHITO_MOTION.impactOvershoot,1+2.3*x*x*x+1.3*x*x);}for(let i=0;i<out.length;i++)out[i]=lerp(a[i],b[i],q);return out;}
function mahitoPoseTarget(f,moving){
 if(f.character!=='mahito'||f.rosterAnim?.comboMotion?.render)return null;const r=f.mahitoRig,L=mahitoPoseLibrary(),p=r.pose,a=f.mahitoAction;let active=false;
 if(a){const age=a.t+(mode==='online'&&net?.role==='guest'?narutoReplicaAge:0);let startup=MAHITO.morphTime*.58,hold=.03,recovery=MAHITO.morphTime-startup-hold,wind=L.gather,strike=L.reveal;
  if(a.kind===2){startup=MAHITO.summonStartup;hold=.07;recovery=MAHITO.summonRecovery-hold;strike=L.expel;}
  if(a.kind===3){startup=MAHITO.trainStartup;hold=MAHITO.trainTime;recovery=MAHITO.trainRecovery;strike=L.ride;}
  if(a.kind===4){startup=MAHITO.healStartup;hold=MAHITO.healTime;recovery=MAHITO.healRecovery;wind=strike=L.heal;}
  if(a.kind===6){startup=MAHITO.touchStartup;hold=MAHITO.touchActive;recovery=MAHITO.touchRecovery;wind=L.touchWind;strike=L.touch;}
  const gather=startup*.55;if(age<gather)mahitoMotionMix(p,L.idle,wind,age/gather);else if(age<startup)mahitoMotionMix(p,wind,strike,(age-gather)/(startup-gather),true);else if(age<startup+hold)p.set(strike);else mahitoMotionMix(p,strike,L.idle,(age-startup-hold)/recovery);if(a.kind===3)p[NP.bob]+=2.1*narutoEase(age/MAHITO.trainStartup)*(1-narutoEase((age-MAHITO.trainStartup-MAHITO.trainTime)/MAHITO.trainRecovery));if(a.kind===4)p[NP.bob]+=Math.sin(time*4)*.014;active=true;
 }else if(f.attack>0&&f.attackIsLight&&f.mahitoArm===2){const t=1-Math.max(0,f.attack-(mode==='online'&&net?.role==='guest'?narutoReplicaAge:0))/f.attackMax,wind=f.mahitoArm===3?L.hammerWind:f.mahitoArm===2?L.gunWind:L.bladeWind,strike=f.mahitoArm===3?L.hammer:f.mahitoArm===2?L.gun:L.blade,c=MAHITO_MOTION;
  if(t<c.windup)mahitoMotionMix(p,L.idle,wind,t/c.windup);else if(t<c.contact)mahitoMotionMix(p,wind,strike,(t-c.windup)/(c.contact-c.windup),true);else if(t<c.settle)p.set(strike);else mahitoMotionMix(p,strike,L.idle,(t-c.settle)/(1-c.settle));
  if(f.mahitoArm===1&&f.combo%2){const x=p[NP.lx],y=p[NP.ly],z=p[NP.lz],e=p[NP.le];p[NP.lx]=p[NP.rx];p[NP.ly]=-p[NP.ry];p[NP.lz]=-p[NP.rz];p[NP.le]=p[NP.re];p[NP.rx]=x;p[NP.ry]=-y;p[NP.rz]=-z;p[NP.re]=e;p[NP.twist]*=-1;}active=true;
 }else if(domainPresentationCast(f)){p.set(L.domain);p[NP.bob]=Math.sin(time*3)*.008;active=true;}
 else if(!moving&&f.grounded&&!f.flying&&!f.block&&!f.energyCharging&&f.attack<=0&&!(f.rosterAnim?.land>0)){p.set(L.idle);p[NP.bob]=Math.sin(time*2.3)*.018;p[NP.lz]+=.012*Math.sin(time*2.3);active=true;}
 return active?p:null;
}
