// Presentation only: damage and collision remain in the host simulation.
// Stable identities keep charged techniques and projectiles intact between snapshots.
const LIMITLESS_OUTPUT={
 blue:{aimLag:.10,steer:22,sweepSteer:26,speed:24,sweepSpeedMin:46,sweepSpeedMax:58,arrivalBrake:.08,travelMin:26,travelMax:40,sweepTime:6,holdTime:3,visualMin:.72,visualMax:1.9,particles:240,particlesLow:96,particleColor:0x197dff,particleAccent:0x48b4ff},
 red:{visualMin:1.05,visualMax:1.75,impactScale:1.35},
 purple:{visualMin:1.45,visualMax:3.3,impactMin:5.5,impactMax:10.5}
};
let techniqueSerial=0;
const techniqueRigs=new Map();
const vfxVertex=`varying vec2 vUv;varying vec3 vP,vN,vView;void main(){vUv=uv;vP=position;vN=normalMatrix*normal;vec4 mv=modelViewMatrix*vec4(position,1.);vView=-mv.xyz;gl_Position=projectionMatrix*mv;}`;
function effectMaterial(color,fragment,extra={}){
 return new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,
  uniforms:{uTime:{value:0},uStrength:{value:1},uFade:{value:1},uColor:{value:new THREE.Color(color)}},vertexShader:vfxVertex,
  fragmentShader:`varying vec2 vUv;varying vec3 vP,vN,vView;uniform float uTime,uStrength,uFade;uniform vec3 uColor;${domainNoise}${fragment}`,...extra});
}
function energySkin(color){return effectMaterial(color,`
 void main(){float rim=pow(1.-abs(dot(normalize(vN),normalize(vView))),2.6);float n=fbm(vP*4.-vec3(0.,uTime*.8,0.));float veins=pow(1.-abs(sin(n*16.+vP.y*9.-uTime*2.)),18.);float a=(rim*.74+veins*.24)*uFade;gl_FragColor=vec4(uColor*(.65+rim*1.7)+vec3(.8,.86,1.)*veins*1.3,a);}`);}
function flameMaterial(){return effectMaterial(0xff721f,`
 void main(){vec2 p=vec2(vUv.x*2.-1.,vUv.y);float n=fbm(vec3(p.x*3.,p.y*5.-uTime*3.7,uTime*.13));float lace=fbm(vec3(p.x*8.+n*2.,p.y*11.-uTime*6.,uTime*.19));float taper=(1.-pow(p.y,.65))*.87;float tongue=taper+(n-.4)*.65;float shape=1.-smoothstep(tongue-.13,tongue+.07,abs(p.x+sin(p.y*9.-uTime*4.)*.055));float fade=(1.-smoothstep(.55,1.,p.y))*smoothstep(0.,.04,p.y);float heat=clamp((1.-p.y)*.72+lace*.4-abs(p.x)*.5,0.,1.);vec3 c=mix(vec3(.75,.014,.001),vec3(1.8,.31,.014),smoothstep(.05,.5,heat));c=mix(c,vec3(2.7,1.8,.65),smoothstep(.57,.94,heat));float alpha=shape*fade*(.3+lace*.8)*uFade;if(alpha<.015)discard;gl_FragColor=vec4(c,alpha);}`);}
function flameColumn(parent,width=1,height=3){
 const g=new THREE.Group(),mat=flameMaterial(),geometry=new THREE.PlaneGeometry(2,2,1,1);geometry.translate(0,1,0);parent.add(g);
 for(let i=0;i<3;i++){const m=mesh(geometry,mat,g);m.rotation.y=i*Math.PI/3;m.scale.set(width,height*.5,1);}return {g,mat};
}
function arcStrip(parent,color,{radius=1,start=0,length=Math.PI*1.5,width=.04,helix=0}={}){
 const vertices=[],n=64;
 for(let i=0;i<n;i++){
  const point=(j,s)=>{const q=j/n,a=start+q*length,r=radius+s*width*Math.sin(Math.PI*q);return [Math.cos(a)*r,Math.sin(a)*r,helix*(q-.5)];};
  vertices.push(...point(i,-1),...point(i+1,-1),...point(i,1),...point(i+1,-1),...point(i+1,1),...point(i,1));
 }
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
 return mesh(geometry,new THREE.MeshBasicMaterial({color,transparent:true,opacity:.8,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}),parent);
}
function boltField(parent,color,count=24){
 const vertices=[];
 for(let i=0;i<count;i++){
  const a=i/count*Math.PI*2,dir=V(Math.cos(a),domainHash(i+390)*.55-.08,Math.sin(a)),side=V(-dir.z,.3,dir.x);let previous=V();
  for(let j=1;j<=9;j++){const p=dir.clone().multiplyScalar(j/9).addScaledVector(side,(domainHash(i*17+j)-.5)*.09);vertices.push(...previous.toArray(),...p.toArray());previous=p;}
 }
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
 const line=new THREE.LineSegments(g,new THREE.LineBasicMaterial({color,transparent:true,opacity:.75,depthWrite:false,blending:THREE.AdditiveBlending}));parent.add(line);return line;
}
// A shader-driven pool gives each technique a dense particle field without allocating
// particles every frame. Blue flows inward, Red bursts outward, and Purple braids both.
function limitlessCloud(parent,color,accent,count=120,mode='blue'){
 const geometry=new THREE.BufferGeometry(),positions=new Float32Array(count*3),seeds=new Float32Array(count*4);
 for(let i=0;i<count;i++){seeds[i*4]=domainHash(i*17+11);seeds[i*4+1]=domainHash(i*29+37);seeds[i*4+2]=domainHash(i*43+71);seeds[i*4+3]=domainHash(i*61+109);}
 geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));geometry.setAttribute('aSeed',new THREE.BufferAttribute(seeds,4));
 const modeId=mode==='red'?1:mode==='purple'?2:0;
 const material=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,toneMapped:false,
  uniforms:{uTime:{value:0},uPower:{value:1},uColor:{value:new THREE.Color(color)},uAccent:{value:new THREE.Color(accent)}},
  vertexShader:`attribute vec4 aSeed;uniform float uTime,uPower;varying float vAlpha,vTone;const float TAU=6.28318530718;
   void main(){float phase=fract(aSeed.x+uTime*mix(.19,.48,aSeed.w));float angle=aSeed.y*TAU+uTime*mix(1.4,4.8,aSeed.z);float polar=acos(clamp(aSeed.z*2.-1.,-1.,1.));vec3 p;
    if(${modeId}==0){float r=mix(4.8,.08,pow(phase,.68));angle+=(1.-phase)*6.5;p=vec3(cos(angle)*sin(polar),cos(polar),sin(angle)*sin(polar))*r;p.y+=sin(angle*2.+uTime*3.)*.18*r;vAlpha=sin(phase*3.14159);}
    else if(${modeId}==1){float r=.1+pow(phase,.72)*5.2;p=vec3(cos(angle)*sin(polar),cos(polar),sin(angle)*sin(polar))*r;p.z+=phase*1.1;vAlpha=pow(1.-phase,.55);}
    else{float braid=aSeed.w>.5?1.:-1.;float z=mix(-5.8,1.25,phase);float r=(.18+(1.-phase)*1.65)*mix(.55,1.,aSeed.z);angle+=braid*uTime*2.7+z*.72;p=vec3(cos(angle)*r,sin(angle)*r,z);vAlpha=sin(phase*3.14159)*.9+.1;}
    vTone=aSeed.w;vec4 mv=modelViewMatrix*vec4(p,1.);gl_Position=projectionMatrix*mv;gl_PointSize=clamp((3.5+aSeed.z*8.)*uPower*180./max(1.,-mv.z),1.5,28.);}`,
  fragmentShader:`uniform vec3 uColor,uAccent;varying float vAlpha,vTone;void main(){float r=length(gl_PointCoord-.5);if(r>.5)discard;float core=pow(max(0.,1.-r*2.),2.2),halo=pow(max(0.,1.-r*2.),.55);vec3 c=mix(uColor,uAccent,step(.62,vTone));gl_FragColor=vec4(c*(.85+core*2.4),vAlpha*(core*.72+halo*.28));}`});
 const points=new THREE.Points(geometry,material);points.frustumCulled=false;points.name='limitless-'+mode+'-particle-pool';parent.add(points);return points;
}
function limitlessShell(parent,color,scale=.9,opacity=.3){
 const shell=mesh(new THREE.SphereGeometry(1,32,22),energySkin(color),parent);shell.scale.setScalar(scale);shell.material.uniforms.uFade.value=opacity;return shell;
}
function cutBlade(parent,length=6,angle=0){
 const g=new THREE.Group();parent.add(g);g.rotation.z=angle;
 const shape=new THREE.BufferGeometry();shape.setAttribute('position',new THREE.Float32BufferAttribute([-1,0,0,-.1,-.11,0,1,0,0,-1,0,0,1,0,0,.1,.055,0],3));
 const edge=mesh(shape,new THREE.MeshBasicMaterial({color:0xffb8ad,side:THREE.DoubleSide,transparent:true,opacity:.7,depthWrite:false}),g,V(0,0,-.004),V(length*.51,1.8,1));
 const core=mesh(shape,new THREE.MeshBasicMaterial({color:0x010003,side:THREE.DoubleSide,transparent:true,opacity:.98,depthWrite:false}),g,V(),V(length*.5,1,1));core.renderOrder=5;edge.renderOrder=4;
 return {g,core,edge};
}
function redMuzzlePosition(f,dir=aimFor(f)){
 f.root.position.copy(f.pos);f.root.updateMatrixWorld(true);
 return f.limbs[1].fingers[0].localToWorld(V(0,-.12,0)).addScaledVector(dir,.055);
}
function makeTechniqueRig(kind){
 const g=new THREE.Group();scene.add(g);g.name='technique-'+kind;const rig={kind,g,arcs:[],skins:[]};
 const color=kind==='blue'?C.blue:kind==='red'?C.red:C.purple;
 if(kind==='bombField'){
  rig.field=waveDisk(g,C.purple);rig.halo=mesh(new THREE.RingGeometry(.99,1,160),new THREE.MeshBasicMaterial({color:0xc8a3ff,transparent:true,opacity:.6,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}),g);rig.halo.rotation.x=-Math.PI/2;
 }else if(kind==='red'){
  rig.core=mesh(geo.sphere,new THREE.MeshBasicMaterial({color:0xfff8ec,toneMapped:false}),g,V(),V(.09,.09,.09));
  rig.core.visible=false;
  rig.skins.push(limitlessShell(g,C.red,.28,.62),limitlessShell(g,0xff9f68,.46,.22));
  for(let i=0;i<6;i++){const ring=arcStrip(g,i%3===2?0xfff4df:i%2?0xff8c55:C.red,{radius:.3+i*.105,length:Math.PI*(1.45+i*.11),start:i*1.37,width:.012+i*.005,helix:i%2?.28:-.18});ring.rotation.x=i*.61;rig.arcs.push(ring);}
  rig.cloud=limitlessCloud(g,C.red,0xffefd0,particleBudget<1000?52:132,'red');
  rig.bolts=boltField(g,0xffd2ac,particleBudget<1000?10:24);rig.bolts.scale.setScalar(1.5);
  rig.halo=glow(C.red,2.8,.72,g);rig.outerHalo=glow(0xff7a34,5.4,.2,g);
 }else if(kind==='furnace'){
  const hot=new THREE.MeshBasicMaterial({color:0xffe8b1,toneMapped:false});
  const shaft=mesh(new THREE.CylinderGeometry(.045,.09,3.8,8),hot,g,V(0,0,.3));shaft.rotation.x=Math.PI/2;
  const tip=mesh(new THREE.ConeGeometry(.21,.85,5),hot,g,V(0,0,2.6));tip.rotation.x=Math.PI/2;
  for(let i=0;i<3;i++){const fin=arcStrip(g,0xffb334,{radius:.45,start:0,length:Math.PI*.8,width:.11,helix:1.5});fin.rotation.z=i*Math.PI*2/3;fin.position.z=-1.3;rig.arcs.push(fin);}
  rig.flame=flameColumn(g,.58,4.5);rig.flame.g.rotation.x=-Math.PI/2;rig.flame.g.position.z=.8;
  rig.bow=new THREE.Group();g.add(rig.bow);rig.bow.name='divine-flame-bow';rig.bowFlames=[];
  const curve=new THREE.CatmullRomCurve3([V(0,-2.2,-.3),V(0,-1.85,.15),V(0,-1.2,.58),V(0,-.4,.25),V(0,0,.16),V(0,.4,.25),V(0,1.2,.58),V(0,1.85,.15),V(0,2.2,-.3)]);
  mesh(new THREE.TubeGeometry(curve,56,.11,6,false),new THREE.MeshBasicMaterial({color:0xff7b16}),rig.bow);
  mesh(new THREE.TubeGeometry(curve,56,.035,5,false),hot,rig.bow);
  for(const side of [-1,1])for(let i=0;i<5;i++){
   const y=side*(.52+i*.32),z=.28+Math.sin(i*.75)*.25,prong=mesh(new THREE.ConeGeometry(.14,.6+i*.07,5),hot,rig.bow,V(0,y,z));prong.rotation.x=side*-.6;
   const fire=flameColumn(rig.bow,.22,.85+i*.1);fire.g.position.set(0,y,z);fire.g.rotation.x=side*.5;rig.bowFlames.push(fire);
  }
  rig.bowRune=arcStrip(rig.bow,0xffc164,{radius:.47,length:Math.PI*2,width:.028});rig.bowRune.rotation.y=Math.PI/2;
  rig.string=new THREE.Line(new THREE.BufferGeometry().setFromPoints([V(0,2.2,-.3),V(0,0,-.8),V(0,-2.2,-.3)]),new THREE.LineBasicMaterial({color:0xfff4c6,transparent:true,opacity:.95}));g.add(rig.string);rig.halo=glow(0xff861a,3,.35,g);
  rig.arrowSkin=mesh(new THREE.ConeGeometry(.33,1.35,6),energySkin(0xff9626),g,V(0,0,2.5));rig.arrowSkin.rotation.x=Math.PI/2;rig.skins.push(rig.arrowSkin);

 }else if(kind==='slash'){
  rig.blades=[cutBlade(g,6,-.35),cutBlade(g,4,.13)];rig.blades[1].g.position.z=-.2;
 }else if(kind==='blue'||kind==='purple'){
  const purple=kind==='purple';
  rig.core=mesh(geo.sphere,new THREE.MeshBasicMaterial({color:purple?0xfff4ff:0xeaffff,toneMapped:false}),g,V(),V(purple ? .24:.2,purple ? .24:.2,purple ? .31:.2));
  rig.skins.push(limitlessShell(g,color,purple?1.02:.92,purple?.5:.44),limitlessShell(g,purple?0x5a22a5:0x063da9,purple?1.36:1.27,.2));
  const num=purple?8:7;
  for(let i=0;i<num;i++){
   const c=purple?(i%3===0?C.blue:i%3===1?C.red:i%4===2?0xfff5ff:C.purple):(i%3===2?0xe9fbff:i%2?0x1557cf:C.blue);
   const a=arcStrip(g,c,{radius:1.05+i*.19,start:i*1.43,length:Math.PI*(purple?2.2+i*.14:1.45+i*.1),width:.028+i*.006,helix:purple?(i%2?3.6:-3.6):i%2?.5:-.4});a.rotation.x=i*.67;rig.arcs.push(a);
  }
  rig.cloud=limitlessCloud(g,purple?C.purple:LIMITLESS_OUTPUT.blue.particleColor,purple?0xffeaff:LIMITLESS_OUTPUT.blue.particleAccent,purple?(particleBudget<1000?72:180):LIMITLESS_OUTPUT.blue.particles,kind);
  rig.bolts=boltField(g,purple?0xf4d7ff:0x9ceaff,particleBudget<1000?12:30);rig.bolts.scale.setScalar(purple?2.2:2.7);
  rig.halo=glow(color,purple?6.8:6.2,purple?.62:.58,g);rig.outerHalo=glow(purple?0x482278:0x071f66,purple?11:10,.28,g);
  rig.contours=[waveDisk(g,purple?C.purple:C.blue),waveDisk(g,purple?C.red:0xd9f8ff)];rig.contours[0].rotation.x=-Math.PI/2;rig.contours[1].rotation.y=Math.PI/2;
  if(purple){
   rig.lobes=[C.blue,C.red].map((c,i)=>{const s=new THREE.Group();g.add(s);const skin=limitlessShell(s,c,.38,.5);rig.skins.push(skin);const h=glow(c,2.2,.42,s);return {g:s,skin,h,side:i?1:-1};});
  }
 }else{
  const lens=mesh(new THREE.SphereGeometry(1,28,20),energySkin(color),g);rig.skins.push(lens);
  const num=kind==='fusion'?4:3;
  for(let i=0;i<num;i++){
   const a=arcStrip(g,kind==='fusion'?(i%2?C.red:C.blue):i===2?0xe3f7ff:color,{radius:1.3+i*.28,start:i*2,length:Math.PI*(kind==='purple'?3.4:1.6),width:.035+i*.009,helix:kind==='purple'?4:0});a.rotation.x=i*.8;rig.arcs.push(a);
  }
  if(kind==='fusion'){
   rig.satellites=[C.blue,C.red].map(c=>{const s=new THREE.Group();g.add(s);mesh(geo.sphere,new THREE.MeshBasicMaterial({color:c===C.blue?0x00050f:0x150003}),s,V(),V(.28,.28,.28));const skin=mesh(new THREE.SphereGeometry(.47,20,14),energySkin(c),s);rig.skins.push(skin);glow(c,2.3,.5,s);return s;});
   rig.bolts=boltField(g,0xdad3ff,particleBudget<1000?12:28);
  }
 }
 return rig;
}
function updateTechniqueRig(rig,data){
 const {g,kind}=rig,t=data.t||0,q=clamp(data.q||0,0,1),size=Math.max(.001,data.size??1);
 g.position.copy(data.p);g.quaternion.setFromUnitVectors(V(0,0,1),data.dir?data.dir.clone().normalize():V(0,0,1));g.scale.setScalar(size);
 for(const skin of rig.skins)skin.material.uniforms.uTime.value=t;
 if(rig.cloud){rig.cloud.material.uniforms.uTime.value=t;rig.cloud.material.uniforms.uPower.value=.72+q*.55;rig.cloud.geometry.setDrawRange(0,Math.max(12,Math.floor((particleBudget<1000?Math.min(rig.cloud.geometry.attributes.aSeed.count,kind==='purple'?72:kind==='blue'?LIMITLESS_OUTPUT.blue.particlesLow:52):rig.cloud.geometry.attributes.aSeed.count)*visualDensity(rig.g.position))));}
 for(let i=0;i<rig.arcs.length;i++){
  const a=rig.arcs[i];a.rotation.z=t*(i%2?-2.3:1.8)+i*1.7;a.material.opacity=.48+q*.32;
  if(kind==='fusion'){const progress=clamp(t/3,0,1),converge=1-THREE.MathUtils.smoothstep(progress,.2,.92);a.scale.setScalar(.7+converge*2.2);a.rotation.x=t*(i%2?1.1:-.8)+i*.7;a.material.color.set(progress>.84?0xdfc6ff:i%2?C.red:C.blue);}
 }
 if(kind==='bombField'){
  rig.field.material.uniforms.uTime.value=t;rig.field.material.uniforms.uFade.value=.22+clamp(t/3,0,1)*.4;rig.halo.material.opacity=.35+Math.sin(t*12)**2*.35;
 }else if(kind==='fusion'){
  const progress=clamp(t/3,0,1),converge=1-THREE.MathUtils.smoothstep(progress,.08,.94),a=t*(3+t*1.8),r=.15+converge*3.4;
  rig.satellites.forEach((s,i)=>{const angle=a+i*Math.PI;s.position.set(Math.cos(angle)*r,Math.sin(angle*1.3)*r*.4,Math.sin(angle)*r);s.scale.setScalar(.8+progress*.55);});
  rig.skins[0].scale.setScalar(.4+progress*1.4);rig.skins[0].material.uniforms.uFade.value=.38+progress*.45;
  rig.bolts.scale.setScalar(2+progress*5);rig.bolts.rotation.y=-t*.3;rig.bolts.material.opacity=progress*.48;
 }else if(kind==='red'){
  const pulse=.82+Math.sin(t*22)*.12;rig.core.scale.setScalar(.82+q*.32+Math.sin(t*31)*.07);rig.skins[0].scale.setScalar(.25+q*.11);rig.skins[1].scale.setScalar(.43+q*.2);
  rig.halo.material.opacity=.66+Math.sin(t*24)*.14;rig.halo.scale.setScalar(pulse);rig.outerHalo.material.opacity=.13+q*.13+Math.sin(t*11)**2*.08;rig.bolts.rotation.set(t*.7,-t*.95,t*.4);rig.bolts.material.opacity=.22+q*.35;
 }else if(kind==='furnace'){
  rig.flame.mat.uniforms.uTime.value=t;rig.flame.mat.uniforms.uFade.value=.65+q*.3;rig.bow.visible=rig.string.visible=!!data.charging;rig.bow.scale.setScalar(1);rig.bowRune.rotation.z=t*2;for(const f of rig.bowFlames){f.mat.uniforms.uTime.value=t;f.mat.uniforms.uFade.value=.6+q*.4;}const string=rig.string.geometry.attributes.position;string.setXYZ(1,0,0,-.55-(data.draw??q)*.85);string.needsUpdate=true;
  rig.flame.g.scale.setScalar(data.charging?.5+q*.55:1.1);rig.halo.material.opacity=.18+q*.16;
 }else if(kind==='slash'){
  rig.blades.forEach((b,i)=>b.g.scale.setScalar(i===1?.45+q*.4:1));
 }else if(kind==='blue'){
  const pulse=1+Math.sin(t*10)*.055,anchored=data.phase==='hold';rig.core.scale.setScalar(.84+Math.sin(t*28)*.09);rig.skins[0].scale.setScalar(1.04*pulse);rig.skins[1].scale.setScalar(1.42-pulse*.06);rig.skins[0].material.uniforms.uFade.value=.48;rig.skins[1].material.uniforms.uFade.value=.22;
  rig.halo.material.opacity=.54+Math.sin(t*12)*.09;rig.halo.scale.setScalar(pulse);rig.outerHalo.material.opacity=(anchored?.34:.22)+Math.sin(t*7)**2*.08;rig.outerHalo.scale.setScalar(1.05+Math.sin(t*5)*.06);rig.bolts.rotation.set(t*.38,-t*.55,t*.21);rig.bolts.material.opacity=.22+q*.28;
  rig.contours.forEach((w,i)=>{w.rotation.z=t*(i?1.25:-1.7);w.scale.setScalar(.74+i*.35+Math.sin(t*6+i)*.08);w.material.uniforms.uTime.value=t;w.material.uniforms.uFade.value=(anchored?.22:.13)+q*.08;});
 }else if(kind==='purple'){
  const pulse=1+Math.sin(t*13)*.045;rig.core.scale.set(.72*pulse,.72*pulse,1.22*pulse);rig.skins[0].scale.set(1.08,1.08,1.55);rig.skins[1].scale.set(1.4,1.4,1.92);rig.skins[0].material.uniforms.uFade.value=.52;rig.skins[1].material.uniforms.uFade.value=.21;
  rig.halo.material.opacity=.58+Math.sin(t*16)*.1;rig.outerHalo.material.opacity=.2+q*.12;rig.bolts.rotation.set(t*.8,-t*.64,t*.55);rig.bolts.material.opacity=.33+q*.28;rig.contours.forEach((w,i)=>{w.position.z=-.2-i*.38;w.scale.setScalar(.78+i*.42+Math.sin(t*7+i)*.07);w.rotation.z=t*(i?1.9:-2.2);w.material.uniforms.uTime.value=t;w.material.uniforms.uFade.value=.17+q*.11;});
  rig.lobes.forEach((l,i)=>{const a=t*4.1+i*Math.PI,r=.72+.1*Math.sin(t*7);l.g.position.set(Math.cos(a)*r,Math.sin(a)*r*.72,-.32);l.g.scale.setScalar(.72+q*.32);l.h.material.opacity=.28+q*.18;});
 }
}
function syncCombatVisuals(){
 const live=new Set(),guest=mode==='online'&&net?.role==='guest',active=phase==='play'||phase==='finish'||phase==='pause';
 const use=(key,kind,data)=>{live.add(key);let rig=techniqueRigs.get(key);if(rig?.kind!==kind){if(rig)removeObject(rig.g);rig=makeTechniqueRig(kind);techniqueRigs.set(key,rig);}updateTechniqueRig(rig,data);};
 const concealFire=o=>{if(!o)return;o.inner.visible=o.shell.visible=false;for(const m of [...o.rings,...o.arcs])m.visible=false;o.aura.material.opacity=.19;};
 const concealLimitless=o=>{if(!o)return;o.g.visible=false;};
 if(active){
  for(const [i,f]of bodies.entries())for(const ch of chargesFor(f)){
   const key='charge'+i+((ch.slot||0)?'-lower':'');const q=chargePower(ch),form=chargeFormation(f,ch),dir=aimFor(f),p=techniqueChargePosition(f,ch,dir);if(ch.orb||ch.o)(ch.orb||ch.o).g.visible=false;ch.satellites?.forEach(o=>o.g.visible=false);
   if(f.character==='sukuna'&&ch.kind===3){use(key,'furnace',{p,dir,q,t:chargeAge(ch),size:(.8+q*.25)*(.15+form*.85),draw:form*(.35+.65*q),charging:true});}
   else if(f.character==='gojo'&&ch.kind===2)use(key,'red',{p,dir,q,t:chargeAge(ch),size:lerp(LIMITLESS_OUTPUT.red.visualMin,LIMITLESS_OUTPUT.red.visualMax,q)*form});
   else if(f.character==='gojo'&&ch.kind<4){const scale=ch.kind===3?lerp(.55,1.55,q)*THREE.MathUtils.smoothstep(form,.45,1):lerp(.42,1.3,q)*form;use(key,['','blue','red','purple'][ch.kind],{p,dir,q,t:chargeAge(ch),size:scale});}
  }
  for(const blue of blues){concealLimitless(blue.o);use('blue'+blue.id,'blue',{p:blue.p,dir:blue.dir||V(0,0,1),q:blue.q,t:blue.age||time,phase:blue.phase,size:lerp(LIMITLESS_OUTPUT.blue.visualMin,LIMITLESS_OUTPUT.blue.visualMax,blue.q)});}
  for(const bomb of bombs){use('fusion'+bomb.id,'fusion',{p:bomb.p,q:bomb.q,t:bomb.t,size:1+bomb.q*.75});use('bombField'+bomb.id,'bombField',{p:bomb.p.clone().setY(.21),dir:V(0,0,1),q:bomb.q,t:bomb.t,size:bomb.radius});}
  const shots=guest?(replicaState?.projectiles||[]):projectiles;
  shots.forEach((p,i)=>{
   if(p.type.startsWith('naruto-'))return;
   const pos=guest?V(...p.p):p.p,dir=guest?V(...p.dir):p.dir,kind=p.type==='fire'?'furnace':p.type;
   if(kind==='furnace')concealFire(guest?replicas.get('projectile'+p.id):p.o);
   if(kind==='purple')concealLimitless(guest?replicas.get('projectile'+p.id):p.o);
   use('shot'+p.id,kind,{p:pos,dir,q:p.q,t:p.t,size:kind==='purple'?lerp(LIMITLESS_OUTPUT.purple.visualMin,LIMITLESS_OUTPUT.purple.visualMax,p.q):kind==='furnace'?.8+p.q*.55:.75+p.q*.45});
  });
 }
 for(const [key,rig]of techniqueRigs)if(!live.has(key)){removeObject(rig.g);techniqueRigs.delete(key);}
 syncStartupVisuals();
}
function clearCombatVisuals(){for(const rig of techniqueRigs.values())removeObject(rig.g);techniqueRigs.clear();clearStartupVisuals();}
function waveDisk(parent,color){
 const mat=effectMaterial(color,`
 void main(){vec2 p=vUv*2.-1.;float r=length(p);float n=fbm(vec3(p*5.,uTime*.4));float rim=exp(-abs(r-(.85+n*.05))*95.);float inner=pow(max(0.,1.-r),3.);float spokes=pow(abs(sin(atan(p.y,p.x)*19.+n*8.)),18.)*smoothstep(.35,.85,r)*(1.-smoothstep(.87,1.,r));gl_FragColor=vec4(uColor*(1.2+rim)+vec3(.85,.8,1.)*rim,(rim*.8+spokes*.13+inner*.035)*uFade);}`);
 const m=mesh(new THREE.PlaneGeometry(2,2),mat,parent);m.rotation.x=-Math.PI/2;return m;
}
function scorchDisk(parent){
 const mat=effectMaterial(0xff6f16,`
 void main(){vec2 p=vUv*2.-1.;float r=length(p),a=atan(p.y,p.x),n=fbm(vec3(p*7.,uTime*.08));float edge=(1.-smoothstep(.76,.99,r));float cracks=pow(1.-abs(sin(a*13.+n*7.+r*19.)),18.)*smoothstep(.13,.8,r);vec3 c=vec3(.012,.004,.003)+vec3(1.6,.14,.004)*cracks*(.55+.3*sin(uTime*4.+r*10.));gl_FragColor=vec4(c,edge*.83*uFade);}`,{blending:THREE.NormalBlending});
 const m=mesh(new THREE.PlaneGeometry(2,2),mat,parent);m.rotation.x=-Math.PI/2;return m;
}
function playCombatFX(kind,pos,radius=5,strength=1,dir=V(0,0,1)){
 netFX('vfx',[kind,pos.toArray(),radius,strength,dir.toArray()]);
 const g=new THREE.Group();scene.add(g);g.position.copy(pos);g.name='impact-'+kind;
 let max=1,update=()=>{};
 if(kind==='blueRelease'){
  max=.85;g.quaternion.setFromUnitVectors(V(0,0,1),dir);const core=mesh(geo.sphere,new THREE.MeshBasicMaterial({color:0xf2ffff,toneMapped:false,transparent:true}),g),skins=[limitlessShell(g,C.blue,1,.55),limitlessShell(g,0x123baf,1.48,.22)],cloud=limitlessCloud(g,LIMITLESS_OUTPUT.blue.particleColor,LIMITLESS_OUTPUT.blue.particleAccent,particleBudget<1000?64:150,'blue'),halo=glow(C.blue,radius*2.1,.72,g),outer=glow(0x09236e,radius*3.3,.28,g),rings=[];
  for(let i=0;i<5;i++){const a=arcStrip(g,i===4?0xf3ffff:i%2?0x0d49c5:C.blue,{radius:.65+i*.24,start:i*1.4,length:Math.PI*(1.35+i*.16),width:.02+i*.008,helix:i%2?.55:-.4});a.rotation.x=i*.7;rings.push(a);}
  update=t=>{const q=clamp(t/max,0,1),open=1-Math.exp(-t*18),fade=(1-q)**1.7;core.scale.setScalar(radius*(.08+.24*Math.sin(Math.min(1,t/.2)*Math.PI)));core.material.opacity=Math.max(0,1-t/.24);skins.forEach((s,i)=>{s.scale.setScalar(radius*(.12+open*(i?.55:.34)));s.material.uniforms.uTime.value=t;s.material.uniforms.uFade.value=fade*(i?.18:.48);});cloud.material.uniforms.uTime.value=t;cloud.material.uniforms.uPower.value=.9+strength*.45;cloud.scale.setScalar(radius*.52);rings.forEach((r,i)=>{r.scale.setScalar(radius*(.18+open*.42));r.rotation.z=t*(i%2?-4.2:3.5)+i;r.material.opacity=fade*(i===4?.9:.58);});halo.material.opacity=Math.max(0,1-t/.48)*.72;outer.material.opacity=fade*.24;};
 }else if(kind==='redBeam'){
  max=.42;g.quaternion.setFromUnitVectors(V(0,0,1),dir);const beams=[];for(const [i,c,w] of [[0,0xfff8df,.045],[1,C.red,.11],[2,0x7d061c,.22]]){const b=mesh(new THREE.CylinderGeometry(w,w,radius,8),new THREE.MeshBasicMaterial({color:c,transparent:true,opacity:i? .62:1,depthWrite:false,blending:THREE.AdditiveBlending,toneMapped:false}),g,V(0,0,radius*.5));b.rotation.x=Math.PI/2;beams.push(b);}const rings=[];for(let i=0;i<6;i++){const r=arcStrip(g,i%2?0xfff0d9:C.red,{radius:.18+i*.06,start:i,length:Math.PI*1.7,width:.012+i*.003});r.position.z=radius*(.08+i*.17);rings.push(r);}const halo=glow(C.red,3.2+strength*2,.55,g);halo.position.z=Math.min(radius,2.5);
  update=t=>{const q=t/max,fade=(1-q)**1.6;beams.forEach((b,i)=>{b.scale.setScalar(i===0?.75+fade*.4:.7+fade*.55);b.material.opacity=fade*(i===0?1:i===1?.62:.28);});rings.forEach((r,i)=>{r.scale.setScalar(1+q*(2.3+i*.12));r.rotation.z=t*(i%2?6:-7);r.material.opacity=fade*.8;});halo.material.opacity=fade*.5;};
 }else if(kind==='purpleRelease'){
  max=1.05;g.quaternion.setFromUnitVectors(V(0,0,1),dir);const core=mesh(geo.sphere,new THREE.MeshBasicMaterial({color:0xffffff,toneMapped:false,transparent:true}),g),skins=[limitlessShell(g,C.purple,1,.62),limitlessShell(g,0x321067,1.45,.22)],cloud=limitlessCloud(g,C.blue,C.red,particleBudget<1000?64:160,'purple'),halo=glow(C.purple,radius*2.2,.75,g),outer=glow(0x351071,radius*3.5,.28,g),rings=[];
  for(let i=0;i<7;i++){const a=arcStrip(g,i%3===0?C.blue:i%3===1?C.red:i===5?0xffffff:C.purple,{radius:.62+i*.2,start:i*1.2,length:Math.PI*(1.6+i*.17),width:.022+i*.006,helix:i%2?1.8:-1.8});a.rotation.x=i*.63;rings.push(a);}
  update=t=>{const q=clamp(t/max,0,1),open=1-Math.exp(-t*15),fade=(1-q)**1.45;core.scale.setScalar(radius*(.06+.18*Math.sin(Math.min(1,t/.26)*Math.PI)));core.material.opacity=Math.max(0,1-t/.34);skins.forEach((s,i)=>{s.scale.set(radius*(.12+open*(i?.46:.3)),radius*(.12+open*(i?.46:.3)),radius*(.16+open*(i?.67:.42)));s.material.uniforms.uTime.value=t;s.material.uniforms.uFade.value=fade*(i?.2:.52);});cloud.material.uniforms.uTime.value=t;cloud.material.uniforms.uPower.value=1+strength*.55;cloud.scale.setScalar(radius*.48);rings.forEach((r,i)=>{r.scale.setScalar(radius*(.13+open*.34));r.rotation.z=t*(i%2?-4.8:4.2)+i;r.material.opacity=fade*(i===5?.95:.62);});halo.material.opacity=Math.max(0,1-t/.58)*.72;outer.material.opacity=fade*.26;};
 }else if(kind==='purpleImpact'){
  max=1.45;g.quaternion.setFromUnitVectors(V(0,0,1),dir);const core=mesh(new THREE.IcosahedronGeometry(1,2),new THREE.MeshBasicMaterial({color:0xffffff,toneMapped:false,transparent:true,depthWrite:false}),g),skins=[limitlessShell(g,C.purple,1,.64),limitlessShell(g,0x351067,1.3,.24)],cloud=limitlessCloud(g,C.purple,0xffefff,particleBudget<1000?70:180,'red'),waves=[waveDisk(g,C.blue),waveDisk(g,C.red),waveDisk(g,0xf2ddff)],rings=[],bolts=boltField(g,0xf4dcff,particleBudget<1000?16:38),halo=glow(C.purple,radius*2.4,.85,g),outer=glow(0x35106e,radius*3.8,.3,g);
  waves[0].rotation.x=-Math.PI/2;waves[1].rotation.y=Math.PI/2;waves[2].rotation.set(-1.2,.5,0);for(let i=0;i<6;i++){const a=arcStrip(g,i%3===0?C.blue:i%3===1?C.red:0xf7eaff,{radius:.7+i*.23,start:i*1.5,length:Math.PI*(1.5+i*.15),width:.03+i*.009});a.rotation.x=i*.72;rings.push(a);}
  update=t=>{const q=clamp(t/max,0,1),front=1-Math.pow(1-clamp(t/.48,0,1),3),fade=(1-q)**1.7;core.scale.setScalar(radius*(.03+.28*Math.sin(Math.min(1,t/.28)*Math.PI)));core.material.opacity=Math.max(0,1-t/.35);skins.forEach((s,i)=>{s.scale.setScalar(radius*front*(i?.88:.68));s.material.uniforms.uTime.value=t;s.material.uniforms.uFade.value=fade*(i?.2:.52);});cloud.material.uniforms.uTime.value=t;cloud.material.uniforms.uPower.value=1.05+strength*.5;cloud.scale.setScalar(radius*.65);waves.forEach((w,i)=>{const a=clamp((t-i*.045)/.85,0,1);w.scale.setScalar(.08+radius*(1-Math.pow(1-a,3))*(1-i*.08));w.material.uniforms.uTime.value=t;w.material.uniforms.uFade.value=(1-a)**1.4*.66;});rings.forEach((r,i)=>{r.scale.setScalar(radius*(.08+front*(.55+i*.05)));r.rotation.z=t*(i%2?-3.7:4.1)+i;r.material.opacity=fade*.62;});bolts.scale.setScalar(radius*(.28+front*.75));bolts.rotation.z=t*2;bolts.material.opacity=Math.max(0,1-t/.62)*.72;halo.material.opacity=Math.max(0,1-t/.52)*.82;outer.material.opacity=fade*.25;};
 }else if(kind==='redMuzzle'){
  max=1.2;g.quaternion.setFromUnitVectors(V(0,0,1),dir);
  const core=mesh(geo.sphere,new THREE.MeshBasicMaterial({color:0xfff4e8,toneMapped:false}),g,V(),V(.075,.075,.075));
  const halo=glow(C.red,1,.9,g),rings=[0,1].map(i=>arcStrip(g,i?0xffd3c4:C.red,{radius:.19+i*.1,length:Math.PI*1.85,start:i*2,width:.012}));
  const sparks=[];for(let i=0;i<(particleBudget<1000?16:34);i++){const a=i*2.39996,r=.14+domainHash(i+5)*.55;const s=mesh(geo.lowSphere,new THREE.MeshBasicMaterial({color:i%4?C.red:0xffe4d5,toneMapped:false,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending}),g,V(Math.cos(a)*r,Math.sin(a)*r,domainHash(i+31)*.65));s.scale.set(.016,.016,.07);sparks.push({m:s,a,r,depth:s.position.z});}
  update=t=>{const fade=Math.pow(1-t/max,1.5);core.scale.setScalar(.075*Math.max(0,1-t/.16));halo.material.opacity=Math.max(0,1-t/.24)*.9;rings.forEach((r,i)=>{r.scale.setScalar(1+t*3);r.rotation.z=t*(i?2:-2);r.material.opacity=Math.max(0,1-t/.38)*.8;});for(const s of sparks){s.m.position.set(Math.cos(s.a+t*.7)*s.r*(1+t*.5),Math.sin(s.a+t*.7)*s.r+t*.2,s.depth+t*.23);s.m.material.opacity=fade*(.55+.45*Math.sin(t*28+s.a)**2);}};
 }else if(kind==='red'){
  max=.86;const compact=Math.max(2.4,radius*LIMITLESS_OUTPUT.red.impactScale);g.quaternion.setFromUnitVectors(V(0,0,1),dir);
  const core=mesh(new THREE.IcosahedronGeometry(1,2),new THREE.MeshBasicMaterial({color:0xffeddd,toneMapped:false,transparent:true,depthWrite:false}),g);
  const skin=mesh(new THREE.SphereGeometry(1,28,20),energySkin(C.red),g),halo=glow(C.red,compact*2.8,1,g);
  const ring=arcStrip(g,C.red,{radius:1,length:Math.PI*2,width:.09}),whiteRing=arcStrip(g,0xffeee0,{radius:1,length:Math.PI*2,width:.028}),bolts=boltField(g,0xffbaa2,particleBudget<1000?12:26),waves=[waveDisk(g,C.red),waveDisk(g,0xffc5a9),waveDisk(g,C.red)],cloud=limitlessCloud(g,C.red,0xffefdc,particleBudget<1000?54:140,'red'),outer=glow(0x7b071d,compact*4,.28,g);waves[0].rotation.x=-Math.PI/2;waves[1].rotation.y=Math.PI/2;waves[2].rotation.set(-1.1,.5,0);
  update=t=>{const pop=Math.sin(clamp(t/.24,0,1)*Math.PI),front=1-Math.exp(-t*24),fade=Math.max(0,1-t/max);core.scale.setScalar(.035+compact*.46*pop);core.material.opacity=Math.max(0,1-t/.27);skin.scale.setScalar(.08+compact*front*(.75+.12*Math.sin(t*60)));skin.material.uniforms.uTime.value=t;skin.material.uniforms.uFade.value=fade**2;ring.scale.setScalar(.08+compact*1.15*front);ring.material.opacity=Math.max(0,1-t/.48);whiteRing.scale.setScalar(.08+compact*.82*front);whiteRing.material.opacity=Math.max(0,1-t/.25);bolts.scale.setScalar(compact*1.3);bolts.rotation.z=t*1.7;bolts.material.opacity=Math.max(0,1-t/.36);waves.forEach((w,i)=>{const a=clamp((t-i*.035)/.62,0,1);w.scale.setScalar(.04+compact*(1-Math.pow(1-a,3))*(1-i*.1));w.material.uniforms.uTime.value=t;w.material.uniforms.uFade.value=(1-a)**1.5*.55;});cloud.material.uniforms.uTime.value=t;cloud.material.uniforms.uPower.value=.8+strength*.55;cloud.scale.setScalar(compact*.7);halo.material.opacity=Math.max(0,1-t/.36)*.9;outer.material.opacity=fade*.22;};
 }else if(kind==='airStep'){
  max=.4;g.position.y+=.12;const ring=waveDisk(g,0xfff0e8),halo=glow(0xffa68e,1.6,.35,g);
  const streaks=[0,1,2].map(i=>arcStrip(g,i?0xffc1b7:0xffffff,{radius:.45+i*.17,length:Math.PI*1.6,start:i*2,width:.018}));for(const s of streaks)s.rotation.x=-Math.PI/2;
  update=t=>{const q=t/max;ring.scale.setScalar(.16+q*1.45);ring.material.uniforms.uFade.value=(1-q)*.7;halo.material.opacity=(1-q)*.25;streaks.forEach((s,i)=>{s.scale.setScalar(.6+q*.8);s.position.y=-q*(.6+i*.15);s.material.opacity=(1-q)**2;});};
 }else if(kind==='launchImpact'){
  max=.7;const ring=waveDisk(g,0xc6d5df),dust=[];
  for(let i=0;i<(particleBudget<1000?6:12);i++){const a=i*2.39996,s=mesh(geo.lowSphere,new THREE.MeshBasicMaterial({color:i%2?0x758392:0xa0a6ac,transparent:true,opacity:.5,depthWrite:false}),g);dust.push({s,a,scale:.18+domainHash(i+17)*.22});}
  update=t=>{const q=t/max;ring.scale.setScalar(.1+radius*(1-Math.exp(-t*8)));ring.material.uniforms.uFade.value=(1-q)*.35;for(const d of dust){d.s.position.set(Math.cos(d.a)*t*radius*1.8,.08+Math.sin(q*Math.PI)*.5,Math.sin(d.a)*t*radius*1.8);d.s.scale.setScalar(d.scale*(1+q*2));d.s.material.opacity=(1-q)*.55;}};
 }else if(kind==='hollow'||kind==='furnaceBurst'){
  const hollow=kind==='hollow',color=hollow?C.purple:0xff8e24;max=hollow?2.6:1.65;
  const skin=mesh(new THREE.SphereGeometry(1,48,32),effectMaterial(color,`
   void main(){float rim=pow(1.-abs(dot(normalize(vN),normalize(vView))),3.2);float n=fbm(vP*6.-uTime*.8);float arcs=pow(1.-abs(sin(n*17.+vP.y*12.-uTime*3.)),22.);vec3 c=uColor*(.5+rim*2.5)+vec3(1.8,1.5,2.)*(rim*.4+arcs*.4);gl_FragColor=vec4(c,(rim*.63+arcs*.12)*uFade);}`),g);
  const waves=[waveDisk(g,color),waveDisk(g,hollow?0xded0ff:0xffefc4),waveDisk(g,color)];waves[1].rotation.x=-1.1;waves[2].rotation.set(-1.65,.22,0);
  const bolts=boltField(g,hollow?0xe2caff:0xffdab6,particleBudget<1000?14:36),halo=glow(color,radius*.75,.75,g);
  update=t=>{const q=clamp(t/max,0,1),front=1-Math.pow(1-clamp(t/(hollow?.9:.42),0,1),3);skin.scale.setScalar(Math.max(.03,radius*front));skin.material.uniforms.uTime.value=t;skin.material.uniforms.uFade.value=Math.pow(1-q,2);
   waves.forEach((w,i)=>{const a=clamp((t-i*.07)/(hollow?1.35:.65),0,1);w.scale.setScalar(.05+radius*(1-Math.pow(1-a,3))*(1-i*.09));w.material.uniforms.uTime.value=t;w.material.uniforms.uFade.value=Math.pow(1-a,1.4);});
   bolts.scale.setScalar(radius*(.25+front*.75));bolts.material.opacity=Math.max(0,1-t/(hollow?.8:.4))*.6;halo.scale.setScalar(radius*(.15+front*.65));halo.material.opacity=Math.max(0,1-t/.55)*.45;};
 }else if(kind==='furnace'){
  max=2.45;const floorGroup=new THREE.Group();g.add(floorGroup);floorGroup.position.y=.19-pos.y;
  const scar=scorchDisk(floorGroup),wave=waveDisk(floorGroup,0xffa12e);scar.scale.setScalar(radius*.75);
  const center=flameColumn(g,radius*.38,radius*2.6),rimFlames=[];
  const count=particleBudget<1000?6:12;
  for(let i=0;i<count;i++){const a=i/count*Math.PI*2,f=flameColumn(floorGroup,.75+strength*.35,2+domainHash(i+43)*3);f.g.position.set(Math.cos(a)*radius*.65,0,Math.sin(a)*radius*.65);rimFlames.push(f);}
  const halo=glow(0xff791b,radius*1.4,.5,g);
  update=t=>{const q=t/max,up=THREE.MathUtils.smoothstep(t,0,.14),fall=1-THREE.MathUtils.smoothstep(t,.3,1.4);center.g.scale.set(up*(.5+fall*.5),up*(.3+fall*.7),up*(.5+fall*.5));center.mat.uniforms.uTime.value=t;center.mat.uniforms.uFade.value=fall;
   for(const f of rimFlames){f.mat.uniforms.uTime.value=t;f.mat.uniforms.uFade.value=1-THREE.MathUtils.smoothstep(t,1.4,2.4);}
   scar.material.uniforms.uTime.value=t;scar.material.uniforms.uFade.value=1-THREE.MathUtils.smoothstep(t,1.9,2.45);wave.scale.setScalar(.1+radius*(1-Math.pow(1-clamp(t/.8,0,1),3)));wave.material.uniforms.uFade.value=Math.max(0,1-t/.85);halo.material.opacity=Math.max(0,1-t/1.1)*.42;};
 }else if(kind==='cleave'){
  max=.35;g.quaternion.setFromUnitVectors(V(0,0,1),dir);const cuts=[cutBlade(g,radius*2,.67),cutBlade(g,radius*2,-.56),cutBlade(g,radius*1.5,.07)];
  update=t=>{const q=t/max;cuts.forEach((c,i)=>{c.g.scale.x=clamp((t-i*.02)*28,0,1);c.core.material.opacity=(1-q)*.98;c.edge.material.opacity=(1-q)*.6;});};
 }else if(kind==='warp'){
  max=.5;g.quaternion.setFromUnitVectors(V(0,0,1),dir);const rings=[],rails=[];
  for(let i=0;i<9;i++){const a=arcStrip(g,i%2?0xdcefff:C.mint,{radius:.95,length:Math.PI*1.8,start:i*.7,width:.024});a.position.z=radius*i/8;rings.push(a);}
  for(let i=0;i<8;i++){
   const a=i*Math.PI/4,points=[];for(let j=0;j<=24;j++){const u=j/24,r=.25+Math.sin(u*Math.PI)*1.1;points.push(V(Math.cos(a+u*.65)*r,Math.sin(a+u*.65)*r,radius*u));}
   const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color:i%2?0xaad5ff:0xdefaff,transparent:true,opacity:.6,blending:THREE.AdditiveBlending,depthWrite:false}));g.add(line);rails.push(line);
  }
  update=t=>{const q=t/max,compress=THREE.MathUtils.smoothstep(q,0,.85);rings.forEach((a,i)=>{const r=.1+Math.sin(Math.PI*clamp(q*1.8-i*.045,0,1))*.9;a.scale.set(r,r,1);a.position.z=radius*lerp(i/8,1,compress*.76);a.rotation.z=i*.7+q*2;a.material.opacity=(1-q)**1.7*.65;});for(const l of rails){l.scale.set(1-compress*.9,1-compress*.9,1);l.material.opacity=(1-q)**2*.65;}};
 }else if(kind==='teleport'){
  max=.4;g.quaternion.setFromUnitVectors(V(0,0,1),dir);const arcs=[0,1,2,3].map(i=>arcStrip(g,i%2?0xe7f6ff:C.mint,{radius:1+i*.16,length:Math.PI*1.85,start:i*1.7,width:.022}));
  const lens=mesh(new THREE.SphereGeometry(1,24,16),energySkin(C.mint),g);lens.scale.set(1,1,.12);
  update=t=>{const q=t/max,squeeze=Math.max(.03,1-THREE.MathUtils.smoothstep(q,0,.75));arcs.forEach((a,i)=>{a.scale.set(squeeze*(1+i*.12),.35+squeeze*.95,1);a.rotation.z=q*1.7+i*1.6;a.material.opacity=(1-q)*.65;});lens.scale.set(squeeze,1.2*squeeze,.08);lens.material.uniforms.uTime.value=t;lens.material.uniforms.uFade.value=(1-q)*.4;};

 }
 update(0);effects.push({m:g,type:'technique',t:0,max,update});return g;
}

// Additional layers use the same domain uniforms and world origin as the realm.
function enrichDomain(v){
 const accents=[];
 if(v.hole){
  for(let i=0;i<3;i++){const a=arcStrip(v.hole,i===0?0xf1eeff:0x82c7ff,{radius:6.8+i*1.45,start:i*2,length:Math.PI*1.7,width:.025+i*.015});a.rotation.x=.75+i*.27;accents.push(a);}
 }
 if(v.temple){
  const circle=mesh(new THREE.SphereGeometry(DOMAIN_ENCLOSURE.radius-.65,48,32),new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,uniforms:v.uniforms,vertexShader:'varying vec2 uv0;varying vec3 world;void main(){uv0=uv;world=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:`varying vec2 uv0;varying vec3 world;uniform float uAge,uTime,uMode,uBalance,uEnd;uniform vec3 uOrigin,uAxis;${domainNoise}
   void main(){vec3 ray=normalize(world-uOrigin-vec3(0.,1.45,0.));vec2 p=vec2(atan(ray.x,ray.z)/3.14159,asin(clamp(ray.y,-1.,1.))/1.5708);float r=abs(p.y),a=p.x*3.14159;float n=fbm(vec3(p*8.,uTime*.04));float cut=pow(1.-abs(sin(a*19.+r*24.+n*5.)),34.);float ring=exp(-abs(r-.52)*250.);float side=uMode>1.5?smoothstep(-2.,2.,dot(world-uOrigin,vec3(-uAxis.z,0.,uAxis.x))-uBalance*30.):1.;float grow=smoothstep(0.,.5,uAge);float alpha=(cut*.33+ring*.33)*(.6+.4*cos(r*3.14159))*side*grow*uEnd;gl_FragColor=vec4(mix(vec3(.008,.001,.003),vec3(.68,.025,.012),ring),alpha);}`}),domainVisual,v.origin.clone().add(V(0,1.45,0)));v.sigil=circle;
 }
 v.accents=accents;
}
function animateDomainAccents(v,age,reveal,ending){
 for(let i=0;i<(v.accents?.length||0);i++){const a=v.accents[i];a.rotation.z=age*(i%2?.12:-.08)+i*2;a.material.opacity=reveal*ending*(i===0?.6:.25);}
}
