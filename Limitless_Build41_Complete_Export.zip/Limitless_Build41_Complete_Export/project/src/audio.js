// Layered, positional sound. The supplied clash recording stays on its own bus.
(() => {
  const BATTLE_AUDIO={tempo:100,beats:16,rate:22050,duck:.34,voiceDuck:.22,attack:.025,release:.28,musicBlend:.45,maxOrdinary:32,maxPriority:12,criticalHealth:.25,base:.28,combat:.48,critical:.25,clash:.38,ultimate:.48};
  class ArenaAudio {
    constructor(assets = {}) {
      this.assets = assets; this.enabled = true; this.activeClash = false;
      this.volumes = {master:.72, effects:.8, music:.65, recordings:.78}; this.voices = []; this.cooldowns = {};
      this.clips = new Map(); this.cues = new Map(); this.shotSerial = 0;this.priorityUntil=0;this.priorityDepth=0;this.ordinaryVoices=0;this.priorityVoices=0;this.scoreBuffers=null;this.scoreNodes=null;this.scoreTargets=[0,0,0,0];
      try { Object.assign(this.volumes, JSON.parse(localStorage.getItem('limitless.audio.v3') || '{}')); } catch {}
      for (const k of Object.keys(this.volumes)) this.volumes[k] = Math.max(0, Math.min(1, Number(this.volumes[k]) || 0));
    }
    async unlock() {
      try {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return;
        if (!this.ctx) {
          const c = this.ctx = new Ctx();
          this.master = c.createGain(); this.fx = c.createGain(); this.music = c.createGain(); this.recordings = c.createGain();
          const compressor = c.createDynamicsCompressor();
          compressor.threshold.value = -12; compressor.knee.value = 18; compressor.ratio.value = 5;
          compressor.attack.value = .003; compressor.release.value = .2;
          this.fxBed=c.createGain();this.fxBed.connect(this.fx);this.fx.connect(this.master); this.music.connect(this.master); this.recordings.connect(this.master); this.master.connect(compressor); compressor.connect(c.destination);
          const length = Math.floor(c.sampleRate * 1.5), impulse = c.createBuffer(2, length, c.sampleRate);
          for (let ch=0; ch<2; ch++) { const a=impulse.getChannelData(ch); for(let i=0;i<length;i++) a[i]=(Math.random()*2-1)*Math.pow(1-i/length,3)*.35; }
          this.reverb = c.createConvolver(); this.reverb.buffer = impulse;
          const wet = c.createGain(); wet.gain.value = .15; this.reverb.connect(wet); wet.connect(this.fxBed);
          this.noise = c.createBuffer(1, c.sampleRate * 2, c.sampleRate);
          const n=this.noise.getChannelData(0); for(let i=0;i<n.length;i++)n[i]=Math.random()*2-1;
          this.applyVolumes();
          for (const key of ['clash','sukunaDomain','hollowNuke','gojoCast','sukunaCast','gojoTheme']) if (this.assets[key]) this.decodeClip(key);
        }
        if (this.ctx.state === 'suspended') await this.ctx.resume();
        if (this.activeClash && this.buffer && !this.loopRunning) this.startLoop();
        for (const cue of this.cues.values()) this.startCue(cue);
      } catch { this.failed = true; }
    }
    async decodeClip(key='clash') {
      try {
        const bytes = Uint8Array.from(atob(this.assets[key].split(',')[1]), c=>c.charCodeAt(0));
        const buffer = await this.ctx.decodeAudioData(bytes.buffer); this.clips.set(key,buffer);
        if(key==='clash'){this.buffer=buffer;if(this.activeClash)this.startLoop();}
        for(const cue of this.cues.values()) if(cue.clip===key)this.startCue(cue);
      } catch { this.clipFailed = true; }
    }
    applyVolumes() {
      if (!this.ctx) return;
      const t=this.ctx.currentTime;
      this.master.gain.setTargetAtTime(this.enabled?this.volumes.master:0,t,.03);
      this.fx.gain.setTargetAtTime(this.volumes.effects,t,.03);
      this.music.gain.setTargetAtTime(this.volumes.music,t,.03);
      this.recordings.gain.setTargetAtTime(this.volumes.recordings,t,.03);
    }
    setVolume(bus, value) {
      if (!(bus in this.volumes)) return;
      this.volumes[bus]=Math.max(0,Math.min(1,Number(value)||0)); this.applyVolumes();
      try { localStorage.setItem('limitless.audio.v3',JSON.stringify(this.volumes)); } catch {}
    }
    setEnabled(v) {this.enabled=!!v;this.applyVolumes();if(!this.enabled)this.stopScore();}
    // Tokens are simulation identities. Repeated snapshots never restart a recording.
    syncCue(channel,clip,token,age=0,{duration=Infinity,level=.8,bus='recordings'}={}) {
      if(this.cues.get(channel)?.token===token)return;
      this.stopCue(channel,.12);
      const cue={channel,clip,token,age:Math.max(0,age),at:this.ctx?.currentTime||0,duration,level,bus,started:false};
      this.cues.set(channel,cue);this.startCue(cue);
    }
    startCue(cue) {
      if(cue.started||!this.ctx||this.ctx.state!=='running'||this.cues.get(cue.channel)!==cue)return;
      const buffer=this.clips.get(cue.clip);if(!buffer)return;
      const c=this.ctx,age=cue.age+Math.max(0,c.currentTime-cue.at),end=Math.min(buffer.duration,cue.duration);
      cue.started=true;if(age>=end)return;
      const s=c.createBufferSource(),g=c.createGain(),mix=c.createGain(),t=c.currentTime+.006,remaining=end-age,fade=Math.min(.28,remaining*.35);
      s.buffer=buffer;s.connect(g);g.connect(mix);mix.connect(cue.bus==='music'?this.music:this.recordings);mix.gain.value=cue.duck??1;
      g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(cue.level,t+Math.min(.025,remaining*.1));g.gain.setValueAtTime(cue.level,t+remaining-fade);g.gain.linearRampToValueAtTime(0,t+remaining);
      cue.s=s;cue.g=g;cue.mix=mix;s.start(t,age);s.stop(t+remaining+.02);
      s.onended=()=>{s.disconnect();g.disconnect();mix.disconnect();cue.s=null;cue.g=null;cue.mix=null;};
    }
    duckCue(channel,level=1){const cue=this.cues.get(channel);if(!cue)return;cue.duck=level;if(cue.mix&&this.ctx)cue.mix.gain.setTargetAtTime(level,this.ctx.currentTime,.15);}
    stopCue(channel,fade=.22) {
      const cue=this.cues.get(channel);this.cues.delete(channel);if(!cue?.s||!this.ctx)return;
      const t=this.ctx.currentTime;try{cue.g.gain.cancelScheduledValues(t);cue.g.gain.setValueAtTime(cue.g.gain.value,t);cue.g.gain.linearRampToValueAtTime(0,t+fade);cue.s.stop(t+fade+.02);}catch{}
    }
    stopCues() {for(const channel of Array.from(this.cues.keys()))this.stopCue(channel,.12);}
    setClash(active) {
      active=!!active; if(active===this.activeClash)return;
      this.activeClash=active;
      if(active){if(this.buffer)this.startLoop();}
      else this.stopLoop();
    }
    startLoop() {
      if(this.loopRunning||!this.ctx||!this.buffer||!this.activeClash)return;
      this.loopRunning=true;this.nextLoop=this.ctx.currentTime+.035;this.scheduleLoop();
    }
    scheduleLoop() {
      if(!this.loopRunning)return;
      const c=this.ctx, t=this.nextLoop, fade=.65, duration=this.buffer.duration;
      const s=c.createBufferSource(),g=c.createGain(),mix=c.createGain();s.buffer=this.buffer;s.connect(g);g.connect(mix);mix.connect(this.music);mix.gain.value=1;
      g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(1,t+fade);g.gain.setValueAtTime(1,t+duration-fade);g.gain.linearRampToValueAtTime(0,t+duration);
      s.start(t);s.stop(t+duration+.03);const voice={s,g,mix};this.voices.push(voice);
      s.onended=()=>{s.disconnect();g.disconnect();mix.disconnect();this.voices=this.voices.filter(v=>v!==voice);};
      this.nextLoop=t+duration-fade;
      this.loopTimer=setTimeout(()=>this.scheduleLoop(),Math.max(100,(this.nextLoop-c.currentTime-.25)*1000));
    }
    stopLoop() {
      this.loopRunning=false;clearTimeout(this.loopTimer);
      if(!this.ctx)return;
      const t=this.ctx.currentTime;
      for(const {s,g} of this.voices){try {g.gain.cancelScheduledValues(t);g.gain.setValueAtTime(g.gain.value,t);g.gain.linearRampToValueAtTime(0,t+.6);s.stop(t+.65);}catch{}}
      this.voices=[];
    }
    output(pan=0, amount=1) {
      const c=this.ctx,g=c.createGain();g.gain.value=amount;g._priority=!!this.priorityDepth;const bus=g._priority?this.fx:this.fxBed;if(g._priority)this.priorityVoices++;else this.ordinaryVoices++;
      if(c.createStereoPanner){const p=c.createStereoPanner();p.pan.value=Math.max(-.9,Math.min(.9,pan));g.connect(p);p.connect(bus);g._pan=p;}else g.connect(bus);
      if(!g._priority)g.connect(this.reverb);return g;
    }
    tone(freq=200,duration=.2,type='sine',volume=.06,slide=.3,pan=0,delay=0) {
      if(!this.enabled||!this.ctx||this.ctx.state!=='running'||(this.priorityDepth?this.priorityVoices>=BATTLE_AUDIO.maxPriority:this.ordinaryVoices>=BATTLE_AUDIO.maxOrdinary))return;
      const c=this.ctx,t=c.currentTime+delay,o=c.createOscillator(),g=c.createGain(),out=this.output(pan);
      o.type=type;o.frequency.setValueAtTime(Math.max(20,freq),t);o.frequency.exponentialRampToValueAtTime(Math.max(20,freq*slide),t+duration);
      g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(volume,t+.008);g.gain.exponentialRampToValueAtTime(.0001,t+duration);
      o.connect(g);g.connect(out);o.start(t);o.stop(t+duration+.02);o.onended=()=>{o.disconnect();g.disconnect();out.disconnect();out._pan?.disconnect();if(out._priority)this.priorityVoices=Math.max(0,this.priorityVoices-1);else this.ordinaryVoices=Math.max(0,this.ordinaryVoices-1);};
    }
    hiss(duration=.2,freq=1000,volume=.08,pan=0,delay=0) {
      if(!this.enabled||!this.ctx||this.ctx.state!=='running'||(this.priorityDepth?this.priorityVoices>=BATTLE_AUDIO.maxPriority:this.ordinaryVoices>=BATTLE_AUDIO.maxOrdinary))return;
      const c=this.ctx,t=c.currentTime+delay,s=c.createBufferSource(),filter=c.createBiquadFilter(),g=c.createGain(),out=this.output(pan);
      s.buffer=this.noise;filter.type='bandpass';filter.frequency.setValueAtTime(freq,t);filter.frequency.exponentialRampToValueAtTime(Math.max(80,freq*.35),t+duration);filter.Q.value=.6;
      g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(volume,t+.008);g.gain.exponentialRampToValueAtTime(.0001,t+duration);
      s.connect(filter);filter.connect(g);g.connect(out);s.start(t,Math.random()*.4);s.stop(t+duration+.02);
      s.onended=()=>{s.disconnect();filter.disconnect();g.disconnect();out.disconnect();out._pan?.disconnect();if(out._priority)this.priorityVoices=Math.max(0,this.priorityVoices-1);else this.ordinaryVoices=Math.max(0,this.ordinaryVoices-1);};
    }
    play(name, strength=1, pan=0) {
      if(!this.enabled||!this.ctx)return;const now=this.ctx.currentTime;
      if(now<(this.cooldowns[name]||0))return;this.cooldowns[name]=now+(name==='step'?.15:name==='hit'?.055:.07);
      if(name==='hollowNuke'){this.priorityUntil=now+1.5;this.syncCue('nuke','hollowNuke','nuke-'+(++this.shotSerial),0,{level:.84});return;}
      this.priorityDepth=['parry','guard','hitFinish','hitHeavy','domain','narutoUltimate','fusion','burst','voidFinisher','shrineFinisher'].includes(name)?1:0;if(this.priorityDepth)this.priorityUntil=Math.max(this.priorityUntil,now+(name==='domain'?1.2:.4));
      const s=Math.max(.1,Math.min(1.6,strength)),T=(f,d,w,v,r=1,delay=0)=>this.tone(f,d,w,v*s,r,pan,delay),N=(d,f,v,delay=0)=>this.hiss(d,f,v*s,pan,delay);
      switch(name){
        case 'kuramaRumble': T(33,.58,'sine',.15,.82);T(51,.5,'triangle',.025,.9);N(.5,190,.055);break;
        case 'kuramaRoar': T(43,1.4,'sawtooth',.09,.38);T(68,1.1,'triangle',.085,.3);N(1.35,470,.24);N(.5,2400,.08,.15);break;
        case 'sealCrack': N(.12,3200,.2);T(110,.7,'triangle',.08,.3);N(.65,750,.09,.08);break;
        case 'mindscapeBreak': N(.85,4800,.16);T(80,.65,'sine',.16,.4);break;
        case 'mindscapeCollapse': N(.6,1100,.16);T(180,.65,'sawtooth',.045,.2);break;
        case 'narutoClone': N(.26,950,.14);N(.12,4300,.045,.05);break;
        case 'rasengan': T(140,.7,'sine',.075,3.2);T(290,.65,'triangle',.025,2.4);N(.55,3200,.045);break;
        case 'rasenganImpact': T(60,.5,'sine',.17,.4);N(.4,2200,.18);T(420,.3,'sine',.04,.25);break;
        case 'rasenshuriken': N(.75,5000,.14);T(640,.7,'sine',.035,1.7);N(.35,2000,.045,.12);break;
        case 'narutoUltimate': T(42,2.1,'sine',.14,2.2);T(90,2.0,'triangle',.04,3);N(1.9,1600,.07);break;
        case 'step': N(.08,750,.024);T(85,.065,'triangle',.026,.55);break;
        case 'airStep': N(.14,2900,.1);T(140,.12,'triangle',.085,.32);N(.1,6500,.03,.06);break;
        case 'launchImpact': T(48,.45,'sine',.17,.48);N(.34,750,.2);N(.18,3400,.11,.03);break;
        case 'light': N(.12,2100,.075);break;
        case 'hitKick': T(86,.19,'sine',.18,.32);N(.09,1900,.10);T(51,.24,'triangle',.04,.6);break;
        case 'hitFinish': T(64,.27,'sine',.22,.28);N(.065,2600,.15);N(.18,820,.09,.025);T(38,.34,'triangle',.045,.65);break;
        case 'hitHeavy': T(57,.32,'sine',.20,.32);N(.08,2100,.13);N(.22,610,.085,.02);break;
        case 'land': T(68,.15,'sine',.10,.4);N(.17,660,.08);break;
        case 'hit': T(120,.16,'sine',.19,.34);N(.13,1500,.14);T(48,.23,'triangle',.05,.7);break;
        case 'guard': T(730,.15,'triangle',.07,.45);T(1370,.23,'sine',.045,.98);N(.05,3900,.055);break;
        case 'parry': [880,1320,1760].forEach((f,i)=>T(f,.45,'sine',.05,1,i*.035));N(.18,6200,.09);break;
        case 'dodge': N(.25,3800,.06);T(390,.2,'sine',.035,.35);break;
        case 'blue': T(58,1.5,'sine',.17,1.2);T(230,1.2,'sine',.04,.5);N(.7,1700,.07);break;
        case 'red': N(.065,5900,.2);T(125,.13,'triangle',.1,.26);T(1800,.055,'sawtooth',.022,.12);N(.22,3600,.04,.045);break;
        case 'redImpact': T(52,.42,'sine',.2,.4);N(.24,2300,.22);T(105,.25,'triangle',.08,.5);break;
        case 'purple': T(48,1.7,'sine',.2,.7);T(144,1.4,'triangle',.07,1.9);N(1.1,2100,.2);break;
        case 'slash': N(.24,4600,.18);T(500,.18,'triangle',.04,.1);break;
        case 'fire': N(1.4,750,.28);T(62,1.2,'triangle',.16,.5);[0,.07,.19,.36].forEach(d=>N(.13,3600,.1,d));break;
        case 'furnaceImpact': T(38,1.8,'sine',.18,.62);N(1.9,520,.23);N(.35,2600,.16);[.2,.43,.7,1.1].forEach(d=>N(.13,3200,.035,d));break;
        case 'fusion': T(48,2.9,'sine',.09,1.8);T(170,2.85,'sine',.025,2.8);N(2.8,2200,.035);break;
        case 'teleport': [650,1150,1800].forEach((f,i)=>T(f,.25,'sine',.035,.4,i*.025));N(.25,6300,.08);break;
        case 'burst': T(42,1.5,'sine',.24,.55);N(1.4,1600,.27);N(.7,4500,.2,.12);break;
        case 'voidArrival': [110,165,330,660].forEach((f,i)=>T(f,2.2,'sine',.035,1.01,i*.035));N(1.4,6200,.065);break;
        case 'shrineCut': N(.095,2400,.085);N(.065,6200,.055,.025);T(72,.13,'triangle',.04,.6);break;
        case 'voidFinisher': T(52,3.3,'sine',.14,1.7);[220,330,495,742].forEach((f,i)=>T(f,2.8,'sine',.025,1.9,i*.18));N(2.8,4200,.075);break;
        case 'shrineFinisher': T(42,3.8,'sine',.16,.6);N(2.4,1200,.11);T(180,1.8,'triangle',.045,.3);break;
        case 'domain': T(48,2,'sine',.18,.85);[110,165,220].forEach((f,i)=>T(f,1.8,'triangle',.04,1,i*.05));N(1.2,3400,.12);break;
        case 'ui': T(540,.06,'sine',.035,1.5);break;
      }this.priorityDepth=0;
    }
    // Four original synchronized stems. Buffers are generated once, sources only on entering battle.
    prepareScore() {
      if(this.scoreBuffers)return;const a=BATTLE_AUDIO,beat=60/a.tempo,duration=beat*a.beats,length=Math.round(duration*a.rate);
      this.scoreDuration=duration;this.scoreBuffers=Array.from({length:4},()=>this.ctx.createBuffer(1,length,a.rate));
      const data=this.scoreBuffers.map(b=>b.getChannelData(0)),roots=[73.416,65.406,58.270,65.406],arp=[1,1.5,2,2.3784,2,1.5,1.3333,1.5];
      for(let i=0;i<length;i++){
        const t=i/a.rate,b=t/beat,bar=Math.floor(b/4),root=roots[bar%4],pulse=(b%1)*beat,eighth=(b*2%1)*beat*.5,barEnv=Math.sin(Math.PI*(b%4)/4)**2,seam=Math.min(1,t/.025,(duration-t)/.025),noise=Math.sin(i*127.1+311.7)*43758.5453,hat=(noise-Math.floor(noise)-.5)*Math.exp(-eighth*90);
        data[0][i]=(Math.sin(t*root*Math.PI*2)*.11+Math.sin(t*root*1.5*Math.PI*2)*.045+Math.sin(t*root*2*Math.PI*2)*.02)*barEnv*seam;
        const kick=Math.sin(2*Math.PI*(45*pulse+3*(1-Math.exp(-pulse*28))))*Math.exp(-pulse*16);
        data[1][i]=(kick*.32+hat*.10+Math.sin(root*.5*t*Math.PI*2)*Math.exp(-eighth*14)*.13)*seam;
        data[2][i]=(Math.sin(45*t*Math.PI*2)*Math.exp(-((b*2)%1)*14)*.25+Math.sin(root*2.1189*t*Math.PI*2)*Math.exp(-eighth*20)*.045)*seam;
        const frequency=root*arp[Math.floor(b*2)%8]*2;data[3][i]=(Math.sin(t*frequency*Math.PI*2)*.12+Math.sin(t*frequency*2*Math.PI*2)*.035)*Math.exp(-eighth*12)*seam;
      }
    }
    startScore(age=0) {
      if(this.scoreNodes||!this.ctx||this.ctx.state!=='running')return;this.prepareScore();const t=this.ctx.currentTime+.012,offset=Math.max(0,age)%this.scoreDuration;
      this.scoreNodes=this.scoreBuffers.map(buffer=>{const s=this.ctx.createBufferSource(),g=this.ctx.createGain();s.buffer=buffer;s.loop=true;g.gain.value=0;s.connect(g);g.connect(this.music);s.start(t,offset);return {s,g};});
    }
    stopScore() {
      if(!this.scoreNodes||!this.ctx)return;const t=this.ctx.currentTime;for(const {s,g}of this.scoreNodes){g.gain.setTargetAtTime(0,t,.08);try{s.stop(t+.4);}catch{}s.onended=()=>{s.disconnect();g.disconnect();};}this.scoreNodes=null;
    }
    mixBattle(active,combat,health,clash,ultimate,speaking,recordedTheme,allowed,age=0) {
      if(!this.ctx||!this.fxBed)return;const a=BATTLE_AUDIO,t=this.ctx.currentTime,priority=t<this.priorityUntil,duck=speaking?a.voiceDuck:priority?a.duck:1;
      this.fxBed.gain.setTargetAtTime(duck,t,duck<1?a.attack:a.release);for(const voice of this.voices)voice.mix?.gain.setTargetAtTime(speaking?.3:1,t,.12);
      if(!active||!allowed||!this.enabled||this.volumes.music<=0||recordedTheme){this.stopScore();return;}this.startScore(age);if(!this.scoreNodes)return;
      const level=speaking?.25:priority?.6:1;this.scoreTargets[0]=a.base*(clash?.5:1);this.scoreTargets[1]=a.combat*Math.max(0,Math.min(1,combat));this.scoreTargets[2]=a.critical*Math.max(0,1-health/a.criticalHealth);this.scoreTargets[3]=ultimate?a.ultimate:clash?a.clash:0;
      for(let i=0;i<4;i++)this.scoreNodes[i].g.gain.setTargetAtTime(this.scoreTargets[i]*level,t,a.musicBlend);
    }
    update({charge=0, color='blue', domain='', pan=0}={}) {
      if(!this.ctx||this.ctx.state!=='running')return;
      if(!this.drone){const c=this.ctx,o=c.createOscillator(),g=c.createGain(),p=c.createStereoPanner?.();o.type='sine';o.connect(g);g.gain.value=0;if(p){g.connect(p);p.connect(this.fxBed);}else g.connect(this.fxBed);o.start();this.drone={o,g,p};}
      const d=this.drone,t=this.ctx.currentTime,volume=charge>0?.035+charge*.035:domain?.025:0;
      d.g.gain.setTargetAtTime(volume,t,.12);d.o.frequency.setTargetAtTime(charge>0?(color==='red'?90:55)+charge*90:domain==='sukuna'?48:66,t,.08);if(d.p)d.p.pan.setTargetAtTime(pan,t,.1);
    }
  }
  window.ArenaAudio=ArenaAudio;
})();
