// Skyline Boroughs uses the existing destructible floor boxes and platform collision.
const METRO_MAP={seed:70429,radius:260,ceiling:124,floorHeight:4,towerFloors:[12,15,16,13,11,14,12,15],outerTowerFloors:[18,22,20,24,19,23,21,18],towerColors:[0x587784,0x7f9198,0x426274,0x9a9d94],brickColors:[0x9b604c,0xb18468,0x755956,0xb5a38c],ledgeInterval:8};
function metroBuilding(x,z,w,d,levels,color,kind){
 const b={id:buildings.length,x,z,w,d,floors:levels,parts:[],kind};buildings.push(b);
 const glass=mapMaterial(kind==='tower'?0x284f65:0x263d47),trim=mapMaterial(kind==='tower'?0xb8c9cd:0xd2ba97),iron=mapMaterial(0x343f45),dummy=new THREE.Object3D();
 for(let level=0;level<levels;level++){
  const p=piece(V(x,2+level*4,z),V(w,3.92,d),color,true);p.solid=true;p.building=b.id;p.level=level;p.hp=p.max=46;b.parts.push(p);
  const cols=Math.max(2,Math.floor(w/3)),rows=Math.max(2,Math.floor(d/3)),windows=new THREE.InstancedMesh(geo.box,glass,2*(cols+rows));p.m.add(windows);let index=0;
  for(const side of [-1,1]){for(let i=0;i<cols;i++){dummy.position.set((i-(cols-1)/2)*2.7/w,.035,side*.503);dummy.scale.set((kind==='tower'?1.85:1.15)/w,kind==='tower'?.58:.43,.007);dummy.updateMatrix();windows.setMatrixAt(index++,dummy.matrix);}for(let i=0;i<rows;i++){dummy.position.set(side*.503,.035,(i-(rows-1)/2)*2.7/d);dummy.scale.set(.007,kind==='tower'?.58:.43,(kind==='tower'?1.85:1.15)/d);dummy.updateMatrix();windows.setMatrixAt(index++,dummy.matrix);}}
  box(p.m,V(0,.475,0),V(1.012,.045,1.012),trim);
  if(kind==='tower')for(const side of [-1,1])for(const a of [-.37,0,.37])box(p.m,V(a,0,side*.508),V(.035,.98,.015),trim);
  if(level===0){box(p.m,V(0,-.15,.511),V(1.65/w,.61,.014),iron);const awning=box(p.m,V(0,.16,.56),V(kind==='tower'?.7:.78,.07,.15),mapMaterial(kind==='tower'?0x526977:kind==='house'?0x637969:0x804334));box(p.m,V(.27,-.30,.511),V(.20,.15,.012),mapMaterial(0xc8a064));}
  // Decorative roof details stay attached to the top destructible floor.
  if(level===levels-1){box(p.m,V(0,.525,0),V(1.025,.08,1.025),trim);for(const side of [-1,1])box(p.m,V(side*.49,.60,0),V(.026,.13,.99),trim);box(p.m,V(.18,.68,-.18),V(.28,.24,.25),iron);
   if(kind==='tower'||kind==='midrise'){const tank=new THREE.Group();p.m.add(tank);tank.position.set(-.26,.6,.19);tank.scale.set(1/w,1/3.92,1/d);for(const sx of [-1,1])for(const sz of [-1,1])box(tank,V(sx*.9,.75,sz*.9),V(.13,1.5,.13),iron);mesh(geo.cylinder,mapMaterial(0x8a654b),tank,V(0,2.65,0),V(2.5,2.5,2.5));mesh(geo.cone,iron,tank,V(0,4.15,0),V(2.8,.65,2.8));}
  }
  batchStaticBoxes(p.m);
 }
 // Landings are real platforms: touching down refills the existing airtime budget.
 const side=x<0?1:-1,ledgeX=x+side*(w/2+1.2),height=levels*4;
 for(let h=4;h<height;h+=METRO_MAP.ledgeInterval){const p=piece(V(ledgeX,h-.14,z),V(2.4,.28,5.5),0x52646d,true);p.building=b.id;p.level=Math.floor(h/4);b.parts.push(p);for(const end of [-1,1])box(p.m,V(0,2,end*.48),V(.95,.22,.035),iron);box(p.m,V(side*.46,2,0),V(.025,.22,.96),iron);batchStaticBoxes(p.m);}
 // A low stoop and an intermediate ledge introduce the route from street level.
 for(let i=0;i<3;i++)piece(V(x,z>85?.2+i*.4:.2+i*.55,z+d/2+3-i*.85),V(Math.min(4,w*.45),.4,1),0xb8a88e,true);
 return b;
}
function buildMetro(mapRoot,horizon){
 const root=new THREE.Group();mapRoot.add(root);mapRoot.name='skyline-boroughs';const road=mapMaterial(0x35434b),curb=mapMaterial(0xb0b6ae),paint=mapMaterial(0xe2dfc4),yellow=mapMaterial(0xc9ab65),park=mapMaterial(0x739577),iron=mapMaterial(0x35424b);
 // Extend the street grid around the original blocks, keeping the central spawn plaza.
 const streetRadius=METRO_MAP.radius-4;
 for(const x of [-228,-166,-126,-72,-36,0,36,72,126,166,228]){const length=Math.sqrt(streetRadius*streetRadius-x*x)*2;box(root,V(x,.005,0),V(x===0?17:10,.05,length),road);for(const side of [-1,1])box(root,V(x+side*(x===0?8.7:5.2),.06,0),V(.3,.16,length),curb);for(let z=-length/2+7;z<length/2-5;z+=10)box(root,V(x,.043,z),V(.15,.01,4),yellow);}
 for(const z of [-214,-170,-130,-82,-40,0,40,82,144,192,238]){const length=Math.sqrt(streetRadius*streetRadius-z*z)*2;box(root,V(0,.012,z),V(length,.05,11),road);for(const side of [-1,1])box(root,V(0,.067,z+side*5.65),V(length,.18,.3),curb);for(let x=-length/2+7;x<length/2-5;x+=10)box(root,V(x,.047,z),V(4,.01,.15),yellow);}
 for(const z of [-40,0,40,82])for(const x of [-72,-36,0,36,72])for(const side of [-1,1])for(let n=-3;n<=3;n++)box(root,V(x+n*1.05,.055,z+side*7),V(.55,.014,2.6),paint);
 let t=0;for(const z of [-100,-64])for(const x of [-54,-18,18,54]){metroBuilding(x,z,24,26,METRO_MAP.towerFloors[t],METRO_MAP.towerColors[t%4],'tower');t++;}
 let m=0;for(const z of [-20,20,60])for(const x of [-90,-54,54,90]){metroBuilding(x,z,24,26,4+(m*3%5),METRO_MAP.brickColors[m%4],'midrise');m++;}
 let h=0;for(const z of [104,124])for(const x of [-104,-88,-72,-56,56,72,88,104]){metroBuilding(x,z,12,14,2+h%2,METRO_MAP.brickColors[h%4],'brownstone');h++;}
 for(const side of [-1,1])for(const z of [-16,28]){const b=metroBuilding(side*146,z,12,16,2,side<0?0x9eafa0:0xc8b89e,'house');const top=b.parts[1].m;box(top,V(0,.66,.36),V(.65,.2,.22),mapMaterial(0x5f726f));box(root,V(side*146,.06,z-10),V(17,.13,4),park);}
 // Twenty-four new climbable high rises: two northern rows and two outer avenues.
 let outer=0;for(const z of [-150,-190])for(const x of [-146,-98,-54,-18,18,54,98,146]){metroBuilding(x,z,24,24,METRO_MAP.outerTowerFloors[outer%8],METRO_MAP.towerColors[outer%4],'tower');outer++;}
 for(const side of [-1,1])for(const z of [-62,-20,20,62]){metroBuilding(side*194,z,26,28,16+(outer%4)*2,METRO_MAP.towerColors[outer%4],'tower');outer++;}
 // Southern blocks make the enlarged area useful beyond the skyscraper district.
 for(const z of [170,214])for(const x of [-98,-54,54,98]){metroBuilding(x,z,24,24,6+m%4,METRO_MAP.brickColors[m%4],'midrise');m++;}
 // Destructible roof bridges connect comparable heights across ten/twelve metre alleys.
 for(const x of [-54,-18,18,54]){const p=piece(V(x,27.8,-82),V(5,.4,11),0x6a8089,true);p.metroBridge=true;for(const side of [-1,1])box(p.m,V(side*.47,1.8,0),V(.035,.12,1),iron);batchStaticBoxes(p.m);}
 for(const side of [-1,1])for(const z of [-20,20,60]){const p=piece(V(side*72,11.8,z),V(13,.4,4),0x6a8089,true);p.metroBridge=true;for(const edge of [-1,1])box(p.m,V(0,1.8,edge*.47),V(1,.12,.035),iron);batchStaticBoxes(p.m);}
 // Clear central spawns and a pocket park; both avenues remain traversable.
 for(const side of [-1,1]){box(root,V(side*21,.045,36),V(17,.12,58),curb);box(root,V(side*21,.115,38),V(13,.12,50),park);for(const z of [18,38,58]){const p=piece(V(side*22,2.3,z),V(.55,4.6,.55),0x6d6755);mesh(geo.lowSphere,mapMaterial(z===38?0x6b8a61:0x4e775f),p.m,V(0,.6,0),V(6,1.1,6));piece(V(side*12,.5,z),V(1.4,1,3.5),0x746b55,true);}}
 // Lamps and taxis provide scale without obstructing the fighting plaza.
 for(const z of [-208,-164,-122,-48,6,76,140,188,232])for(const x of [-9.8,9.8]){const p=piece(V(x,2.7,z),V(.2,5.4,.2),0x394852);box(p.m,V(.8,.46,0),V(12,.035,3),iron);box(p.m,V(5,.44,0),V(4,.025,2.4),mapMaterial(0xffecc4,true));}
 for(const [x,z]of [[-3,-120],[4,-45],[-4,72],[4,137],[-125,12],[126,-36]]){const p=piece(V(x,.7,z),V(2.1,1.4,4.3),0xcba345,true);box(p.m,V(0,.59,-.02),V(.83,.6,.54),mapMaterial(0x3e5b66));for(const side of [-1,1])for(const end of [-1,1])mesh(geo.cylinder,iron,p.m,V(side*.52,-.24,end*.3),V(.3,.16,.18)).rotation.z=Math.PI/2;}
 for(let i=0;i<48;i++){const a=i/48*Math.PI*2,r=METRO_MAP.radius+48+rr(0,32),height=rr(28,110);box(horizon,V(Math.cos(a)*r,height/2-4,Math.sin(a)*r),V(rr(9,18),height,rr(10,18)),mapMaterial(i%2?0x8ea5ac:0xa4b5b7));}
 mesh(new THREE.SphereGeometry(11,20,14),mapMaterial(0xfff4d7,true),horizon,V(-230,185,-310));for(let i=0;i<11;i++)mesh(new THREE.SphereGeometry(1,12,8),mapMaterial(0xe6efee),horizon,V(-270+i*54,155+i%3*9,-340),V(27,3.6,9));
 batchStaticBoxes(root);
}
