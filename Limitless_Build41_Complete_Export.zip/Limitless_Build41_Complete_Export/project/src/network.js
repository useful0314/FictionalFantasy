// Host-authoritative six-fighter rooms. One authenticated transport per human input stream.
(() => {
 const VERSION='limitless-41.0',PREFIX='limitless41-',MAX=6,characters=new Set(['gojo','sukuna','naruto','mahito','spiderman']),arenas=new Set(['district','harbor','sanctuary','metro']),levels=new Set(['easy','normal','hard','impossible']);
 const actions=new Set(['forward','back','left','right','sprint','jump','fly','descend','light','guard','dodge','energy','special1','special2','special3','special4','special5','special6','domain']);
 const finite=(n,min,max)=>Number.isFinite(n)&&n>=min&&n<=max;
 const validWebView=v=>!!v&&Array.isArray(v.origin)&&v.origin.length===3&&v.origin.every(n=>finite(n,-1e4,1e4))&&Array.isArray(v.direction)&&v.direction.length===3&&v.direction.every(n=>finite(n,-1,1))&&Math.abs(Math.hypot(...v.direction)-1)<.001;
 const validInputEdge=e=>Array.isArray(e)&&actions.has(e[0])&&typeof e[1]==='boolean'&&(e.length===2||e.length===3&&e[0]==='special4'&&e[1]&&validWebView(e[2]));
 const validRoster=r=>Array.isArray(r)&&r.length>=1&&r.length<=MAX&&new Set(r.map(f=>f?.id)).size===r.length&&r.every(f=>f&&/^[pb][0-5]$/.test(f.id)&&characters.has(f.character)&&typeof f.bot==='boolean'&&(!f.bot||levels.has(f.difficulty)));
 class ArenaNet{
  constructor(cb={}){this.cb=cb;this.role=null;this.state='idle';this.roster=[];this.connections=new Map();this.now=()=>performance.now();this.match=0;this.seq=0;this.rtt=0;}
  status(message,state=this.state){this.state=state;this.message=message;this.cb.status?.(message,state);}
  randomCode(){const a=new Uint8Array(8);crypto.getRandomValues(a);const letters='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';return Array.from(a,n=>letters[n%32]).join('');}
  create(character,arena='district'){this.close(false);this.role='host';this.localId='p0';this.character=characters.has(character)?character:'gojo';this.arena=arenas.has(arena)?arena:'district';this.roster=[{id:'p0',character:this.character,bot:false,ready:false,connected:true}];this.code=this.randomCode();this.handshake=true;this.status('Opening your private room…','connecting');this.openPeer(PREFIX+this.code);}
  join(code,character='gojo'){code=String(code).toUpperCase().replace(/[\s-]/g,'');if(!/^[A-HJ-NP-Z2-9]{8}$/.test(code)){this.status('Enter the 8-character room code.','idle');return;}this.close(false);this.role='guest';this.code=code;this.character=characters.has(character)?character:'gojo';this.status('Finding room '+code+'…','connecting');this.openPeer();}
  openPeer(id){
   if(typeof window.Peer!=='function'){this.fail('Online library unavailable. Solo modes still work.');return;}
   try{const peer=this.peer=new window.Peer(id,{debug:0});this.deadline=this.now()+22000;
    peer.on('open',()=>{if(this.peer!==peer)return;this.deadline=0;if(this.role==='host'){this.status('Room open · up to 6 fighters. Invite friends or add AI.','lobby');this.cb.room?.(this.code);}else this.attach(peer.connect(PREFIX+this.code,{reliable:true,serialization:'json',metadata:{version:VERSION}}));});
    peer.on('connection',conn=>{if(this.peer!==peer)return;if(this.role!=='host'||this.state==='playing'||this.roster.filter(f=>f.bot||f.id==='p0').length+this.connections.size>=MAX||conn.metadata?.version!==VERSION){conn.on('open',()=>{conn.send({t:'reject',reason:this.state==='playing'?'Match already started. Join the next room.':conn.metadata?.version!==VERSION?'Build mismatch. Refresh all games.':'Room full. Ask the host to remove an AI.'});setTimeout(()=>conn.close(),200);});return;}this.attach(conn);});
    peer.on('error',e=>{if(this.peer!==peer)return;this.fail(e.type==='peer-unavailable'?'Room not found. Check the code and host connection.':'Could not connect. Check your network or create a new room.');});
    peer.on('disconnected',()=>{if(this.peer===peer&&this.state!=='playing')this.fail('Signaling disconnected. Create or join again.');});
   }catch{this.fail('Could not initialize private rooms in this browser.');}
  }
  attach(conn){
   const used=new Set([...this.connections.values()].map(c=>c.id));const id=this.role==='host'?Array.from({length:5},(_,i)=>'p'+(i+1)).find(id=>!used.has(id)):'host';if(!id)return;
   const record={id,conn,handshake:false,inputSeq:-1,last:this.now(),rateAt:this.now(),count:0,deadline:this.now()+22000};this.connections.set(id,record);this.conn=conn;
   conn.on('open',()=>{if(this.connections.get(id)!==record)return;record.deadline=0;record.last=this.now();if(this.role==='host')this.sendTo(record,{t:'welcome',version:VERSION,yourId:id,arena:this.arena,roster:this.roster});else this.sendTo(record,{t:'hello',version:VERSION,character:this.character});});
   conn.on('data',d=>{if(this.connections.get(id)===record)this.receive(d,record);});
   conn.on('close',()=>this.disconnected(record));conn.on('error',()=>this.disconnected(record));
  }
  sendTo(record,data){if(!record?.conn?.open)return false;try{if(data.t==='state'&&(record.conn.dataChannel?.bufferedAmount||0)>196608)return false;record.conn.send(data);return true;}catch{return false;}}
  send(data){let sent=false;for(const c of this.connections.values())sent=this.sendTo(c,data)||sent;return sent;}
  broadcastLobby(){if(this.role!=='host')return;this.ready=!!this.roster.find(f=>f.id===this.localId)?.ready;this.remoteReady=this.roster.filter(f=>!f.bot&&f.id!==this.localId&&f.connected!==false).every(f=>f.ready);this.send({t:'lobby',roster:this.roster,arena:this.arena});this.cb.lobby?.();}
  resetReadiness(){for(const f of this.roster)if(!f.bot)f.ready=false;this.ready=false;this.remoteReady=false;}
  receive(d,record=[...this.connections.values()][0]){
   if(!record||!d||typeof d!=='object'||Array.isArray(d)||typeof d.t!=='string')return;const now=this.now();if(now-record.rateAt>1000){record.rateAt=now;record.count=0;}if(++record.count>180){record.conn.close();return;}record.last=now;
   if(d.t==='reject'&&this.role==='guest'){this.fail(typeof d.reason==='string'?d.reason.slice(0,100):'Room unavailable.');return;}
   if(d.t==='hello'&&this.role==='host'){
    if(record.handshake)return;if(d.version!==VERSION||!characters.has(d.character)){this.sendTo(record,{t:'reject',reason:'Invalid character or mismatched build.'});record.conn.close();return;}
    record.handshake=true;this.roster.push({id:record.id,character:d.character,bot:false,ready:false,connected:true});this.resetReadiness();this.broadcastLobby();return;
   }
   if(d.t==='welcome'&&this.role==='guest'){
    if(d.version!==VERSION||!/^p[1-5]$/.test(d.yourId)||!validRoster(d.roster)||!arenas.has(d.arena))return;this.localId=d.yourId;this.arena=d.arena;this.roster=d.roster;this.handshake=record.handshake=true;this.status('Connected. Choose your fighter, then Ready.','lobby');return;
   }
   if(!record.handshake)return;
   if(d.t==='lobby'&&this.role==='guest'&&validRoster(d.roster)&&arenas.has(d.arena)){this.roster=d.roster;this.arena=d.arena;const me=this.roster.find(f=>f.id===this.localId);if(me){this.character=me.character;this.ready=me.ready;}this.cb.lobby?.();return;}
   if(d.t==='select'&&this.role==='host'&&this.state==='lobby'&&characters.has(d.character)){const f=this.roster.find(f=>f.id===record.id);if(f){f.character=d.character;this.resetReadiness();this.broadcastLobby();}return;}
   if(d.t==='ready'&&this.role==='host'&&this.state==='lobby'&&typeof d.value==='boolean'){const f=this.roster.find(f=>f.id===record.id);if(f)f.ready=d.value;this.broadcastLobby();this.maybeStart();return;}
   if(d.t==='start'&&this.role==='guest'&&Number.isSafeInteger(d.match)&&d.match>this.match&&validRoster(d.roster)&&d.roster.length>=2&&d.roster.some(f=>f.id===this.localId)&&arenas.has(d.arena)){this.match=d.match;this.roster=d.roster;this.arena=d.arena;this.character=d.roster.find(f=>f.id===this.localId).character;this.state='playing';this.stateSeq=-1;this.localRematch=false;this.cb.start?.(this.character,this.arena);return;}
   if(d.t==='input'&&this.role==='host'&&this.state==='playing'&&d.match===this.match){
    if(d.clear!==undefined&&typeof d.clear!=='boolean'||!Number.isSafeInteger(d.seq)||d.seq<=record.inputSeq||!Array.isArray(d.held)||d.held.length>18||!d.held.every(a=>actions.has(a))||!Array.isArray(d.edges)||d.edges.length>32||!d.edges.every(validInputEdge)||!finite(d.yaw,-1e6,1e6)||!finite(d.pitch,-1.45,1.52)||!Array.isArray(d.move)||d.move.length!==2||!d.move.every(n=>finite(n,-1,1)))return;record.inputSeq=d.seq;this.cb.input?.(d,record.id);return;
   }
   if(d.t==='state'&&this.role==='guest'&&this.state==='playing'&&d.match===this.match&&Number.isSafeInteger(d.seq)&&d.seq>this.stateSeq&&d.data){this.stateSeq=d.seq;this.cb.snapshot?.(d.data);return;}
   if(d.t==='rematch'&&this.role==='host'&&this.state==='playing'){const f=this.roster.find(f=>f.id===record.id);if(f)f.rematch=true;this.maybeRematch();return;}
   if(d.t==='ping'&&finite(d.at,0,1e14)){this.sendTo(record,{t:'pong',at:d.at});return;}
   if(d.t==='pong'&&finite(d.at,0,now))this.rtt=Math.round(now-d.at);
  }
  setCharacter(character){if(this.state!=='lobby'||!characters.has(character))return;this.character=character;if(this.role==='host'){this.roster.find(f=>f.id==='p0').character=character;this.resetReadiness();this.broadcastLobby();}else this.send({t:'select',character});}
  configureBots(charactersList,difficulty='normal'){
   if(this.role!=='host'||this.state!=='lobby'||!Array.isArray(charactersList)||!levels.has(difficulty)||charactersList.length+1+this.connections.size>MAX||!charactersList.every(c=>characters.has(c)))return false;
   this.roster=this.roster.filter(f=>!f.bot);this.roster.push(...charactersList.map((character,i)=>({id:'b'+i,character,bot:true,difficulty,ready:true,connected:true})));this.resetReadiness();this.broadcastLobby();return true;
  }
  setReady(){if(this.state!=='lobby'||!this.handshake)return;this.ready=!this.ready;if(this.role==='host'){this.roster.find(f=>f.id===this.localId).ready=this.ready;this.broadcastLobby();this.maybeStart();}else this.send({t:'ready',value:this.ready});}
  maybeStart(){if(this.role!=='host'||this.state!=='lobby'||this.roster.length<2||!this.roster.filter(f=>!f.bot).every(f=>f.ready)||[...this.connections.values()].some(c=>!c.handshake))return;this.startMatch();}
  startMatch(){this.roster=this.roster.filter(f=>f.connected!==false);if(this.roster.length<2){this.status('Add a fighter before starting again.','lobby');this.resetReadiness();this.broadcastLobby();return;}this.match++;this.state='playing';this.localRematch=false;for(const f of this.roster)f.rematch=false;for(const c of this.connections.values())c.inputSeq=-1;this.send({t:'start',match:this.match,roster:this.roster,arena:this.arena});this.cb.start?.(this.character,this.arena);}
  requestRematch(){if(this.state!=='playing')return;this.localRematch=true;if(this.role==='host'){this.roster.find(f=>f.id===this.localId).rematch=true;this.maybeRematch();}else this.send({t:'rematch'});this.cb.rematch?.();}
  maybeRematch(){if(this.role==='host'&&this.roster.filter(f=>!f.bot&&f.connected!==false).every(f=>f.rematch))this.startMatch();}
  input(payload){if(this.role==='guest'&&this.state==='playing')this.send({t:'input',match:this.match,seq:++this.seq,...payload});}
  snapshot(data){if(this.role==='host'&&this.state==='playing')this.send({t:'state',match:this.match,seq:++this.seq,data});}
  disconnected(record){if(this.connections.get(record.id)!==record)return;this.connections.delete(record.id);if(this.role==='guest'){this.fail('Host disconnected. The match has stopped.');return;}if(this.state==='playing'){const f=this.roster.find(f=>f.id===record.id);if(f)f.connected=false;this.cb.departed?.(record.id);this.broadcastLobby();}else{this.roster=this.roster.filter(f=>f.id!==record.id);this.resetReadiness();this.broadcastLobby();}this.conn=[...this.connections.values()][0]?.conn||null;}
  tick(){const now=this.now();if(this.deadline&&now>this.deadline){this.fail('Connection timed out. Check the code and host tab.');return;}for(const c of this.connections.values()){if(c.deadline&&now>c.deadline||c.conn.open&&now-c.last>12000){c.conn.close();this.disconnected(c);continue;}if(c.conn.open&&(!c.pingAt||now-c.pingAt>1500)){c.pingAt=now;this.sendTo(c,{t:'ping',at:now});}}}
  fail(message){this.close(false);this.status(message,'error');this.cb.disconnected?.(message);}
  close(notify=true){const connections=[...this.connections.values()],peer=this.peer;this.connections.clear();this.peer=this.conn=null;this.role=null;this.state='idle';this.roster=[];this.ready=this.remoteReady=this.handshake=this.localRematch=false;this.deadline=0;this.match=0;for(const c of connections)try{c.conn.close();}catch{}try{peer?.destroy();}catch{}if(notify)this.status('Create a room or enter a friend’s code.','idle');}
 }
 ArenaNet.VERSION=VERSION;ArenaNet.actions=actions;ArenaNet.validRoster=validRoster;ArenaNet.validWebView=validWebView;window.ArenaNet=ArenaNet;
})();
