// Video reference: the joined mass blooms behind the caster, then belongs to the realm.
// Visual only. Existing cast/clash ages, sphere clipping and instanced hands are reused.
const MAHITO_AMALGAM={hands:24,rear:12,hubHeight:6.4,spread:7.4,delay:.10,unfurl:1.05,stagger:.30,fade:.38,
 skin:0xaa8caa,ink:0x382d47,emissive:0x372340,glow:0xb990f3,breath:.10};
const mahitoAmalgams=[],mahitoFormationAnchors=new Map();
function beginMahitoFormation(f){if(f.character==='mahito')mahitoFormationAnchors.set(f.id,{id:f.castVoiceId,owner:f.id,p:f.pos.clone(),dir:aimFor(f).setY(0).normalize()});}
function packMahitoFormations(){return Array.from(mahitoFormationAnchors.values(),a=>({id:a.id,owner:a.owner,p:vec(a.p),dir:vec(a.dir)}));}
function validMahitoFormations(list,ids){return Array.isArray(list)&&list.length<=MAX_FIGHTERS&&new Set(list.map(a=>a?.owner)).size===list.length&&list.every(a=>a&&Number.isSafeInteger(a.id)&&ids.has(a.owner)&&actorById(a.owner)?.character==='mahito'&&validVector(a.p)&&validVector(a.dir)&&Math.hypot(...a.dir)>.9&&Math.hypot(...a.dir)<1.1&&Math.abs(a.dir[1])<.001);}
function receiveMahitoFormations(list){for(const a of list){let r=mahitoFormationAnchors.get(a.owner);if(!r){r={id:a.id,owner:a.owner,p:V(),dir:V()};mahitoFormationAnchors.set(a.owner,r);}r.id=a.id;r.p.fromArray(a.p);r.dir.fromArray(a.dir);}for(const id of mahitoFormationAnchors.keys())if(!list.some(a=>a.owner===id))mahitoFormationAnchors.delete(id);}
function makeMahitoAmalgam(slot){
 const c=MAHITO_AMALGAM,g=new THREE.Group();g.name='mahito-caster-hand-amalgamation-'+slot;scene.add(g);g.visible=false;
 const hands=makeMahitoHandBatch(g,c.hands),material=hands.palm.material;material.color.setHex(c.skin);material.emissive.setHex(c.emissive);material.emissiveIntensity=.45;hands.details.material.color.setHex(c.ink);
 const branches=new THREE.InstancedMesh(mahitoBlock.clone(),material,c.hands*2+7);branches.name='fused-branching-forearms';branches.frustumCulled=false;branches.instanceMatrix.setUsage(THREE.DynamicDrawUsage);g.add(branches);
 const sealMaterial=new THREE.MeshBasicMaterial({color:c.glow,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false}),seals=[];
 for(let i=0;i<2;i++){const ring=mesh(new THREE.TorusGeometry(.16,.026,5,20),sealMaterial,g);ring.name='hand-sign-chakra-'+i;seals.push(ring);}
 const r={g,hands,branches,seals,sealMaterial,materials:[material,hands.details.material,sealMaterial],slot,key:0,owner:'',age:0,exit:0,active:false,origin:V(),axis:V(0,0,1),clipCenter:V(),p:V(),normal:V(),wrist:V(),join:V(),bend:V(),up:V(0,1,0),dummy:new THREE.Object3D(),layout:[]};
 // Converging radial wrists share an interlocked core; a forward curled palm crowns it.
 for(let i=0;i<c.hands;i++){
  const outer=i<14,hero=i>=22,a=outer?i/14*Math.PI*2+.13*Math.sin(i*3.2):(i-14)/8*Math.PI*2+.4,
   spread=(outer?c.spread:3.6)*(.82+.36*domainHash(i+17));
  r.layout.push({x:hero?(i===22?-.6:3.4):Math.sin(a)*spread,y:hero?(i===22?8.8:4.1):c.hubHeight+Math.cos(a)*spread*.82,z:hero?-c.rear+2.2:-c.rear-(outer?.2+domainHash(i+91)*4:domainHash(i+49)*2),a,
   roll:hero?(i===22?Math.PI:1.9):-a+Math.sin(i*3.7)*.48,size:hero?(i===22?4.3:3.1):outer?1.8+domainHash(i+71)*1.4:2.0+domainHash(i+81)*1.25,
   delay:hero?.26:outer?.14+(i%6)*.034:(i-14)*.025,curl:hero?(i===22?1.25:1.0):outer?(i%3===0?1.2:.08+.3*domainHash(i+33)):i%3===0?1.5:.5});
 }
 confineDomainVisual(g,V());return r;
}
function setMahitoBranch(r,index,from,to,width,grow){
 const d=r.dummy;d.position.copy(from).lerp(to,.5);r.normal.copy(to).sub(from);const length=r.normal.length();d.quaternion.setFromUnitVectors(r.up,r.normal.divideScalar(Math.max(.0001,length)));d.scale.set(width*grow,Math.max(.001,length+.18*grow),width*.83*grow);d.updateMatrix();r.branches.setMatrixAt(index,d.matrix);
}
function poseMahitoAmalgam(r,age,fade){
 const c=MAHITO_AMALGAM,h=r.hands,settle=narutoEase((age-c.delay)/c.unfurl),breath=Math.sin(age*1.6)*c.breath*settle;let branch=0;
 for(let i=0;i<r.layout.length;i++){
  const l=r.layout[i],q=narutoEase((age-c.delay-l.delay)/(c.unfurl-c.stagger)),grow=q*fade,spread=.18+.82*q;
  r.p.set(l.x*spread,c.hubHeight+(l.y-c.hubHeight)*spread+breath,l.z-1.9*(1-q));r.normal.set(Math.sin(l.a)*.42,Math.cos(l.a)*.27,1).normalize();
  const curl=lerp(1.65,l.curl,q)+Math.sin(age*.9+i*.7)*.06*settle;
  setMahitoHand(h,i,r.p,r.normal,l.size*grow,curl,l.roll+(1-q)*.32*Math.sin(i));
  r.wrist.set(0,-2.78,0).applyMatrix4(h.base.matrix);r.join.set(Math.sin(l.a)*1.1,c.hubHeight+Math.cos(l.a)*1.0,-c.rear-2.3);r.bend.copy(r.join).lerp(r.wrist,.53);r.bend.z-=.65*grow;
  setMahitoBranch(r,branch++,r.join,r.bend,(i<14?.85:1.05),grow);setMahitoBranch(r,branch++,r.bend,r.wrist,(i<14?.72:.9),grow);
 }
 // Overlapping knuckle/forearm blocks make the shared root visibly continuous.
 for(let i=0;i<7;i++){const a=i/7*Math.PI*2,d=r.dummy;d.position.set(Math.sin(a)*1.35,c.hubHeight+Math.cos(a)*1.1,-c.rear-2.3);d.rotation.set(.3*Math.sin(a),a,.5*Math.cos(a));d.scale.set(2.8*settle*fade,2.5*settle*fade,2.8*settle*fade);d.updateMatrix();r.branches.setMatrixAt(branch++,d.matrix);}
 flushMahitoHands(h,c.hands);r.branches.count=branch;r.branches.instanceMatrix.needsUpdate=true;
}
function updateMahitoAmalgams(dt){
 const allowed=phase==='play'||phase==='pause'||phase==='finish',paused=phase==='pause',c=MAHITO_AMALGAM;
 for(let slot=0;slot<MAX_FIGHTERS;slot++){
  const f=bodies[slot],cast=f&&castFor(f),inClash=!!(f&&clash?.participants.includes(f.id)),owns=!!(f&&domain?.owner===f),wanted=allowed&&f?.character==='mahito'&&f.hp>0&&!!(cast||inClash||owns);let r=mahitoAmalgams[slot];
  if(wanted){
   if(!r)r=mahitoAmalgams[slot]=makeMahitoAmalgam(slot);
   const anchor=mahitoFormationAnchors.get(f.id),key=f.castVoiceId||cast?.id||clash?.id||domain?.id;
   if(!r.active||r.key!==key||r.owner!==f.id){
    r.key=key;r.owner=f.id;r.active=true;r.exit=0;r.age=0;r.origin.copy(anchor?.p||cast?.origin||f.pos);
    if(!anchor&&!cast&&!inClash&&domain)r.origin.copy(domain.origin);
    // Networked facing already exists in each fighter snapshot. Latch once per expansion.
    const angle=mode==='online'&&net?.role==='guest'?f.input.yaw:f===player?yaw:f.input.yaw;r.axis.set(-Math.sin(angle),0,-Math.cos(angle));if(anchor)r.axis.copy(anchor.dir);r.g.position.copy(r.origin);r.g.rotation.y=Math.atan2(r.axis.x,r.axis.z);
   }
   const sourceAge=cast?domainPresentationAge(cast.t):owns?DOMAIN_ENCLOSURE.startup+domainPresentationAge(domain.t):domainPresentationAge(f.castVoiceAge||clash.t);
   r.age=Math.max(r.age+(paused?0:dt),sourceAge);r.exit=0;
   r.clipCenter.copy(enclosure()?.origin||cast?.origin||r.origin).y+=1.45;
   for(const mat of r.materials)mat.userData.domainClip.center.copy(r.clipCenter);
   // Captured players see the interior; outsiders only see the opaque existing barrier.
   r.g.visible=!enclosure()||insideEnclosure(player);poseMahitoAmalgam(r,r.age,owns?1-narutoEase((domain.t-DOMAIN_RULES.duration+c.fade)/c.fade):1);
   r.sealMaterial.opacity=cast?.45*narutoEase(cast.t/.15)*(1-narutoEase((cast.t-1.2)/.3)):0;
   r.g.updateWorldMatrix(true,false);f.root.updateWorldMatrix(true,true);
   for(let i=0;i<2;i++){const s=r.seals[i];s.visible=!!cast;if(cast){f.limbs[i].hand.getWorldPosition(r.p);s.position.copy(r.g.worldToLocal(r.p));s.rotation.set(r.age*3+i,r.age*2,0);s.scale.setScalar(1+.12*Math.sin(r.age*16));}}
  }else if(r){r.sealMaterial.opacity=0;for(const s of r.seals)s.visible=false;if(r.active&&allowed){r.exit+=paused?0:dt;poseMahitoAmalgam(r,r.age,1-narutoEase(r.exit/c.fade));if(r.exit>=c.fade){r.active=false;r.g.visible=false;}}else{r.active=false;r.g.visible=false;}}
 }
}
function resetMahitoAmalgams(){mahitoFormationAnchors.clear();for(const r of mahitoAmalgams)if(r){r.active=false;r.key=0;r.age=r.exit=0;r.g.visible=false;}}
