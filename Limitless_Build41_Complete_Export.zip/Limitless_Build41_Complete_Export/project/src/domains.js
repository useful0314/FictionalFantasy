// Domain staging is driven by simulation age so both peers see the same transition.
const DOMAIN_RULES={duration:12,voidTunnel:1.35,voidReveal:2.05,shrineTick:.1,shrineDPS:600/12,voidTick:.6,voidDamage:550/20};
const SHRINE_VISUALS={air:320,ground:96,lowAir:128,lowGround:40,cycle:.28,groundCycle:.55,soundHz:9};
const domainNoise=`
float hash31(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
float noise3(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(hash31(i),hash31(i+vec3(1,0,0)),f.x),mix(hash31(i+vec3(0,1,0)),hash31(i+vec3(1,1,0)),f.x),f.y),mix(mix(hash31(i+vec3(0,0,1)),hash31(i+vec3(1,0,1)),f.x),mix(hash31(i+vec3(0,1,1)),hash31(i+vec3(1,1,1)),f.x),f.y),f.z);}
float fbm(vec3 p){float n=0.,a=.5;for(int i=0;i<4;i++){n+=a*noise3(p);p=p*2.03+vec3(4.2,1.7,3.8);a*=.5;}return n;}
`;
function domainPhase(age){return age<DOMAIN_RULES.voidTunnel?'tunnel':age<DOMAIN_RULES.voidReveal?'transition':'void';}
function domainUniforms(kind,origin,axis){return {uTime:{value:0},uAge:{value:0},uMode:{value:kind==='gojo'?0:kind==='sukuna'?1:2},uBalance:{value:0},uOrigin:{value:origin.clone()},uAxis:{value:axis.clone()},uReveal:{value:0},uEnd:{value:1}};}
// Clip every realm layer at the physical wall, including instanced cuts and glows.
function confineDomainVisual(root,origin){
 const center={value:origin.clone().add(V(0,1.45,0))},radius={value:DOMAIN_ENCLOSURE.radius-.18};
 const patch=(shader,custom)=>{
  shader.uniforms.uDomainCenter=center;shader.uniforms.uDomainRadius=radius;
  shader.vertexShader='varying vec3 vDomainWorld;\n'+shader.vertexShader;
  const world='\nvec4 domainLocal=vec4('+(custom?'position':'transformed')+',1.);\n#ifdef USE_INSTANCING\ndomainLocal=instanceMatrix*domainLocal;\n#endif\nvDomainWorld=(modelMatrix*domainLocal).xyz;\n';
  shader.vertexShader=custom?shader.vertexShader.replace(/void\s+main\s*\(\s*\)\s*\{/,m=>m+world):shader.vertexShader.includes('#include <project_vertex>')?shader.vertexShader.replace('#include <project_vertex>','#include <project_vertex>'+world):shader.vertexShader.replace(/void\s+main\s*\(\s*\)\s*\{/,m=>m+world.replace('transformed','position'));
  shader.fragmentShader='varying vec3 vDomainWorld;uniform vec3 uDomainCenter;uniform float uDomainRadius;\n'+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace(/void\s+main\s*\(\s*\)\s*\{/,m=>m+'if(distance(vDomainWorld,uDomainCenter)>uDomainRadius)discard;');
 };
 const seen=new Set();root.traverse(o=>{if(!o.material)return;for(const m of Array.isArray(o.material)?o.material:[o.material]){if(seen.has(m))continue;seen.add(m);m.userData.domainClip={center:center.value,radius:radius.value};if(m.isShaderMaterial)patch(m,true);else{m.onBeforeCompile=s=>patch(s,false);m.customProgramCacheKey=()=> 'domain-sphere-v1';}m.needsUpdate=true;}});
}
function clearDomainVisual(){
 if(mindscapePool)mindscapePool.g.visible=false;
 const previous=domainVisual.userData;
 for(const item of previous.surfaces||[])item.mesh.material=item.material;
 for(const item of previous.hidden||[])item.object.visible=item.visible;
 for(const d of debris)if(d.m.material===previous.surfaceMaterial)d.m.material=mats.stone;
 previous.surfaceMaterial?.dispose();
 while(domainVisual.children.length)removeObject(domainVisual.children[0]);
 domainVisual.userData={};domainVisual.rotation.set(0,0,0);applyMapEnvironment();syncDomainTerrain();
 $('domainState')?.classList.add('hidden');
}
function domainBackdrop(kind,origin,axis=V(0,0,-1)){
 if(kind==='mahito'){mahitoDomainBackdrop(origin,axis);return;}
 if(kind==='mahito-clash'){buildMahitoClash(origin,axis);return;}
 if(kind==='naruto'){mindscapeBackdrop(kind,origin,axis);return;}
 if(kind==='mindscape-clash'){buildMindscapeClash(origin,axis);return;}
 clearDomainVisual();if(enclosure()&&!insideEnclosure(player))return;axis=axis.clone().setY(0).normalize();if(axis.lengthSq()<.5)axis.set(0,0,-1);
 sky.visible=false;shrine.visible=false;scene.background.set(0x02030c);scene.fog.density=.0015;scene.fog.color.set(kind==='sukuna'?0x310511:0x030311);hemi.intensity=1.6;sun.intensity=2.1;rim.intensity=1.8;
 const uniforms=domainUniforms(kind,origin,axis),hidden=[];
 for(const object of [grid,edge,arenaAccents]){hidden.push({object,visible:object.visible});object.visible=false;}
 for(const p of pieces)p.m.traverse(o=>{if(o.isSprite){hidden.push({object:o,visible:o.visible});o.visible=false;}});
 const dome=mesh(new THREE.SphereGeometry(DOMAIN_ENCLOSURE.radius-.3,64,40),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:true,uniforms,
  vertexShader:'varying vec3 vP;void main(){vP=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:`varying vec3 vP;uniform float uTime,uAge,uMode,uBalance,uReveal,uEnd;uniform vec3 uAxis;${domainNoise}
  void main(){vec3 d=normalize(vP),right=vec3(-uAxis.z,0.,uAxis.x);float a=atan(dot(d,right),dot(d,uAxis));float latitude=d.y;
   float nebula=fbm(d*5.+vec3(0.,uTime*.013,0.));float dust=fbm(d*27.-uTime*.015);float star=pow(hash31(floor(d*650.)),210.)*(.5+.5*sin(uTime*.4+hash31(floor(d*650.))*20.));
   vec3 voidColor=vec3(.001,.002,.008)+vec3(.016,.09,.21)*pow(nebula,3.)+vec3(.23,.48,.74)*star*.7+vec3(.035,.065,.1)*pow(dust,5.);
   float horizon=pow(1.-abs(latitude),5.);float storm=fbm(d*7.+vec3(uTime*.028,0.,-uTime*.02));
   vec3 shrineColor=vec3(.12,.003,.012)+vec3(.49,.014,.026)*(storm*.6+horizon*.35);float rift=pow(1.-abs(sin(a*8.+latitude*16.+storm*8.)),28.);shrineColor+=vec3(.7,.09,.075)*rift*.13;
   float split=smoothstep(-.07,.07,dot(d,right)-uBalance*.58);float red=uMode<.5?0.:uMode<1.5?1.:split;
   vec3 finalColor=mix(voidColor,shrineColor,red);float seam=uMode>1.5?pow(1.-abs(split*2.-1.),7.):0.;finalColor+=vec3(.43,.11,.64)*seam*.5;
   gl_FragColor=vec4(finalColor*uEnd,1.);
  }`}),domainVisual,origin.clone().add(V(0,1.45,0)));
 const surfaceMaterial=new THREE.ShaderMaterial({uniforms,vertexShader:'varying vec3 w,n;varying vec2 tex;void main(){vec4 world=modelMatrix*vec4(position,1.);w=world.xyz;n=normalize(mat3(modelMatrix)*normal);tex=uv;gl_Position=projectionMatrix*viewMatrix*world;}',
  fragmentShader:`varying vec3 w,n;varying vec2 tex;uniform vec3 uOrigin,uAxis;uniform float uMode,uTime,uAge,uBalance,uReveal;${domainNoise}
   void main(){vec3 right=vec3(-uAxis.z,0.,uAxis.x);float split=smoothstep(-3.,3.,dot(w-uOrigin,right)-uBalance*30.);float red=uMode<.5?0.:uMode<1.5?1.:split;float edge=1.-smoothstep(.006,.022,min(min(tex.x,tex.y),min(1.-tex.x,1.-tex.y)));float grain=fbm(w*.12+vec3(0.,uTime*.015,0.));float speck=pow(hash31(floor(w*9.)),90.);float sheen=pow(max(0.,n.y),4.);
    vec3 blue=mix(vec3(.055,.009,.09),vec3(.002,.008,.024),uReveal)+vec3(.05,.22,.4)*(edge*.28+speck*.12+grain*sheen*.09);
    vec3 crimson=vec3(.105,.006,.012)+vec3(.28,.014,.022)*grain+vec3(.35,.045,.035)*edge*.4;
    gl_FragColor=vec4(mix(blue,crimson,red)*(.65+.35*sheen),1.);
   }`});
 const surfaces=[];for(const object of [floor,base,...pieces.map(p=>p.m)]){surfaces.push({mesh:object,material:object.material});object.material=surfaceMaterial;}
 const rings=[];for(let i=0;i<3;i++){const r=mesh(new THREE.TorusGeometry(DOMAIN_ENCLOSURE.radius-.8,.025,4,128),new THREE.MeshBasicMaterial({color:kind==='sukuna'?0x830f23:0x709bcf,transparent:true,opacity:.22,depthWrite:false,blending:THREE.AdditiveBlending}),domainVisual,origin.clone().add(V(0,1.45,0)));r.rotation.set(i*Math.PI/3,Math.PI/4,i*Math.PI/4);rings.push(r);}
 let tunnel=null,hole=null,temple=null,cuts=null,motes=null;
 if(kind!=='sukuna'){
  // Project the rushing tunnel onto the inner sphere, keeping its vanishing point within the wall.
  tunnel=mesh(new THREE.SphereGeometry(DOMAIN_ENCLOSURE.radius-.55,64,40),new THREE.ShaderMaterial({side:THREE.BackSide,transparent:true,depthWrite:false,uniforms,
   vertexShader:'varying vec2 vUv;varying vec3 vW;void main(){vUv=uv;vW=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
   fragmentShader:`varying vec2 vUv;varying vec3 vW;uniform vec3 uAxis,uOrigin;uniform float uTime,uAge,uReveal,uMode,uBalance;${domainNoise}
    void main(){vec3 ray=normalize(vW-uOrigin-vec3(0.,1.45,0.)),right=vec3(-uAxis.z,0.,uAxis.x);float angle=atan(ray.y,dot(ray,right));float radial=max(.055,length(vec2(ray.y,dot(ray,right))));float z=dot(ray,uAxis)/radial*8.-uAge*22.;float bend=sin(z*.09+angle*3.)*.5;float lanes=pow(max(0.,sin(angle*83.+bend)),24.);float fine=pow(max(0.,sin(angle*171.-bend*.4)),48.);float ribbons=pow(max(0.,sin(angle*14.+z*.02+sin(angle*4.+z*.025))),8.);float streak=noise3(vec3(z*.35,floor(angle*27.),0.));float rush=pow(max(0.,sin(z+hash31(vec3(floor(angle*13.),0.,0.))*25.)),14.);vec3 c=vec3(.018,.002,.03)+vec3(.5,.018,.82)*(lanes*(.2+streak)*1.6+ribbons*.24)+vec3(1.,.25,.7)*(fine*.9+lanes*rush*1.1);float side=uMode>1.5?1.-smoothstep(-.08,.08,dot(vW-uOrigin,right)/40.-uBalance*.58):1.;gl_FragColor=vec4(c,(1.-uReveal)*side);}
   `}),domainVisual,origin.clone().add(V(0,1.45,0)));tunnel.quaternion.setFromUnitVectors(V(0,1,0),axis);tunnel.renderOrder=-1;
  hole=new THREE.Group();domainVisual.add(hole);hole.position.copy(origin).addScaledVector(axis,30).add(V(0,11,0));if(kind==='clash')hole.position.addScaledVector(V(-axis.z,0,axis.x),-15);
  mesh(new THREE.PlaneGeometry(37,37),new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms,vertexShader:'varying vec2 uv0;void main(){uv0=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:`varying vec2 uv0;uniform float uTime,uReveal,uEnd;${domainNoise}
   void main(){vec2 p=uv0-.5;float r=length(p),a=atan(p.y,p.x);vec2 curl=vec2(cos(a-r*8.+uTime*.04),sin(a-r*8.+uTime*.04));float cloud=fbm(vec3(curl*(r*12.+1.),uTime*.055));float wisps=fbm(vec3(p*35.+curl*2.,-uTime*.08));float rim=exp(-abs(r-.16)*210.);float outer=smoothstep(.153,.21,r)*(1.-smoothstep(.22,.49,r));float smoke=pow(cloud,2.)*outer*(.6+wisps);float filaments=pow(max(0.,sin(a*18.+cloud*12.-r*35.-uTime*.1)),12.)*smoke;vec3 c=vec3(.018,.07,.15)*smoke+vec3(.55,.78,1.)*(smoke*1.7+filaments*.8)+vec3(1.,.97,.91)*rim*2.;float blackCore=1.-smoothstep(.151,.157,r);c*=1.-blackCore;float alpha=max(blackCore,max(rim,smoke*2.8));gl_FragColor=vec4(c*uEnd,clamp(alpha,0.,1.)*uReveal*uEnd);}
  `}),hole);
  const data=[];for(let i=0;i<600;i++){const a=i*2.399963,y=domainHash(i+93)*2-1,r=Math.cbrt(domainHash(i+21))*51,h=Math.sqrt(1-y*y)*r;data.push(Math.cos(a)*h,1.45+y*r,Math.sin(a)*h);}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(data,3));motes=new THREE.Points(g,new THREE.PointsMaterial({color:0xc2e9ff,size:.08,transparent:true,opacity:0,depthWrite:false,blending:THREE.AdditiveBlending}));motes.position.copy(origin);domainVisual.add(motes);
 }
 if(kind!=='gojo'){
  const right=V(-axis.z,0,axis.x);temple=buildShrine(domainVisual,origin.clone().addScaledVector(axis,-26).addScaledVector(right,kind==='clash'?24:0),1.65);temple.rotation.y=Math.atan2(axis.x,axis.z);
  cuts=makeShrineCuts();domainVisual.add(cuts.core,cuts.edge,cuts.ground);
  const moon=mesh(new THREE.SphereGeometry(4,32,24),new THREE.MeshBasicMaterial({color:0xb91232}),domainVisual,origin.clone().addScaledVector(axis,32).add(V(11,28,0)));const halo=glow(0xff294f,18,.24,domainVisual);halo.position.copy(moon.position);
 }
 domainVisual.userData={dome,tunnel,hole,temple,cuts,motes,rings,kind,origin:origin.clone(),axis:axis.clone(),uniforms,surfaces,surfaceMaterial,hidden,lastCutSound:-1,transitionSound:false};
 enrichDomain(domainVisual.userData);confineDomainVisual(domainVisual,origin);animateDomainVisual();
}
function domainHash(n){const a=Math.sin(n*127.1+311.7)*43758.5453;return a-Math.floor(a);}
function makeShrineCuts(){
 const positions=[];for(let i=0;i<6;i++){const x=i/6-.5,nx=(i+1)/6-.5,y=Math.sin(i*2.1)*.015,ny=Math.sin((i+1)*2.1)*.015,w=Math.sin((i+.1)/6*Math.PI)*.5,nw=Math.sin((i+1)/6*Math.PI)*.5;positions.push(x,y-w,0,nx,ny-nw,0,x,y+w,0,nx,ny-nw,0,nx,ny+nw,0,x,y+w,0);}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
 const core=new THREE.InstancedMesh(g,new THREE.MeshBasicMaterial({color:0x010003,side:THREE.DoubleSide,transparent:true,opacity:.98,depthWrite:false,toneMapped:false}),SHRINE_VISUALS.air);
 const edgeMesh=new THREE.InstancedMesh(g,new THREE.MeshBasicMaterial({color:0xc87078,side:THREE.DoubleSide,transparent:true,opacity:.46,depthWrite:false,toneMapped:false}),SHRINE_VISUALS.air);
 const ground=new THREE.InstancedMesh(g,new THREE.MeshBasicMaterial({color:0x010003,side:THREE.DoubleSide,transparent:true,opacity:.9,depthWrite:false,toneMapped:false}),SHRINE_VISUALS.ground);
 for(const m of [core,edgeMesh,ground]){m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);m.frustumCulled=false;}core.renderOrder=4;edgeMesh.renderOrder=3;ground.renderOrder=2;
 return {core,edge:edgeMesh,ground,dummy:new THREE.Object3D(),roll:new THREE.Quaternion(),right:V(),normal:V(),up:V(0,0,1)};
}
function animateShrineCuts(v,age,balance){
 const c=v.cuts;if(!c)return;const light=particleBudget<1000,count=light?SHRINE_VISUALS.lowAir:SHRINE_VISUALS.air,groundCount=light?SHRINE_VISUALS.lowGround:SHRINE_VISUALS.ground,axis=v.axis,right=c.right.set(-axis.z,0,axis.x),dummy=c.dummy;
 c.core.count=c.edge.count=count;c.ground.count=groundCount;
 for(let i=0;i<count;i++){
  const clock=age+domainHash(i+100)*1.15,epoch=Math.floor(clock/SHRINE_VISUALS.cycle),life=clock/SHRINE_VISUALS.cycle-epoch,h=i+epoch*997;
  const a=domainHash(h+3)*Math.PI*2,y=domainHash(h+20)*2-1,r=Math.cbrt(domainHash(h+11))*48,flat=Math.sqrt(1-y*y)*r,across=Math.cos(a)*flat,depth=Math.sin(a)*flat;
  const onSide=v.kind!=='clash'||across-balance*30>0,open=narutoEase(life/.1),fade=clamp((.65-life)/.25,0,1),length=(8+domainHash(h+70)*23)*open;
  dummy.position.copy(v.origin).addScaledVector(right,across).addScaledVector(axis,depth);dummy.position.y+=1.45+y*r;
  dummy.quaternion.copy(camera.quaternion);c.roll.setFromAxisAngle(c.up,(domainHash(h+32)-.5)*Math.PI*2);dummy.quaternion.multiply(c.roll);
  dummy.scale.set(onSide?length:0,(.055+domainHash(h+52)*.16)*fade,1);dummy.updateMatrix();c.core.setMatrixAt(i,dummy.matrix);
  dummy.scale.y*=2.1;dummy.updateMatrix();c.edge.setMatrixAt(i,dummy.matrix);
 }
 // Former floor cuts now rake every latitude of the inner barrier, never world Y=0.
 for(let i=0;i<groundCount;i++){
  const h=i+Math.floor(age/SHRINE_VISUALS.groundCycle)*911,a=domainHash(h+200)*Math.PI*2,y=domainHash(h+219)*2-1,r=Math.sqrt(1-y*y),across=Math.cos(a)*r*52;
  c.normal.copy(right).multiplyScalar(Math.cos(a)*r).addScaledVector(axis,Math.sin(a)*r);c.normal.y=y;
  dummy.position.copy(v.origin).addScaledVector(c.normal,52);dummy.position.y+=1.45;dummy.quaternion.setFromUnitVectors(c.up,c.normal);c.roll.setFromAxisAngle(c.up,a+.7);dummy.quaternion.multiply(c.roll);
  dummy.scale.set(v.kind==='clash'&&across-balance*30<0?0:5+domainHash(h+213)*16,.025+domainHash(h+333)*.08,1);dummy.updateMatrix();c.ground.setMatrixAt(i,dummy.matrix);
 }
 c.core.instanceMatrix.needsUpdate=c.edge.instanceMatrix.needsUpdate=c.ground.instanceMatrix.needsUpdate=true;
 const soundBeat=Math.floor(age*SHRINE_VISUALS.soundHz);if(soundBeat!==v.lastCutSound&&phase==='play'){v.lastCutSound=soundBeat;sound.play('shrineCut',.7,Math.sin(age*11)*.65);}
}
function animateDomainVisual(){
 if(domainVisual.userData.mahitoHands)animateMahitoDomain();
 const v=domainVisual.userData;if(!v.uniforms)return;
 const age=clash?clash.t:domain?(finisher?DOMAIN_RULES.voidReveal+finisher.t*.3:domain.t):0,balance=clash?clamp(clash.participants.reduce((sum,id)=>sum+(clash.scores[id]||0)*(actorById(id)?.character==='gojo'?1:-1),0)/12,-1,1):0,reveal=THREE.MathUtils.smoothstep(age,DOMAIN_RULES.voidTunnel,DOMAIN_RULES.voidReveal),ending=finisher?1:domain?1-THREE.MathUtils.smoothstep(age,DOMAIN_RULES.duration-.35,DOMAIN_RULES.duration):1;
 v.uniforms.uTime.value=age;v.uniforms.uAge.value=age;v.uniforms.uBalance.value=balance;v.uniforms.uReveal.value=reveal;v.uniforms.uEnd.value=ending;
 if(v.tunnel)v.tunnel.visible=reveal<1;
 if(v.hole){v.hole.quaternion.copy(camera.quaternion);v.hole.scale.setScalar(1+Math.sin(age*.3)*.012);}
 if(v.motes){v.motes.material.opacity=reveal*.65*ending;v.motes.rotation.y=age*.006;}
 if(v.temple){const appear=THREE.MathUtils.smoothstep(age,0,.7);v.temple.position.y=v.origin.y-4*(1-appear);}
 for(let i=0;i<v.rings.length;i++){v.rings[i].rotation.z=age*(i%2?.1:-.08);v.rings[i].material.opacity=(.12+Math.sin(age*1.2+i)*.04)*ending;}
 animateShrineCuts(v,age,balance);animateDomainAccents(v,age,reveal,ending);
 if(v.kind!=='sukuna'&&reveal>=.7&&!v.transitionSound){v.transitionSound=true;sound.play('voidArrival',.8);}
 const status=$('domainState');if(status){status.classList.toggle('hidden',!domain||phase!=='play');if(domain){$('domainStage').textContent=domain.owner.character==='gojo'?(domainPhase(age)==='void'?'UNLIMITED VOID':'LIMITLESS · ENTERING THE VOID'):'MALEVOLENT SHRINE · CONTINUOUS SLASHES';$('domainTime').textContent=Math.max(0,DOMAIN_RULES.duration-age).toFixed(1)+'s';status.dataset.kind=domain.owner.character;}}
}
function updateDomains(dt){
 for(const f of bodies){const cast=castFor(f);if(!cast)continue;cast.t+=dt;if(frameCount%3===0)particles(headPos(f),fighterColor(f),5,3,.7,.15);if(cast.t>=DOMAIN_ENCLOSURE.startup){activateDomain(f);break;}}
 if(clash){clash.t+=dt;clash.joinRemaining=Math.max(0,clash.joinRemaining-dt);syncClashScores();const winner=clash.participants.find(id=>(clash.scores[id]||0)>=12);if(winner&&clash.joinRemaining<=0)activateDomain(actorById(winner));}
 if(domain?.owner.character==='mahito')updateMahitoDomain(domain,dt);
 else if(domain?.owner.character==='naruto')updateMindscapeDomain(domain,dt);
 else if(domain){
  const d=domain,activeTime=Math.min(dt,Math.max(0,DOMAIN_RULES.duration-d.t));d.t+=activeTime;d.pulse+=activeTime;d.terrainPulse=(d.terrainPulse||0)+activeTime;
  const shrineDomain=d.owner.character==='sukuna',interval=shrineDomain?DOMAIN_RULES.shrineTick:DOMAIN_RULES.voidTick;
  while(d.pulse+1e-8>=interval&&phase==='play'){d.pulse=Math.max(0,d.pulse-interval);for(const victim of opponents(d.owner))if(insideEnclosure(victim)){hurt(victim,shrineDomain?DOMAIN_RULES.shrineDPS*interval:DOMAIN_RULES.voidDamage,d.owner,'ultimate',V(),0);if(!shrineDomain){particles(headPos(victim),C.blue,8,2,.7,.14);slashRibbon(headPos(victim),V(0,0,1),C.blue,2,.45,Math.PI/2);}}}
  if(shrineDomain&&d.terrainPulse>=.3){d.terrainPulse%=.3;const n=Math.floor(d.t/.3),a=domainHash(n+77)*Math.PI*2,r=8+domainHash(n+90)*17;destroyAt(d.origin.clone().add(V(Math.cos(a)*r,1,Math.sin(a)*r)),5,25);for(const victim of opponents(d.owner))if(insideEnclosure(victim))destroyAt(victim.pos,3.5,15);shakeIt(.045);}
  if((d.t>=DOMAIN_RULES.duration-1e-8||d.owner.hp<=0)&&phase==='play'){endActiveDomain(d);toast('DOMAIN COLLAPSED · normal battlefield restored',2);}
 }
 animateDomainVisual();
}
