// Cached DOM rows: duplicate characters remain distinguishable by fighter ID.
const opponentHealthRows=new Map();let opponentHealthKey='';
function updateOpponentHealthBars(){
 const host=$('opponentHealthBars'),show=bodies.length>2;host.classList.toggle('hidden',!show);if(!show)return;
 const key=bodies.filter(f=>f!==player).map(f=>f.id+':'+f.character+':'+f.bot).join('|');
 if(key!==opponentHealthKey){
  opponentHealthKey=key;opponentHealthRows.clear();host.replaceChildren();
  for(const f of bodies){if(f===player)continue;
   const row=document.createElement('div'),label=document.createElement('span'),value=document.createElement('b'),track=document.createElement('div'),fill=document.createElement('i'),trail=document.createElement('i');trail.className='healthTrail';
   row.className='opponentHealthRow';label.textContent=f.id.toUpperCase()+' · '+kit(f).short+' · '+(f.bot?'AI':'PLAYER');track.className='opponentHealthTrack';track.setAttribute('role','progressbar');track.setAttribute('aria-label',label.textContent);track.setAttribute('aria-valuemin','0');track.setAttribute('aria-valuemax',String(MAX_HEALTH));row.style.setProperty('--fighter-color',fighterTone(f));track.append(trail,fill);row.append(label,value,track);host.append(row);opponentHealthRows.set(f.id,{row,value,track,fill,trail,hp:-1});
  }
 }
 const target=other(player);
 for(const f of bodies){const r=opponentHealthRows.get(f.id);if(!r)continue;const hp=Math.ceil(clamp(f.hp,0,MAX_HEALTH));r.row.classList.toggle('target',f===target);r.row.classList.toggle('out',hp===0);if(hp===r.hp)continue;r.hp=hp;r.value.textContent=hp>0?String(hp):'OUT';r.fill.style.width=(hp/MAX_HEALTH*100)+'%';r.track.setAttribute('aria-valuenow',String(hp));}
}
