// Mahito-only geometry: softly bevelled blocks, independent joints and readable facial details.
const MAHITO_DESIGN={skin:0xc8d1d4,cloth:0x263344,patch:0x42546b,pants:0xd9dcd6,hair:0x839daf,hairLight:0xa5bbc7,ink:0x242937,bone:0xe1e3d9,wing:0x697c90};
function mahitoBlockGeometry(){return blockUnitGeometry();}
const mahitoBlock=mahitoBlockGeometry();
function mahitoShape(points,depth=.12){const s=new THREE.Shape();points.forEach((p,i)=>i?s.lineTo(...p):s.moveTo(...p));s.closePath();const g=new THREE.ExtrudeGeometry(s,{depth,steps:1,bevelEnabled:true,bevelThickness:.015,bevelSize:.015,bevelSegments:1,curveSegments:1});g.translate(0,0,-depth/2);return g;}
function fighterModelMahito(){
 const root=new THREE.Group(),body=new THREE.Group();root.name='mahito';scene.add(root);root.add(body);
 const materials={};for(const [name,color]of Object.entries(MAHITO_DESIGN))materials[name]=new THREE.MeshStandardMaterial({color,roughness:name==='hair'?.72:.87});
 const {skin,cloth,patch,pants,hair:hairMat,hairLight,ink,bone,wing:wingMat}=materials;
 function part(name,g,m,parent,p,s){const o=mesh(g,m,parent,p,s);o.name=name;o.castShadow=true;return o;}
 const block=(name,m,parent,p,s)=>part(name,mahitoBlock,m,parent,p,s);
 function joint(name,parent,p){const g=new THREE.Group();g.name=name;g.position.copy(p);parent.add(g);return g;}
 function seam(parent,p,width,count=5){block('sewn-seam',ink,parent,p,V(width,.008,.009));for(let i=0;i<count;i++)block('stitch',bone,parent,V(p.x-width/2+(i+.5)*width/count,p.y,p.z+.009),V(.014,.041,.009)).rotation.z=-.25;}
 const torso=block('patchwork-tunic',cloth,body,V(0,1.48,0),V(.76,.86,.46));
 block('asymmetric-chest-panel',patch,body,V(-.19,1.59,.238),V(.34,.58,.026));block('lower-tunic-panel',patch,body,V(.21,1.25,.24),V(.27,.28,.024));seam(body,V(0,1.34,.26),.74,9);for(let j=0;j<7;j++)block('vertical-tunic-stitch',bone,body,V(.011,1.4+j*.07,.266),V(.055,.012,.009)).rotation.z=.35;
 block('collar',cloth,body,V(0,1.91,.005),V(.42,.13,.38));block('waist',cloth,body,V(0,1.03,0),V(.68,.13,.43));block('hips',pants,body,V(0,.95,0),V(.62,.2,.40));block('neck',skin,body,V(0,2.01,0),V(.23,.21,.23));
 const headGroup=joint('head',body,V(0,2.25,0)),head=block('stitched-face',skin,headGroup,V(),V(.53,.59,.46));
 for(const side of [-1,1]){block('eye-socket',ink,headGroup,V(side*.125,.027,.237),V(.17,.06,.018)).rotation.z=-side*.08;block('eye-white',bone,headGroup,V(side*.125,.031,.249),V(.145,.035,.009));block('mismatched-iris',new THREE.MeshBasicMaterial({color:side<0?0x627dcc:0xa79255}),headGroup,V(side*.115,.029,.257),V(.041,.037,.009));block('pupil',ink,headGroup,V(side*.113,.029,.264),V(.017,.034,.006));block('eyebrow',hairMat,headGroup,V(side*.13,.108,.243),V(.16,.021,.017)).rotation.z=side*.1;}
 block('nose',skin,headGroup,V(0,-.037,.254),V(.063,.075,.045));block('smirk',ink,headGroup,V(.014,-.144,.242),V(.18,.012,.014)).rotation.z=.08;seam(headGroup,V(0,-.065,.241),.5,7);block('forehead-seam',ink,headGroup,V(.11,.19,.238),V(.009,.18,.01));for(let j=0;j<4;j++)block('forehead-stitch',ink,headGroup,V(.11,.125+j*.047,.249),V(.053,.012,.011));
 const hair=joint('layered-blue-hair',headGroup,V(0,.2,-.035));block('hair-crown',hairMat,hair,V(0,.035,-.017),V(.59,.25,.48));block('hair-back',hairMat,hair,V(0,-.25,-.227),V(.57,.67,.17));
 const locks=[],lockGeo=mahitoShape([[-.09,0],[.09,0],[.095,-.42],[.025,-.57],[-.062,-.48]],.13);
 for(let i=0;i<7;i++){const side=i<2?-1:i>4?1:0,x=side?side*(.265+(i%2)*.01):(i-3)*.16,z=side?.015:-.235,lock=joint('hair-lock-'+i,hair,V(x,-.025,z));part('layered-lock',lockGeo,i%2?hairLight:hairMat,lock,V(),V(side?.83:1,side?1.2:1.35,1));lock.rotation.z=side*.1;lock.userData.restZ=lock.rotation.z;locks.push(lock);}
 const fringe=mahitoShape([[-.1,.10],[.1,.07],[.065,-.10],[-.065,-.28],[-.055,-.04]],.075);for(let i=0;i<3;i++)part('swept-fringe',fringe,i===1?hairLight:hairMat,hair,V(-.18+i*.155,-.035,.235),V(1,1,1)).rotation.z=-.13;
 const limbs=[],legs=[],knees=[],weapons=[],hems=[],feet=[],bladeGeo=mahitoShape([[-.14,.12],[.14,.08],[.21,-.46],[.11,-1.2],[-.1,-1.48],[-.035,-.38]],.11);
 for(const side of [-1,1]){
  const arm=joint('shoulder',body,V(side*.5,1.83,0));block('upper-arm',cloth,arm,V(0,-.205,0),V(.29,.43,.30));block('sleeve-panel',patch,arm,V(side*.147,-.21,0),V(.018,.30,.25));
  const elbow=joint('elbow',arm,V(0,-.425,0)),forearm=block('forearm',skin,elbow,V(0,-.18,0),V(.245,.36,.25));block('sleeve-cuff',cloth,elbow,V(0,-.025,0),V(.26,.09,.27));seam(elbow,V(0,-.12,.133),.235,4);
  const hand=joint('hand',elbow,V(0,-.385,.005));block('palm',skin,hand,V(0,-.028,0),V(.23,.17,.135));const fingers=[];for(let j=0;j<4;j++){const finger=joint('finger-'+j,hand,V((j-1.5)*.052,-.104,.013));block('finger',skin,finger,V(0,-.057,0),V(.047,.114,.063));fingers.push(finger);}block('thumb',skin,hand,V(-side*.137,-.043,.012),V(.067,.135,.079)).rotation.z=-side*.28;
  const blade=joint('blade-arm',elbow,V(0,-.065,0));part('curved-bone-blade',bladeGeo,bone,blade,V(),V(side,1,1));block('blade-root',skin,blade,V(0,-.12,0),V(.3,.38,.28));block('blade-spine',patch,blade,V(side*.095,-.44,0),V(.065,.57,.12)).rotation.z=-side*.08;
  const gun=joint('gun-arm',elbow,V(0,-.04,0));block('organic-receiver',patch,gun,V(0,-.21,0),V(.37,.42,.38));block('bone-barrel',bone,gun,V(0,-.52,0),V(.31,.43,.33));block('barrel-mouth',ink,gun,V(0,-.747,0),V(.21,.02,.22));for(let j=0;j<3;j++)block('barrel-ridge',skin,gun,V(0,-.3-j*.14,0),V(.355,.052,.37));
  const hammer=joint('hammer-arm',elbow,V(0,-.035,0));block('heavy-forearm',skin,hammer,V(0,-.215,0),V(.32,.45,.32));block('hammer-core',patch,hammer,V(0,-.53,0),V(.72,.51,.60));for(const s of [-1,1]){block('hammer-striking-face',bone,hammer,V(s*.38,-.53,0),V(.12,.54,.64));for(let j=0;j<3;j++)block('hammer-stitch',ink,hammer,V(s*.27,-.38-j*.14,.305),V(.10,.018,.014));}block('hammer-bone-ridge',skin,hammer,V(0,-.53,.315),V(.16,.49,.036));
  for(const w of [blade,gun,hammer]){w.scale.setScalar(.001);w.visible=false;}weapons.push({blade,gun,hammer,hand,forearm});limbs.push({arm,elbow,hand,fingers});
  const hip=joint('hip',body,V(side*.184,.95,0));block('baggy-thigh',pants,hip,V(0,-.19,0),V(.325,.39,.37));block('pant-fold',bone,hip,V(side*.15,-.16,.09),V(.025,.25,.16)).rotation.z=-side*.07;
  const knee=joint('knee',hip,V(0,-.385,0));block('lower-leg',pants,knee,V(0,-.18,0),V(.285,.36,.30));block('ankle-cuff',patch,knee,V(0,-.315,0),V(.28,.06,.30));const foot=joint('ankle',knee,V(0,-.46,.09));block('bare-foot',skin,foot,V(),V(.29,.16,.44));for(let j=0;j<3;j++)block('toe-separation',ink,foot,V((j-1)*.065,.063,.145),V(.008,.011,.11));feet.push(foot);legs.push(hip);knees.push(knee);
  const hem=joint('tunic-hem',body,V(side*.2,1.075,0));block('tunic-tail',cloth,hem,V(0,-.07,-.015),V(.35,.17,.47));hems.push(hem);
 }
 const wings=[],membrane=mahitoShape([[0,0],[.58,.6],[1.48,.77],[1.22,.2],[1.65,-.08],[1.10,-.42],[.77,-.20],[.35,-.48],[.19,-.1]],.055);
 for(const side of [-1,1]){const wing=joint('transfigured-wing',body,V(side*.25,1.78,-.23));part('stitched-wing-membrane',membrane,wingMat,wing,V(),V(side,1,1));for(const [x,y,length,angle]of [[.34,.31,.84,-.78],[1.02,.66,.9,-1.42],[.75,.08,1.18,-1.1]]){const o=block('wing-bone',skin,wing,V(side*x,y,-.01),V(.07,length,.09));o.rotation.z=side*angle;}wing.visible=false;wing.scale.setScalar(.001);wings.push(wing);}
 const shadow=mesh(new THREE.CircleGeometry(.7,24),new THREE.MeshBasicMaterial({color:0x02060e,transparent:true,opacity:.4,depthWrite:false}),scene);shadow.rotation.x=-Math.PI/2;
 const shieldMat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,uniforms:{uOpacity:{value:0},uTime:{value:0}},vertexShader:'varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 p;uniform float uOpacity,uTime;void main(){gl_FragColor=vec4(.65,.9,.85,(.1+pow(abs(sin(p.y*15.-uTime*2.)),12.))*uOpacity);}'});shieldMat.opacity=0;
 const shield=mesh(new THREE.SphereGeometry(1.3,16,12),shieldMat,root,V(0,1.35,0));return {root,body,head,headGroup,limbs,legs,knees,shadow,shield,band:null,blockRig:null,narutoRig:null,mahitoRig:{torso,locks,weapons,wings,hems,feet,pose:new Float32Array(30)}};
}
function animateMahitoDetail(f,dt){
 const blend=1-Math.exp(-dt/MAHITO.blend),deformed=f.soulTime>0;
 if(f.character!=='mahito'){if(!deformed&&!f.soulDeforming)return;f.soulDeforming=deformed||Math.abs(f.body.scale.x-1)>.001;f.body.scale.lerp(mahitoScratch.a.set(deformed?1.12:1,deformed?.94:1,deformed?.91:1),blend);return;}
 const r=f.mahitoRig;for(let i=0;i<r.feet.length;i++){const stride=Math.sin((f.walkPhase||0)+(i?Math.PI:0)),moving=(f.rosterAnim?.speed||0)>.4;r.feet[i].rotation.x=f.rosterAnim?.comboMotion?.render?f.rosterAnim.comboMotion.pose[i?NP.rf:NP.lf]:lerp(r.feet[i].rotation.x,!f.grounded?.15:moving?-stride*.19:0,1-Math.exp(-dt/ROSTER_MOTION.blend));}const form=f.mahitoForm||0,scale=MAHITO.forms[form].scale;f.root.scale.lerp(mahitoScratch.a.set(scale*(deformed?1.12:1),scale*(deformed?.94:1),scale),blend);
 for(let i=0;i<2;i++){const w=r.weapons[i];for(let k=1;k<=3;k++){const obj=k===1?w.blade:k===2?w.gun:w.hammer,target=f.mahitoArm===k?1:.001;obj.scale.lerp(mahitoScratch.a.setScalar(target),blend);obj.visible=obj.scale.x>.015;}w.hand.scale.setScalar(Math.max(.001,1-Math.max(w.blade.scale.x,w.gun.scale.x,w.hammer.scale.x)));w.hand.visible=w.hand.scale.x>.015;w.forearm.visible=f.mahitoArm!==3;
  const wing=r.wings[i],target=form===3?1:.001;wing.scale.lerp(mahitoScratch.a.setScalar(target),blend);wing.visible=wing.scale.x>.015;wing.rotation.y=(i?1:-1)*(.23+Math.sin(time*6)*.28);wing.rotation.z=(i?1:-1)*Math.sin(time*6)*.10;
 }
 for(let i=0;i<r.locks.length;i++){const lock=r.locks[i];lock.rotation.x=lerp(lock.rotation.x,Math.sin(time*2.2+i*.7)*.03+(f.sprinting?.24:0)-f.body.rotation.x*.23,1-Math.exp(-dt/.14));lock.rotation.z=lerp(lock.rotation.z,lock.userData.restZ-Math.sin(f.body.rotation.y)*.08+Math.sin(time*2+i)*.018,1-Math.exp(-dt/.16));}
 for(let i=0;i<r.hems.length;i++)r.hems[i].rotation.x=lerp(r.hems[i].rotation.x,Math.sin((f.walkPhase||0)+i*Math.PI)*.045+(f.sprinting?.15:0),1-Math.exp(-dt/.12));
}
