// Naruto presentation pools. No game damage is applied from these functions.
// Appearance and effect lifetimes; move timings/shake/pool sizes live in NARUTO.
const NARUTO_VFX={core:0xc7f6ff,blades:0xe3fbff,smoke:0xdbdbd3,dust:0xa9a096,cracks:0x2d2534,stones:0x586477,
 smokeLife:.55,trailLife:.11,emberLife:2,particleLife:.65,fxLife:{bomb:1.8,transform:1.2,ground:1.1,other:.65},rasenganSize:.32,shurikenSize:.75,bombSize:3,dim:.33};
let narutoVisuals=null;
function narutoSphereRig(){
 const g=new THREE.Group(),core=mesh(geo.sphere,new THREE.MeshBasicMaterial({color:NARUTO_VFX.core}),g,V(),V(.57,.57,.57)),skin=mesh(geo.sphere,energySkin(NARUTO.colors.chakra),g),arcs=[];
 for(let i=0;i<3;i++){const a=arcStrip(g,i===1?0xffffff:NARUTO.colors.chakra,{radius:1+i*.08,start:i*1.8,length:Math.PI*3,width:.055,helix:1.2});a.rotation.x=i*Math.PI/3;arcs.push(a);}
 const blades=new THREE.Group();g.add(blades);const bladeGeometry=new THREE.BufferGeometry();bladeGeometry.setAttribute('position',new THREE.Float32BufferAttribute([.35,-.18,0,2.8,-.05,0,1.3,.27,0,.35,-.18,0,1.3,.27,0,.4,.2,0],3));const mat=new THREE.MeshBasicMaterial({color:NARUTO_VFX.blades,transparent:true,opacity:.8,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,depthWrite:false});
 for(let i=0;i<4;i++){const m=mesh(bladeGeometry,mat,blades);m.rotation.z=i*Math.PI/2;}
 const beam=mesh(new THREE.CylinderGeometry(1,1,1,12,1,true),energySkin(NARUTO.colors.ember),g);beam.rotation.x=Math.PI/2;beam.visible=false;
 g.visible=false;scene.add(g);return {g,core,skin,arcs,blades,beam,kind:3};
}
function narutoSphereAppearance(r,kind,t,q,scale){
 const bomb=kind===5;r.g.visible=true;r.kind=kind;r.g.scale.setScalar(scale);r.core.visible=true;r.core.material.color.setHex(bomb?NARUTO.colors.dark:NARUTO_VFX.core);r.skin.material.uniforms.uColor.value.setHex(bomb?NARUTO.colors.ember:NARUTO.colors.chakra);r.skin.material.uniforms.uTime.value=t;r.skin.material.uniforms.uFade.value=.7;
 r.blades.visible=kind===4;r.blades.rotation.z=t*22;r.beam.visible=false;
 for(let i=0;i<r.arcs.length;i++){const arc=r.arcs[i];arc.rotation.z=t*(i%2?-4.3:5.2);arc.rotation.y=t*.8+i*1.2;arc.material.color.setHex(bomb?(i%2?NARUTO.colors.gold:NARUTO.colors.ember):i%2?0xffffff:NARUTO.colors.chakra);arc.material.opacity=.65;}
}
function ensureNarutoVisuals(){
 if(narutoVisuals)return narutoVisuals;
 const pool=NARUTO.particlePool,geometry=new THREE.BufferGeometry(),pos=new Float32Array(pool*3),color=new Float32Array(pool*3),size=new Float32Array(pool),opacity=new Float32Array(pool),smoke=new Float32Array(pool);
 geometry.setAttribute('position',new THREE.BufferAttribute(pos,3).setUsage(THREE.DynamicDrawUsage));geometry.setAttribute('color',new THREE.BufferAttribute(color,3));geometry.setAttribute('size',new THREE.BufferAttribute(size,1));geometry.setAttribute('opacity',new THREE.BufferAttribute(opacity,1).setUsage(THREE.DynamicDrawUsage));geometry.setAttribute('smoke',new THREE.BufferAttribute(smoke,1));
 const material=new THREE.ShaderMaterial({transparent:true,depthWrite:false,vertexColors:true,uniforms:{ratio:{value:renderer.getPixelRatio()}},vertexShader:'attribute float size,opacity,smoke;varying vec3 c;varying float a,s;uniform float ratio;void main(){c=color;a=opacity;s=smoke;vec4 p=modelViewMatrix*vec4(position,1.);gl_Position=projectionMatrix*p;gl_PointSize=clamp(size*ratio*280./max(1.,-p.z),1.,150.);}',fragmentShader:'varying vec3 c;varying float a,s;void main(){float r=length(gl_PointCoord-.5)*2.;if(r>1.)discard;float edge=pow(1.-r,s>.5?1.2:2.);gl_FragColor=vec4(c,a*edge);}'});
 const points=new THREE.Points(geometry,material);points.frustumCulled=false;scene.add(points);
 const v=narutoVisuals={particles:{geometry,pos,color,size,opacity,smoke,life:new Float32Array(pool),max:new Float32Array(pool),velocity:new Float32Array(pool*3),cursor:0,farCursor:0,points,material},fx:[],fxCursor:0,charges:[],shots:[],zones:[],clones:[],cloneBatches:[],zero:new THREE.Matrix4().makeScale(0,0,0),tmp:V(),tmp2:V(),up:V(0,0,1),cloaks:new Map(),lastTime:0};
 for(let i=0;i<MAX_FIGHTERS;i++)v.charges.push(narutoSphereRig());for(let i=0;i<NARUTO.visualProjectiles;i++)v.shots.push(narutoSphereRig());for(let i=0;i<12;i++)v.zones.push(narutoSphereRig());
 const crackVertices=[];for(let i=0;i<9;i++){let x=0,z=0;const a=i/9*Math.PI*2;for(let n=1;n<=4;n++){const xx=Math.cos(a)*n*.25+Math.sin(i*4+n)*.07,zz=Math.sin(a)*n*.25;crackVertices.push(x,.015,z,xx,.015,zz);x=xx;z=zz;}}
 const crackGeo=new THREE.BufferGeometry();crackGeo.setAttribute('position',new THREE.Float32BufferAttribute(crackVertices,3));
 for(let i=0;i<NARUTO.fxPool;i++){const g=new THREE.Group();scene.add(g);g.visible=false;const mat=new THREE.MeshBasicMaterial({color:0x99e8ff,transparent:true,opacity:0,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}),rings=[];for(let j=0;j<3;j++){const ring=mesh(geo.ring,mat,g);ring.rotation.x=j===0?Math.PI/2:j*.6;ring.rotation.y=j*.8;rings.push(ring);}const cracks=new THREE.LineSegments(crackGeo,new THREE.LineBasicMaterial({color:NARUTO_VFX.cracks,transparent:true,opacity:0}));g.add(cracks);const chunks=new THREE.InstancedMesh(geo.lowSphere,new THREE.MeshStandardMaterial({color:NARUTO_VFX.stones,roughness:.9}),12);chunks.instanceMatrix.setUsage(THREE.DynamicDrawUsage);chunks.frustumCulled=false;g.add(chunks);v.fx.push({g,mat,rings,cracks,chunks,dummy:new THREE.Object3D(),t:99,life:1,radius:1,kind:'',dir:V()});}
 return v;
}
function narutoEmit(pos,color,count,life,speed,size,smoke=false,inward=false){
 const p=ensureNarutoVisuals().particles,r=((color>>16)&255)/255,g=((color>>8)&255)/255,b=(color&255)/255;
 for(let n=0;n<count;n++){const a=rr(0,Math.PI*2),y=rr(-.5,1),radius=Math.sqrt(1-y*y),s=rr(.3,1)*speed,x=Math.cos(a)*radius,z=Math.sin(a)*radius,lifeSample=rr(.7,1),sizeSample=rr(.6,1.5),density=visualDensity(pos);if(Math.floor((n+1)*density)===Math.floor(n*density))continue;const reserve=Math.floor(NARUTO.particlePool*BATTLE_VISUAL.particleReserve),i=player.pos.distanceToSquared(pos)<BATTLE_VISUAL.near**2?p.cursor++%NARUTO.particlePool:reserve+p.farCursor++%(NARUTO.particlePool-reserve),j=i*3;p.pos[j]=pos.x+(inward?x*speed*.4:0);p.pos[j+1]=pos.y+(inward?y*speed*.4:0);p.pos[j+2]=pos.z+(inward?z*speed*.4:0);p.velocity[j]=x*s*(inward?-1:1);p.velocity[j+1]=y*s*(inward?-1:1)+(smoke?.9:0);p.velocity[j+2]=z*s*(inward?-1:1);p.life[i]=p.max[i]=life*lifeSample;p.color[j]=r;p.color[j+1]=g;p.color[j+2]=b;p.size[i]=size*sizeSample;p.smoke[i]=smoke?1:0;}
 p.geometry.attributes.color.needsUpdate=p.geometry.attributes.size.needsUpdate=p.geometry.attributes.smoke.needsUpdate=true;
}
function narutoFX(kind,pos,radius=1,dir=null,replicate=true){
 if(replicate)netFX('naruto',[kind,pos.toArray(),radius,dir?dir.toArray():[0,0,1]]);
 if(kind==='smoke'||kind==='dust'){narutoEmit(pos,kind==='smoke'?NARUTO_VFX.smoke:NARUTO_VFX.dust,kind==='smoke'?22:12,NARUTO_VFX.smokeLife,kind==='smoke'?3:2,kind==='smoke'?1.0:.55,true);return;}
 const v=ensureNarutoVisuals(),e=v.fx[v.fxCursor++%v.fx.length];e.kind=kind;e.t=0;e.life=NARUTO_VFX.fxLife[kind]||NARUTO_VFX.fxLife.other;e.radius=radius;e.g.position.copy(pos);e.g.rotation.set(0,0,0);if(dir)e.dir.copy(dir);else e.dir.set(0,0,1);e.g.visible=true;e.mat.color.setHex(kind==='bomb'||kind==='transform'?NARUTO.colors.gold:kind==='ground'?0xf0c596:NARUTO.colors.chakra);e.cracks.visible=kind==='ground'||kind==='transform'||kind==='bomb';e.chunks.visible=kind==='ground'||kind==='transform';for(const ring of e.rings)ring.visible=kind!=='wind';
 if(kind==='spiral'||kind==='muzzle')e.g.quaternion.setFromUnitVectors(v.up,e.dir);
 narutoEmit(pos,kind==='bomb'?NARUTO.colors.ember:kind==='transform'?NARUTO.colors.gold:NARUTO.colors.chakra,kind==='bomb'?100:kind==='transform'?55:22,kind==='bomb'?NARUTO_VFX.emberLife:NARUTO_VFX.particleLife,kind==='bomb'?20:8,kind==='bomb'?.25:.14);
 if(e.cracks.visible)narutoEmit(pos,0xb5aa94,28,.8,5,.65,true);
}
function narutoLimbTrail(from,to,color){
 if(from.distanceToSquared(to)>9||from.distanceToSquared(to)<.008)return;const v=ensureNarutoVisuals();for(let i=1;i<=3;i++){v.tmp.copy(from).lerp(to,i/3);narutoEmit(v.tmp,color,1,NARUTO_VFX.trailLife,.1,.13);}
}
function makeNarutoCloak(f){
 const g=new THREE.Group();f.body.add(g);g.name='nine-tails-cloak';
 const material=new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,uniforms:{uTime:{value:0},uFade:{value:0}},vertexShader:'varying vec3 p,n,v;uniform float uTime;void main(){p=position;n=normalMatrix*normal;vec3 q=position+normal*(sin(position.y*12.-uTime*9.+position.x*6.)*.028);vec4 mv=modelViewMatrix*vec4(q,1.);v=-mv.xyz;gl_Position=projectionMatrix*mv;}',fragmentShader:'varying vec3 p,n,v;uniform float uTime,uFade;void main(){float rim=pow(1.-abs(dot(normalize(n),normalize(v))),1.8);float flame=pow(.5+.5*sin(p.y*16.-uTime*8.+sin(p.x*11.+uTime*2.)),3.);float a=(rim*.65+flame*.17)*uFade;gl_FragColor=vec4(mix(vec3(1.5,.22,.008),vec3(2.5,1.7,.15),rim),a);}'});
 mesh(geo.sphere,material,g,V(0,1.52,0),V(.52,.68,.38));mesh(geo.sphere,material,g,V(0,2.25,0),V(.32,.37,.29));for(const side of [-1,1]){const ear=mesh(geo.cone,material,g,V(side*.19,2.64,-.04),V(.22,.38,.18));ear.rotation.z=-side*.25;}
 const tails=[];for(let i=0;i<9;i++){const t=new THREE.Group();t.position.set(0,1.18,-.16);g.add(t);const a=i/8*Math.PI*1.5-Math.PI*.75;const curve=new THREE.CatmullRomCurve3([V(),V(Math.sin(a)*.8,.5,-.7),V(Math.sin(a)*1.8,1.0+Math.cos(a)*.7,-1.6),V(Math.sin(a)*2.4,1.8+Math.cos(a),-1.1)]);mesh(new THREE.TubeGeometry(curve,12,.115,5,false),material,t);tails.push(t);}
 g.visible=false;return {g,material,tails};
}
function ensureNarutoClones(){
 const v=ensureNarutoVisuals();if(v.clones.length)return;const template=fighterModelNaruto(false),original=[];template.root.traverse(o=>original.push(o));const prototypeMeshes=[];template.body.traverse(o=>{if(o.isMesh)prototypeMeshes.push(o);});const batches=new Map(),offsets=[];
 for(const m of prototypeMeshes){const key=m.geometry.uuid+'|'+m.material.uuid;let batch=batches.get(key);if(!batch){batch={geometry:m.geometry,material:m.material,perClone:0};batches.set(key,batch);}offsets.push({batch,index:batch.perClone++});}
 for(const batch of batches.values()){batch.mesh=new THREE.InstancedMesh(batch.geometry,batch.material,batch.perClone*NARUTO.clonePool);batch.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);batch.mesh.frustumCulled=false;batch.mesh.castShadow=false;scene.add(batch.mesh);v.cloneBatches.push(batch);for(let i=0;i<batch.mesh.count;i++)batch.mesh.setMatrixAt(i,v.zero);}
 for(let slot=0;slot<NARUTO.clonePool;slot++){
  const root=template.root.clone(true),copies=[];root.traverse(o=>copies.push(o));const copy=o=>copies[original.indexOf(o)];const f={root,body:copy(template.body),head:copy(template.head),headGroup:copy(template.headGroup),band:null,shadow:template.shadow,shield:copy(template.shield),limbs:template.limbs.map(l=>({arm:copy(l.arm),elbow:copy(l.elbow),hand:copy(l.hand),fingers:l.fingers.map(copy)})),legs:template.legs.map(copy),knees:template.knees.map(copy),blockRig:null,narutoRig:{...template.narutoRig,hair:copy(template.narutoRig.hair),hems:template.narutoRig.hems.map(copy),tails:template.narutoRig.tails.map(copy),feet:template.narutoRig.feet.map(copy)},character:'naruto',pos:V(),vel:V(),grounded:true,hp:100,slot,stun:0,attack:0,cloneFacing:0};
  initNarutoAnimation(f);v.clones.push({f,active:false,used:false,pose:{strike:0,kick:false},entries:prototypeMeshes.map((m,i)=>({node:copy(m),batch:offsets[i].batch,index:slot*offsets[i].batch.perClone+offsets[i].index}))});
 }
}
function animateNarutoClones(actions,dt){
 const v=ensureNarutoVisuals();for(const slot of v.clones)slot.used=false;let index=0;
 for(const a of actions){if(a.type!=='naruto'||a.kind!==1||a.cancelled)continue;const t=narutoAge(a);for(let i=0;i<3;i++){
  if(t>=NARUTO.moves[1].hits[i]||index>=NARUTO.clonePool)continue;ensureNarutoClones();const c=v.clones[index++],start=i*.13,end=NARUTO.moves[1].hits[i],u=narutoEase((t-start)/(end-start));c.used=true;c.active=true;narutoCloneStart(c.f.pos,a,i);c.f.pos.lerp(a.cloneEnds[i],u);c.f.pos.y+=Math.sin(u*Math.PI)*.6;
  c.f.cloneFacing=Math.atan2(a.dir.x,a.dir.z);c.pose.strike=narutoEase((u-.6)/.4);c.pose.kick=i===1;c.pose.boost=false;c.pose.technique=0;c.f.root.scale.setScalar(1);animateNaruto(c.f,dt,c.pose);c.f.root.updateMatrixWorld(true);for(const entry of c.entries)entry.batch.mesh.setMatrixAt(entry.index,entry.node.matrixWorld);
 }}
 index=animateNarutoBoostClones(v,index,dt);
 index=animateMindscapeClones(v,index,dt);
 for(const c of v.clones)if(c.active&&!c.used){for(const entry of c.entries)entry.batch.mesh.setMatrixAt(entry.index,v.zero);c.active=false;}
 for(const b of v.cloneBatches){b.mesh.count=index*b.perClone;b.mesh.visible=index>0;b.mesh.instanceMatrix.needsUpdate=true;}
}
function updateNarutoVisuals(dt){
 if(phase==='pause')dt=0;if(mode==='online'&&net?.role==='guest')narutoReplicaAge=Math.min(.15,narutoReplicaAge+dt);updateNarutoSpeedLines(dt);updateNarutoSubstitutions(dt);
 const hasNaruto=bodies.some(f=>f.character==='naruto');if(!hasNaruto&&!narutoVisuals)return;const v=ensureNarutoVisuals(),active=['play','finish','pause'].includes(phase),guest=mode==='online'&&net?.role==='guest';if(!active){clearNarutoVisuals();return;}if(phase==='pause')dt=0;
 const actions=guest?narutoReplicas.values():techniques;
 animateNarutoClones(actions,dt);updateNarutoMobilityTrails(dt);
 for(let i=0;i<v.charges.length;i++){const r=v.charges[i],f=bodies[i];r.g.visible=false;if(!f||f.character!=='naruto'||f.hp<=0)continue;const ch=chargeFor(f),a=f.narutoAction,t=a?narutoAge(a):0;
  if(ch&&(ch.kind===3||ch.kind===4)||a&&((a.kind===3&&t<NARUTO.moves[3].active)||(a.kind===4&&t<.14)||(a.kind===5&&t<NARUTO.moves[5].startup))){const kind=ch?.kind||a.kind,q=ch?chargePower(ch):a.q,age=ch?ch.elapsed:t,form=ch?narutoEase(ch.elapsed/techniqueStartup(f,ch.kind)):kind===5?narutoEase(t/NARUTO.moves[5].startup):1,size=kind===5?.1+(NARUTO_VFX.bombSize-.1)*form:(kind===4?NARUTO_VFX.shurikenSize:NARUTO_VFX.rasenganSize)*(.1+form*.9)*(1+q*.3);narutoSphereAppearance(r,kind,age,q,size);f.limbs[1].hand.getWorldPosition(r.g.position);narutoAim(v.tmp,f);if(kind===5){narutoHead(r.g.position,f);r.g.position.addScaledVector(v.tmp,2.8);r.g.position.y+=.4;}else if(kind===4)r.g.position.y+=.8;else r.g.position.addScaledVector(v.tmp,.2);r.g.quaternion.setFromUnitVectors(v.up,v.tmp);if(kind===5&&dt>0&&frameCount%4===0)narutoEmit(r.g.position,NARUTO.colors.ember,5,.38,9,.11,false,true);}
  const mindCloak=mindscapeCloak(f);let cloak=v.cloaks.get(f.root.uuid);if((a?.kind===5||mindCloak)&&!cloak){cloak=makeNarutoCloak(f);v.cloaks.set(f.root.uuid,cloak);}if(cloak){const on=a?.kind===5,fade=mindCloak?(.55+.45*Math.sin(domain.t*33)**2):on?narutoEase(t/.45)*(1-narutoEase((t-a.duration+.4)/.4)):0;cloak.g.visible=fade>0;cloak.material.uniforms.uFade.value=fade;cloak.material.uniforms.uTime.value=mindCloak?domain.t:t;for(let j=0;j<cloak.tails.length;j++){cloak.tails[j].rotation.x=Math.sin(t*3+j*.6)*.12;cloak.tails[j].rotation.y=Math.sin(t*2+j*.8)*.14;}}
 }
 let shotIndex=0;const shots=guest?(replicaState?.projectiles||[]):projectiles;for(const r of v.shots)r.g.visible=false;
 for(const p of shots){if(!p.type.startsWith('naruto-')||shotIndex>=v.shots.length)continue;const r=v.shots[shotIndex++],kind=p.type==='naruto-bomb'?5:4,t=p.t+(guest?narutoReplicaAge:0);narutoSphereAppearance(r,kind,t,p.q,kind===5?NARUTO_VFX.bombSize:1);if(guest){v.tmp.fromArray(p.dir);v.tmp2.fromArray(p.p).addScaledVector(v.tmp,NARUTO.moves[kind].speed*narutoReplicaAge);if(r.id!==p.id){r.id=p.id;r.g.position.fromArray(p.p);}r.g.position.lerp(v.tmp2,1-Math.exp(-28*dt));}else{r.g.position.copy(p.p);v.tmp.copy(p.dir);}r.g.quaternion.setFromUnitVectors(v.up,v.tmp);if(kind===5){r.beam.visible=true;r.beam.scale.set(.75,Math.min(9,t*20),.75);r.beam.position.z=-Math.min(9,t*20)*.5;r.beam.material.uniforms.uTime.value=t;}}
 let zoneIndex=0;for(const r of v.zones)r.g.visible=false;const zones=guest?narutoReplicas.values():techniques;for(const a of zones){if(a.type!=='naruto-wind'||zoneIndex>=v.zones.length)continue;const r=v.zones[zoneIndex++],t=narutoAge(a);narutoSphereAppearance(r,4,t,a.q,a.radius*(.65+.35*narutoEase(t/.12)));r.g.position.copy(a.p);r.g.rotation.set(Math.PI/2,0,t*2);r.core.visible=false;r.skin.material.uniforms.uFade.value=.12;r.blades.scale.setScalar(.35);for(let j=0;j<r.arcs.length;j++){r.arcs[j].rotation.x=j*.4;r.arcs[j].rotation.z=t*(j%2?-12:10);r.arcs[j].material.opacity=.3;}}
 for(const e of v.fx){if(!e.g.visible)continue;e.t+=dt;if(e.t>=e.life){e.g.visible=false;continue;}const u=e.t/e.life,grow=1-(1-u)**3;e.mat.opacity=(1-u)*.78;e.cracks.material.opacity=(1-u)*.85;e.cracks.scale.setScalar(e.radius);for(let j=0;j<e.rings.length;j++){const r=e.rings[j];r.scale.setScalar(.15+e.radius*grow*(1-j*.16));r.rotation.z+=dt*(j%2?-2:2);}
  if(e.chunks.visible){for(let j=0;j<12;j++){const a=j/12*Math.PI*2,d=e.radius*(.3+(j%3)*.2);e.dummy.position.set(Math.cos(a)*d,Math.sin(u*Math.PI)*(e.kind==='transform'?1.5:.7),Math.sin(a)*d);e.dummy.rotation.set(u*(j+1),u*3,j);e.dummy.scale.setScalar((.12+(j%3)*.07)*(1-u));e.dummy.updateMatrix();e.chunks.setMatrixAt(j,e.dummy.matrix);}e.chunks.instanceMatrix.needsUpdate=true;}}
 const p=v.particles;for(let i=0;i<NARUTO.particlePool;i++){p.life[i]=Math.max(0,p.life[i]-dt);if(p.life[i]<=0){p.opacity[i]=0;continue;}const j=i*3,u=p.life[i]/p.max[i];p.opacity[i]=Math.min(1,u*3)*(p.smoke[i]?.6:1);p.pos[j]+=p.velocity[j]*dt;p.pos[j+1]+=p.velocity[j+1]*dt;p.pos[j+2]+=p.velocity[j+2]*dt;p.velocity[j+1]-=dt*(p.smoke[i]?-.15:2);}
 p.geometry.attributes.position.needsUpdate=p.geometry.attributes.opacity.needsUpdate=true;p.material.uniforms.ratio.value=renderer.getPixelRatio();p.points.visible=true;
 if(post?.composite.uniforms.narutoHeat){let strength=0;for(const f of bodies)if(f.narutoAction?.kind===5&&f.hp>0){const t=narutoAge(f.narutoAction),w=narutoEase(t/.5)*(1-narutoEase((t-2.4)/1));if(w>strength){strength=w;narutoHead(v.tmp,f);v.tmp.project(camera);post.composite.uniforms.narutoCenter.value.set(v.tmp.x*.5+.5,v.tmp.y*.5+.5);}}post.composite.uniforms.narutoHeat.value=strength;post.composite.uniforms.narutoTime.value+=dt;}
 const c=cinematic?.type==='naruto'?cinematic:null;const dim=c&&options.cinematics?narutoEase(c.t/.45)*(1-narutoEase((c.t-(c.duration-.65))/.65))*NARUTO_VFX.dim:0;$('narutoCinema').style.opacity=String(dim);
}
function clearNarutoVisuals(){
 clearNarutoSubstitutions();clearMindscapeClones();
 if(narutoSpeedLines){narutoSpeedLines.lines.visible=false;narutoSpeedLines.age=0;}
 const v=narutoVisuals;if(!v)return;for(const r of v.charges)r.g.visible=false;for(const r of v.shots)r.g.visible=false;for(const r of v.zones)r.g.visible=false;for(const r of v.fx)r.g.visible=false;for(const c of v.cloaks.values())c.g.visible=false;
 for(const c of v.clones)if(c.active){for(const e of c.entries)e.batch.mesh.setMatrixAt(e.index,v.zero);c.active=false;}for(const b of v.cloneBatches){b.mesh.count=0;b.mesh.visible=false;b.mesh.instanceMatrix.needsUpdate=true;}v.particles.life.fill(0);v.particles.opacity.fill(0);v.particles.points.visible=false;if(post?.composite.uniforms.narutoHeat)post.composite.uniforms.narutoHeat.value=0;$('narutoCinema').style.opacity='0';
}
