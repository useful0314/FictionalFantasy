// Shared visual four-hit chain. Existing attack timers, confirmed-hit progression and damage own combat.
const LIGHT_COMBO_MOTION={rightLimb:0,leftLimb:1,entryBlend:.08,windupFraction:.27,linkHold:.12,linkSettle:.22,plantLimit:.38,contactHold:.055,punchOvershoot:1.045,trailInterval:.025};
let lightComboPoses=null;
function lightComboLibrary(){
 if(lightComboPoses)return lightComboPoses;const p=narutoPoseTemplate;
 lightComboPoses={
  rightWind:p({lx:-.65,le:-1.85,lz:.13,rx:-.28,ry:-.14,rz:-.3,re:-1.5,lean:-.045,twist:.26,bob:-.05,ll:-.12,rl:.13,lk:.32,rk:.21,lc:-1.4,rc:-1.55}),
  right:p({lx:-.56,le:-2.15,lz:.12,rx:-1.58,ry:-.08,rz:-.06,re:-.045,lean:.13,twist:-.24,stretch:1.025,bob:.008,ll:-.13,rl:.22,lk:.23,rk:.12,lc:-1.45,rc:-1.6}),
  rightReturn:p({lx:-.85,le:-1.37,rx:-.84,re:-1.30,twist:-.12,lean:.06,ll:-.1,rl:.1,lk:.23,rk:.16,lc:-1.4,rc:-1.4}),
  leftWind:p({lx:-.30,ly:.14,lz:.3,le:-1.5,rx:-.65,re:-1.85,rz:-.13,lean:-.04,twist:-.27,bob:-.045,ll:-.1,rl:.15,lk:.26,rk:.32,lc:-1.55,rc:-1.4}),
  left:p({lx:-1.61,ly:.08,lz:.055,le:-.045,rx:-.55,re:-2.1,rz:-.13,lean:.15,twist:.26,stretch:1.03,bob:.01,ll:.18,rl:-.12,lk:.13,rk:.23,lc:-1.6,rc:-1.45}),
  leftReturn:p({lx:-.90,le:-1.32,rx:-.82,re:-1.37,twist:.15,lean:.07,ll:.06,rl:-.12,lk:.18,rk:.27,lc:-1.4,rc:-1.4}),
  roundWind:p({lx:-.86,le:-1.3,lz:.23,rx:-.65,re:-1.12,rz:-.30,rl:-.86,rs:.34,rk:1.28,ll:.06,lk:.22,lean:.06,tilt:.12,twist:.28,bob:-.04,stretch:.978,lc:-1.4,rc:-1.4}),
  round:p({lx:-.76,le:-1.27,lz:.30,rx:-.48,re:-.86,rz:-.43,rl:-.16,rs:1.43,rk:.10,rf:-.24,ll:.04,lk:.17,lf:-.08,lean:.045,tilt:.17,twist:-Math.PI/2,bob:-.012,stretch:1.035,lc:-1.4,rc:-1.4}),
  roundFollow:p({lx:-.60,le:-1.13,lz:.4,rx:-.7,re:-1.22,rz:-.25,rl:-.30,rs:.94,rk:.55,rf:-.12,ll:.03,lk:.2,lean:.08,tilt:.12,twist:-2.45,bob:-.025,lc:-1.4,rc:-1.4}),
  crossStep:p({lx:-.66,le:-1.18,lz:.32,rx:-.85,re:-1.35,rz:-.22,rl:-.17,rs:.07,rk:.24,ll:.18,ls:-.13,lk:.64,lean:.10,tilt:-.035,twist:-Math.PI,bob:-.035,stretch:.985,lc:-1.4,rc:-1.4}),
  spinWind:p({lx:-.50,le:-.95,lz:.48,rx:-.85,re:-1.35,rz:-.25,ll:-.64,ls:-.55,lk:1.14,rl:.02,rk:.23,lean:.10,tilt:-.10,twist:-3.63,bob:-.025,stretch:.98,lc:-1.4,rc:-1.4}),
  spin:p({lx:-.44,le:-.88,lz:.45,rx:-.78,re:-1.30,rz:-.30,ll:-.12,ls:-1.45,lk:.08,lf:-.23,rl:.045,rk:.19,rf:-.08,lean:.03,tilt:-.18,twist:-Math.PI*1.5,bob:-.01,stretch:1.045,lc:-1.4,rc:-1.4}),
  spinFollow:p({lx:-.76,le:-1.2,lz:.25,rx:-.65,re:-1.16,rz:-.3,ll:-.28,ls:-.74,lk:.68,rl:.025,rk:.23,lean:.095,tilt:-.085,twist:-5.72,bob:-.035,lc:-1.4,rc:-1.4}),
  finish:p({lx:-.78,le:-1.3,lz:.17,rx:-.80,re:-1.32,rz:-.18,ll:-.04,lk:.24,rl:.10,rk:.18,lean:.04,twist:-Math.PI*2,bob:-.02,lc:-1.3,rc:-1.3})
 };
 // The inherited l/r pose fields describe local X, not anatomical sides. Facing +Z,
 // limb 0 at -X is the fighter's right. Mirror the authored poses once, never per frame.
 for(const pose of Object.values(lightComboPoses))mirrorCombatPose(pose);
 return lightComboPoses;
}
function mirrorCombatPose(p){
 const pairs=[[NP.lx,NP.rx,1],[NP.ly,NP.ry,-1],[NP.lz,NP.rz,-1],[NP.le,NP.re,1],[NP.lh,NP.rh,1],[NP.lhz,NP.rhz,-1],[NP.ll,NP.rl,1],[NP.ls,NP.rs,-1],[NP.lk,NP.rk,1],[NP.lf,NP.rf,1],[NP.lc,NP.rc,1]];
 for(const [a,b,sign] of pairs){const value=p[a];p[a]=p[b]*sign;p[b]=value*sign;}
 p[NP.twist]*=-1;p[NP.tilt]*=-1;p[NP.hy]*=-1;
}
function lightComboState(f){
 const n=rosterAnimationState(f);return n.comboMotion||(n.comboMotion={index:-1,kind:0,previous:0,elapsed:0,active:false,render:false,entry:0,idleAge:0,offset:0,startX:0,startZ:0,pose:narutoPoseTemplate(),start:narutoPoseTemplate(),target:narutoPoseTemplate(),plant:V(),point:V(),inverse:new THREE.Matrix4(),support:1,weight:0});
}
function lightComboAllowed(f){return f.hp>0&&f.stun<=0&&f.ragdollT<=0&&f.hitReact<=0&&f.dodge<=0&&f.recovery<=0&&!f.block&&f.guardReact<=0&&!chargeFor(f)&&!domainPresentationCast(f)&&!f.energyCharging&&!(f.narutoMobility?.kind)&&!f.narutoAction&&!f.mahitoAction&&!worldCutBusy(f);}
function captureCombatPose(f,p){
 p.set(rosterPoseLibrary()[f.character]);p[NP.lean]=f.body.rotation.x;p[NP.twist]=f.body.rotation.y;p[NP.tilt]=f.body.rotation.z;p[NP.bob]=f.body.position.y;p[NP.stretch]=f.body.scale.y;p[NP.hx]=f.headGroup.rotation.x;p[NP.hy]=f.headGroup.rotation.y;
 for(let i=0;i<2;i++){const l=f.limbs[i],j=i?NP.rx:NP.lx,k=i?NP.rl:NP.ll;p[j]=l.arm.rotation.x;p[j+1]=l.arm.rotation.y;p[j+2]=l.arm.rotation.z;p[j+3]=l.elbow.rotation.x;p[j+4]=l.hand.rotation.x;p[j+5]=l.hand.rotation.z;p[k]=f.legs[i].rotation.x;p[k+1]=f.legs[i].rotation.z;p[k+2]=f.knees[i].rotation.x;p[k+3]=(f.blockRig?.feet||f.narutoRig?.feet||f.mahitoRig?.feet)[i].rotation.x;p[i?NP.rc:NP.lc]=l.fingers[0].rotation.x;}
}
function lightComboMix(out,a,b,t,snap=false){let q=narutoEase(t);if(snap){const x=clamp(t,0,1)-1;q=Math.min(LIGHT_COMBO_MOTION.punchOvershoot,1+2.3*x*x*x+1.3*x*x);}narutoMixPose(out,a,b,q);}
function sampleDirectionalCombat(f,out,idle,t,duration,hit){
 const L=rosterPoseLibrary(),kind=f.attackKind,wind=f.attackCounter?L.crossWind:kind===1?L.kickWind:kind===2?L.upperWind:f.attackAir?L.slamWind:L.sweepWind,strike=f.attackCounter?L.cross:kind===1?L.kick:kind===2?L.upper:f.attackAir?L.slam:L.sweep,windEnd=hit*LIGHT_COMBO_MOTION.windupFraction,hold=Math.min(duration*.61,hit+LIGHT_COMBO_MOTION.contactHold);
 if(t<windEnd)lightComboMix(out,idle,wind,t/windEnd);else if(t<hit)lightComboMix(out,wind,strike,(t-windEnd)/(hit-windEnd));else if(t<hold)out.set(strike);else lightComboMix(out,strike,idle,(t-hold)/(duration-hold));
}
function sampleLightCombo(f,out,idle,dt){
 const n=lightComboState(f),L=lightComboLibrary(),guest=mode==='online'&&net?.role==='guest',remaining=Math.max(0,f.attack-(guest?narutoReplicaAge:0)),neutral=f.attackKind===0,gun=f.character==='mahito'&&f.mahitoArm===2,active=f.attackIsLight&&remaining>0&&!gun,allowed=lightComboAllowed(f);n.render=false;
 if(!allowed||gun||f.attack>0&&!f.attackIsLight){n.active=false;n.idleAge=1;n.weight=0;return false;}
 if(!active){
  if(n.active){n.active=false;n.idleAge=0;captureCombatPose(f,n.start);}n.idleAge+=dt;
  const hold=f.comboHits===3&&f.comboTimer>0?LIGHT_COMBO_MOTION.linkHold:0;
  if(n.index!==2||n.idleAge>hold+LIGHT_COMBO_MOTION.linkSettle)return false;
  n.target.set(idle);n.target[NP.twist]+=Math.PI*2+n.offset;lightComboMix(out,n.start,n.target,(n.idleAge-hold)/LIGHT_COMBO_MOTION.linkSettle);n.pose.set(out);n.render=true;n.weight=0;return true;
 }
 const index=neutral?clamp(f.combo||0,0,3):-1,kind=(f.attackAir?8:0)+(f.attackCounter?4:0)+f.attackKind,duration=f.attackMax||.34,tempo=f.character==='mahito'?MAHITO.arms[f.mahitoArm||0].tempo:1,hit=(f.attackCounter?.09:.12)*tempo;
 if(!n.active||n.index!==index||n.kind!==kind||f.attack>n.previous+Math.min(.08,duration*.35)){
  captureCombatPose(f,n.start);n.entry=0;n.airLand=0;n.elapsed=0;n.idleAge=0;n.index=index;n.kind=kind;n.active=true;n.offset=index===3?Math.ceil((n.start[NP.twist]-Math.PI*1.5)/(Math.PI*2))*Math.PI*2:Math.round(n.start[NP.twist]/(Math.PI*2))*Math.PI*2;
  n.support=index===3?LIGHT_COMBO_MOTION.rightLimb:LIGHT_COMBO_MOTION.leftLimb;n.startX=f.body.position.x;n.startZ=f.body.position.z;f.root.updateMatrixWorld(true);const foot=(f.blockRig?.feet||f.narutoRig?.feet||f.mahitoRig?.feet)[n.support];foot.getWorldPosition(n.plant);n.inverse.copy(f.root.matrixWorld).invert();n.plant.applyMatrix4(n.inverse);
 }
 n.entry+=dt;n.previous=f.attack;n.render=true;const t=n.elapsed=guest?Math.max(n.elapsed,clamp(duration-remaining,0,duration)):clamp(duration-remaining,0,duration),p=n.target,windEnd=hit*LIGHT_COMBO_MOTION.windupFraction,hold=hit+LIGHT_COMBO_MOTION.contactHold*tempo,recover=duration*.75;
 if(index<0)sampleDirectionalCombat(f,p,idle,t,duration,hit);
 else if(index<2){const wind=index===0?L.rightWind:L.leftWind,strike=index===0?L.right:L.left,back=index===0?L.rightReturn:L.leftReturn;
  if(t<windEnd)lightComboMix(p,idle,wind,t/windEnd);else if(t<hit)lightComboMix(p,wind,strike,(t-windEnd)/(hit-windEnd),true);else if(t<hold)p.set(strike);else if(t<recover)lightComboMix(p,strike,back,(t-hold)/(recover-hold));else lightComboMix(p,back,idle,(t-recover)/(duration-recover));
 }else if(index===2){
  if(t<windEnd)lightComboMix(p,idle,L.roundWind,t/windEnd);else if(t<hit)lightComboMix(p,L.roundWind,L.round,(t-windEnd)/(hit-windEnd));else if(t<hold)p.set(L.round);else if(t<duration*.70)lightComboMix(p,L.round,L.roundFollow,(t-hold)/(duration*.70-hold));else lightComboMix(p,L.roundFollow,L.crossStep,(t-duration*.70)/(duration*.30));
 }else{
  if(t<windEnd)lightComboMix(p,L.crossStep,L.spinWind,t/windEnd);else if(t<hit)lightComboMix(p,L.spinWind,L.spin,(t-windEnd)/(hit-windEnd));else if(t<hold)p.set(L.spin);else if(t<duration*.73)lightComboMix(p,L.spin,L.spinFollow,(t-hold)/(duration*.73-hold));else lightComboMix(p,L.spinFollow,L.finish,(t-duration*.73)/(duration*.27));
 }
 sampleAirCombat(f,p,idle,t,duration,hit,dt,n);
 p[NP.twist]+=n.offset;if(index===3)p[NP.twist]=Math.max(n.start[NP.twist],p[NP.twist]);p[NP.hy]=clamp(-Math.atan2(Math.sin(p[NP.twist]),Math.cos(p[NP.twist])),-.65,.65)*.65;
 const entry=narutoEase(n.entry/Math.min(LIGHT_COMBO_MOTION.entryBlend,hit*.72));narutoMixPose(out,n.start,p,entry);n.pose.set(out);n.weight=index>=2&&f.grounded&&!f.attackAir?narutoEase(t/(.07*tempo))*(1-narutoEase((t/duration-.80)/.20)):0;return true;
}
function combatPoseBlend(f,normal){return f.rosterAnim?.comboMotion?.render?1:normal;}
function combatBodyYaw(f,target,blend){if(f.spider?.action?.kind===2&&f.spider.action.mode==='normal')return lerp(f.body.rotation.y,target,blend);if(f.rosterAnim?.comboMotion?.render)return target;const current=Math.atan2(Math.sin(f.body.rotation.y),Math.cos(f.body.rotation.y));return current+Math.atan2(Math.sin(target-current),Math.cos(target-current))*blend;}
function plantCombatFoot(f){
 const n=f.rosterAnim?.comboMotion;if(!n?.render||!f.grounded)return;const feet=f.blockRig?.feet||f.narutoRig?.feet||f.mahitoRig?.feet;feet[0].rotation.x=n.pose[NP.lf];feet[1].rotation.x=n.pose[NP.rf];f.root.updateMatrixWorld(true);const foot=feet[n.support];foot.getWorldPosition(n.point);n.inverse.copy(f.root.matrixWorld).invert();n.point.applyMatrix4(n.inverse);const limit=LIGHT_COMBO_MOTION.plantLimit,enter=narutoEase(n.entry/LIGHT_COMBO_MOTION.entryBlend);
 f.body.position.x+=lerp(n.startX,clamp(n.plant.x-n.point.x,-limit,limit)*n.weight,enter);f.body.position.z+=lerp(n.startZ,clamp(n.plant.z-n.point.z,-limit,limit)*n.weight,enter);
}
