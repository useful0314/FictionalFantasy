// Game-clock motion: entry, readable hold, and exit stay synchronized across clients.
const DOMAIN_CUTOUTS_ENABLED=false;
const CUTOUT_MOTION={cast:1.8,clash:2.35,enter:.42,exit:.46,stagger:.035,crossfade:.22};
let cutoutState=null;const portraitCache=new Map(),cutoutLayers=[];
const cutoutEase=x=>1-Math.pow(1-clamp(x,0,1),5),cutoutSmooth=x=>{x=clamp(x,0,1);return x*x*(3-2*x);};
function clearDomainCutouts(){cutoutState=null;cutoutLayers.length=0;$('domainCutouts').classList.add('hidden');$('domainCutouts').replaceChildren();}
function makeCutoutModel(f){
 const model=f.body.clone(true);model.position.set(0,0,0);model.rotation.set(0,-.12,0);model.visible=true;
 const originals=[],copies=[];f.body.traverse(o=>originals.push(o));model.traverse(o=>copies.push(o));
 const copyOf=o=>copies[originals.indexOf(o)];if(f.band)copyOf(f.band).visible=false;
 const head=copyOf(f.headGroup);head.rotation.set(-.02,.12,-.025);
 f.limbs.forEach((limb,i)=>{const side=i%2?1:-1,lower=i>=2,arm=copyOf(limb.arm),elbow=copyOf(limb.elbow),hand=copyOf(limb.hand);
  // Put the seal near the face, with two extended fingers for Gojo.
  if(f.character==='gojo'&&i===0){arm.rotation.set(.12,0,-.12);elbow.rotation.set(-.12,0,0);hand.rotation.set(0,0,0);}
  else{const target=f.character==='gojo'?V(.12,2.03,.48):V(side*(lower?.16:.085),lower?1.28:1.94,lower?.52:.56),delta=target.clone().sub(arm.position),distance=clamp(delta.length(),.15,.93),direction=delta.normalize(),along=(.54*.54-.4*.4+distance*distance)/(2*distance),bend=V(side,-.85,.12);bend.addScaledVector(direction,-bend.dot(direction)).normalize();const joint=arm.position.clone().addScaledVector(direction,along).addScaledVector(bend,Math.sqrt(Math.max(0,.54*.54-along*along))),upper=joint.clone().sub(arm.position).normalize(),fore=target.clone().sub(joint).normalize(),foreRotation=new THREE.Quaternion().setFromUnitVectors(V(0,-1,0),fore);arm.quaternion.setFromUnitVectors(V(0,-1,0),upper);elbow.quaternion.copy(arm.quaternion).invert().multiply(foreRotation);const palm=new THREE.Quaternion().setFromEuler(new THREE.Euler(0,f.character==='gojo'?.12:side*.55,Math.PI+(f.character==='gojo'?-.06:side*.05)));hand.quaternion.copy(foreRotation).invert().multiply(palm);}
  limb.fingers.forEach((finger,j)=>{copyOf(finger).rotation.set(f.character==='gojo'&&i===1&&j<2?0:lower?-.4:-1.35,0,f.character==='gojo'&&i===1&&j<2?(j===0?.09:-.09):0);});
 });return model;
}
function cutoutCamera(){const cam=new THREE.PerspectiveCamera(31,1,.1,10);cam.position.set(.12,2.22,3.35);cam.lookAt(0,1.97,0);return cam;}
function portraitFor(f){
 if(portraitCache.has(f.character))return portraitCache.get(f.character);
 if(typeof renderer.domElement.toDataURL!=='function'||!renderer.setRenderTarget)return '';
 const portraitScene=new THREE.Scene(),model=makeCutoutModel(f);portraitScene.add(model);portraitScene.add(new THREE.HemisphereLight(0xddeaff,0x181b2b,2.6));const key=new THREE.DirectionalLight(0xfff1df,3.4);key.position.set(-2,4,5);portraitScene.add(key);const rim=new THREE.DirectionalLight(f.character==='gojo'?0x79dcff:0xff6f59,3);rim.position.set(3,2,-2);portraitScene.add(rim);
 const target=new THREE.WebGLRenderTarget(512,512),pixels=new Uint8Array(512*512*4),oldTarget=renderer.getRenderTarget(),oldColor=renderer.getClearColor(new THREE.Color()),oldAlpha=renderer.getClearAlpha();
 try{renderer.setClearColor(0,0);renderer.setRenderTarget(target);renderer.clear();renderer.render(portraitScene,cutoutCamera());renderer.readRenderTargetPixels(target,0,0,512,512,pixels);const canvas=document.createElement('canvas');canvas.width=canvas.height=512;const context=canvas.getContext('2d'),data=context.createImageData(512,512);for(let y=0;y<512;y++)data.data.set(pixels.subarray((511-y)*2048,(512-y)*2048),y*2048);context.putImageData(data,0,0);const url=canvas.toDataURL('image/png');portraitCache.set(f.character,url);return url;}catch{return '';}finally{renderer.setRenderTarget(oldTarget);renderer.setClearColor(oldColor,oldAlpha);target.dispose();}
}
function warmDomainPortraits(){if(!DOMAIN_CUTOUTS_ENABLED)return;for(const character of new Set(bodies.map(f=>f.character))){const f=bodies.find(f=>f.character===character);portraitFor(f);}}
function cutoutElement(tag,cls,parent,text){const el=document.createElement(tag);el.className=cls;if(text!==undefined)el.textContent=text;parent.append(el);return el;}
function renderCutouts(ids){
 if(!DOMAIN_CUTOUTS_ENABLED){clearDomainCutouts();return;}
 const host=$('domainCutouts');host.dataset.count=String(ids.length);host.classList.remove('hidden');host.setAttribute('aria-hidden','true');
 // Preserve the currently visible composition while the new clash panels arrive.
 for(const layer of cutoutLayers)if(layer.retiring===null)layer.retiring=0;
 while(cutoutLayers.length>1)cutoutLayers.shift().el.remove();
 const el=cutoutElement('div','cutoutLayer',host);el.dataset.count=String(ids.length);const frame=cutoutElement('div','cutoutFrame',el),panels=[];
 ids.forEach((id,index)=>{const f=actorById(id);if(!f)return;const panel=cutoutElement('div','domainCutout '+f.character,frame);panel.dataset.index=String(index);panel.style.setProperty('--index',index);
  const atmosphere=cutoutElement('div','cutoutAtmosphere',panel);cutoutElement('i','cutoutHalo',atmosphere);cutoutElement('i','cutoutHatch',atmosphere);const speed=cutoutElement('div','cutoutSpeed',atmosphere);
  for(let n=0;n<18;n++){const line=cutoutElement('i','',speed);line.style.setProperty('--line',n);line.style.top=((n*37)%100)+'%';line.style.left=((n*29)%80-20)+'%';line.style.width=(12+n%5*9)+'%';line.style.opacity=String(.09+n%4*.055);}
  const art=cutoutElement('div','cutoutArt',panel),src=portraitFor(f);if(src){const ghost=cutoutElement('img','cutoutGhost',art);ghost.src=src;ghost.alt='';const image=cutoutElement('img','cutoutPortrait',art);image.src=src;image.alt=kit(f).short+' domain hand sign';image.draggable=false;}
  cutoutElement('div','cutoutShade',panel);cutoutElement('div','cutoutGlyph',panel,'領域展開');
  const copy=cutoutElement('div','cutoutCopy',panel);cutoutElement('span','cutoutEyebrow',copy,ids.length===1?(f.character==='gojo'?'LIMITLESS / SATORU GOJO':'KING OF CURSES / RYOMEN SUKUNA'):id.toUpperCase()+' / DOMAIN EXPANSION');
  const title=cutoutElement('strong','cutoutTitle',copy);if(ids.length===1){cutoutElement('span','',title,'DOMAIN');cutoutElement('span','',title,'EXPANSION');}else title.textContent=kit(f).short;
  cutoutElement('span','cutoutDomain',copy,kit(f).domain);cutoutElement('div','cutoutEdge cutoutEdgeTop',panel);cutoutElement('div','cutoutEdge cutoutEdgeBottom',panel);cutoutElement('div','cutoutGlint',panel);panels.push(panel);
 });
 if(ids.length===3){const seam=cutoutElement('div','cutoutSeams',frame);seam.innerHTML='<svg viewBox="0 0 1000 600" preserveAspectRatio="none" aria-hidden="true"><path d="M500 0V318L0 600M500 318L1000 600" fill="none" stroke="#edf4ff" stroke-width="3"/><circle cx="500" cy="318" r="5" fill="#fff"/></svg>';}
 if(ids.length>1)cutoutElement('div','cutoutClashLabel',el,ids.length+'-WAY DOMAIN CLASH');
 const layer={el,panels,time:cutoutState?.t||0,duration:cutoutState?.duration||CUTOUT_MOTION.cast,retiring:null};cutoutLayers.push(layer);paintCutout(layer);
}
function cutoutPose(t,duration,index,count,reduced=false){
 const delay=count>1?index*CUTOUT_MOTION.stagger:0,entry=cutoutEase((t-delay)/CUTOUT_MOTION.enter),exit=cutoutSmooth((t-(duration-CUTOUT_MOTION.exit))/CUTOUT_MOTION.exit),fadeIn=cutoutSmooth((t-delay)/.12),alpha=fadeIn*(1-exit),direction=count===1||index%2===0?-1:1,bottom=count===3&&index===2;
 return {x:reduced||bottom?0:direction*(1-entry)*115-direction*exit*105,y:reduced?0:bottom?(1-entry)*105+exit*105:(1-entry)*3-exit*3,scale:reduced?1:1.045-entry*.045-exit*.015,alpha,reveal:reduced?1:clamp(entry*1.5,0,1)*(1-exit*.82),art:reduced?0:(1-entry)*22-t*1.2+exit*15,copy:reduced?0:(1-cutoutEase((t-delay-.055)/.36))*8+exit*9,blur:reduced?0:(1-entry)*3,glint:reduced?0:clamp((t-delay-.10)/.72,0,1),phase:exit>0?'exit':entry<1?'enter':'hold'};
}
function paintCutout(layer){
 const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches||false,count=layer.panels.length;
 layer.panels.forEach((panel,i)=>{const p=cutoutPose(layer.time,layer.duration,i,count,reduced);for(const [key,value]of Object.entries(p))if(key==='phase')panel.dataset.phase=value;else panel.style.setProperty('--'+key,value.toFixed(4));});
 const envelope=cutoutSmooth(layer.time/.16)*(1-cutoutSmooth((layer.time-layer.duration+.4)/.4));layer.el.style.setProperty('--envelope',envelope.toFixed(4));
 if(layer.retiring!==null){const fade=1-cutoutSmooth(layer.retiring/CUTOUT_MOTION.crossfade);layer.el.style.opacity=fade.toFixed(4);}else layer.el.style.opacity='1';
}
function showDomainCutout(f){if(!DOMAIN_CUTOUTS_ENABLED)return;cutoutState={key:'cast-'+f.castVoiceId,ids:[f.id],t:0,duration:CUTOUT_MOTION.cast};renderCutouts([f.id]);}
function showClashCutouts(){if(!DOMAIN_CUTOUTS_ENABLED)return;if(!clash)return;cutoutState={key:'clash-'+clash.id+'-'+clash.participants.length,ids:[...clash.participants],t:0,duration:CUTOUT_MOTION.clash};renderCutouts(cutoutState.ids);}
function updateDomainCutouts(dt){
 if(!['play','finish','pause'].includes(phase)){if(cutoutLayers.length)clearDomainCutouts();return;}if(phase==='pause')return;
 if(cutoutState)cutoutState.t=Math.min(cutoutState.duration,cutoutState.t+dt);
 for(let i=cutoutLayers.length-1;i>=0;i--){const layer=cutoutLayers[i];if(layer.retiring!==null)layer.retiring+=dt;else layer.time=cutoutState?.t??layer.time+dt;paintCutout(layer);if(layer.time>=layer.duration||layer.retiring!==null&&layer.retiring>=CUTOUT_MOTION.crossfade){layer.el.remove();cutoutLayers.splice(i,1);}}
 if(!cutoutLayers.length)clearDomainCutouts();
}
