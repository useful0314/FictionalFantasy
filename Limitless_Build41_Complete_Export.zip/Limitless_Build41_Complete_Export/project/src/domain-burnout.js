// Shared post-domain lockout. Movement, guarding, light attacks and energy recovery stay available.
const DOMAIN_BURNOUT={duration:15};
function techniqueBurnedOut(f,notify=false){
 if(!(f.techniqueBurnout>0))return false;
 if(notify&&f===player)toast('TECHNIQUE BURNOUT · '+Math.ceil(f.techniqueBurnout)+'s',1);
 return true;
}
function beginDomainBurnout(f){
 if(!f)return;f.techniqueBurnout=Math.max(f.techniqueBurnout||0,DOMAIN_BURNOUT.duration);cancelCharge(f);
}
function endActiveDomain(d){
 if(domain!==d)return;beginDomainBurnout(d.owner);domain=null;clearDomainVisual();
}
function updateBurnoutHUD(){
 const remaining=player.techniqueBurnout||0,active=remaining>0,el=$('techniqueBurnoutStatus');
 el.classList.toggle('hidden',!active);if(active)el.textContent='TECHNIQUE BURNOUT · '+remaining.toFixed(1)+'s';
 for(const key of [1,2,3,4,5,6,'Q'])$('ability'+key).classList.toggle('burnout',active);
 if(active)$('abilityQ').classList.remove('ready');
}
