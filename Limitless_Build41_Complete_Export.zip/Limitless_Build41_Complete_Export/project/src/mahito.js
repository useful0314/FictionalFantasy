// Functional kit defaults. Optional balance proposals are documented, never loaded by the game.
const MAHITO={
 color:0x99c9c8,ink:0x262638,soul:0xb8ffe4,blend:.10,
 arms:[{name:'HANDS',reach:3.3,damage:1,tempo:1},{name:'BLADES',reach:5.8,damage:.7,tempo:.72},{name:'GUNS',reach:60,damage:1,tempo:1},{name:'HAMMERS',reach:4.4,damage:2.4,tempo:1.8}],
 forms:[{name:'NORMAL',scale:1,speed:1,damage:1},{name:'BIG',scale:1.75,speed:.65,damage:1.75},{name:'SMALL',scale:.55,speed:1.35,damage:.55},{name:'WINGED',scale:1,speed:1,damage:1}],
 morphTime:.38,formDuration:12,summonStartup:.65,summonRecovery:.35,summonCount:4,summonLife:8,summonSpeed:14,summonInterval:.8,
 trainStartup:.55,trainTime:2.4,trainRecovery:.4,trainSpeed:48,trainTurn:4.5,trainRadius:2.3,trainDamage:100,
 healStartup:.65,healTime:3,healRecovery:.35,healPerSecond:50,
 touchStartup:.32,touchActive:.16,touchRecovery:.32,touchRange:2.8,touchRadius:.9,touchMeter:20,disableTime:8,
 domainHaste:1.2,domainSlow:.65,bulletSpeed:48,bulletLife:1.25,bulletRadius:.32,
 summonPool:24,bulletPool:48,domainHands:224
};
const MAHITO_KIT={name:'MAHITO',short:'MAHITO',title:'IDLE TRANSFIGURATION',domain:'SELF-EMBODIMENT OF PERFECTION',color:MAHITO.color,
 names:['','SHAPESHIFTING ARMS','MORPHED HUMANS','SERPENT EXPRESS','SOUL REGENERATION','BODY TRANSFORMATIONS','CURSED TOUCH'],
 hints:['','Cycle blade → gun → hammer; attack to use','Expel four autonomous allies','Ride and steer with aim / movement','Stationary healing · damage interrupts','Cycle Big → Small → Winged','20% ultimate · touch disables one technique'],
 tags:['','ARM FORMS','SUMMON','STEERABLE RIDE','VULNERABLE HEAL','BODY FORMS','SOUL DAMAGE'],colors:['','#b5dcd5','#e2c8c1','#abbccf','#aff6d6','#bdb5ec','#abffe2']};
const mahitoUnits=[],mahitoBullets=[];let mahitoReplica=null;
const mahitoScratch={a:V(),b:V(),c:V(),d:V(),ray:new THREE.Raycaster(),hits:[],surfaces:[],proxy:{pos:null,vel:V()},turn:new THREE.Quaternion(),targetTurn:new THREE.Quaternion()};
function mahitoBusy(f){return f.character==='mahito'&&!!f.mahitoAction;}
function soulLocked(f,kind,notify=false){const locked=f.soulTime>0&&f.soulSlot===kind;if(locked&&notify&&f===player)toast('SOUL DISTORTED · technique '+kind+' sealed for '+f.soulTime.toFixed(1)+'s',1);return locked;}
function mahitoCanAct(f){return phase==='play'&&f.hp>0&&f.stun<=0&&!(f.ragdollT>0)&&!(f.recovery>0)&&f.attack<=.08&&!(f.dodge>0)&&!castFor(f)&&!chargeFor(f)&&!trappedByVoid(f)&&!mahitoBusy(f);}
function startMahitoMove(f,kind){
 if(f.character!=='mahito'||!Number.isInteger(kind)||kind<1||kind>6||!mahitoCanAct(f)||f.cooldown>0||techniqueBurnedOut(f,true)||soulLocked(f,kind,true))return false;
 if(kind===6&&f.ult<MAHITO.touchMeter){if(f===player)toast('Cursed Touch needs 20% ultimate');return false;}
 if(kind===4&&f.hp>=MAX_HEALTH)return false;
 if(kind===6)f.ult-=MAHITO.touchMeter;
 cancelNarutoMobility(f);f.block=false;f.attackIsLight=false;f.vel.set(0,0,0);
 const a={id:++techniqueSerial,owner:f,kind,t:0,done:false,hit:new Set(),dir:aimFor(f),old:f.pos.clone()};f.mahitoAction=a;
 if(kind===1)f.mahitoArm=(f.mahitoArm||0)%3+1;
 if(kind===5){f.mahitoForm=(f.mahitoNextForm||0)%3+1;f.mahitoNextForm=f.mahitoForm;f.mahitoFormTime=MAHITO.formDuration;f.flying=f.mahitoForm===3;if(f.flying){f.grounded=false;f.vel.y=3;}}
 sfx('narutoClone',f.pos,.65);narutoFX('smoke',headPos(f),kind===3?2:1);return true;
}
function interruptMahito(f){if(f.mahitoAction){f.mahitoAction=null;f.cooldown=Math.max(f.cooldown||0,.14);}}
function mahitoDamageScale(f){return f.character==='mahito'?MAHITO.forms[f.mahitoForm||0].damage:1;}
function mahitoSpeedScale(f){let s=f.character==='mahito'?MAHITO.forms[f.mahitoForm||0].speed:1;if(domain?.owner.character==='mahito'&&insideEnclosure(f))s*=domain.owner===f?MAHITO.domainHaste:MAHITO.domainSlow;return s;}
function mahitoExecution(attacker,target,kind){return attacker.character==='mahito'&&domain?.owner===attacker&&insideEnclosure(target)&&(kind==='light'||kind==='mahito-touch');}
function mahitoContactTarget(f,range,radius=.9,direction=null){
 const start=headPos(f),dir=direction||aimFor(f);let target=null,nearest=Math.min(range,barrierRayDistance(start,dir,range));
 for(const b of bodies){if(b===f||b.hp<=0||barrierSeparates(f,b))continue;const n=raySphere(start,dir,headPos(b),radius);if(n>=0&&n<=nearest){nearest=n;target=b;}}
 return target;
}
function resolveMahitoTouch(f,a){
 const b=mahitoContactTarget(f,MAHITO.touchRange,MAHITO.touchRadius);if(!b||!hurt(b,0,f,'mahito-touch',V(),1))return;
 if(b.hp>0&&!soulExecutionPending(b)){const count=b.character==='mahito'?6:b.character==='gojo'?4:5;b.soulSlot=(f.mahitoTouchSerial||0)%count+1;f.mahitoTouchSerial=(f.mahitoTouchSerial||0)+1;b.soulTime=MAHITO.disableTime;cancelCharge(b,b.soulSlot);if(b===player)toast('SOUL DISTORTED · technique '+b.soulSlot+' temporarily sealed',2);}
 a.done=true;narutoFX('impact',headPos(b),1.1);shock(headPos(b),MAHITO.soul,2.6,.35);hitStop=.06;
}
function mahitoLightStart(f){
 if(f.character!=='mahito')return false;if(!mahitoCanAct(f)||inputFor(f).has('KeyC')||f.stamina<3)return true;
 const form=MAHITO.arms[f.mahitoArm||0],counter=f.counterWindow>0;f.attackCounter=counter;f.counterWindow=0;f.lightOutcome=f.lightOutcomeTime=0;f.attackIsLight=true;f.block=false;f.stamina-=3;f.combo=f.comboTimer>0?(f.comboHits||0):0;f.attackAir=!f.grounded;f.attackKind=lightAttackKind(f);f.attackMax=(counter?.32:.34)*form.tempo;f.attack=f.attackMax;
 pendingHits.push({f,kind:f.attackKind,combo:f.combo,air:f.attackAir,counter,t:(counter?.09:.12)*form.tempo,seq:++lightSerial,mahitoArm:f.mahitoArm||0});sfx('light',f.pos);return true;
}
function resolveMahitoLight(h){
 const f=h.f;if(f.character!=='mahito')return false;if(f.stun>0||f.hp<=0||f.ragdollT>0||phase!=='play')return true;
 const arm=MAHITO.arms[h.mahitoArm||0],dir=h.mahitoArm===2?aimFor(f):lightStrikeDirection(f,h.kind,h.air),origin=headPos(f),damage=(BALANCE.light[h.combo]||BALANCE.light[0])*arm.damage*mahitoDamageScale(f);
 if(h.mahitoArm===2){if(mahitoBullets.length<MAHITO.bulletPool)mahitoBullets.push({id:++techniqueSerial,owner:f,p:origin.addScaledVector(dir,1),dir:dir.clone(),t:0,damage});shock(origin,MAHITO.soul,.7,.15);breakLightChain(f);return true;}
 slashRibbon(origin.clone().addScaledVector(dir,1.1),dir,MAHITO.color,arm.reach*.5,.22,h.mahitoArm===3?Math.PI/2:.4);
 const target=mahitoContactTarget(f,arm.reach,1.05,dir);if(!target){lightOutcome(f,3);breakLightChain(f);return true;}
 const end=h.combo===3,knock=dir.clone().multiplyScalar(h.mahitoArm===3?18:end?15:1.2);knock.y=h.mahitoArm===3?7:end?5:0;airLightKnockback(knock,h);
 if(hurt(target,damage,f,'light',knock,1)){f.comboHits=end?0:h.combo+1;f.comboTimer=end?0:.85;target.comboLock=end?0:.62;target.stun=Math.max(target.stun,end?.28:.62);if(h.mahitoArm===3){startRagdoll(target,knock);narutoFX('ground',target.pos,1.4);shakeIt(.3);hitStop=.065;}else hitStop=.035;f.comboDisplay=1.05;}else breakLightChain(f);return true;
}
function summonMahitoHumans(f){
 // Refresh this owner's wave; summons do not consume player slots or join clashes.
 for(let i=mahitoUnits.length-1;i>=0;i--)if(mahitoUnits[i].owner===f)mahitoUnits.splice(i,1);
 const dir=aimFor(f).setY(0).normalize(),right=V(-dir.z,0,dir.x);
 for(let i=0;i<MAHITO.summonCount;i++){const p=f.pos.clone().addScaledVector(dir,1.5).addScaledVector(right,(i-1.5)*.8);mahitoUnits.push({id:++techniqueSerial,owner:f,p,dir:dir.clone(),t:0,next:.4+i*.12,variant:i,target:null});narutoFX('smoke',p,1);}
}
function updateMahitoFighter(f,dt){
 f.soulTime=Math.max(0,(f.soulTime||0)-dt);if(!f.soulTime)f.soulSlot=0;if(f.character!=='mahito')return;
 if(f.mahitoFormTime>0){f.mahitoFormTime=Math.max(0,f.mahitoFormTime-dt);if(f.mahitoFormTime===0){f.mahitoForm=0;f.flying=false;narutoFX('smoke',headPos(f),1.5);}}
 const a=f.mahitoAction;if(!a)return;if(f.hp<=0||f.stun>0||trappedByVoid(f)){interruptMahito(f);return;}
 const prev=a.t;a.t+=dt;let duration=MAHITO.morphTime;
 if(a.kind===2){duration=MAHITO.summonStartup+MAHITO.summonRecovery;if(!a.done&&a.t>=MAHITO.summonStartup){a.done=true;summonMahitoHumans(f);}}
 if(a.kind===3){duration=MAHITO.trainStartup+MAHITO.trainTime+MAHITO.trainRecovery;const activeDt=Math.max(0,Math.min(a.t,MAHITO.trainStartup+MAHITO.trainTime)-Math.max(prev,MAHITO.trainStartup));
  if(activeDt>0){const desired=moveDirection(f);if(desired.lengthSq()<.1)desired.copy(aimFor(f));else desired.y=aimFor(f).y;desired.normalize();mahitoScratch.targetTurn.setFromUnitVectors(a.dir,desired);mahitoScratch.turn.identity().slerp(mahitoScratch.targetTurn,1-Math.exp(-MAHITO.trainTurn*dt));a.dir.applyQuaternion(mahitoScratch.turn).normalize();a.old.copy(f.pos);f.pos.addScaledVector(a.dir,narutoMobilityDistance(f,a.dir,MAHITO.trainSpeed*activeDt));f.pos.y=Math.max(.13,f.pos.y);resolveDistrictCollision(f,a.old);constrainBarrier(f,f.pos,a.old,f.vel);f.grounded=false;f.vel.set(0,0,0);
   const delta=f.pos.clone().sub(a.old),length=delta.length();if(length>.001){delta.divideScalar(length);for(const b of bodies)if(b!==f&&b.hp>0&&!a.hit.has(b.id)&&!barrierSeparates(f,b)&&raySphere(a.old.clone().add(V(0,1.45,0)),delta,headPos(b),MAHITO.trainRadius)<=length){a.hit.add(b.id);hurt(b,MAHITO.trainDamage,f,'special',a.dir.clone().multiplyScalar(22).add(V(0,8,0)),2);narutoFX('impact',headPos(b),2);shakeIt(.4);}}
  }
 }
 if(a.kind===4){duration=MAHITO.healStartup+MAHITO.healTime+MAHITO.healRecovery;const healing=Math.max(0,Math.min(a.t,MAHITO.healStartup+MAHITO.healTime)-Math.max(prev,MAHITO.healStartup));f.hp=Math.min(MAX_HEALTH,f.hp+MAHITO.healPerSecond*healing);if(healing>0&&Math.floor(a.t*8)!==Math.floor(prev*8))narutoFX('smoke',headPos(f),.35);}
 if(a.kind===6){duration=MAHITO.touchStartup+MAHITO.touchActive+MAHITO.touchRecovery;if(!a.done&&a.t>=MAHITO.touchStartup&&prev<MAHITO.touchStartup+MAHITO.touchActive)resolveMahitoTouch(f,a);}
 if(a.t>=duration){f.mahitoAction=null;f.cooldown=Math.max(f.cooldown||0,.14);}
}
function updateMahitoEntities(dt){
 for(let i=mahitoUnits.length-1;i>=0;i--){const u=mahitoUnits[i];u.t+=dt;if(u.t>=MAHITO.summonLife||u.owner.hp<=0){narutoFX('smoke',u.p,.8);mahitoUnits.splice(i,1);continue;}let b=null,dist=Infinity;
  for(const f of bodies)if(f!==u.owner&&f.hp>0&&!barrierSeparates(u.owner,f)){const d=f.pos.distanceToSquared(u.p);if(d<dist){dist=d;b=f;}}if(!b)continue;u.target=b.id;const p=mahitoScratch.a.copy(u.p),dir=mahitoScratch.b.copy(b.pos).sub(u.p);if(dir.lengthSq()>.001)u.dir.copy(dir).normalize();
  if(dist>4){u.p.addScaledVector(u.dir,Math.min(Math.sqrt(dist)-1.4,MAHITO.summonSpeed*dt));const proxy=mahitoScratch.proxy;proxy.pos=u.p;proxy.vel.set(0,0,0);resolveDistrictCollision(proxy,p);constrainBarrier(u.owner,u.p,p);}
  if(u.t>=u.next&&dist<9){u.next=u.t+MAHITO.summonInterval;hurt(b,BALANCE.light[0],u.owner,'mahito-summon',u.dir.clone().multiplyScalar(2),.25);narutoFX('impact',headPos(b),.45);}
 }
 for(let i=mahitoBullets.length-1;i>=0;i--){const b=mahitoBullets[i],distance=MAHITO.bulletSpeed*dt;let travel=Math.min(distance,barrierRayDistance(b.p,b.dir,distance));mahitoScratch.surfaces.length=0;for(const p of pieces)if(arenaPieceActive(p)&&p.solid)mahitoScratch.surfaces.push(p.m);mahitoScratch.ray.set(b.p,b.dir);mahitoScratch.ray.far=distance;mahitoScratch.hits.length=0;mahitoScratch.ray.intersectObjects(mahitoScratch.surfaces,false,mahitoScratch.hits);travel=Math.min(travel,mahitoScratch.hits[0]?.distance??Infinity);let target=null;
  for(const f of bodies)if(f!==b.owner&&f.hp>0&&!barrierSeparates(b.owner,f)){const d=raySphere(b.p,b.dir,headPos(f),.9+MAHITO.bulletRadius);if(d<=travel){travel=d;target=f;}}b.p.addScaledVector(b.dir,travel);b.t+=dt;
  if(target){hurt(target,b.damage,b.owner,'mahito-shot',b.dir.clone().multiplyScalar(3),1);narutoFX('impact',b.p,.65);}if(target||travel<distance||b.t>=MAHITO.bulletLife||b.p.y<.1||b.owner.hp<=0){narutoFX('smoke',b.p,.45);mahitoBullets.splice(i,1);}
 }
}
function resetMahito(){resetMahitoAmalgams();resetMahitoSouls();mahitoUnits.length=mahitoBullets.length=0;mahitoReplica=null;for(const f of actorPool){f.mahitoAction=null;f.mahitoArm=f.mahitoForm=f.mahitoNextForm=f.mahitoFormTime=f.soulTime=f.soulSlot=0;f.body.scale.set(1,1,1);f.root.scale.set(1,1,1);}hideMahitoVisuals();}
function packMahito(){return {formations:packMahitoFormations(),souls:packMahitoSouls(),hands:packMahitoHands(),units:mahitoUnits.map(u=>({id:u.id,owner:u.owner.id,p:vec(u.p),dir:vec(u.dir),t:u.t,variant:u.variant})),bullets:mahitoBullets.map(b=>({id:b.id,owner:b.owner.id,p:vec(b.p),dir:vec(b.dir),t:b.t}))};}
function packMahitoAction(f){const a=f.mahitoAction;return a?{id:a.id,kind:a.kind,t:a.t,dir:vec(a.dir)}:null;}
function validMahitoAction(a){return a===null||!!(a&&Number.isSafeInteger(a.id)&&Number.isInteger(a.kind)&&a.kind>=1&&a.kind<=6&&Number.isFinite(a.t)&&a.t>=0&&a.t<=4.1&&validVector(a.dir));}
function validMahito(s,ids,d){const entity=e=>e&&Number.isSafeInteger(e.id)&&ids.has(e.owner)&&actorById(e.owner)?.character==='mahito'&&validVector(e.p)&&validVector(e.dir)&&Number.isFinite(e.t)&&e.t>=0&&e.t<=9;return !!s&&validMahitoFormations(s.formations,ids)&&validMahitoSouls(s.souls,ids)&&validMahitoHands(s.hands,ids,d)&&Array.isArray(s.units)&&s.units.length<=MAHITO.summonPool&&s.units.every(u=>entity(u)&&Number.isInteger(u.variant)&&u.variant>=0&&u.variant<4)&&Array.isArray(s.bullets)&&s.bullets.length<=MAHITO.bulletPool&&s.bullets.every(entity);}
function receiveMahitoAction(f,a){f.mahitoAction=a?{...a,owner:f,dir:V(...a.dir)}:null;}
function updateMahitoHUD(){
 for(let i=1;i<=6;i++){$('ability'+i).classList.toggle('soul-locked',soulLocked(player,i));$('ability'+i).title=soulLocked(player,i)?'Temporarily sealed · '+player.soulTime.toFixed(1)+'s':'';}
 const status=$('soulStatus');status.classList.toggle('hidden',!(player.soulTime>0));if(player.soulTime>0)status.textContent='SOUL DISTORTED · '+player.soulSlot+' SEALED · '+player.soulTime.toFixed(1)+'s';
 if(player.character!=='mahito')return;const a=player.mahitoAction;$('abilityTag1').textContent=MAHITO.arms[player.mahitoArm||0].name;$('abilityTag5').textContent=MAHITO.forms[player.mahitoForm||0].name;$('abilityHint5').textContent=player.mahitoFormTime>0?player.mahitoFormTime.toFixed(1)+'s · press to cycle form':MAHITO_KIT.hints[5];
 for(let i=1;i<=6;i++)$('ability'+i).classList.toggle('active',a?.kind===i);$('ability6').classList.toggle('ready',player.ult>=20&&!soulLocked(player,6)&&!techniqueBurnedOut(player));
}
function mahitoManual(){return '<p><kbd>1</kbd> Cycle Blade → Gun → Hammer arms; normal attack uses the selected weapon.<br><kbd>2</kbd> Expel four allies that pursue other fighters for 8s.<br><kbd>3</kbd> Ride a serpent for 2.4s. Aim or move to steer. Walls and domain barriers stop it.<br><kbd>4</kbd> Remain still to heal for 3s. Damage interrupts healing.<br><kbd>5</kbd> Cycle Big → Small → Winged. Forms last 12s. Winged uses Jump / Descend to fly up/down.<br><kbd>6</kbd> Spend 20% ultimate on a short touch attempt. A hit deforms the opponent and seals one technique for 8s. A miss affects nobody.<br><kbd>Q</kbd> Self-Embodiment of Perfection: the existing 12s enclosed domain. Enemies are slower and Mahito is faster. His own melee/touch hits twist, stretch and inflate caught enemies for 1.18s, then pop them into a soul burst and defeat them; summons and gun shots do not. Four pursuing hands per caught enemy deal 24 damage per contact (guard reduces this); the surrounding wall of hands is decorative. Practice still prevents KOs. Normal clash rules and 15s burnout apply.</p>';}
