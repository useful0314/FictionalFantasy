// A sealed sewer vault wraps every latitude of the barrier, including beneath aerial casts.
const MINDSCAPE_SPHERE={radius:53.6};
function mindscapeSphereMaterial(){
 return new THREE.ShaderMaterial({side:THREE.BackSide,transparent:true,depthWrite:false,uniforms:{uTime:{value:0},uGlow:{value:0},uFade:{value:0}},
  vertexShader:'varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:`varying vec3 p;uniform float uTime,uGlow,uFade;
  void main(){vec3 d=normalize(p);float a=atan(d.x,d.z),lat=asin(clamp(d.y,-1.,1.));
   float blocks=step(.07,fract(a*9.55+floor(lat*8.)*.5))*step(.065,fract(lat*8.));
   float ribs=pow(1.-abs(sin(a*7.)),45.),hoops=pow(1.-abs(sin(lat*8.)),48.);
   float pipe=exp(-abs(sin(a*4.+lat*.65)) * 85.);float pulse=.5+.5*sin(lat*14.-uTime*3.);
   float grain=fract(sin(dot(floor(d*650.),vec3(127.1,311.7,74.7)))*43758.5453);
   vec3 stone=mix(vec3(.009,.012,.014),vec3(.034,.038,.043),blocks)*( .65+grain*.45);
   stone+=vec3(.065,.075,.085)*(ribs+hoops)*.6+vec3(.25,.038,.018)*pipe*(.35+uGlow*pulse);
   float flood=1.-smoothstep(-.65,-.06,d.y);float ripple=pow(.5+.5*sin(lat*100.+sin(a*13.)*.7-uTime*(4.+uGlow*3.)),18.);
   vec3 water=vec3(.008,.018,.023)+vec3(.22,.014,.006)*(ripple*.5+uGlow*.12);
   vec3 c=mix(stone,water,flood*.85);c+=vec3(.12,.002,.001)*uGlow*(.45+.2*sin(uTime*5.+lat*3.));
   gl_FragColor=vec4(c,uFade);
  }`});
}
function animateMindscapeSphere(v,age,glow,fade){
 const u=v.dome.material.uniforms;u.uTime.value=age;u.uGlow.value=glow;u.uFade.value=fade;
 // Reflective water stays on the actual arena floor, never an opaque floating slab.
 v.water.position.y=(MINDSCAPE.waterHeight-v.origin.y)/v.g.scale.y;v.waterUniforms.uLevel.value=v.water.position.y;
}
