// Build 39: presentation only. Existing combat, resources, maps and input remain authoritative.
const PRESENTATION={build:41,damagePool:28,numberLife:.78,numberMerge:.12,healthDelay:.32,healthCatch:3.8,
 hitLife:.19,cueLife:.55,lowHealth:.22,motionBlend:.12,cameraSkin:.4,shadowDistance:2.4,
 autoWindow:1.2,autoSlowFPS:48,autoFastFPS:58,autoSlowWindows:3,autoFastWindows:7,autoMin:.65,autoStep:.1};
const FIGHTER_TONES={gojo:'#82d8ff',sukuna:'#ff829e',naruto:'#ffc06e',mahito:'#afe5d7',spiderman:'#ff7782'};
const FIGHTER_STYLES={gojo:'SPACE CONTROL',sukuna:'DUAL CASTER',naruto:'CLONE PRESSURE',mahito:'SHAPESHIFTER',spiderman:'MOMENTUM'};
const presentation={numbers:null,cursor:0,hit:0,cue:0,damage:0,selection:'',results:'',health:new Map(),ability:[],clock:0,
 camera:{ray:new THREE.Raycaster(),hits:[],box:new THREE.Box3(),head:V(),desired:V(),direction:V(),point:V()},
 auto:{scale:1,elapsed:0,frames:0,slow:0,fast:0,warmup:3,base:1}};
function presentationText(el,value){const text=String(value);if(el.textContent!==text)el.textContent=text;}
function fighterTone(f){return FIGHTER_TONES[f.character]||FIGHTER_TONES.gojo;}
function initPresentation(){
 if(typeof options.hitMarkers!=='boolean')options.hitMarkers=true;
 if(typeof options.damageNumbers!=='boolean')options.damageNumbers=true;
 if(!Number.isFinite(options.shakeStrength))options.shakeStrength=.8;options.shakeStrength=clamp(options.shakeStrength,0,1);
 for(const [id,key]of [['hitMarkers','hitMarkers'],['showDamageNumbers','damageNumbers']]){$(id).checked=options[key];$(id).onchange=e=>{options[key]=e.target.checked;saveOptions();};}
 $('shakeStrength').value=options.shakeStrength;$('shakeStrengthValue').textContent=Math.round(options.shakeStrength*100)+'%';
 $('shakeStrength').oninput=e=>{options.shakeStrength=clamp(+e.target.value,0,1);$('shakeStrengthValue').textContent=Math.round(options.shakeStrength*100)+'%';saveOptions();};
 for(const [id,label]of [['phealthTrack','Your health'],['ehealthTrack','Target health']]){const el=$(id);el.setAttribute('role','progressbar');el.setAttribute('aria-label',label);el.setAttribute('aria-valuemin','0');el.setAttribute('aria-valuemax',String(MAX_HEALTH));}
 for(let i=1;i<=6;i++)presentation.ability.push({el:$('ability'+i),status:$('abilityStatus'+i),touch:$('touchSpecial'+i),last:''});
 $('combatCue').setAttribute('aria-live','polite');$('damageNumbers').setAttribute('aria-hidden','true');
 scene.add(sun.target);
}
function ensureDamageNumbers(){
 if(presentation.numbers)return presentation.numbers;
 return presentation.numbers=Array.from({length:PRESENTATION.damagePool},()=>{const el=document.createElement('span');el.className='combatNumber';el.style.display='none';$('damageNumbers').append(el);return {el,position:V(),screen:V(),view:V(),age:99,total:0,id:'',heal:false,lane:0};});
}
function showDamageNumber(f,amount,heal=false){
 if(!options.damageNumbers||!Number.isFinite(amount)||amount<=0)return;
 const pool=ensureDamageNumbers();let n=pool.find(x=>x.id===f.id&&x.heal===heal&&x.age<PRESENTATION.numberMerge);
 if(n)n.total+=amount;else{n=pool[presentation.cursor++%pool.length];n.position.copy(f.pos);n.position.y+=2.5;n.age=0;n.total=amount;n.id=f.id;n.heal=heal;n.lane=(presentation.cursor%5-2)*.14;}
 n.el.className='combatNumber'+(heal?' heal':f===player?' received':'')+(n.total>=80?' heavy':'');presentationText(n.el,(heal?'+':'−')+Math.round(n.total));
}
function combatCue(target,attacker,event,amount=0){
 if(!options.hitMarkers)return;
 if(target===player&&event==='hit')presentation.damage=Math.max(presentation.damage,clamp(amount/180,.12,.7));
 if(attacker===player&&event==='hit'){presentation.hit=PRESENTATION.hitLife;$('hitConfirm').dataset.kind=amount>=80?'heavy':'hit';}
 if(event==='guard'&&(target===player||attacker===player)||event==='evade'&&target===player){presentation.cue=PRESENTATION.cueLife;$('combatCue').dataset.kind=event;presentationText($('combatCue'),event==='evade'?'PERFECT DODGE':target===player?'GUARD':'BLOCKED');}
}
function resetPresentation(){
 resetCombatFeel();resetBattleReadability();
 presentation.health.clear();presentation.results='';presentation.hit=presentation.cue=presentation.damage=0;presentation.clock=0;
 if(presentation.numbers)for(const n of presentation.numbers){n.age=99;n.el.style.display='none';}
 for(const a of presentation.ability)a.last='';
}
function updatePresentation(dt){
 const p=presentation;p.clock+=dt;p.hit=Math.max(0,p.hit-dt);p.cue=Math.max(0,p.cue-dt);p.damage*=Math.exp(-dt*8);
 updateArenaLighting();
 const playing=phase==='play'&&!menuOpen&&!cursorFree&&!options.freeOrbit;
 $('hitConfirm').style.opacity=playing&&options.hitMarkers?clamp(p.hit/PRESENTATION.hitLife,0,1):0;
 $('hitConfirm').style.transform='translate(-50%,-50%) scale('+(1+(1-p.hit/PRESENTATION.hitLife)*.22)+')';
 $('combatCue').style.opacity=playing&&options.hitMarkers?Math.min(1,p.cue/.12):0;
 $('damageVignette').style.opacity=playing&&options.hitMarkers?p.damage*options.shakeStrength:0;
 if(p.numbers)for(const n of p.numbers){n.age+=dt;if(n.age>=PRESENTATION.numberLife||!options.damageNumbers||!playing){n.el.style.display='none';continue;}
  n.screen.copy(n.position);n.screen.x+=n.lane;n.screen.y+=narutoEase(n.age/PRESENTATION.numberLife)*1.15;n.view.copy(n.screen).applyMatrix4(camera.matrixWorldInverse);n.screen.project(camera);
  if(n.view.z>=0||n.screen.z>1||Math.abs(n.screen.x)>1.1||Math.abs(n.screen.y)>1.1){n.el.style.display='none';continue;}
  n.el.style.display='block';n.el.style.left=(n.screen.x*.5+.5)*innerWidth+'px';n.el.style.top=(-n.screen.y*.5+.5)*innerHeight+'px';
  n.el.style.opacity=Math.min(1,(PRESENTATION.numberLife-n.age)/.22);n.el.style.transform='translate(-50%,-50%) scale('+(1+Math.sin(Math.min(1,n.age/.12)*Math.PI)*.16)+')';
 }
 if(phase==='play'||phase==='finish'){
  healthTrail('player',player,$('phealthTrail'),$('phealthTrack'),dt);const target=other(player);healthTrail('target',target,$('ehealthTrail'),$('ehealthTrack'),dt);
  $('hud').style.setProperty('--player',fighterTone(player));$('hud').style.setProperty('--opponent',fighterTone(target));$('healthHUD').classList.toggle('critical',player.hp>0&&player.hp/MAX_HEALTH<=PRESENTATION.lowHealth);
  for(const f of bodies){const row=opponentHealthRows.get(f.id);if(row?.trail)healthTrail('row-'+f.id,f,row.trail,null,dt);}
  updateAbilityReadiness();
 }
}
function healthTrail(key,f,el,track,dt){
 let s=presentation.health.get(key);if(!s||s.id!==f.id){s={id:f.id,hp:f.hp,trail:f.hp,wait:0};presentation.health.set(key,s);}
 if(f.hp<s.hp)s.wait=PRESENTATION.healthDelay;else if(f.hp>s.hp)s.trail=Math.max(s.trail,f.hp);s.hp=f.hp;
 s.wait=Math.max(0,s.wait-dt);if(!s.wait)s.trail=lerp(s.trail,f.hp,1-Math.exp(-PRESENTATION.healthCatch*dt));
 if(Math.abs(s.trail-f.hp)<.5)s.trail=f.hp;el.style.width=clamp(s.trail/MAX_HEALTH*100,0,100)+'%';if(track)track.setAttribute('aria-valuenow',String(Math.ceil(f.hp)));
}
// These hints read the same existing values as the casts; they never decide whether a move can execute.
function abilityReadiness(f,i){
 const ch=chargeFor(f,i),burn=f.techniqueBurnout||0,soul=soulLocked(f,i),active=!!ch||f.narutoAction?.kind===i||f.mahitoAction?.kind===i||f.spider?.action?.kind===i||i===5&&worldCutBusy(f);
 if(active)return 'ACTIVE';if(soul)return 'SEALED';if(burn>0)return 'BURNOUT';
 const c=f.character,cd=c==='spiderman'?(f.spider?.cd[i]||0):f.cooldown||0,link=c==='spiderman'&&i===1&&f.spider?.linkTime>0&&f.spider.link?.hp>0&&f.spider.link.pos.y>1;
 if(c==='sukuna'&&i===3&&hasFurnaceArrow(f))return 'DETONATE';
 if(cd>.05&&!link&&!(c==='sukuna'&&i<=4&&chargeFor(f)))return cd.toFixed(1)+'s';
 if(c==='gojo'&&i===1&&blueFor(f))return 'ANCHOR';
 const energy=c==='naruto'?NARUTO.moves[i]?.cost||0:c==='spiderman'?SPIDER.costs[i]||0:c==='mahito'?0:i===5?WORLD_CUT.cost:(c==='gojo'?[0,5,7,16,2]:[0,7,9,16,7])[i]||0;
 const meter=c==='naruto'&&i===5?NARUTO.moves[5].ultCost:c==='sukuna'&&i===5?WORLD_CUT.ultCost:c==='mahito'&&i===6?MAHITO.touchMeter:0;
 if(f.energy<energy)return c==='naruto'?'CHAKRA':'ENERGY';if(f.ult<meter)return 'METER';if(c==='mahito'&&i===4&&f.hp>=MAX_HEALTH)return 'FULL HP';return link?'CHASE':'';
}
function updateAbilityReadiness(){
 for(let i=1;i<=presentation.ability.length;i++){const a=presentation.ability[i-1],label=abilityReadiness(player,i);if(a.last===label)continue;a.last=label;presentationText(a.status,label);a.el.dataset.availability=label==='ACTIVE'?'active':['ANCHOR','DETONATE','CHASE'].includes(label)?'followup':label?'waiting':'available';a.touch.dataset.availability=a.el.dataset.availability;a.touch.dataset.status=label;}
}
function updateSelectionPresentation(){
 const c=selectedCharacter,k=KITS[c],count=c==='mahito'?6:['gojo','spiderman'].includes(c)?4:5,labels=[];for(let i=1;i<=count;i++)labels.push(controls?.label('special'+i)||String(i));
 const key=c+':'+labels.join(',')+':'+(controls?.label('domain')||'Q');if(presentation.selection===key)return;presentation.selection=key;
 $('menu').style.setProperty('--selection',FIGHTER_TONES[c]);presentationText($('fighterStyle'),FIGHTER_STYLES[c]);presentationText($('fighterVitals'),MAX_HEALTH.toLocaleString('en-US')+' HP · '+(c==='sukuna'?150:100)+' STAMINA');
 const list=$('loadoutPreview');list.replaceChildren();for(let i=1;i<=count;i++){const row=document.createElement('li'),keycap=document.createElement('kbd'),name=document.createElement('span');keycap.textContent=labels[i-1];name.textContent=i===5&&c==='naruto'?NARUTO.moves[5].name:i===5&&c==='sukuna'?'WORLD CUTTING SLASH':k.names[i];row.append(keycap,name);list.append(row);}
 if(c!=='spiderman'){const row=document.createElement('li'),keycap=document.createElement('kbd'),name=document.createElement('span');row.className='loadoutDomain';keycap.textContent=controls?.label('domain')||'Q';name.textContent=k.domain;row.append(keycap,name);list.append(row);}
}
function presentResults(){
 const resultKey=winnerId+':'+Math.floor(matchTime)+':'+bodies.map(f=>f.id+','+f.character+','+f.hp+','+f.score+','+f.damageTaken).join('|');if(presentation.results===resultKey)return;presentation.results=resultKey;
 const host=$('resultBreakdown');host.replaceChildren();const seconds=Math.floor(matchTime),values=[['DAMAGE DEALT',Math.round(player.score).toLocaleString('en-US')],['DAMAGE TAKEN',Math.round(player.damageTaken).toLocaleString('en-US')],['TIME',Math.floor(seconds/60)+':'+String(seconds%60).padStart(2,'0')],['HEALTH LEFT',Math.ceil(player.hp)+' / '+MAX_HEALTH]];
 for(const [label,value]of values){const cell=document.createElement('div'),name=document.createElement('span'),number=document.createElement('b');name.textContent=label;number.textContent=value;cell.append(name,number);host.append(cell);}
 const list=$('resultRoster');list.replaceChildren();for(const f of [...bodies].sort((a,b)=>(b.id===winnerId)-(a.id===winnerId)||b.score-a.score)){const row=document.createElement('li'),name=document.createElement('span'),score=document.createElement('b');row.style.setProperty('--fighter-color',fighterTone(f));name.textContent=(f===player?'YOU · ':f.id.toUpperCase()+' · ')+kit(f).short;score.textContent=(f.id===winnerId?'WINNER · ':'')+Math.round(f.score)+' DMG';row.append(name,score);list.append(row);}
 $('rematchButton').focus?.();
}
// Reuse collision query objects, and reject most building meshes before triangle tests.
function cameraSurfaceDistance(origin,direction,range){
 const c=presentation.camera;let nearest=range;c.ray.set(origin,direction);c.ray.near=0;c.ray.far=range;
 for(const p of pieces){if(!arenaPieceActive(p)||!p.solid||!p.m?.visible)continue;c.box.min.copy(p.pos).addScaledVector(p.size,-.5);c.box.max.copy(p.pos).addScaledVector(p.size,.5);
  if(!c.ray.ray.intersectBox(c.box,c.point)||origin.distanceToSquared(c.point)>nearest*nearest&&!c.box.containsPoint(origin))continue;
  p.m.updateWorldMatrix(true,false);c.hits.length=0;c.ray.intersectObject(p.m,false,c.hits);if(c.hits.length){nearest=Math.min(nearest,c.hits[0].distance);c.ray.far=nearest;}
 }return nearest;
}
function positionGameplayCamera(view,side,orbitWeight,dt){
 const c=presentation.camera;c.head.copy(player.pos);c.head.y+=1.45;c.desired.copy(c.head).addScaledVector(view,-options.camDistance).addScaledVector(side,.85*(1-orbitWeight));c.desired.y=Math.max(.8,c.desired.y+.65);
 c.direction.copy(c.desired).sub(c.head);let distance=c.direction.length();c.direction.normalize();let hit=cameraSurfaceDistance(c.head,c.direction,distance);if(hit<distance)c.desired.copy(c.head).addScaledVector(c.direction,Math.max(.2,hit-PRESENTATION.cameraSkin));
 if(enclosure()&&insideEnclosure(player)){const center=enclosureCenter();c.direction.copy(c.desired).sub(center);if(c.direction.length()>DOMAIN_ENCLOSURE.radius-.3)c.desired.copy(center).addScaledVector(c.direction.normalize(),DOMAIN_ENCLOSURE.radius-.3);}
 camPos.lerp(c.desired,1-Math.exp(-speedFollowRate()*dt));c.direction.copy(camPos).sub(c.head);distance=c.direction.length();if(distance>.01){c.direction.divideScalar(distance);hit=cameraSurfaceDistance(c.head,c.direction,distance);if(hit<distance)camPos.copy(c.head).addScaledVector(c.direction,Math.max(.2,hit-PRESENTATION.cameraSkin));}
}
function presentationShake(){
 if(!options.shake||shake<=.001)return;const s=shake*.18*(Number.isFinite(options.shakeStrength)?options.shakeStrength:.8),t=time;
 camera.position.x+=(Math.sin(t*47)*.65+Math.sin(t*79)*.35)*s;camera.position.y+=(Math.sin(t*53+.8)*.65+Math.sin(t*83)*.35)*s;camera.position.z+=Math.sin(t*61)*s*.3;
}
function polishLocomotion(f,p,n,dt,moving){
 const m=n.motion||(n.motion={last:f.pos.clone(),speed:0,forward:0,side:0,accel:0}),b=1-Math.exp(-dt/PRESENTATION.motionBlend),dx=f.pos.x-m.last.x,dz=f.pos.z-m.last.z;m.last.copy(f.pos);
 const speed=dt>0?Math.min(40,Math.hypot(dx,dz)/dt):m.speed,angle=f.root.rotation.y,forward=speed>1?(dx*Math.sin(angle)+dz*Math.cos(angle))/Math.max(.001,Math.hypot(dx,dz)):0,side=speed>1?(dx*Math.cos(angle)-dz*Math.sin(angle))/Math.max(.001,Math.hypot(dx,dz)):0;
 m.accel=lerp(m.accel,clamp((speed-m.speed)/Math.max(.001,dt)/100,-1,1),b);m.speed=lerp(m.speed,speed,b);m.forward=lerp(m.forward,forward,b);m.side=lerp(m.side,side,b);
 if(!f.grounded||f.flying||f.attack>0||f.block||f.stun>0||f.dodge>0||f.ragdollT>0||chargeFor(f)||castFor(f)||narutoBusy(f)||spiderBusy(f)||mahitoBusy(f)||worldCutBusy(f)||f.narutoMobility?.kind)return;
 if(moving){p[NP.ll]*=m.forward;p[NP.rl]*=m.forward;p[NP.ls]+=Math.sin(f.walkPhase||f.narutoAnim?.phase||0)*m.side*.32;p[NP.rs]-=Math.sin(f.walkPhase||f.narutoAnim?.phase||0)*m.side*.32;p[NP.lean]*=m.forward;p[NP.tilt]-=m.side*.11;p[NP.twist]-=m.side*.14;p[NP.hy]+=m.side*.1;}
 p[NP.lean]+=m.accel*.07;p[NP.bob]-=Math.max(0,-m.accel)*.045;
}
function resetAdaptiveQuality(){const a=presentation.auto;a.scale=1;a.elapsed=a.frames=a.slow=a.fast=0;a.warmup=3;a.base=renderer.getPixelRatio();}
// Keep each arena's light direction while moving its detailed shadow region with the fight.
function updateArenaLighting(){
 if(!renderer.shadowMap.enabled||enclosure()||phase!=='play')return;
 const texel=170/1024,x=Math.round(player.pos.x/texel)*texel,z=Math.round(player.pos.z/texel)*texel,y=Math.round(Math.max(0,player.pos.y-16)/texel)*texel,scale=PRESENTATION.shadowDistance,sunset=activeMap==='sanctuary',far=sunset?520:360;
 sun.target.position.set(x,y,z);sun.target.updateMatrixWorld(true);sun.position.set(x+(sunset?-80:-15)*scale,y+(sunset?35:65)*scale,z+(sunset?-100:16)*scale);
 if(sun.shadow.camera.far!==far){sun.shadow.camera.far=far;sun.shadow.camera.updateProjectionMatrix();}
}
function sampleAdaptiveQuality(raw){
 const a=presentation.auto;if(options.quality!=='auto'||phase!=='play'||menuOpen||document.hidden||!Number.isFinite(raw)||raw<=0||raw>.15){a.elapsed=a.frames=a.slow=a.fast=0;return;}
 if(a.warmup>0){a.warmup-=raw;return;}a.elapsed+=raw;a.frames++;if(a.elapsed<PRESENTATION.autoWindow)return;
 const fps=a.frames/a.elapsed;a.elapsed=a.frames=0;a.slow=fps<PRESENTATION.autoSlowFPS?a.slow+1:0;a.fast=fps>PRESENTATION.autoFastFPS?a.fast+1:0;let scale=a.scale;
 if(a.slow>=PRESENTATION.autoSlowWindows){scale=Math.max(PRESENTATION.autoMin,scale-PRESENTATION.autoStep);a.slow=0;}else if(a.fast>=PRESENTATION.autoFastWindows){scale=Math.min(1,scale+PRESENTATION.autoStep);a.fast=0;}
 if(Math.abs(scale-a.scale)<.001)return;a.scale=scale;renderer.setPixelRatio(a.base*scale);renderer.setSize(innerWidth,innerHeight);resizePost();pm.uniforms.ratio.value=renderer.getPixelRatio();
}
