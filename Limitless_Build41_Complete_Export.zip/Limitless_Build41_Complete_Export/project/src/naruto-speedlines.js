// Reused world-space white streaks; presentation only, no movement or camera override.
const NARUTO_SPEEDLINES={perFighter:12,low:6,cycle:.26,length:2.8,alpha:.5,radius:.9};
let narutoSpeedLines=null;
function ensureNarutoSpeedLines(){
 if(narutoSpeedLines)return narutoSpeedLines;
 const count=MAX_FIGHTERS*NARUTO_SPEEDLINES.perFighter*6,positions=new Float32Array(count*3),opacity=new Float32Array(count),geometry=new THREE.BufferGeometry();
 geometry.setAttribute('position',new THREE.BufferAttribute(positions,3).setUsage(THREE.DynamicDrawUsage));geometry.setAttribute('aOpacity',new THREE.BufferAttribute(opacity,1).setUsage(THREE.DynamicDrawUsage));
 const material=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,vertexShader:'attribute float aOpacity;varying float alpha;void main(){alpha=aOpacity;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying float alpha;void main(){gl_FragColor=vec4(.91,.96,1.,alpha);}'});
 const lines=new THREE.LineSegments(geometry,material);lines.frustumCulled=false;lines.visible=false;scene.add(lines);
 return narutoSpeedLines={lines,geometry,positions,opacity,axis:V(),side:V(),up:V(),point:V(),age:0};
}
function updateNarutoSpeedLines(dt){
 if(phase==='pause'||dt<=0)return;
 let active=false;if(phase==='play')for(const f of bodies){const k=f.narutoMobility?.kind;if(f.hp>0&&(k===1||k===3||k===4||f.spider?.action?.kind===4||f.spider?.momentum>0)){active=true;break;}}
 if(!active){if(narutoSpeedLines)narutoSpeedLines.lines.visible=false;return;}
 const v=ensureNarutoSpeedLines(),c=NARUTO_SPEEDLINES,count=particleBudget<1000?c.low:c.perFighter;v.lines.visible=true;v.age+=dt;let vertex=0;
 for(const f of bodies){const swing=f.character==='spiderman'&&(f.spider?.action?.kind===4||f.spider?.momentum>0),m=f.narutoMobility;if(f.hp<=0||!swing&&(!m||m.charging||m.kind!==1&&m.kind!==3&&m.kind!==4))continue;
  const t=swing?(f.spider.action?.t||1):narutoMobilityAge(m),k=swing?null:m.kind===1?NARUTO_MOBILITY.boost:m.kind===4?NARUTO_MOBILITY.wallJump:null;
  const weight=narutoEase(t/.10)*(k?1-narutoEase((t-k.startup-(m.kind===1?narutoBoostActive(m):k.active))/k.recovery):1);
  if(swing||m.kind===3)v.axis.copy(f.vel);else{v.axis.copy(m.dir).multiplyScalar(24);v.axis.y=f.vel.y;}if(v.axis.lengthSq()<.01)v.axis.set(0,1,0);v.axis.normalize();v.side.set(v.axis.z,0,-v.axis.x);if(v.side.lengthSq()<.01)v.side.set(1,0,0);else v.side.normalize();v.up.crossVectors(v.axis,v.side).normalize();
  for(let i=0;i<count;i++){const seed=i+f.slot*23,phase0=(v.age/c.cycle+domainHash(seed+41))%1,angle=domainHash(seed+57)*Math.PI*2,r=c.radius+domainHash(seed+4)*.95,length=c.length*(.6+domainHash(seed+8));
   v.point.copy(f.pos);v.point.y+=1.3;v.point.addScaledVector(v.side,Math.cos(angle)*r).addScaledVector(v.up,Math.sin(angle)*r).addScaledVector(v.axis,2.5-phase0*7);
   for(let segment=0;segment<3;segment++)for(let end=0;end<2;end++){const q=(segment+end)/3,j=vertex*3;v.positions[j]=v.point.x-v.axis.x*length*q;v.positions[j+1]=v.point.y-v.axis.y*length*q;v.positions[j+2]=v.point.z-v.axis.z*length*q;v.opacity[vertex++]=Math.sin(q*Math.PI)*Math.sin(phase0*Math.PI)*weight*c.alpha;}
  }
 }
 v.geometry.setDrawRange(0,vertex);v.geometry.attributes.position.needsUpdate=v.geometry.attributes.aOpacity.needsUpdate=true;
}
