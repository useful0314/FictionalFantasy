// Build 41: small forgiveness windows around the existing authoritative actions.
const RESPONSE={buffer:.14,coyote:.10,wallGrace:.12,wallReach:1.35,alignment:.85,alignmentTime:.10,outcomeLife:.28,locomotionBlend:.10};
function responseState(f){return f.response||(f.response={action:'',remaining:0,released:false,webView:null,wallPending:false,groundGrace:0,wallGrace:0,wallIndex:-1,wallPoint:V(),normal:V(),carry:V(),alignTime:0,alignDistance:0,alignMoved:0,alignDir:V(),before:V()});}
function clearBufferedAction(f){const r=f.response;if(r){r.action='';r.remaining=0;r.webView=null;r.wallPending=false;}}
function resetCombatResponse(){for(const f of actorPool){f.response=null;f.lightOutcome=f.lightOutcomeTime=0;}}
function approachingJumpWall(f){
 if(f.grounded||f.flying||f.narutoMobility?.kind||responseState(f).groundGrace>0||!inputFor(f).has('ShiftLeft'))return false;
 const d=moveDirection(f);if(d.lengthSq()<.1)return false;
 for(const p of pieces){if(!arenaPieceActive(p)||!p.solid||p.size.y<1.5||f.pos.y+1.4<p.pos.y-p.size.y/2||f.pos.y+1>p.pos.y+p.size.y/2)continue;
  const dx=f.pos.x-p.pos.x,dz=f.pos.z-p.pos.z,hx=p.size.x/2,hz=p.size.z/2;
  for(let face=0;face<4;face++){const x=face<2?(face===0?1:-1):0,z=face>=2?(face===2?1:-1):0,gap=x?dx*x-hx:dz*z-hz;if(gap>=.38&&gap<1.15&&(x?Math.abs(dz)<hz-.05:Math.abs(dx)<hx-.05)&&d.x*x+d.z*z<-.2)return true;}
 }return false;
}
function actionWait(f,action){
 if(!['jump','dodge','light'].includes(action)&&!action.startsWith('special'))return -1;
 if(f.hp<=0||f.ragdollT>0||soulExecutionPending(f)||castFor(f)||trappedByVoid(f)||chargeFor(f)||narutoBusy(f)||worldCutBusy(f)||mahitoBusy(f)||spiderBusy(f))return -1;
 if(action.startsWith('special')&&(f.techniqueBurnout>0||f.soulTime>0&&f.soulSlot===+action.slice(-1)))return -1;
 let wait=Math.max(f.stun||0,f.recovery||0);
 if(action==='jump'){wait=Math.max(wait,f.airJumpCooldown||0);const r=responseState(f);if(r.wallPending&&f.narutoMobility?.kind!==3&&!f.grounded)return .001;
  if(!f.grounded&&!f.flying&&!f.narutoMobility?.kind&&!['naruto','sukuna'].includes(f.character)&&r.groundGrace<=0&&r.wallGrace<=0)wait=Math.max(wait,.001);
 }else{wait=Math.max(wait,f.dodge||0,action==='dodge'?f.dodgeCooldown||0:Math.max(0,(f.attack||0)-.08));
  if(action==='light'&&f.stamina<3||action==='dodge'&&(f.stamina<14||f.character==='naruto'&&f.energy<4))return -1;
  if(action.startsWith('special'))wait=Math.max(wait,f.character==='spiderman'?f.spider?.cd?.[+action.slice(-1)]||0:f.cooldown||0);
 }return wait>RESPONSE.buffer?-1:wait;
}
function bufferAction(f,action,webView){
 let wait=actionWait(f,action),wall=action==='jump'&&wait>=0&&approachingJumpWall(f);if(wall)wait=Math.max(.001,wait);if(wait<=0)return false;
 const r=responseState(f);r.action=action;r.remaining=RESPONSE.buffer;r.released=false;r.wallPending=wall;r.webView=webView||(action==='special4'&&f.character==='spiderman'&&f===player?captureSpiderView():null);return true;
}
function releaseBufferedAction(f,action){if(f.response?.action===action){f.response.released=true;if(action==='special4'&&f.character==='spiderman')clearBufferedAction(f);}}
function updateBufferedAction(f,dt){const r=f.response;if(!r?.action)return;r.remaining-=dt;if(r.remaining<=0||phase!=='play'||countdown>0||f===player&&menuOpen){clearBufferedAction(f);return;}if(actionWait(f,r.action)!==0)return;const a=r.action,released=r.released,view=r.webView;clearBufferedAction(f);actionFor(f,a,true,view,true);if(released)actionFor(f,a,false,null,true);}
function responseTimers(f,dt){const r=f.response;if(r){r.groundGrace=Math.max(0,r.groundGrace-dt);r.wallGrace=Math.max(0,r.wallGrace-dt);}f.lightOutcomeTime=Math.max(0,(f.lightOutcomeTime||0)-dt);}
function groundResponse(f,was){const r=responseState(f);if(f.grounded)r.groundGrace=0;else if(was&&f.vel.y<=0&&!f.flying&&!f.narutoMobility?.kind&&!f.ragdollT)r.groundGrace=RESPONSE.coyote;}
function rememberWall(f){const r=responseState(f),m=narutoMobility(f);r.wallGrace=RESPONSE.wallGrace;r.wallIndex=m.wallIndex;r.wallPoint.copy(f.pos);r.normal.copy(m.normal);r.carry.copy(m.wallVelocity);}
function tryGraceJump(f){
 const r=responseState(f),m=narutoMobility(f);if(f.grounded||m.kind===3||narutoMobilityBlocked(f)||f.airJumpCooldown>0||f.dodge>0)return false;
 if(r.wallGrace>0&&m.wallJumpCD<=0&&f.pos.distanceTo(r.wallPoint)<=RESPONSE.wallReach&&arenaPieceActive(pieces[r.wallIndex])){m.kind=3;m.wallIndex=r.wallIndex;m.normal.copy(r.normal);m.wallVelocity.copy(r.carry);r.wallGrace=r.groundGrace=0;if(startNarutoWallJump(f,true))return true;cancelNarutoMobility(f);}
 if(r.groundGrace>0){r.groundGrace=0;f.grounded=true;if(jumpFighter(f))return true;f.grounded=false;}return false;
}
function beginMeleeAlignment(f,victim,dir){const r=responseState(f);r.alignTime=0;r.alignDistance=r.alignMoved=0;if(f.combo<=0||!victim||barrierSeparates(f,victim))return;r.alignDir.copy(victim.pos).sub(f.pos);r.alignDir.y=0;const d=r.alignDir.length();if(d<=2.35||d>5.2||r.alignDir.normalize().dot(dir)<=.2)return;r.alignDistance=Math.min(RESPONSE.alignment,d-2.35);r.alignTime=RESPONSE.alignmentTime;}
function updateMeleeAlignment(f,dt){const r=f.response;if(!r||r.alignTime<=0)return;if(f.hp<=0||f.stun>0||f.dodge>0||f.ragdollT>0||f.attack<=0){r.alignTime=0;return;}r.alignTime=Math.max(0,r.alignTime-dt);const total=r.alignDistance*narutoEase(1-r.alignTime/RESPONSE.alignmentTime),step=Math.max(0,total-r.alignMoved);r.alignMoved=total;r.before.copy(f.pos);f.pos.addScaledVector(r.alignDir,narutoMobilityDistance(f,r.alignDir,step));resolveDistrictCollision(f,r.before);constrainBarrier(f,f.pos,r.before,f.vel);}
function lightOutcome(f,code){f.lightOutcome=code;f.lightOutcomeTime=RESPONSE.outcomeLife;}
function applyLightOutcomePose(f,p){if(!(f.lightOutcomeTime>0)||!f.attackIsLight||f.hitReact>0||f.ragdollT>0||f.dodge>0||f.block||chargeFor(f)||castFor(f)||f.hp<=0)return;const age=RESPONSE.outcomeLife-f.lightOutcomeTime,w=narutoEase(age/.045)*(1-narutoEase(age/RESPONSE.outcomeLife)),side=f.combo%2?1:-1;
 if(f.lightOutcome===2){p[NP.lean]-=.23*w;p[NP.twist]+=side*.17*w;p[NP.le]-=.30*w;p[NP.re]-=.30*w;p[NP.bob]-=.035*w;}
 else if(f.lightOutcome===3||f.lightOutcome===4){p[NP.lean]+=.10*w;p[NP.twist]-=side*.12*w;p[NP.hx]-=.06*w;}else{p[NP.lean]+=.035*w;p[NP.stretch]+=.012*w;}
}
function continuousGait(f,p,n,dt,speed){
 const g=n.gait||(n.gait={speed:0,pose:p.slice(),ready:false});g.speed=lerp(g.speed,Math.min(65,speed),1-Math.exp(-dt/RESPONSE.locomotionBlend));
 if(!f.grounded||f.flying||f.narutoMobility?.kind||spiderBusy(f))return;
 const walk=narutoEase(g.speed/2),run=narutoEase((g.speed-WORLD.walk)/(WORLD.sprint-WORLD.walk)),phase=f.character==='naruto'?f.narutoAnim.phase:f.walkPhase||0,s=Math.sin(phase),c=Math.cos(phase),base=rosterPoseLibrary()[f.character];
 p[NP.ll]=lerp(base[NP.ll],s*lerp(.66,1.05,run),walk);p[NP.rl]=lerp(base[NP.rl],-s*lerp(.66,1.05,run),walk);p[NP.lk]=lerp(base[NP.lk],.15+Math.max(0,-s)*lerp(.82,1.42,run),walk);p[NP.rk]=lerp(base[NP.rk],.15+Math.max(0,s)*lerp(.82,1.42,run),walk);
 p[NP.lx]=lerp(base[NP.lx],f.character==='naruto'?lerp(-s*.55,.8,run):-s*lerp(.57,.94,run),walk);p[NP.rx]=lerp(base[NP.rx],f.character==='naruto'?lerp(s*.55,.8,run):s*lerp(.57,.94,run),walk);p[NP.le]=lerp(base[NP.le],f.character==='naruto'?lerp(-.8,-.32,run):-1.15,walk);p[NP.re]=lerp(base[NP.re],f.character==='naruto'?lerp(-.8,-.32,run):-1.15,walk);
 p[NP.lean]=lerp(base[NP.lean],lerp(.08,f.character==='naruto'?.4:.29,run),walk);p[NP.twist]=lerp(base[NP.twist],c*lerp(.075,.13,run),walk);
}
function blendGait(n,p,dt){const g=n.gait;if(!g)return;if(!g.ready){g.pose.set(p);g.ready=true;}else for(let i=0;i<p.length;i++)g.pose[i]=lerp(g.pose[i],p[i],1-Math.exp(-dt/.045));p.set(g.pose);}
