// Confirmed-hit chains and physically driven knockback presentation.
let lightSerial=0;
const AIR_STEP={cost:3,groundCost:0,impulse:12.5,cooldown:.18};
function updateCombatTimers(f,dt){
 responseTimers(f,dt);
 for(const prefix of ['special','auxSpecial'])if(f[prefix+'Kind']>0){f[prefix+'Age']+=dt;if(f[prefix+'Age']>=f[prefix+'Duration'])f[prefix+'Kind']=0;}
 if(f.castVoiceActive){f.castVoiceAge+=dt;if(f.castVoiceAge>(f.character==='gojo'?5.4:7.9))f.castVoiceActive=false;}
 for(const key of ['techniqueBurnout','comboLock','counterWindow','guardReact','recovery','airJumpCooldown','jumpPose','launchImpactCD','redRecoil'])f[key]=Math.max(0,(f[key]||0)-dt);
 if(f.ragdollT>0){
  f.ragdollT=Math.max(f.ragdollGround?0:.22,f.ragdollT-dt);f.ragdollAge=(f.ragdollAge||0)+dt;f.flying=false;f.block=false;
  if(f.ragdollGround){const rest=Math.round((f.ragdollPitch+Math.PI/2)/(Math.PI*2))*Math.PI*2-Math.PI/2;f.ragdollPitch=lerp(f.ragdollPitch,rest,1-Math.exp(-12*dt));f.ragdollRoll=lerp(f.ragdollRoll,.1*f.ragdollSpin,1-Math.exp(-10*dt));}
  else{f.ragdollPitch-=f.ragdollRate*dt;f.ragdollRoll+=f.ragdollSpin*.85*dt;}
  f.stun=Math.max(f.stun,f.ragdollT+.2);if(f.ragdollT===0){f.recovery=.55;f.stun=Math.max(f.stun,.55);f.body.rotation.x=THREE.MathUtils.euclideanModulo(f.body.rotation.x+Math.PI,Math.PI*2)-Math.PI;}
 }
 if(f.comboTimer<=0)f.comboHits=0;
}
function startRagdoll(f,impulse){
 const horizontal=Math.hypot(impulse.x,impulse.z);f.vel.x*=1.25;f.vel.z*=1.25;f.vel.y=Math.max(f.vel.y,10+Math.min(4,horizontal*.095));
 f.ragdollMax=2.4;f.ragdollT=2.4;f.ragdollAge=0;f.ragdollGround=false;f.ragdollBounces=0;f.ragdollSpin=impulse.x>=0?1:-1;f.ragdollPitch=-.25;f.ragdollRoll=0;f.ragdollRate=clamp(3+horizontal*.09,4.5,7.5);
 f.ragdollYaw=horizontal>.1?Math.atan2(-impulse.x,-impulse.z):f.root.rotation.y;f.launchImpactCD=0;f.stun=Math.max(f.stun,2.4);f.flying=false;f.grounded=false;f.block=false;f.comboHits=0;f.comboTimer=0;f.comboLock=0;f.attack=0;f.jumpPose=0;cancelCharge(f);
}
function launchImpact(f,pos,strength=1){
 if(f.launchImpactCD>0)return;f.launchImpactCD=.18;playCombatFX('launchImpact',pos,1.4+strength,strength);sfx('launchImpact',pos,.6+strength*.3);if(f===player)shakeIt(.2+strength*.13);
}
function jumpFighter(f){
 if(!f.grounded&&tryGraceJump(f))return true;
 if(f.spider?.action?.kind===4){const sliding=f.spider.action.sliding&&f.grounded;stopSpider(f,true);if(!sliding)return true;}
 if(f.spider?.action?.kind===3&&f.spider.action.bound)return throwSpiderCocoon(f,true);
 if(f.narutoMobility?.kind===3)return startNarutoWallJump(f);
 if(f.character==='naruto'&&!f.grounded)return requestNarutoAirJump(f);
 if(narutoBusy(f)||worldCutBusy(f)||mahitoBusy(f)||spiderBusy(f))return false;
 if(phase!=='play'||f.flying||f.stun>0||f.ragdollT>0||f.recovery>0||f.airJumpCooldown>0||chargeFor(f)||castFor(f)||trappedByVoid(f))return false;
 const airborne=!f.grounded;if(f.pos.y>WORLD.ceiling-2)return false;if(airborne&&f.character!=='sukuna')return false;
 const cost=airborne?AIR_STEP.cost:0;if(f.energy<cost){if(f===player)toast('Air step needs '+cost+' cursed energy',1);return false;}f.energy-=cost;responseState(f).groundGrace=responseState(f).wallGrace=0;
 f.vel.y=f.character==='sukuna'?(airborne?AIR_STEP.impulse:10.2):9;f.grounded=false;f.block=false;f.airJumpCooldown=AIR_STEP.cooldown;f.jumpPose=.3;f.jumpSide=1-(f.jumpSide||0);
 if(airborne){const dir=moveDirection(f);f.vel.addScaledVector(dir,3.2);playCombatFX('airStep',f.pos.clone(),1.2,.7);sfx('airStep',f.pos,.8);}else sfx('step',f.pos,.8);
 return true;
}
function breakLightChain(f){f.comboHits=0;f.comboTimer=0;}
function lightAttack(f){
 if(mahitoLightStart(f))return;
 if(narutoBusy(f)||worldCutBusy(f)||mahitoBusy(f)||spiderBusy(f))return;
 if(phase!=='play'||f.hp<=0||f.stun>0||f.ragdollT>0||f.recovery>0||f.attack>.08||f.stamina<3||f.dodge>0)return;
 if(trappedByVoid(f)||chargeFor(f)||castFor(f)||inputFor(f).has('KeyC'))return;
 const kind=lightAttackKind(f);
 f.lightOutcome=f.lightOutcomeTime=0;f.attackIsLight=true;f.attackCounter=f.counterWindow>0;f.counterWindow=0;f.block=false;f.stamina-=3;f.combo=f.comboTimer>0?(f.comboHits||0):0;f.attackAir=!f.grounded;
 const duration=f.attackCounter?.32:.34;f.attack=duration;f.attackMax=duration;f.attackKind=kind;
 const dir=aimFor(f).setY(0).normalize(),victim=other(f),distance=f.pos.distanceTo(victim.pos);
 beginMeleeAlignment(f,victim,dir);
 f.vel.addScaledVector(dir,f.attackCounter?2:1.2);sfx(f.attackCounter?'parry':'light',f.pos);
 pendingHits.push({f,kind,combo:f.combo,air:f.attackAir,counter:f.attackCounter,t:f.attackCounter?.09:.12,seq:++lightSerial});
}
function resolveLight(h){
 if(resolveMahitoLight(h))return;
 const f=h.f;if(f.stun>0||f.hp<=0||f.ragdollT>0||phase!=='play')return;
 const dir=lightStrikeDirection(f,h.kind,h.air),start=headPos(f),end=start.clone().addScaledVector(dir,2.6),col=fighterColor(f);
 slashRibbon(start.clone().addScaledVector(dir,1.5),dir,col,h.kind===1?2.5:1.8,.18,h.kind===2?Math.PI/2:h.kind===3?-.85:.25);
 destroyAt(end,1.6,9);const range=3.3,target=opponents(f).filter(b=>!barrierSeparates(f,b)&&headPos(b).distanceTo(start)<range&&headPos(b).sub(start).normalize().dot(dir)>=.1).sort((a,b)=>a.pos.distanceTo(f.pos)-b.pos.distanceTo(f.pos))[0];
 if(!target){lightOutcome(f,3);breakLightChain(f);return;}
 const final=h.combo===3,knock=dir.clone().multiplyScalar(final?15:1.2);if(final)knock.y=h.kind===2?10:5;airLightKnockback(knock,h);
 const hit=hurt(target,(f.character==='sukuna'?BALANCE.sukunaLight:BALANCE.light)[h.combo]||(f.character==='sukuna'?BALANCE.sukunaLight:BALANCE.light)[0],f,'light',knock,1);
 if(hit){if(f.character==='spiderman'&&h.air&&h.kind===3&&f.spider?.linkTime>0)spiderSlam(f,target);f.comboHits=final?0:h.combo+1;f.comboTimer=final?0:.85;target.comboLock=final?0:.62;target.stun=Math.max(target.stun,final?.28:.62);target.block=false;
  if(!final){target.vel.x*=.25;target.vel.z*=.25;}else{target.recovery=.18;f.cooldown=Math.max(f.cooldown||0,.18);}
  if(f===player){$('comboReadout').textContent=(h.combo+1)+' / 4'+(final?' · FINISH':'');$('comboReadout').classList.remove('hidden');f.comboDisplay=1.05;}
 }else breakLightChain(f);
}
