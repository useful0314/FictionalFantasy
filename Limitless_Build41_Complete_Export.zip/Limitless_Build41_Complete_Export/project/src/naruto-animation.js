// Compact visual pose channels shared by the animation helpers; Naruto keeps his existing animator and IK.
const NP={lean:0,twist:1,tilt:2,bob:3,stretch:4,hx:5,hy:6,lx:7,ly:8,lz:9,le:10,lh:11,lhz:12,rx:13,ry:14,rz:15,re:16,rh:17,rhz:18,ll:19,ls:20,lk:21,lf:22,rl:23,rs:24,rk:25,rf:26,lc:27,rc:28,z:29};
function narutoPoseTemplate(values={}){const p=new Float32Array(30);p[NP.stretch]=1;p[NP.lx]=p[NP.rx]=-.36;p[NP.lz]=.19;p[NP.rz]=-.19;p[NP.le]=p[NP.re]=-.9;p[NP.lk]=p[NP.rk]=.16;p[NP.lc]=p[NP.rc]=-.65;for(const k of Object.keys(values))p[NP[k]]=values[k];return p;}
const NARUTO_POSES={
 idle:narutoPoseTemplate(),sign:narutoPoseTemplate({lx:-1.02,ly:-.22,lz:-.36,le:-1.65,lh:-.3,lhz:-.55,rx:-1.02,ry:.22,rz:.36,re:-1.65,rh:-.3,rhz:.55,lc:-1.4,rc:-1.4,bob:-.06,lk:.3,rk:.3,hy:.04}),
 crouch:narutoPoseTemplate({lean:.28,bob:-.21,stretch:.95,lx:.45,rx:-.5,le:-.6,re:-1.3,ll:-.25,rl:.3,lk:.7,rk:.35}),
 dash:narutoPoseTemplate({lean:.5,bob:-.13,stretch:1.035,lx:.78,rx:.6,lz:.3,rz:-.3,le:-.4,re:-.6,ll:-.65,rl:.6,lk:.9,rk:.2}),
 punch:narutoPoseTemplate({lean:.23,twist:.72,bob:.04,stretch:1.025,lx:-.65,le:-1.4,rx:-1.65,re:-.06,ry:-.12,rz:-.04,rl:.2,lk:.25,rc:-1.55}),
 kick:narutoPoseTemplate({lean:.08,twist:6.05,tilt:.25,rx:-.7,re:-1.3,lx:-.9,le:-1.1,rl:-1.65,rs:-.4,rk:.08,ll:.2,lk:.35,bob:.1,stretch:1.035}),
 upper:narutoPoseTemplate({lean:-.2,twist:6.8,bob:.18,stretch:1.06,rx:-2.85,re:-.26,lx:-.75,le:-1.35,ll:-.2,rl:.3,lk:.4,rk:.65}),
 chamber:narutoPoseTemplate({lean:-.12,twist:6.45,rx:-.75,lx:-.8,le:-1.4,re:-1.2,rl:-2.65,rk:.42,ll:.3,lk:.6,bob:.12,stretch:.97}),
 slam:narutoPoseTemplate({lean:.65,twist:6.9,bob:-.2,stretch:.94,rx:.15,lx:-.7,rl:.5,rk:.08,ll:-.45,lk:.85}),
 palm:narutoPoseTemplate({lean:-.1,twist:-.35,lx:-1.3,ly:-.25,lz:-.2,le:-.55,rx:-1.08,ry:.2,rz:.22,re:-.95,rh:-1.2,lc:-.2,rc:-.2,ll:-.15,rl:.2,lk:.36,rk:.25,bob:-.08}),
 thrust:narutoPoseTemplate({lean:.43,twist:.6,stretch:1.05,rx:-1.64,re:-.04,rh:-.9,lx:.6,le:-.7,lz:.3,ll:-.6,rl:.75,lk:.8,rk:.1,bob:.03,rc:-.2}),
 overhead:narutoPoseTemplate({lean:-.12,twist:-.24,rx:-3.03,re:-.12,rh:-1.6,rz:.08,lx:-2.4,le:-.6,lz:-.18,lc:-.18,rc:-.15,ll:-.16,rl:.25,lk:.28,rk:.4,bob:-.05,hx:-.12}),
 throw:narutoPoseTemplate({lean:.5,twist:.8,rx:-1.38,re:-.02,lx:.5,le:-.4,rc:0,rh:0,ll:-.55,rl:.6,lk:.75,rk:.16,bob:.05,stretch:1.04}),
 cloak:narutoPoseTemplate({lean:-.13,twist:0,lx:-.25,lz:.8,le:-.3,rx:-.25,rz:-.8,re:-.3,ll:-.24,ls:.15,rl:-.24,rs:-.15,lk:.48,rk:.48,bob:-.16,stretch:.97,hx:-.12}),
 bomb:narutoPoseTemplate({lean:-.12,lx:-1.34,lz:.24,le:-.35,rx:-1.34,rz:-.24,re:-.35,lh:-1.2,rh:-1.2,lc:-.15,rc:-.15,ll:-.25,rl:.2,lk:.6,rk:.3,bob:-.15}),
 fire:narutoPoseTemplate({lean:.35,lx:-1.58,le:-.03,rx:-1.58,re:-.03,lz:.2,rz:-.2,lc:0,rc:0,bob:.09,stretch:1.065,ll:-.2,rl:.35,lk:.4,rk:.2})
};
function narutoMixPose(out,a,b,q){for(let i=0;i<out.length;i++)out[i]=a[i]+(b[i]-a[i])*q;}
const NARUTO_TRACKS={
 1:[[0,'sign'],[.72,'sign'],[.86,'crouch'],[1.00,'punch','snap'],[1.21,'punch'],[1.6,'idle']],
 2:[[0,'crouch'],[.09,'dash'],[.15,'punch','snap'],[.26,'crouch'],[.35,'kick','snap'],[.48,'kick'],[.52,'crouch'],[.58,'upper','snap'],[.82,'chamber'],[.95,'slam','snap'],[1.15,'slam'],[1.46,'idle']],
 3:[[0,'palm'],[.15,'thrust','snap'],[.48,'thrust'],[.8,'idle']],
 4:[[0,'overhead'],[.085,'throw','snap'],[.3,'throw'],[.72,'idle']],
 5:[[0,'crouch'],[.48,'cloak','snap'],[.82,'cloak'],[1.2,'bomb'],[2.08,'bomb'],[2.16,'fire','snap'],[2.75,'fire'],[3.4,'idle']]
};
function narutoSampleTrack(out,kind,t){
 const track=NARUTO_TRACKS[kind];let i=1;while(i<track.length-1&&t>track[i][0])i++;const a=track[i-1],b=track[i],u=clamp((t-a[0])/(b[0]-a[0]),0,1);narutoMixPose(out,NARUTO_POSES[a[1]],NARUTO_POSES[b[1]],b[2]==='snap'?narutoBack(u):narutoEase(u));
 if(kind===2){if(t>=.17&&t<=.39)out[NP.twist]=narutoEase((t-.17)/.22)*Math.PI*2;else if(t>.39)out[NP.twist]=THREE.MathUtils.euclideanModulo(out[NP.twist],Math.PI*2);}
}
function initNarutoAnimation(f){
 if(f.narutoAnim)return f.narutoAnim;
 const n=f.narutoAnim={pose:narutoPoseTemplate(),temp:narutoPoseTemplate(),last:f.pos.clone(),initialized:false,wasGrounded:f.grounded,land:0,phase:0,hair:0,jacket:0,tail:0,previousLean:0,trailClock:0,trailLeft:V(),trailRight:V(),trailFoot:V(),point:V(),ik:[0,1].map(()=>({upper:new THREE.Quaternion(),elbow:new THREE.Quaternion(),hand:new THREE.Quaternion(),fore:new THREE.Quaternion(),palm:new THREE.Quaternion(),delta:V(),bend:V(),joint:V(),foreDir:V(),down:V(0,-1,0),euler:new THREE.Euler()}))};return n;
}
function narutoSealIK(f,i,x,y,z,sign){
 const k=f.narutoAnim.ik[i],arm=f.limbs[i].arm,side=i?1:-1;k.delta.set(x,y,z).sub(arm.position);const d=clamp(k.delta.length(),.15,.90),along=(.51**2-.405**2+d*d)/(2*d);k.delta.normalize();k.bend.set(side,-.85,.12).addScaledVector(k.delta,-k.bend.set(side,-.85,.12).dot(k.delta)).normalize();k.joint.copy(arm.position).addScaledVector(k.delta,along).addScaledVector(k.bend,Math.sqrt(Math.max(0,.51**2-along**2)));k.foreDir.set(x,y,z).sub(k.joint).normalize();k.delta.copy(k.joint).sub(arm.position).normalize();k.upper.setFromUnitVectors(k.down,k.delta);k.fore.setFromUnitVectors(k.down,k.foreDir);k.elbow.copy(k.upper).invert().multiply(k.fore);k.euler.set(sign?0:-Math.PI/2,sign?side*.2:0,sign?Math.PI-side*.42:0);k.palm.setFromEuler(k.euler);k.hand.copy(k.fore).invert().multiply(k.palm);return k;
}
function animateNaruto(f,dt,clonePose=null){
 const n=initNarutoAnimation(f),p=n.pose,r=f.narutoRig,secondary=1-Math.exp(-dt/NARUTO.secondaryBlend);let b=1-Math.exp(-dt/NARUTO.blend);
 let speed=n.initialized?Math.hypot(f.pos.x-n.last.x,f.pos.z-n.last.z)/Math.max(dt,.001):0;n.last.copy(f.pos);n.initialized=true;
 f.root.position.copy(f.pos);let facing=clonePose?f.cloneFacing:Math.atan2(narutoAim(n.point,f).x,n.point.z);if(!clonePose&&narutoMobilityFacing(f)!==null)facing=narutoMobilityFacing(f);if(f.ragdollT>0)facing=f.ragdollYaw;f.root.rotation.y+=Math.atan2(Math.sin(facing-f.root.rotation.y),Math.cos(facing-f.root.rotation.y))*(1-Math.exp(-22*dt));
 p.set(rosterPoseLibrary().naruto);const sprint=f.sprinting||speed>11,moving=speed>.3&&f.grounded;n.phase+=Math.min(speed,26)*dt*lerp(1.9,1.04,narutoEase((speed-WORLD.walk)/(WORLD.sprint-WORLD.walk)));
 const breath=Math.sin(time*2.5+(f.slot||0));p[NP.bob]=breath*.022;p[NP.lx]+=breath*.028;p[NP.rx]-=breath*.023;p[NP.hy]=Math.sin(time*.8)*.025;
 if(moving){const s=Math.sin(n.phase),c=Math.cos(n.phase);p[NP.ll]=s*(sprint?1.03:.62);p[NP.rl]=-p[NP.ll];p[NP.lk]=.15+Math.max(0,-s)*(sprint?1.4:.75);p[NP.rk]=.15+Math.max(0,s)*(sprint?1.4:.75);p[NP.lean]=sprint?.4:.1;p[NP.bob]=Math.abs(s)*.105;p[NP.twist]=c*.09;p[NP.hy]=-c*.045;p[NP.tilt]=s*.022;p[NP.lf]=-s*.19;p[NP.rf]=s*.19;p[NP.stretch]=1+Math.sin(n.phase*2)*.012;p[NP.lx]=sprint?.8:-s*.55;p[NP.rx]=sprint?.8:s*.55;p[NP.le]=p[NP.re]=sprint?-.32:-.8;p[NP.lz]=.25;p[NP.rz]=-.25;}
 if(!f.grounded){const rising=f.vel.y>0;p[NP.ll]=rising?-.7:.25;p[NP.rl]=rising?.35:-.3;p[NP.lk]=rising?1.05:.4;p[NP.rk]=rising?.45:.8;p[NP.lx]=rising?-.55:.15;p[NP.rx]=rising?-.8:.2;p[NP.lz]=.5;p[NP.rz]=-.5;p[NP.lean]=rising?.13:-.08;p[NP.stretch]=rising?1.03:.985;}
 if(!f.grounded)n.fallSpeed=Math.max(n.fallSpeed||0,-f.vel.y);
 if(f.grounded&&!n.wasGrounded){n.land=.2;if(!clonePose&&phase==='play')landingContact(f,n.fallSpeed||0,.6);n.fallSpeed=0;}n.wasGrounded=f.grounded;n.land=Math.max(0,n.land-dt);
 if(n.land>0){const w=Math.sin(n.land/.2*Math.PI);p[NP.bob]-=.14*w;p[NP.lk]+=.4*w;p[NP.rk]+=.4*w;p[NP.stretch]-=.05*w;}
 if(!clonePose){continuousGait(f,p,n,dt,speed);polishLocomotion(f,p,rosterAnimationState(f),dt,moving);blendGait(n,p,dt);}n.temp.set(p);rosterLightPose(f,p,n.temp,dt);if(!clonePose)applyLightOutcomePose(f,p);b=combatPoseBlend(f,b);
 const ch=clonePose?null:chargeFor(f),a=clonePose?null:f.narutoAction,cast=clonePose?null:domainPresentationCast(f);
 if(ch){const pose=ch.kind===1?NARUTO_POSES.sign:ch.kind===2?NARUTO_POSES.crouch:ch.kind===3?NARUTO_POSES.palm:NARUTO_POSES.overhead;narutoMixPose(p,p,pose,narutoEase(ch.elapsed/Math.max(.12,techniqueStartup(f,ch.kind)*.7)));}
 if(a)narutoSampleTrack(p,a.kind,narutoAge(a));
 if(cast)narutoMixPose(p,p,NARUTO_POSES.sign,narutoEase(cast.t/.2));
 if(clonePose?.boost){p.set(NARUTO_MOBILITY_POSES.support);p[NP.stretch]=lerp(.91,1.04,narutoBack(clonePose.strike));p[NP.bob]+=.13*clonePose.strike;}
 else if(clonePose?.technique){narutoSampleTrack(p,clonePose.technique,clonePose.age);}
 else if(clonePose){narutoMixPose(p,NARUTO_POSES.dash,clonePose.kick?NARUTO_POSES.kick:NARUTO_POSES.punch,narutoBack(clonePose.strike));p[NP.twist]=clonePose.kick?.9*clonePose.strike:.6*clonePose.strike;}
 if(f.energyCharging&&!a&&!ch){p[NP.lx]=p[NP.rx]=-.65;p[NP.le]=p[NP.re]=-1.5;p[NP.bob]-=.08;p[NP.lk]=p[NP.rk]=.35;}
 if(f.block||f.guardReact>0){p[NP.lx]=p[NP.rx]=-1.08;p[NP.le]=p[NP.re]=-1.45;p[NP.lz]=-.2;p[NP.rz]=.2;p[NP.lean]=-.12;p[NP.lc]=p[NP.rc]=-1.5;}
 if(f.dodge>0){p[NP.lean]=.62;p[NP.bob]=-.23;p[NP.lx]=p[NP.rx]=.7;p[NP.stretch]=.93;p[NP.lk]=.6;p[NP.rk]=.35;}
 if(!clonePose)animateNarutoMobilityPose(f,p);
 if(f.hitReact>0){f.hitReact=Math.max(0,f.hitReact-dt);const hitPose=clonePose?null:sampleHitRecoil(f);p[NP.lean]=hitPose?hitPose.lean:-.32;p[NP.hx]=hitPose?hitPose.head:-.17;p[NP.tilt]=hitPose?hitPose.tilt:Math.sin(f.hitReact*28)*.09;p[NP.stretch]=hitPose?hitPose.squash:.97;if(hitPose){p[NP.twist]=hitPose.twist;p[NP.bob]+=hitPose.bob;}}
 if(f.ragdollT>0){p[NP.lean]=f.ragdollPitch;p[NP.tilt]=f.ragdollRoll;p[NP.twist]=0;p[NP.lz]=1.1;p[NP.rz]=-1.1;p[NP.lx]=Math.sin(f.ragdollAge*6)*.7;p[NP.rx]=-p[NP.lx];p[NP.ll]=Math.sin(f.ragdollAge*5)*.6;p[NP.rl]=-p[NP.ll];p[NP.lk]=p[NP.rk]=.7;p[NP.bob]=0;}
 else if(f.recovery>0&&f.ragdollGround){const rise=narutoEase(1-f.recovery/.55);p[NP.lean]=-Math.PI/2*(1-rise);p[NP.lk]=p[NP.rk]=Math.sin(rise*Math.PI);p[NP.bob]=-.15;}
 if(f.hp<=0){p[NP.tilt]=1.5;p[NP.lean]=.12;p[NP.bob]=-.46;p[NP.lz]=.6;p[NP.rz]=-.6;p[NP.lk]=.65;p[NP.rk]=.25;}
 f.body.rotation.x=lerp(f.body.rotation.x,p[NP.lean],b);f.body.rotation.y=combatBodyYaw(f,p[NP.twist],b);f.body.rotation.z=lerp(f.body.rotation.z,p[NP.tilt],b);
 f.body.position.y=lerp(f.body.position.y,p[NP.bob],b);f.body.position.z=lerp(f.body.position.z,p[NP.z],b);const stretch=lerp(f.body.scale.y,p[NP.stretch],b);f.body.scale.set(1/Math.sqrt(stretch),stretch,1/Math.sqrt(stretch));
 if(f.ragdollT>0||f.hp<=0){n.point.set(0,1.15,0).applyEuler(f.body.rotation);f.body.position.set(-n.point.x,(f.hp<=0?.40:f.ragdollGround?.62:1.15)-n.point.y,-n.point.z);}else f.body.position.x=lerp(f.body.position.x,0,b);
 f.headGroup.rotation.x=lerp(f.headGroup.rotation.x,p[NP.hx],b);f.headGroup.rotation.y=lerp(f.headGroup.rotation.y,p[NP.hy],b);
 for(let i=0;i<2;i++){const arm=f.limbs[i],j=i?NP.rx:NP.lx,k=i?NP.rl:NP.ll,seal=!!cast||ch?.kind===1||a?.kind===1&&narutoAge(a)<.72,palm=ch?.kind===3,ik=(seal||palm)&&f.hitReact<=0&&f.ragdollT<=0&&f.hp>0;
  if(ik){const q=narutoSealIK(f,i,seal?(i?.068:-.068):(i?.38:-.1),seal?1.95:1.57,seal?.49:(i?.66:.58),seal);arm.arm.quaternion.slerp(q.upper,b);arm.elbow.quaternion.slerp(q.elbow,b);arm.hand.quaternion.slerp(q.hand,b);}
  else{arm.arm.rotation.x=lerp(arm.arm.rotation.x,p[j],b);arm.arm.rotation.y=lerp(arm.arm.rotation.y,p[j+1],b);arm.arm.rotation.z=lerp(arm.arm.rotation.z,p[j+2],b);arm.elbow.rotation.x=lerp(arm.elbow.rotation.x,p[j+3],b);arm.elbow.rotation.y=lerp(arm.elbow.rotation.y,0,b);arm.elbow.rotation.z=lerp(arm.elbow.rotation.z,0,b);arm.hand.rotation.x=lerp(arm.hand.rotation.x,p[j+4],b);arm.hand.rotation.y=lerp(arm.hand.rotation.y,0,b);arm.hand.rotation.z=lerp(arm.hand.rotation.z,p[j+5],b);}
  f.legs[i].rotation.x=lerp(f.legs[i].rotation.x,p[k],b);f.legs[i].rotation.z=lerp(f.legs[i].rotation.z,p[k+1],b);f.knees[i].rotation.x=lerp(f.knees[i].rotation.x,p[k+2],b);r.feet[i].rotation.x=lerp(r.feet[i].rotation.x,p[k+3],b);
  for(let j=0;j<4;j++){const sign=!!castFor(f)||ch?.kind===1||a?.kind===1&&narutoAge(a)<.72;arm.fingers[j].rotation.x=lerp(arm.fingers[j].rotation.x,sign&&j<2?0:p[i?NP.rc:NP.lc],b);arm.fingers[j].rotation.z=lerp(arm.fingers[j].rotation.z,sign&&j<2?(i?1:-1)*(j?-.18:.18):0,b);}
 }
 const acceleration=clamp((p[NP.lean]-n.previousLean)/Math.max(dt,.001),-8,8);n.previousLean=p[NP.lean];n.hair=lerp(n.hair,-acceleration*.025+Math.sin(time*5)*.018,secondary);n.jacket=lerp(n.jacket,clamp(speed/26,0,1)*.15+Math.sin(n.phase)*.035,secondary);n.tail=lerp(n.tail,clamp(speed/18,0,1)*1.1+acceleration*.025,secondary);
 r.hair.rotation.x=n.hair;for(let i=0;i<r.hems.length;i++)r.hems[i].rotation.x=n.jacket+Math.sin(time*6+i)*.026;for(let i=0;i<r.tails.length;i++){r.tails[i].rotation.x=-n.tail+Math.sin(time*7-i*.8)*.12;r.tails[i].rotation.z=Math.sin(time*4-i)*.09;}
 const cloak=mindscapeCloak(f)?1:a?.kind===5?Math.sin(Math.min(Math.PI,narutoAge(a)/a.duration*Math.PI)):0;r.eyes.color.setHex(cloak>.15?NARUTO.colors.gold:NARUTO.colors.chakra);
 f.root.updateMatrixWorld(true);
 if(!clonePose){rosterAnimationState(f).speed=speed;animateRosterDetail(f,dt,moving);}
 if(moving&&!clonePose&&(Math.sin(n.phase)>0)!==(f.lastFoot||false)){f.lastFoot=Math.sin(n.phase)>0;sfx('step',f.pos,f===player?.7:.3,false);}
 f.shield.material.opacity=Math.max(0,f.shield.material.opacity-dt*2.7);f.shield.material.uniforms.uOpacity.value=f.shield.material.opacity;f.shield.material.uniforms.uTime.value=time;f.shadow.position.set(f.pos.x,.14,f.pos.z);f.shadow.scale.setScalar(clamp(1-f.pos.y*.025,.4,1));
}
function narutoCinematic(c,dt){
 const f=c.owner,t=c.t,d=c.duration,w=narutoEase(t/.42)*(1-narutoEase((t-(d-.65))/.65)),close=1-narutoEase((t-.65)/.65),s=narutoScratch;narutoAim(s.a,f);s.b.set(-s.a.z,0,s.a.x);narutoHead(s.c,f);s.d.copy(s.c).addScaledVector(s.a,lerp(-5.5,3.6,close)).addScaledVector(s.b,lerp(5,1.2,close));s.d.y+=lerp(1.4,.45,close);camPos.lerp(s.d,w);s.c.addScaledVector(s.a,lerp(4,0,close));camLook.lerp(s.c,w);return w;
}
