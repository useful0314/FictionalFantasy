// Build 40. Cosmetic hooks for confirmed combat outcomes; no damage, hitbox or input authority.
// Research and rationale: BUILD40.md. Timings are seconds; distances use existing world units.
const COMBAT_FEEL={flashLife:.105,heavyFlashLife:.14,flashHold:.018,flashGap:.24,flashWhite:2.4,
 recoilLife:.24,recoilPeak:.035,recoilLean:.34,recoilTilt:.28,recoilSquash:.045,
 burstPool:18,burstLife:.24,heavyBurstLife:.34,burstRange:95,streaks:7,
 threatLife:.9,threatPool:4,landingThreshold:6,landingMax:24,
 hitWhite:0xf4fbff,hitGold:0xffcc8a,guardBlue:0x71d9ff,dodgeMint:0x9affdf,dust:0xc6bba7};
const combatFeel={rigs:new WeakMap(),materials:new WeakMap(),states:[],pool:null,cursor:0,clock:0,
 point:V(),direction:V(),axis:V(0,0,1),up:V(0,1,0),cameraDirection:V(),
 threats:[],threatCursor:0};
function initCombatFeel(){
 for(const key of ['hitFlashes','impactEffects','damageDirection'])if(typeof options[key]!=='boolean')options[key]=true;
 for(const [id,key]of [['characterHitFlashes','hitFlashes'],['contactEffects','impactEffects'],['damageDirection','damageDirection']]){
  $(id).checked=options[key];$(id).onchange=e=>{options[key]=e.target.checked;saveOptions();};
 }
 for(let i=0;i<COMBAT_FEEL.threatPool;i++){const el=document.createElement('i');el.className='incomingHit';el.style.opacity=0;$('incomingHits').append(el);combatFeel.threats.push({el,source:V(),id:'',age:99,heavy:false});}
 for(const f of bodies)prepareCombatFeelRig(f);
 ensureContactPool();
}
function prepareCombatFeelRig(f){
 let s=combatFeel.rigs.get(f.root);if(s)return s;
 s={root:f.root,flash:{value:0},flashAge:99,flashLife:COMBAT_FEEL.flashLife,flashPower:0,nextFlash:0,
  age:99,power:0,dir:V(),pose:{lean:0,tilt:0,twist:0,head:0,squash:1,bob:0},materials:[]};
 combatFeel.rigs.set(f.root,s);combatFeel.states.push(s);
 const own=original=>{
  if(!original||original===outlineMaterial||original.transparent||!(original.isMeshStandardMaterial||original.isMeshBasicMaterial))return original;
  let m=original,owner=combatFeel.materials.get(m);if(owner===s)return m;
  // Current factories own their materials; this branch also protects any future shared material.
  if(owner)m=original.clone();
  const before=m.onBeforeCompile,key=m.customProgramCacheKey();
  m.onBeforeCompile=function(shader,renderer){before.call(this,shader,renderer);shader.uniforms.uConfirmedHit=s.flash;
   shader.fragmentShader='uniform float uConfirmedHit;\n'+shader.fragmentShader.replace('#include <opaque_fragment>',
    '#include <opaque_fragment>\ngl_FragColor.rgb = mix(gl_FragColor.rgb, vec3('+COMBAT_FEEL.flashWhite.toFixed(2)+'), uConfirmedHit);');
  };
  m.customProgramCacheKey=()=>key+'|limitless-confirmed-hit-40';m.needsUpdate=true;combatFeel.materials.set(m,s);s.materials.push(m);return m;
 };
 f.body.traverse(o=>{if(o.isMesh)o.material=Array.isArray(o.material)?o.material.map(own):own(o.material);});
 return s;
}
function contactStyle(amount,kind,knock,attacker){
 if(kind==='light'&&attacker.combo===3)return 'finish';
 if(amount>=80||knock.lengthSq()>256)return 'heavy';
 if(amount<5&&kind!=='light')return 'chip';return 'hit';
}
function contactSound(style,kind,attacker){return style==='finish'?'hitFinish':style==='heavy'?'hitHeavy':kind==='light'&&attacker.combo>=2?'hitKick':'hit';}
function confirmedContact(target,attacker,amount,style='hit',direction=null){
 if(!(amount>0)||!target?.root||!attacker?.pos)return;
 const c=COMBAT_FEEL,s=prepareCombatFeelRig(target),d=combatFeel.direction;
 if(direction&&direction.lengthSq()>.001)d.copy(direction);else d.copy(target.pos).sub(attacker.pos);
 if(d.lengthSq()<.001)d.set(-Math.sin(target.root.rotation.y),0,-Math.cos(target.root.rotation.y));d.normalize();
 s.dir.copy(d);s.age=0;s.power=style==='finish'?1:style==='heavy'?.9:style==='chip'?.22:.55;
 if(combatFeel.clock>=s.nextFlash){s.flashAge=0;s.flashLife=style==='heavy'||style==='finish'?c.heavyFlashLife:c.flashLife;s.flashPower=style==='chip'?.3:1;s.nextFlash=combatFeel.clock+c.flashGap;}
 s.flash.value=options.hitFlashes?s.flashPower:0;
 combatFeel.point.copy(target.pos);combatFeel.point.y+=1.35;combatFeel.point.addScaledVector(d,-.42);
 spawnContactBurst(combatFeel.point,d,style,1,attacker.character);cameraImpulse(combatFeel.point,d,style==='finish'?.85:style==='heavy'?.7:style==='chip'?.08:.35);battleVisual.activity=4;
 if(target===player&&options.damageDirection)markIncomingHit(attacker,style);
 if(attacker===player&&options.hitMarkers&&style==='finish')$('hitConfirm').dataset.kind='finish';
}
function blockedContact(target,attacker){
 const d=combatFeel.direction.copy(target.pos).sub(attacker.pos);if(d.lengthSq()<.001)d.set(0,0,1);d.normalize();
 combatFeel.point.copy(target.pos);combatFeel.point.y+=1.45;combatFeel.point.addScaledVector(d,-.65);spawnContactBurst(combatFeel.point,d,'guard');
}
function evadedContact(target,attacker){
 const d=combatFeel.direction.copy(target.pos).sub(attacker.pos);if(d.lengthSq()<.001)d.set(0,0,1);d.normalize();
 combatFeel.point.copy(target.pos);combatFeel.point.y+=1;spawnContactBurst(combatFeel.point,d,'evade');
}
function sampleHitRecoil(f){
 const s=combatFeel.rigs.get(f.root);if(!s||s.age>=COMBAT_FEEL.recoilLife||f.ragdollT>0||f.hp<=0||soulExecutionPending(f))return null;
 const c=COMBAT_FEEL,t=s.age,w=(t<c.recoilPeak?narutoEase(t/c.recoilPeak):1-narutoEase((t-c.recoilPeak)/(c.recoilLife-c.recoilPeak)))*s.power;
 const angle=f.root.rotation.y,x=s.dir.x*Math.cos(angle)-s.dir.z*Math.sin(angle),z=s.dir.x*Math.sin(angle)+s.dir.z*Math.cos(angle),p=s.pose;
 p.lean=z*c.recoilLean*w;p.tilt=-x*c.recoilTilt*w;p.twist=x*.16*w;p.head=p.lean*.55;p.squash=1-c.recoilSquash*w;p.bob=-.035*w;return p;
}
function ensureContactPool(){
 if(combatFeel.pool)return combatFeel.pool;
 const c=COMBAT_FEEL,vertices=[];
 for(let i=0;i<c.streaks;i++){const a=i/c.streaks*Math.PI*2,inner=.12,outer=i%2?1:.76,width=.045;for(const [r,b]of [[inner,a-width],[outer,a],[inner,a+width]])vertices.push(Math.cos(b)*r,Math.sin(b)*r,0);}
 const starGeo=new THREE.BufferGeometry();starGeo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
 const ringGeo=new THREE.RingGeometry(.91,1,32),coreGeo=new THREE.PlaneGeometry(1,1);
 combatFeel.pool=Array.from({length:c.burstPool},()=>{
  const g=new THREE.Group();g.name='pooled-contact';g.visible=false;scene.add(g);
  const material=color=>new THREE.MeshBasicMaterial({color,transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,toneMapped:false});
  const accent=material(c.hitGold),white=material(c.hitWhite),coreMat=material(c.hitWhite);coreMat.map=glowMap;
  const ring=mesh(ringGeo,accent,g),star=mesh(starGeo,white,g),core=mesh(coreGeo,coreMat,g);star.position.z=.015;core.position.z=.025;
  const characterShapes=makeCharacterAccent(g,accent);return {characterShapes,characterEntries:Object.entries(characterShapes),g,ring,star,core,accent,white,coreMat,age:99,life:c.burstLife,size:1,kind:'hit',dir:V(),origin:V()};
 });return combatFeel.pool;
}
function spawnContactBurst(pos,dir,kind,size=1,character=''){
 if(!options.impactEffects||player.pos.distanceToSquared(pos)>COMBAT_FEEL.burstRange**2)return;
 const c=COMBAT_FEEL,pool=ensureContactPool(),e=pool[combatFeel.cursor++%pool.length];
 e.age=0;e.kind=kind;e.life=kind==='heavy'||kind==='finish'?c.heavyBurstLife:c.burstLife;e.size=size*(kind==='finish'?1.3:kind==='heavy'?1.1:kind==='guard'?.68:kind==='chip'?.32:.72);
 e.origin.copy(pos);e.dir.copy(dir);e.g.position.copy(pos);e.g.quaternion.setFromUnitVectors(combatFeel.axis,dir);e.g.visible=true;
 e.accent.color.setHex(kind==='guard'?c.guardBlue:kind==='evade'?c.dodgeMint:kind==='land'?c.dust:c.hitGold);
 e.white.color.setHex(kind==='guard'?c.guardBlue:kind==='evade'?c.dodgeMint:c.hitWhite);
 // Strong contact frame followed by fast outward motion; never an opaque screen-sized flash.
 const identity=CHARACTER_EFFECTS[character];for(const [shape,line]of e.characterEntries)line.visible=!!identity&&identity.shape===shape;if(identity)e.accent.color.setHex(identity.color);animateContactBurst(e,0);
}
function animateContactBurst(e,dt){
 e.age+=dt;const t=clamp(e.age/e.life,0,1),ease=1-(1-t)**3,fade=(1-t)**2,guard=e.kind==='guard',land=e.kind==='land',evade=e.kind==='evade';
 e.g.visible=t<1&&options.impactEffects;e.ring.scale.setScalar(e.size*(.25+ease*(land?2:1.25)));e.accent.opacity=fade*(land?.24:guard?.8:.38);
 e.star.visible=!land;e.star.scale.set(e.size*(.42+ease*1.7),e.size*(.34+ease*1.5),1);e.star.rotation.z=guard?.4:evade?ease*.8:0;e.white.opacity=fade*(options.flash?.9:.5);
 e.core.visible=!land&&!evade;e.core.quaternion.copy(e.g.quaternion).invert().multiply(camera.quaternion);e.core.scale.setScalar(e.size*(1.0-ease*.7));e.coreMat.opacity=Math.max(0,1-t*4)*(options.flash?.8:.25);
 e.g.userData.characterLineMaterial.color.copy(e.accent.color);e.g.userData.characterLineMaterial.opacity=fade*.65;for(const [shape,line]of e.characterEntries){line.scale.setScalar(e.size*(.6+ease*1.65));line.rotation.z=shape==='spiral'?ease*1.2:shape==='soul'?-ease*.4:0;}
 e.g.position.copy(e.origin).addScaledVector(e.dir,ease*(land?.015:.12));
}
function landingContact(f,fallSpeed,dustScale=.6){
 narutoFX('dust',f.pos,dustScale,undefined,false);
 if(fallSpeed<COMBAT_FEEL.landingThreshold||f.hp<=0||phase!=='play')return;
 const power=clamp((fallSpeed-COMBAT_FEEL.landingThreshold)/(COMBAT_FEEL.landingMax-COMBAT_FEEL.landingThreshold),0,1);
 combatFeel.point.copy(f.pos);combatFeel.point.y+=.035;spawnContactBurst(combatFeel.point,combatFeel.up,'land',.7+power*.7);sfx('land',f.pos,.35+power*.45,false);
}
function markIncomingHit(attacker,style){
 let n=combatFeel.threats.find(t=>t.id===attacker.id&&t.age<COMBAT_FEEL.threatLife);if(!n)n=combatFeel.threats[combatFeel.threatCursor++%combatFeel.threats.length];
 if(!n)return;n.id=attacker.id;n.source.copy(attacker.pos);n.age=0;n.heavy=style==='heavy'||style==='finish';
}
function updateCombatFeel(dt){
 const frozen=phase==='pause',elapsed=frozen?0:dt;combatFeel.clock+=elapsed;
 for(const s of combatFeel.states){s.age+=elapsed;s.flashAge+=elapsed;const t=clamp((s.flashAge-COMBAT_FEEL.flashHold)/(s.flashLife-COMBAT_FEEL.flashHold),0,1);s.flash.value=options.hitFlashes?s.flashPower*(1-narutoEase(t)):0;}
 if(combatFeel.pool)for(const e of combatFeel.pool)if(e.age<e.life)animateContactBurst(e,elapsed);
 camera.getWorldDirection(combatFeel.cameraDirection);const facing=Math.atan2(combatFeel.cameraDirection.x,combatFeel.cameraDirection.z),show=phase==='play'&&!menuOpen&&player.hp>0&&options.damageDirection;
 for(const n of combatFeel.threats){n.age+=elapsed;const left=COMBAT_FEEL.threatLife-n.age;n.el.style.opacity=show&&left>0?Math.min(1,left/.28):0;if(left<=0)continue;
  const dx=n.source.x-player.pos.x,dz=n.source.z-player.pos.z,angle=facing-Math.atan2(dx,dz);n.el.style.transform='rotate('+angle+'rad)';n.el.dataset.weight=n.heavy?'heavy':'normal';
 }
}
function resetCombatFeel(){
 combatFeel.clock=0;combatFeel.cursor=combatFeel.threatCursor=0;
 for(const s of combatFeel.states){s.flash.value=0;s.flashAge=s.age=99;s.flashPower=s.power=s.nextFlash=0;}
 if(combatFeel.pool)for(const e of combatFeel.pool){e.g.visible=false;e.age=99;}
 for(const n of combatFeel.threats){n.age=99;n.id='';n.el.style.opacity=0;}
}
