const MOVE_HITS={web:[.52],spiderCombo:[.38,.48,.60],cocoon:[.65],bladeRush:[.40,.49],spiral:[.34,.44,.54,.64],spear:[.68],stretch:[.49],gatling:[.33,.40,.47,.54,.61],stomp:[.61],dragon:[.36,.47,.58],beam:[.47,.57,.67],spirit:[.68],crescent:[.53],flashCombo:[.34,.47,.60],bankai:[.60],chain:[.46],tojiStab:[.43],staff:[.35,.47,.60]};
const MOVE_POWER={spirit:2.5,stomp:1.8,beam:1.3,spear:1.9,bankai:1.8,staff:1.2};
function animateMove(a,dt){
 const q=clamp(a.t/a.duration),p=targetPose,wind=span(q,0,.23),settle=1-span(q,.76,1),go=span(q,.23,.40),drive=wind*settle,hit=go*settle;
 p.yaw=Math.PI/2*drive;p.y-=Math.sin(wind*Math.PI)*.10*settle;p.squash=1-.06*Math.sin(wind*Math.PI)*settle;p.head=-.05*drive;p.lax=-.55*drive;p.rax=-.65*drive;p.lex=-.9*drive;p.rex=-.9*drive;p.ll=-.25*drive;p.rl=.2*drive;p.lk=.35*drive;p.rk=.14*drive;
 switch(a.key){
 case 'web':p.rax=(-.65-go*.95)*drive;p.rex=-.6*(1-go)*drive;p.lax=.25*drive;p.roll=-.12*hit;p.x=-.3*hit;break;
 case 'spiderCombo':{const t=span(q,.24,.68);p.x=Math.sin(Math.PI*t)*3.3;p.y=Math.sin(Math.PI*t)*.95;p.lean=-Math.sin(Math.PI*t)*.45;p.rax=-1.65*hit;p.lax=-.4*drive;p.rex=-.2;p.ll=-1.1*Math.sin(t*TAU);p.rl=.9*Math.sin(t*TAU);p.rk=.8*hit;if(q>.52){p.y+=Math.sin(span(q,.52,.88)*Math.PI)*.7;p.lean+=Math.sin(span(q,.52,.88)*Math.PI)*2.4;}break;}
 case 'cocoon':p.rax=p.lax=-1.5*drive;p.raz=-.20*drive;p.laz=.20*drive;p.rex=p.lex=-.2*drive;p.y+=Math.sin(q*Math.PI)*.18;p.roll=Math.sin(q*TAU*2)*.07*hit;break;
 case 'bladeRush':p.x=Math.sin(span(q,.21,.8)*Math.PI)*3.5;p.y=.12*Math.sin(q*Math.PI);p.lean=.38*hit;p.lax=(-2.2+go*2.4)*drive;p.rax=(-1.5+go*2.6)*drive;p.laz=-.5*hit;p.raz=.5*hit;p.lex=p.rex=-.3*drive;p.ll=-.8*hit;p.rl=.75*hit;p.rk=.55*hit;break;
 case 'spiral':{const t=span(q,.24,.73);p.x=Math.sin(t*Math.PI)*3.3;p.y=Math.sin(t*Math.PI)*1.5;p.z=Math.sin(t*TAU)*.9;p.yaw+=t*TAU*2;p.lean=.7*Math.sin(t*Math.PI);p.laz=-1.2*hit;p.raz=1.2*hit;p.lax=p.rax=-.25*hit;p.lex=p.rex=-.1;p.ll=-.8*hit;p.rl=.4*hit;p.lk=.9*hit;break;}
 case 'spear':p.rax=(-2.35+go*.8)*drive;p.rex=(-1.0+go*.8)*drive;p.lax=-.5*drive;p.twist=-.24*(1-go)*drive;p.roll=-.13*hit;break;
 case 'stretch':{const punch=span(q,.30,.48)*(1-span(q,.57,.78));p.rax=(-.3-1.25*punch)*drive;p.rex=-1.3*drive*(1-punch);p.stretch=1+punch*7;p.x=-.15*punch;p.roll=-.17*punch;p.twist=.4*(1-punch)*drive;p.lax=.4*drive;p.squash=1-.08*(1-go)*drive;break;}
 case 'gatling':{const barrage=q>.27&&q<.68,beat=barrage?Math.sin((q-.27)*Math.PI*38):0;p.rax=(-1.5+beat*.25)*drive;p.lax=(-1.5-beat*.25)*drive;p.rex=(-.3-.35*(1-beat))*drive;p.lex=(-.3-.35*(1+beat))*drive;p.stretch=1+(barrage?2+beat*1.3:0);p.x=.4*hit;p.roll=beat*.055*hit;p.twist=beat*.15*hit;break;}
 case 'stomp':{const lift=span(q,.17,.40),slam=span(q,.46,.62);p.y=lift*(1-slam)*2.3;p.x=span(q,.28,.5)*settle*2.7;p.rl=-2.25*lift*(1-slam)+.2*slam;p.ll=-.4*lift;p.rk=.1;p.lk=1.1*lift*(1-slam);p.foot=1+lift*settle*3.2;p.lax=-2.1*lift;p.rax=-1.8*lift;p.lean=.45*slam*settle;p.squash=1-.18*Math.sin(slam*Math.PI);break;}
 case 'dragon':{const rush=span(q,.20,.35);p.x=rush*settle*3.0;p.y=Math.sin(q*Math.PI)*.3;p.rax=(-1.5+Math.sin(q*40)*.55)*hit;p.lax=(-1.5-Math.sin(q*40)*.55)*hit;p.lex=p.rex=-.25*drive;p.twist=Math.sin(q*40)*.15*hit;p.rl=-Math.sin(span(q,.51,.63)*Math.PI)*1.5;p.rk=.15;p.lean=.2*hit;break;}
 case 'beam':{const release=span(q,.34,.45);p.lax=p.rax=(-.7-release*.8)*drive;p.lex=p.rex=(-1.5+release*1.4)*drive;p.laz=.42*(1-release)*drive;p.raz=-.42*(1-release)*drive;p.twist=-.55*(1-release)*drive;p.roll=-.08*release*settle;p.x=-.22*release*settle;p.ll=-.35*drive;p.rl=.25*drive;break;}
 case 'spirit':{const toss=span(q,.48,.64);p.lax=p.rax=(-2.95+toss*1.25)*drive;p.lex=p.rex=-.13*drive;p.laz=-.13*drive;p.raz=.13*drive;p.y=.38*drive;p.ll=-.15*drive;p.rl=.15*drive;p.head=-.15*(1-toss)*drive;p.roll=-.14*toss*settle;break;}
 case 'crescent':{const cut=span(q,.29,.46);p.rax=(-2.6+cut*3.0)*drive;p.rex=-.25*drive;p.lax=-.6*drive;p.twist=(-.65+cut*1.2)*drive;p.x=.3*hit;p.lean=.13*hit;break;}
 case 'flashCombo':{const t=span(q,.23,.69);p.x=Math.sin(t*Math.PI)*3.7;p.z=Math.sin(t*TAU*1.5)*.8;p.y=Math.sin(t*Math.PI)*.55;p.rax=(-1.4+Math.sin(t*TAU*3)*1.3)*drive;p.rex=-.15*drive;p.lax=.3*hit;p.twist=Math.sin(t*TAU*3)*.5*drive;p.lean=.2*hit;break;}
 case 'bankai':p.rax=-1.4*drive;p.rex=-.15*drive;p.lax=-.15*drive;p.y+=span(q,.15,.45)*settle*.35;p.laz=-.3*drive;p.raz=.2*drive;p.head=.12*drive;p.roll=-.07*hit;break;
 case 'chain':{const cast=span(q,.26,.44);p.rax=(-.4-cast*1.2)*drive;p.rex=-.5*(1-cast)*drive;p.lax=.3*drive;p.twist=.5*(1-cast)*drive;p.x=-.15*hit;break;}
 case 'tojiStab':p.x=Math.sin(span(q,.24,.78)*Math.PI)*3.55;p.rax=-1.58*drive;p.rex=-1.0*(1-go)*drive;p.lax=.65*hit;p.lean=.35*hit;p.ll=-.65*hit;p.rl=.55*hit;break;
 case 'staff':{const t=span(q,.23,.72);p.x=span(q,.23,.4)*settle*2.6;p.yaw+=t*TAU;p.lax=(-2.3+Math.sin(t*TAU*2)*.65)*drive;p.lex=-.2*drive;p.rax=-.5*drive;p.twist=Math.sin(t*TAU*2)*.25*drive;p.ll=-.3*drive;p.rl=.3*drive;break;}
 case 'swing':{const t=span(q,.12,.88);p.x=Math.sin(t*Math.PI)*3.5;p.y=Math.sin(t*Math.PI)*2.8;p.z=Math.sin(t*TAU)*1.0;p.rax=-2.9*drive;p.rex=-.1*drive;p.lax=.5*drive;p.lean=Math.sin(t*TAU)*.55;p.ll=-.6*drive;p.rl=.9*drive;p.lk=.8*drive;p.rk=.6*drive;break;}
 case 'odm':{const t=span(q,.17,.88);p.x=Math.sin(t*Math.PI)*3.6;p.y=Math.sin(t*Math.PI)*2.45;p.z=Math.sin(t*TAU)*1.5;p.lean=.65*drive;p.lax=-1.0*drive;p.rax=-1.0*drive;p.lex=p.rex=-.4*drive;p.laz=-.6*drive;p.raz=.6*drive;p.ll=-1*drive;p.rl=.5*drive;p.lk=.9*drive;break;}
 case 'slingshot':{const launch=span(q,.32,.49),travel=span(q,.36,.88);p.x=-.65*wind*(1-launch)+Math.sin(travel*Math.PI)*4;p.y=Math.sin(travel*Math.PI)*1.8;p.squash=1-.23*wind*(1-launch)+.12*Math.sin(travel*Math.PI);p.rax=(-1.55+launch*2.0)*drive;p.lax=.5*launch*drive;p.stretch=1+4*wind*(1-launch);p.lean=.5*launch*settle;p.ll=-1*launch*settle;p.rl=.6*launch*settle;break;}
 case 'flight':{const t=span(q,.19,.87);p.x=Math.sin(t*Math.PI)*3.7;p.y=Math.sin(t*Math.PI)*2.9;p.z=-Math.sin(t*Math.PI)*.6;p.lean=.45*drive;p.rax=-2.1*drive;p.rex=-.2*drive;p.lax=.6*drive;p.ll=-.3*drive;p.rl=.45*drive;p.lk=.45*drive;break;}
 case 'shunpo':{const t=span(q,.24,.78);p.x=Math.sin(t*Math.PI)*4.0;p.y=Math.sin(t*Math.PI)*.8;p.z=-Math.sin(t*TAU)*.45;p.lean=.40*drive;p.rax=-1.1*drive;p.rex=-.3;p.lax=.4*drive;p.ll=-.8*drive;p.rl=.6*drive;break;}
 case 'wall':{const approach=span(q,.15,.38),rebound=span(q,.40,.75),land=1-span(q,.78,1);p.x=(-3.3*approach+6.6*rebound)*land;p.z=-2.15*approach*(1-rebound);p.y=Math.sin(span(q,.15,.85)*Math.PI)*2.2;p.yaw=(-Math.PI/2+Math.PI*rebound)*drive;p.ll=-1.0*drive;p.rl=.7*drive;p.lk=1.1*drive;p.rk=.3*drive;p.lax=-1*drive;p.rax=-1.4*drive;p.lean=.3*rebound*settle;break;}
 }
 for(const at of MOVE_HITS[a.key]||[])if(crossing(a,at*a.duration))impact(MOVE_POWER[a.key]||1);
 if(a.index===3&&crossing(a,.85*a.duration)){ring(rig.root.position.x,.06,rig.root.position.z,1.7,0xddd7be);emit(rig.root.position.x,.08,rig.root.position.z,20,2,0xb3b99c);}
}
function moveEffects(a,dt){
 const q=clamp(a.t/a.duration),c=CANDIDATES[selected],on=q>.22&&q<.76,px=rig.root.position.x,py=rig.root.position.y,pz=rig.root.position.z;
 rig.arms[1].hand.getWorldPosition(tmpA);rig.arms[0].hand.getWorldPosition(tmpB);
 switch(a.key){
 case 'web':if(q>.20&&q<.72){const reach=span(q,.20,.39);cable(0,tmpA.x,tmpA.y,tmpA.z,tmpA.x+(3-tmpA.x)*reach,1.5,tmpA.z*(1-reach),.10);for(let i=1;i<4;i++)cable(i,3,1.5,0,3+(i-2)*.35,1.5+Math.sin(i*2)*.5,.25,.06);}break;
 case 'cocoon':if(on){const t=span(q,.25,.62);for(let i=0;i<2;i++)cable(i,i?tmpA.x:tmpB.x,i?tmpA.y:tmpB.y,i?tmpA.z:tmpB.z,3,1.5,(i-.5)*.3,.04);cocoon.visible=true;cocoon.position.set(3,1.3,0);cocoon.scale.set(.65*t,1.38*t,.65*t);cocoon.rotation.y=a.t*2;cocoon.material.opacity=.7*(1-span(q,.68,.85));}break;
 case 'swing':if(q>.16&&q<.81)cable(0,tmpA.x,tmpA.y,tmpA.z,0,6,-1,.05);break;
 case 'odm':if(q>.18&&q<.78){cable(0,px-.35,py+1.15,pz,-5.6,3.7,-2.2,.05);cable(1,px+.35,py+1.15,pz,5.6,3.7,-2.2,.05);}break;
 case 'bladeRush':case 'spiral':case 'flashCombo':case 'staff':case 'dragon':case 'spiderCombo':if(on){const cycles=a.key==='spiral'?5:3;for(let i=0;i<3;i++){const beat=(q*cycles*2+i*.23)%1;slash(i,px+.65+i*.25,py+1.4+Math.sin(i*2)*.4,pz, .7+beat*.6,Math.sin(a.t*10+i)*2,c.hex);slashes[i].material.opacity=(1-beat)*.65;}}break;
 case 'spear':if(q>.23&&q<.68){const travel=span(q,.33,.63),x=tmpA.x+(3-tmpA.x)*travel,y=tmpA.y+(1.4-tmpA.y)*travel;showOrb(0,x,y,0,.12,0xfed890);cable(0,x-.7,y,0,x+.2,y,0,0);emit(x-.25,y,0,2,1,0xd1c8ad);}if(q>.68&&q<.81)showOrb(0,3,1.4,0,span(q,.68,.73)*(1-span(q,.73,.81))*1.5,0xffb76c);break;
 case 'stretch':if(q>.37&&q<.6){slash(0,3,1.4,0,.55+span(q,.37,.49)*.7,Math.PI*.2,0xffe1b2);slashes[0].material.opacity=.4;}
 break;
 case 'gatling':if(q>.27&&q<.68){for(let i=0;i<fists.length;i++){const u=(a.t*3+i*.127)%1,f=fists[i];f.visible=true;f.position.set(px+.7+u*3.6,py+1.45+Math.sin(i*2.4)*.45,pz+Math.cos(i*2.4)*.35);f.scale.set(.38,.26,.25);f.material.opacity=Math.sin(u*Math.PI)*.75;cable(i,px+.5,py+1.6,pz,f.position.x,f.position.y,f.position.z,0);cables[i].line.material.opacity=.15;}}break;
 case 'stomp':if(q>.61&&q<.8){slash(0,3,.15,0,1+span(q,.61,.8)*1.5,0,0xe9d6b4);slashes[0].rotation.x=Math.PI/2;slashes[0].material.opacity=(1-span(q,.61,.8))*.7;}break;
 case 'beam':{const charge=span(q,.04,.35),firing=q>.39&&q<.73;const hx=(tmpA.x+tmpB.x)/2,hy=(tmpA.y+tmpB.y)/2,hz=(tmpA.z+tmpB.z)/2;if(q<.74)showOrb(0,hx+.12,hy,hz,.07+charge*.26,0x48baff);if(firing){tmpA.set(hx,hy,hz);tmpB.set(3,1.45,0);showBeam(tmpA,tmpB,.65+Math.sin(time*30)*.05,0x3faaff);showOrb(1,3,1.45,0,.55+Math.sin(time*34)*.05,0x75ceff);}break;}
 case 'spirit':if(q<.70){const build=span(q,.08,.48),throwing=span(q,.48,.68),x=px+(3-px)*throwing,y=py+3.5+(1.4-py-3.5)*throwing;showOrb(0,x,y,0,Math.max(.01,build*1.1),0x65cfff);for(let i=0;i<3;i++){slash(i,x,y,0,.5+build*1.2,a.t*(i%2?1:-1)+i,0xa1e8ff);slashes[i].rotation.y=i*Math.PI/3;slashes[i].material.opacity=.5;}}else if(q<.84)showOrb(1,3,1.4,0,(1-span(q,.70,.84))*2,0x9be5ff);break;
 case 'crescent':if(q>.33&&q<.70){const t=span(q,.33,.62),x=px+1+(3-px-1)*t;slash(0,x,1.6,0,1.1+q*.7,-.5,0xcba2ff);slash(1,x-.07,1.6,-.02,1.03+q*.7,-.5,0x443157);slashes[1].material.opacity=.9;}break;
 case 'bankai':if(q>.17&&q<.81){for(let i=0;i<5;i++){const z=i*.35-1;slash(i,px,py+1.4,z,1.1+Math.sin(time*4+i)*.2,time*2+i,0xc7a0ff);slashes[i].rotation.y=i*.5;slashes[i].material.opacity=.30;}showOrb(0,px,py+1.3,0,.43,0xa58be8);}break;
 case 'chain':if(q>.26&&q<.72){const t=span(q,.26,.46)*(1-span(q,.51,.72)),x=tmpA.x+(3-tmpA.x)*t;cable(0,tmpA.x,tmpA.y,tmpA.z,x,1.5,0,.18);for(let i=0;i<7;i++){const u=i/6;slash(i,tmpA.x+(x-tmpA.x)*u,1.5-.10*Math.sin(u*Math.PI),0,.05,.8,0xced8b8);}}
 break;
 case 'tojiStab':if(q>.33&&q<.57){slash(0,px+.8,py+1.5,0,.85,-.7,0xd9e8bc);slashes[0].material.opacity=.45;}break;
 case 'slingshot':if(q>.12&&q<.42)cable(0,tmpA.x,tmpA.y,tmpA.z,4,1.5,0,.02);break;
 case 'flight':if(on){showOrb(0,px,py+1.35,pz,.42,0x76cfff);for(let i=0;i<2;i++){slash(i,px,py+1.3,pz,1.1,time*3+i*Math.PI,0x8dddff);slashes[i].rotation.y=Math.PI/2;slashes[i].material.opacity=.35;}}break;
 case 'wall':if(q>.35&&q<.46){slash(0,-5.1,2,-2.0,.75,0,0xdcebc2);slashes[0].rotation.y=Math.PI/2;}break;
 }
 if(q>.18&&q<.78){fxAccumulator+=dt;while(fxAccumulator>1/CONFIG.particleRate){fxAccumulator-=1/CONFIG.particleRate;const mobility=a.index===3,energy=['beam','spirit','bankai'].includes(a.key);if(energy)emit(orbs[0].g.position.x,orbs[0].g.position.y,orbs[0].g.position.z,1,1.5,a.key==='bankai'?0xcaa4ff:0x80d7ff);else if(mobility)emit(px,py+.8,pz,1,1.6,c.hex);}
  if(a.index===3||['spiderCombo','bladeRush','spiral','flashCombo','dragon'].includes(a.key)){ghostClock+=dt;if(ghostClock>CONFIG.trailInterval){ghostClock=0;ghost();}}
 }
}
