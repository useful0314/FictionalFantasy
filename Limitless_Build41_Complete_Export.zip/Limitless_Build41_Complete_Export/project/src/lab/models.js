// Isolated concept rigs. Joint spacing follows the live blocky roster; no live model is modified.
const LAB_MODEL={bevel:.035,blend:.10,skin:0xe6b99a,ink:0x141a23,white:0xeee9dc};
const geometry={box:null,sphere:new THREE.SphereGeometry(1,16,12),cylinder:new THREE.CylinderGeometry(.5,.5,1,10),cone:new THREE.ConeGeometry(.5,1,5)};
const materialCache=new Map();
function material(color,metal=false){const key=color+'-'+metal;if(!materialCache.has(key))materialCache.set(key,new THREE.MeshStandardMaterial({color,roughness:metal?.35:.8,metalness:metal?.65:.05}));return materialCache.get(key);}
function blockGeometry(){if(geometry.box)return geometry.box;const a=.5-LAB_MODEL.bevel,s=new THREE.Shape();s.moveTo(-a,-a);s.lineTo(a,-a);s.lineTo(a,a);s.lineTo(-a,a);s.closePath();const g=new THREE.ExtrudeGeometry(s,{depth:a*2,steps:1,bevelEnabled:true,bevelThickness:LAB_MODEL.bevel,bevelSize:LAB_MODEL.bevel,bevelSegments:1,curveSegments:1});g.translate(0,0,-a);return geometry.box=g;}
function part(parent,x,y,z,w,h,d,color,geo=blockGeometry()){const m=new THREE.Mesh(geo,material(color));m.position.set(x,y,z);m.scale.set(w,h,d);m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
function joint(parent,x,y,z){const g=new THREE.Group();g.position.set(x,y,z);parent.add(g);return g;}
function makeFighter(id){
 const root=new THREE.Group(),body=joint(root,0,0,0),spider=id==='spiderman',levi=id==='levi',luffy=id==='luffy',goku=id==='goku',ichigo=id==='ichigo',toji=id==='toji';
 const skin=spider?0xc62d3a:LAB_MODEL.skin,cloth=spider?0xc62d3a:levi?0x8b7663:luffy?0xbd352c:goku?0xec7826:ichigo?0x171d27:0x252e2c,pants=spider?0x204b88:levi?0xd5cdb4:luffy?0x416aa0:goku?0xe97a25:ichigo?0x171d27:0xbac0bb,hairColor=goku?0x141920:ichigo?0xe58534:luffy?0x1d2025:0x20272b;
 const torso=joint(body,0,1.53,0);part(torso,0,0,0,.78,.86,.46,cloth);part(body,0,1.04,0,.66,.24,.43,pants);part(body,0,2.03,0,.22,.16,.22,skin);
 const head=joint(body,0,2.29,0);part(head,0,0,0,.54,.58,.46,skin);
 if(!spider){part(head,0,-.025,.25,.052,.07,.04,skin);part(head,0,-.15,.242,.12,.014,.013,LAB_MODEL.ink);for(const side of [-1,1]){part(head,side*.12,.055,.242,.14,.038,.015,LAB_MODEL.white);part(head,side*.113,.052,.255,.045,.038,.013,0x293637);part(head,side*.12,.11,.249,.15,.023,.015,LAB_MODEL.ink).rotation.z=side*.13;part(head,side*.28,-.02,0,.05,.14,.10,skin);}}
 const hair=joint(head,0,.25,-.02),secondary=[];
 if(!spider){part(hair,0,0,-.02,.58,.16,.47,hairColor);part(hair,0,-.12,-.22,.56,.26,.10,hairColor);for(let i=0;i<(goku?9:8);i++){const a=i*2.39996,r=.13+(i%3)*.045,m=part(hair,Math.cos(a)*r,.10+Math.sin(i*3)*.02,Math.sin(a)*r,.16,goku?.48:ichigo?.29:.16,.17,hairColor,geometry.cone);m.rotation.z=Math.sin(a)*(goku?.85:.4);m.rotation.x=Math.cos(a)*.3;}
  for(let i=0;i<4;i++){const m=part(hair,(i-1.5)*.12,-.12,.20,.13,levi||toji?.26:.14,.10,hairColor);m.rotation.z=(i-1.5)*.15;}
 }
 const arms=[],legs=[],weapons=[],capeParts=[];
 for(const side of [-1,1]){
  const shoulder=joint(body,side*.5,1.89,0),upper=part(shoulder,0,-.265,0,.29,.53,.30,luffy||toji?skin:cloth),elbow=joint(shoulder,0,-.53,0),forearm=part(elbow,0,-.17,0,.255,.35,.26,luffy||toji?skin:levi?0xeeeece:cloth),hand=joint(elbow,0,-.405,.015);
  part(hand,0,0,0,.22,.18,.17,skin);for(let n=0;n<3;n++)part(hand,(n-1)*.065,-.095,.01,.055,.055,.12,skin);
  if(goku){part(shoulder,0,-.10,0,.32,.19,.32,0x244b7f);part(elbow,0,-.30,0,.27,.14,.28,0x244b7f);}if(spider)part(shoulder,side*.148,-.28,0,.016,.35,.30,0x1e4483);
  const hip=joint(body,side*.20,1.04,0),thigh=part(hip,0,-.24,0,.32,.49,.34,pants),knee=joint(hip,0,-.49,0);part(knee,0,-.17,0,.29,.35,.31,luffy?skin:pants);const foot=joint(knee,0,-.42,.04);part(foot,0,0,.055,.30,.16,.43,luffy?0x705236:spider?0xc62d3a:goku?0x244b7f:0x20272b);part(foot,0,-.08,.06,.31,.035,.44,LAB_MODEL.ink);
  if(luffy){part(hip,0,-.44,0,.335,.10,.35,0xd9d1b6);part(foot,0,.08,.08,.31,.06,.12,0xc39b54);}if(levi){part(hip,0,-.20,.18,.31,.07,.024,0x554c41);part(knee,0,-.19,0,.305,.33,.32,0x564939);part(hip,side*.18,-.18,0,.11,.26,.12,0x5a534a);}
  arms.push({shoulder,elbow,hand,upper,forearm});legs.push({hip,knee,foot,thigh});
 }
 if(spider){
  for(const side of [-1,1]){const eye=part(head,side*.13,.04,.249,.195,.15,.024,0x141c29);eye.rotation.z=side*.22;const white=part(head,side*.13,.05,.267,.139,.10,.012,0xf2ede3);white.rotation.z=side*.22;}
  for(const y of [-.20,.19])part(head,0,y,.239,.48,.011,.009,0x652633);part(head,0,0,.241,.012,.54,.009,0x652633);
  for(const side of [-1,1]){part(head,side*.23,0,.241,.012,.47,.009,0x652633).rotation.z=-side*.18;for(let j=0;j<4;j++){part(torso,side*(.09+j*.03),.13-j*.08,.248,.25,.022,.018,0x142033).rotation.z=side*(.5+j*.25);}}
  part(torso,0,-.02,.249,.10,.28,.03,0x142033);
 }
 if(luffy){
  part(torso,0,-.03,.244,.25,.81,.027,skin);for(let i=0;i<3;i++)part(torso,.20,.23-i*.22,.25,.037,.037,.02,0xe6ba53);
  const hat=joint(head,0,.35,0);part(hat,0,0,0,1.02,.07,1.02,0xd1af6a,geometry.cylinder);part(hat,0,.13,0,.64,.27,.64,0xd8b977,geometry.cylinder);part(hat,0,.055,0,.656,.07,.656,0xa44536,geometry.cylinder);secondary.push(hat);
  part(head,.16,-.10,.245,.12,.012,.014,0x6f4035);for(const side of [-1,1])part(torso,side*.18,-.11,.265,.23,.022,.015,0xa86c50).rotation.z=side*.6;
  for(const side of [-1,1]){const hem=joint(torso,side*.26,-.37,0);part(hem,0,-.08,0,.25,.20,.48,cloth);secondary.push(hem);}
 }
 if(goku){
  for(const side of [-1,1])part(torso,side*.17,.27,.25,.13,.44,.025,0x244b7f).rotation.z=side*-.55;
  part(body,0,1.12,0,.73,.13,.48,0x244b7f);const tail=joint(body,.17,1.09,.26);part(tail,0,-.20,0,.10,.39,.06,0x244b7f);secondary.push(tail);
  part(torso,-.23,.05,.254,.19,.19,.025,0xe7d9ba,geometry.cylinder).rotation.x=Math.PI/2;part(torso,-.23,.05,.272,.10,.12,.015,0x232a32);
 }
 if(levi){
  part(torso,0,.31,.25,.24,.23,.03,0xdad5bf);for(const side of [-1,1]){part(torso,side*.24,-.01,.248,.07,.76,.022,0x554d41);part(torso,side*.18,.18,.263,.20,.20,.018,0x6d8273);part(body,side*.48,1.02,-.08,.27,.35,.50,0x6a797b);}
  part(torso,0,-.28,.27,.79,.08,.035,0x514940);
  const cape=joint(torso,0,.38,-.20);for(let i=0;i<3;i++){const panel=joint(cape,(i-1)*.31,0,0);part(panel,0,-.47,-.07,.34,1.05,.055,0x385448);capeParts.push(panel);}secondary.push(cape);
  for(let i=0;i<2;i++){const blade=joint(arms[i].hand,0,-.06,.04);part(blade,0,-.17,0,.095,.32,.10,0x363d42);part(blade,0,-.36,0,.24,.06,.12,0x79888d);part(blade,0,-.94,0,.13,1.12,.035,0xb9ccd0);for(let j=0;j<5;j++)part(blade,0,-.48-j*.18,.025,.13,.009,.008,0x647b85);weapons.push(blade);}
 }
 if(ichigo){
  for(const side of [-1,1]){part(torso,side*.16,.25,.245,.08,.48,.025,0xe7e5d8).rotation.z=-side*.53;const hem=joint(body,side*.24,1.02,0);part(hem,0,-.33,0,.40,.70,.47,cloth);secondary.push(hem);}
  part(body,0,1.11,0,.77,.11,.51,0xe6e1cf);
  const blade=joint(arms[1].hand,0,-.02,.06);part(blade,0,-.20,0,.10,.39,.10,0xddd6c4);part(blade,0,-.43,0,.28,.055,.13,0x424a51);part(blade,0,-1.30,0,.35,1.72,.065,0x182631);part(blade,.16,-1.31,.005,.045,1.72,.075,0xc3d0d4);part(blade,.06,-2.21,0,.23,.22,.06,0xc3d0d4,geometry.cone).rotation.z=Math.PI;weapons.push(blade);
 }
 if(toji){
  part(head,.11,-.16,.25,.025,.13,.014,0x8b5549).rotation.z=-.36;part(body,0,1.12,0,.73,.10,.47,0x364044);
  const worm=joint(torso,-.38,.28,-.05);for(let i=0;i<10;i++){const a=i/9*Math.PI*1.7;part(worm,Math.cos(a)*.25,Math.sin(a)*.27,Math.sin(i*.6)*.10,.24,.23,.24,0x867294,geometry.sphere);}part(worm,-.08,-.33,.14,.27,.30,.27,0x9b83a0,geometry.sphere);for(const side of [-1,1])part(worm,-.08+side*.065,-.31,.275,.035,.035,.02,0x262536);
  const spear=joint(arms[1].hand,0,-.06,.02);part(spear,0,-.19,0,.09,.35,.10,0x48433d);part(spear,0,-.39,0,.22,.06,.10,0x85969a);part(spear,0,-.69,0,.09,.55,.05,0xc4d0c9);part(spear,-.11,-.60,0,.15,.07,.05,0xc4d0c9);part(spear,-.16,-.69,0,.05,.23,.05,0xc4d0c9);weapons.push(spear);
  const staff=joint(arms[0].hand,0,-.04,0);for(let i=0;i<3;i++){part(staff,0,-.40-i*.85,0,.11,.72,.11,0xa23934);if(i<2)part(staff,0,-.83-i*.85,0,.035,.16,.035,0xa3a99d);}staff.visible=false;weapons.push(staff);
 }
 root.userData={id};return {root,body,torso,head,hair,arms,legs,weapons,secondary,capeParts,id};
}
function makeDummy(){const rig=makeFighter('dummy');rig.root.traverse(o=>{if(o.isMesh)o.material=material(0x67736f);});for(const a of rig.arms)a.shoulder.rotation.z=a===rig.arms[0]?-.28:.28;part(rig.torso,0,.04,.25,.27,.27,.035,0xd9d3b9,geometry.cylinder).rotation.x=Math.PI/2;return rig;}
