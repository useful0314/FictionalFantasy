// Naruto-only domain rules. Gojo/Sukuna durations, damage and point gains are unchanged.
const MINDSCAPE={
 stages:[{duration:4,clashBonus:0,glow:.18,rumble:.14,shake:.008},{duration:4,clashBonus:.45,glow:.55,rumble:.42,shake:.025},{duration:4,clashBonus:.9,glow:1,rumble:.8,shake:.06}],
 clashBase:.65,clones:{enabled:true,perClone:.10,max:.30},finisherDelay:.65,
 transition:.7,exit:.65,waterHeight:.27,gateZ:32,colors:{water:0x161a1d,iron:0x292b30,stone:0x242a2c,red:0xff2418,seal:0xedd9a9,fox:0x643018},dustInterval:.12
};
let mindscapePool=null,mindscapeEnd=null;
const mindscapeContextState={origin:null,axis:V(),age:0,forming:0,head:V()};
function mindscapeDuration(){return MINDSCAPE.stages.reduce((n,s)=>n+s.duration,0);}
function mindscapeStage(age){let end=0;for(let i=0;i<3;i++){end+=MINDSCAPE.stages[i].duration;if(age<end)return i;}return 2;}
function mindscapeFinisherAt(){return mindscapeDuration()-MINDSCAPE.finisherDelay;}
function mindscapeClashGain(f,gain){if(f.character!=='naruto'||!clash)return gain;const a=f.narutoAction,stage=MINDSCAPE.stages[mindscapeStage(clash.t)];let bonus=0;if(MINDSCAPE.clones.enabled&&a?.kind===1&&!a.cancelled)for(let i=0;i<3;i++)if(a.t<NARUTO.moves[1].hits[i])bonus+=MINDSCAPE.clones.perClone;return gain*(MINDSCAPE.clashBase+stage.clashBonus+Math.min(MINDSCAPE.clones.max,bonus));}
function updateMindscapeDomain(d,dt){
 const duration=mindscapeDuration();d.t=Math.min(duration,d.t+dt);updateMindscapeAssault(d);
 if((d.t>=duration-1e-8||d.owner.hp<=0)&&phase==='play'){endActiveDomain(d);toast('MINDSCAPE RELEASED · battlefield restored',2);}
}
function mindscapeClashEnding(old,winner){
 if(!old)return;const narutos=old.participants.filter(id=>actorById(id)?.character==='naruto');if(!narutos.length)return;
 const win=winner.character==='naruto';domain.mindscapeLosers=narutos.filter(id=>id!==winner.id);const pos=old.origin.clone().add(V(0,2,0));
 netFX('mindEnd',[win?1:0,pos.toArray()]);showMindscapeEnding(win,pos);if(win)sfx('mindscapeBreak',pos);else sfx('mindscapeCollapse',pos);
}
function showMindscapeEnding(win,pos){mindscapeEnd={win,t:0,pos:pos.clone()};if(win){narutoFX('windBurst',pos,18,undefined,false);narutoEmit(pos,MINDSCAPE.colors.seal,60,1,15,.22);shock(pos,MINDSCAPE.colors.red,48,.8);}else{narutoEmit(pos,MINDSCAPE.colors.red,45,.65,14,.18,false,true);narutoFX('smoke',pos,4,undefined,false);}}
function mindscapeCloak(f){return !!(domain?.owner===f&&f.character==='naruto'&&domain.t>=mindscapeFinisherAt()-.35&&domain.t<mindscapeFinisherAt()+1.2);}
function mindscapeContext(){
 const s=mindscapeContextState;
 if(domain?.owner.character==='naruto'||clash?.participants.some(id=>actorById(id)?.character==='naruto')){const e=domain||clash;s.origin=e.origin;s.axis.copy(clash&&domainVisual.userData.mixedMindscape?domainVisual.userData.mindscapeAxis:e.axis);s.age=e.t;s.forming=1;return s;}
 for(const f of bodies){const c=castFor(f);if(f.character==='naruto'&&c&&narutoHead(s.head,player).distanceTo(c.origin)<DOMAIN_ENCLOSURE.radius){s.origin=c.origin;narutoAim(s.axis,f);s.age=0;s.forming=narutoEase(c.t/DOMAIN_ENCLOSURE.startup);return s;}}return null;
}
