// Local presentation only. Shared cast/clash ages remain the source of truth.
const DOMAIN_CAMERA={orbitRadius:4.6,orbitHeight:.65,orbitTurns:1,blend:.10,clashIntro:2.35,clashRadius:4.3,clashFov:49};
const domainCinema={weight:0,castId:null,angle:0,position:V(),look:V(),offset:V(),center:V(),key:'',castPose:{t:.3},panels:[],rects:[],cameras:[]};
for(let i=0;i<6;i++){domainCinema.cameras.push(new THREE.PerspectiveCamera(DOMAIN_CAMERA.clashFov,1,.1,600));domainCinema.rects.push({x:0,y:0,w:1,h:1});}
function domainPresentationAge(age){return age+(mode==='online'&&net?.role==='guest'&&phase==='play'?Math.min(.1,Math.max(0,(performance.now()-replicaFresh)/1000)):0);}
function domainSplitVisible(){return !!(clash&&clash.participants.includes(player.id)&&player.hp>0&&domainPresentationAge(clash.t)<DOMAIN_CAMERA.clashIntro&&options.cinematics&&!options.freeOrbit&&!cursorFree&&!menuOpen&&(phase==='play'||phase==='pause'));}
function domainPresentationCast(f){const actual=castFor(f);if(actual)return actual;return clash&&domainPresentationAge(clash.t)<DOMAIN_CAMERA.clashIntro&&clash.participants.includes(f.id)&&!f.attack&&!chargeFor(f)&&f.stun<=0&&f.ragdollT<=0&&f.hp>0?domainCinema.castPose:null;}
function domainOrbitVisible(){return !!(castFor(player)&&player.hp>0&&options.cinematics&&!options.freeOrbit&&!cursorFree&&!menuOpen&&(phase==='play'||phase==='pause'));}
function domainPanelRect(i,n,out){if(n<=3&&innerWidth/innerHeight<.85){out.x=0;out.y=i/n;out.w=1;out.h=1/n;return out;}const cols=n<=3?n:Math.ceil(n/2),rows=n<=3?1:2,row=Math.floor(i/cols),inRow=Math.min(cols,n-row*cols);out.x=(i%cols)/inRow;out.y=row/rows;out.w=1/inRow;out.h=1/rows;return out;}
function resetDomainCinema(){domainCinema.weight=0;domainCinema.castId=null;domainCinema.key='';$('domainPanels').classList.add('hidden');$('domainPanels').replaceChildren();domainCinema.panels.length=0;}
function updateDomainCinema(dt){
 const v=domainCinema,cast=castFor(player),active=domainOrbitVisible(),split=domainSplitVisible();
 if(active){if(v.castId!==cast.id){v.castId=cast.id;v.angle=Math.atan2(camPos.x-player.pos.x,camPos.z-player.pos.z);}const q=clamp(domainPresentationAge(cast.t)/DOMAIN_ENCLOSURE.startup,0,1),a=v.angle+narutoEase(q)*Math.PI*2*DOMAIN_CAMERA.orbitTurns;v.look.copy(player.pos);v.look.y+=1.8;v.position.copy(v.look);v.position.x+=Math.sin(a)*DOMAIN_CAMERA.orbitRadius;v.position.z+=Math.cos(a)*DOMAIN_CAMERA.orbitRadius;v.position.y+=DOMAIN_CAMERA.orbitHeight+Math.sin(q*Math.PI)*.35;}
 v.weight=split?0:lerp(v.weight,active?1:0,1-Math.exp(-dt/DOMAIN_CAMERA.blend));if(v.weight>.001){camPos.lerp(v.position,v.weight);camLook.lerp(v.look,v.weight);}
 const host=$('domainPanels');host.classList.toggle('hidden',!split);if(!split)return;
 const key=clash.id+':'+clash.participants.join(',');if(key!==v.key){v.key=key;host.replaceChildren();v.panels.length=0;for(let i=0;i<clash.participants.length;i++){const f=actorById(clash.participants[i]),panel=document.createElement('div'),title=document.createElement('b'),name=document.createElement('span');panel.className='domainPanel';title.textContent=kit(f).domain;name.textContent=f.id.toUpperCase()+' · '+kit(f).short;panel.append(name,title);host.append(panel);v.panels.push(panel);}}
 const n=clash.participants.length;for(let i=0;i<n;i++){const r=domainPanelRect(i,n,v.rects[i]),p=v.panels[i];p.style.left=r.x*100+'%';p.style.top=r.y*100+'%';p.style.width=r.w*100+'%';p.style.height=r.h*100+'%';}
 host.style.opacity=String(narutoEase(domainPresentationAge(clash.t)/.12)*(1-narutoEase((domainPresentationAge(clash.t)-DOMAIN_CAMERA.clashIntro+.2)/.2)));
}
function renderDomainSplit(){
 if(!domainSplitVisible()||typeof renderer.setScissor!=='function')return false;
 const v=domainCinema,n=clash.participants.length,auto=renderer.shadowMap.autoUpdate,autoClear=renderer.autoClear;
 renderer.setRenderTarget(null);renderer.setScissorTest(true);renderer.autoClear=true;
 for(let i=0;i<n;i++){const f=actorById(clash.participants[i]),r=domainPanelRect(i,n,v.rects[i]),c=v.cameras[i],progress=narutoEase(domainPresentationAge(clash.t)/DOMAIN_CAMERA.clashIntro),angle=f.root.rotation.y+progress*Math.PI*2+i*.22,aspect=innerWidth*r.w/(innerHeight*r.h),radius=Math.max(DOMAIN_CAMERA.clashRadius,(f.character==='sukuna'?1.65:1.35)/(Math.tan(DOMAIN_CAMERA.clashFov*Math.PI/360)*aspect));
  v.look.copy(f.pos);v.look.y+=1.65;c.position.copy(v.look);c.position.x+=Math.sin(angle)*radius;c.position.z+=Math.cos(angle)*radius;c.position.y+=.4;
  if(enclosure()){v.center.copy(enclosure().origin).y+=1.45;v.offset.copy(c.position).sub(v.center);if(v.offset.length()>DOMAIN_ENCLOSURE.radius-.6)c.position.copy(v.center).addScaledVector(v.offset.normalize(),DOMAIN_ENCLOSURE.radius-.6);}
  c.aspect=aspect;c.updateProjectionMatrix();c.lookAt(v.look);if(domainVisual.userData.hole)domainVisual.userData.hole.quaternion.copy(c.quaternion);if(mindscapePool?.g.visible){mindscapePool.waterUniforms.uCamera.value.copy(c.position);mindscapePool.g.worldToLocal(mindscapePool.waterUniforms.uCamera.value);}
  const x=Math.round(r.x*innerWidth),y=Math.round((1-r.y-r.h)*innerHeight),w=Math.round(r.w*innerWidth),h=Math.round(r.h*innerHeight);renderer.setViewport(x,y,w,h);renderer.setScissor(x,y,w,h);renderer.render(scene,c);renderer.shadowMap.autoUpdate=false;
 }
 renderer.shadowMap.autoUpdate=auto;renderer.autoClear=autoClear;renderer.setScissorTest(false);renderer.setViewport(0,0,innerWidth,innerHeight);if(domainVisual.userData.hole)domainVisual.userData.hole.quaternion.copy(camera.quaternion);if(mindscapePool?.g.visible){mindscapePool.waterUniforms.uCamera.value.copy(camera.position);mindscapePool.g.worldToLocal(mindscapePool.waterUniforms.uCamera.value);}return true;
}
