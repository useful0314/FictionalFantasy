// Bounded reusable creature/track meshes. Smoke uses the existing pooled particle system.
const MAHITO_REALM={void:0x04030a,fog:0x181124,fogDensity:.005,entry:.65,exit:.35,
 outerRadius:44,middleRadius:35,innerRadius:27,outerScale:3.3,middleScale:4.5,innerScale:5.8,breath:1.4};
let mahitoVisuals=null;
function makeMorphedHuman(parent,variant=0){
 const g=new THREE.Group();parent.add(g);const skin=new THREE.MeshStandardMaterial({color:variant%2?0xadb6c3:0xc5ccc3,roughness:.9}),dark=new THREE.MeshBasicMaterial({color:0x29303c}),joints=[];
 mesh(mahitoBlock,skin,g,V(0,.75,0),V(.52,.68,.35));mesh(mahitoBlock,dark,g,V(0,.65,.18),V(.39,.018,.012));
 const head=mesh(mahitoBlock,skin,g,V(0,1.27,.045),V(.50,.49,.40));for(const side of [-1,1]){mesh(geo.box,dark,head,V(side*.22,.04,.51),V(.22,.09,.028));const arm=new THREE.Group();arm.position.set(side*.34,1.02,0);g.add(arm);mesh(mahitoBlock,skin,arm,V(0,-.22,0),V(.20,.43,.22));const elbow=new THREE.Group();elbow.position.y=-.42;arm.add(elbow);mesh(mahitoBlock,skin,elbow,V(0,-.16,0),V(.18,.34,.20));mesh(mahitoBlock,skin,elbow,V(0,-.34,.025),V(.21,.17,.19));elbow.rotation.x=-.32;joints.push(arm);const leg=new THREE.Group();leg.position.set(side*.145,.44,0);g.add(leg);mesh(mahitoBlock,skin,leg,V(0,-.18,0),V(.22,.38,.23));mesh(mahitoBlock,skin,leg,V(0,-.37,.055),V(.24,.14,.32));joints.push(leg);}mesh(geo.box,dark,head,V(0,-.28,.51),V(.42,.055,.026));g.visible=false;return {g,joints};
}
function ensureMahitoVisuals(){
 if(mahitoVisuals)return mahitoVisuals;const group=new THREE.Group();scene.add(group);group.name='mahito-pooled-creatures';
 const units=Array.from({length:MAHITO.summonPool},(_,i)=>makeMorphedHuman(group,i)),bullets=Array.from({length:MAHITO.bulletPool},(_,i)=>makeMorphedHuman(group,i)),trains=[];
 for(let n=0;n<6;n++){const g=new THREE.Group();group.add(g);g.visible=false;const skin=new THREE.MeshToonMaterial({color:0xa6b6bf}),dark=new THREE.MeshStandardMaterial({color:0x323b50,roughness:.82}),mouth=new THREE.MeshBasicMaterial({color:0x15151f}),bone=new THREE.MeshToonMaterial({color:0xe7dfcb}),segments=[];
  for(let i=0;i<14;i++){const s=new THREE.Group();g.add(s);mesh(mahitoBlock,dark,s,V(),V(2.6,1.8,2.9));mesh(mahitoBlock,skin,s,V(0,.68,.05),V(2.75,.65,2.4));mesh(mahitoBlock,bone,s,V(0,1.04,.06),V(.25,.16,1.95));for(const side of [-1,1]){const foot=mesh(mahitoBlock,skin,s,V(side*1.36,-.67,0),V(.38,.93,.5));foot.rotation.z=side*.5;}segments.push(s);}
  const head=new THREE.Group();g.add(head);mesh(mahitoBlock,skin,head,V(0,.28,.4),V(3.15,1.9,3.35));mesh(mahitoBlock,mouth,head,V(0,-.24,2.09),V(2.48,1.25,.16));mesh(mahitoBlock,dark,head,V(0,-.96,1.15),V(2.8,.45,2.14));for(const side of [-1,1]){mesh(mahitoBlock,dark,head,V(side*.82,.73,2.11),V(.77,.20,.17)).rotation.z=-side*.18;mesh(mahitoBlock,skin,head,V(side*1.52,-.22,1.21),V(.31,1.3,1.35));}for(let i=0;i<9;i++){mesh(geo.cone,bone,head,V((i-4)*.27,.38,2.20),V(.24,.48,.22)).rotation.z=Math.PI;mesh(geo.cone,bone,head,V((i-4)*.27,-.78,2.20),V(.24,.4,.22));}for(const side of [-1,1])mesh(mahitoBlock,new THREE.MeshBasicMaterial({color:0xb4ffe0}),head,V(side*.85,.57,2.12),V(.46,.12,.12));
  const path=Array.from({length:48},()=>V()),positions=new Float32Array(48*3),geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(positions,3).setUsage(THREE.DynamicDrawUsage));const track=new THREE.Line(geometry,new THREE.LineBasicMaterial({color:MAHITO.soul,transparent:true,opacity:.45}));scene.add(track);track.visible=false;track.frustumCulled=false;trains.push({g,head,segments,path,positions,track,key:0});
 }return mahitoVisuals={group,units,bullets,trains};
}
function hideMahitoVisuals(){if(!mahitoVisuals)return;mahitoVisuals.group.visible=false;for(const t of mahitoVisuals.trains)t.track.visible=false;}
function updateMahitoVisuals(dt){
 updateMahitoAmalgams(dt);
 if(!bodies.some(f=>f.character==='mahito')){hideMahitoVisuals();return;}const v=ensureMahitoVisuals(),active=['play','pause','finish'].includes(phase);v.group.visible=active;if(!active){hideMahitoVisuals();return;}
 const guest=mode==='online'&&net?.role==='guest',data=guest?mahitoReplica:null,units=data?.units||mahitoUnits,bullets=data?.bullets||mahitoBullets;
 for(let i=0;i<v.units.length;i++){const r=v.units[i],u=units[i];r.g.visible=!!u;if(!u)continue;const p=guest?mahitoScratch.a.fromArray(u.p):u.p,dir=guest?mahitoScratch.b.fromArray(u.dir):u.dir;r.g.position.copy(p);r.g.rotation.y=Math.atan2(dir.x,dir.z);r.g.scale.set(1+(u.variant%2)*.3,1-(u.variant%2)*.15,1);for(let j=0;j<r.joints.length;j++)r.joints[j].rotation.x=Math.sin(time*14+j*Math.PI)*.8;r.g.position.y+=Math.abs(Math.sin(time*14))*.10;}
 for(let i=0;i<v.bullets.length;i++){const r=v.bullets[i],b=bullets[i];r.g.visible=!!b;if(!b)continue;r.g.position.copy(guest?mahitoScratch.a.fromArray(b.p):b.p);r.g.scale.setScalar(.32);r.g.rotation.set(time*14,time*5,time*3);}
 for(let n=0;n<v.trains.length;n++){const tr=v.trains[n],f=bodies[n],a=f?.mahitoAction,show=f?.character==='mahito'&&a?.kind===3;tr.g.visible=tr.track.visible=!!show;if(!show)continue;
  const grow=narutoEase(a.t/MAHITO.trainStartup)*(1-narutoEase((a.t-MAHITO.trainStartup-MAHITO.trainTime)/MAHITO.trainRecovery));if(tr.key!==a.id){tr.key=a.id;for(let i=0;i<tr.path.length;i++)tr.path[i].copy(f.pos).addScaledVector(a.dir,-i*.72);}
  const distance=tr.path[0].distanceTo(f.pos);if(distance>=.72){const steps=Math.min(48,Math.floor(distance/.72)),from=mahitoScratch.c.copy(tr.path[0]),delta=mahitoScratch.d.copy(f.pos).sub(from);for(let k=1;k<=steps;k++){for(let i=tr.path.length-1;i>0;i--)tr.path[i].copy(tr.path[i-1]);tr.path[0].copy(from).addScaledVector(delta,k/steps);}}
  tr.head.position.copy(f.pos);tr.head.position.y+=1;tr.head.quaternion.setFromUnitVectors(mahitoScratch.a.set(0,0,1),a.dir);tr.head.scale.setScalar(grow);
  for(let i=0;i<tr.segments.length;i++){const s=tr.segments[i],index=Math.min(tr.path.length-1,(i+1)*2);s.position.copy(tr.path[index]);s.position.y+=.7+Math.sin(time*12-i*.7)*.22;s.scale.setScalar(grow*(1-i/26));mahitoScratch.b.copy(tr.path[Math.max(0,index-2)]).sub(tr.path[index]);if(mahitoScratch.b.lengthSq()>.001)s.quaternion.setFromUnitVectors(mahitoScratch.a.set(0,0,1),mahitoScratch.b.normalize());}
  for(let i=0;i<tr.path.length;i++){tr.positions[i*3]=tr.path[i].x;tr.positions[i*3+1]=tr.path[i].y+.2;tr.positions[i*3+2]=tr.path[i].z;}tr.track.geometry.attributes.position.needsUpdate=true;
 }
}
function addMahitoHands(origin){
 const container=new THREE.Group();container.name='self-embodiment-hands';domainVisual.add(container);container.position.copy(origin);container.position.y+=1.45;
 const h=makeMahitoHandBatch(container,MAHITO_DOMAIN.backgroundHands);h.hunters=makeMahitoHandBatch(container,MAHITO_DOMAIN.maxHunters,true);h.container=container;return h;
}
function mahitoDomainBackdrop(origin,axis){
 clearDomainVisual();if(enclosure()&&!insideEnclosure(player))return;sky.visible=false;shrine.visible=false;scene.background.set(MAHITO_REALM.void);scene.fog.color.set(MAHITO_REALM.fog);scene.fog.density=MAHITO_REALM.fogDensity;hemi.intensity=1.15;sun.intensity=.9;rim.intensity=1.4;
 const dome=mesh(new THREE.SphereGeometry(DOMAIN_ENCLOSURE.radius-.3,40,28),new THREE.MeshBasicMaterial({color:MAHITO_REALM.void,side:THREE.BackSide}),domainVisual,origin.clone().add(V(0,1.45,0))),hands=addMahitoHands(origin);domainVisual.userData={kind:'mahito',origin:origin.clone(),axis:axis.clone(),dome,mahitoHands:hands};confineDomainVisual(domainVisual,origin);animateMahitoDomain();
}
function animateMahitoDomain(){
 const v=domainVisual.userData,h=v.mahitoHands;if(!h)return;const c=MAHITO_REALM,age=(domain?.t||clash?.t||0)+(mode==='online'&&net?.role==='guest'?Math.min(.12,narutoReplicaAge):0),ending=domain?1-narutoEase((age-(DOMAIN_RULES.duration-c.exit))/c.exit):1,n=particleBudget<1000?MAHITO_DOMAIN.lowBackgroundHands:MAHITO_DOMAIN.backgroundHands;
 // Giant overlapping silhouettes in three staggered shells; all positions relative to the sphere centre.
 // Hero palms and curled fists share the same instanced, articulated hand batch.
 for(let i=0;i<n;i++){
  const layer=i%7===0?2:i%3===0?1:0,y=1-2*(i+.5)/n,a=i*2.399963+Math.sin(age*.16+i)*.025,r=Math.sqrt(1-y*y),seed=domainHash(i+13),reach=.5+.5*Math.sin(age*.75+i*1.7),entry=narutoEase((age-seed*.18)/c.entry),radius=(layer===2?c.innerRadius:layer===1?c.middleRadius:c.outerRadius)-reach*c.breath,
  size=(layer===2?c.innerScale:layer===1?c.middleScale:c.outerScale)*(.82+seed*.32)*entry*ending,curl=i%5===0?1.7+.16*Math.sin(age+i):i%5===1?.7+.3*reach:.04+.21*reach;
  h.normal.set(Math.cos(a)*r,y,Math.sin(a)*r);h.p.copy(h.normal).multiplyScalar(radius);h.normal.negate();setMahitoHand(h,i,h.p,h.normal,size,curl,i*1.83+Math.sin(age*.3+i)*.07);
 }flushMahitoHands(h,n);animateMahitoHunters(h.hunters);
 const status=$('domainState');status.classList.toggle('hidden',!domain||phase!=='play');if(domain?.owner.character==='mahito'){$('domainStage').textContent='SELF-EMBODIMENT · PURSUING HANDS / LETHAL TOUCH';$('domainTime').textContent=Math.max(0,DOMAIN_RULES.duration-age).toFixed(1)+'s';status.dataset.kind='mahito';}
}
function buildMahitoClash(origin,axis){
 const kinds=new Set(clash.participants.map(id=>actorById(id)?.character));if(kinds.has('naruto'))buildMindscapeClash(origin,axis);else if(kinds.has('gojo')||kinds.has('sukuna'))domainBackdrop(kinds.has('gojo')&&kinds.has('sukuna')?'clash':kinds.has('gojo')?'gojo':'sukuna',origin,axis);else{mahitoDomainBackdrop(origin,axis);return;}
 if(!domainVisual.userData.kind)return;domainVisual.userData.mahitoHands=addMahitoHands(origin);confineDomainVisual(domainVisual.userData.mahitoHands.container,origin);animateMahitoDomain();
}
