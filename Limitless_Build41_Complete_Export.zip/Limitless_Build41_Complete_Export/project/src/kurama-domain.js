// Naruto-only roaming avatar. The host and all clients evaluate the same timeline.
const KURAMA={stomp:{first:1.5,interval:1.15,count:8,damage:35,radius:5.5,height:7.5,windup:.36,recovery:.28,shake:.38},roam:{radiusX:14,radiusZ:12,speed:.32},slamWindup:1.1,pawX:5,pawFront:-7,pawBack:6,tailCount:9,pawOrder:[0,3,1,2]};
const kuramaScratch={pose:V(),foot:V(),knock:V(),local:V()};
function kuramaPoseAt(t,out){
 const a=Math.max(0,t-1.1)*KURAMA.roam.speed,enter=narutoEase(t/1.1),returning=narutoEase((t-mindscapeFinisherAt()+KURAMA.slamWindup)/KURAMA.slamWindup);
 out.set(Math.sin(a)*KURAMA.roam.radiusX*enter,Math.atan2(-Math.cos(a)*KURAMA.roam.radiusX,Math.sin(a)*KURAMA.roam.radiusZ)*enter,lerp(35,6+Math.cos(a)*KURAMA.roam.radiusZ,enter));
 out.x*=1-returning;out.z=lerp(out.z,3,returning);out.y*=1-returning;return out;
}
function kuramaPawIndex(step){return KURAMA.pawOrder[step%4];}
function kuramaLocalFoot(t,index,out){
 const p=kuramaPoseAt(t,kuramaScratch.pose),x=index%2?KURAMA.pawX:-KURAMA.pawX,z=index<2?KURAMA.pawFront:KURAMA.pawBack,c=Math.cos(p.y),s=Math.sin(p.y);
 return out.set(p.x+x*c+z*s,.28,p.z-x*s+z*c);
}
function kuramaFootAt(t,index,origin,axis,out){
 kuramaLocalFoot(t,index,out);const a=Math.atan2(axis.x,axis.z),c=Math.cos(a),s=Math.sin(a),x=out.x,z=out.z;
 return out.set(origin.x+x*c+z*s,origin.y+.28,origin.z-x*s+z*c);
}
function kuramaStomp(d,step){
 const c=KURAMA.stomp,t=c.first+step*c.interval,p=kuramaFootAt(t,kuramaPawIndex(step),d.origin,d.axis,kuramaScratch.foot);
 for(const victim of bodies){if(victim===d.owner||victim.hp<=0||!insideEnclosure(victim))continue;
  const dx=victim.pos.x-p.x,dz=victim.pos.z-p.z;if(dx*dx+dz*dz>c.radius*c.radius||victim.pos.y>p.y+c.height)continue;
  const knock=kuramaScratch.knock.set(dx,0,dz);if(knock.lengthSq()<.01)knock.copy(d.axis).setY(0);knock.normalize().multiplyScalar(9);knock.y=5;
  hurt(victim,c.damage,d.owner,'domain-stomp',knock,0);
 }
 narutoFX('ground',p,c.radius);shock(p,0xff6435,c.radius,.45);sfx('launchImpact',p,1.2);if(insideEnclosure(player))shakeIt(c.shake);
}
function createKuramaAvatar(v){
 const root=new THREE.Group();root.name='Kurama-full-nine-tailed-fox';v.g.add(root);root.visible=false;
 const torso=new THREE.Group();root.add(torso);torso.position.y=KURAMA_LOOK.torsoHeight;
 mesh(geo.sphere,v.fox,torso,V(0,0,.8),V(4.1,3.6,9.3));mesh(geo.lowSphere,v.fox,torso,V(0,.8,-5.3),V(5.6,5.3,5.5));mesh(geo.lowSphere,v.fox,torso,V(0,-.2,6.4),V(4.7,3.9,4.3));
 const belly=new THREE.MeshStandardMaterial({color:0x703017,roughness:.93,emissive:0x3d0902,emissiveIntensity:.12,transparent:true});v.mats.push(belly);
 mesh(geo.lowSphere,belly,torso,V(0,-1.9,-2),V(3.5,2.5,6.9));
 for(let i=0;i<16;i++){const side=i%2?1:-1,j=Math.floor(i/2),tuft=mesh(geo.cone,v.fox,torso,V(side*(4.6-j*.17),2.1-j*.18,-6+j*1.8),V(2.9,5.4-j*.2,3.0));tuft.rotation.set(.48,side*.23,-side*1.1);}
 for(let i=0;i<5;i++){const crest=mesh(geo.cone,v.fox,torso,V(0,4.6,-6+i*2.4),V(2.6,3.6-i*.2,3.1));crest.rotation.x=.65;}
 const neck=new THREE.Group();torso.add(neck);neck.position.set(0,KURAMA_LOOK.neckHeight,-7.5);const face=createKuramaHead(v.fox,v.black,v.mats[4],v.eyeMat),head=face.head;head.scale.setScalar(KURAMA_LOOK.headScale);neck.add(head);
 const legs=[];
 for(let i=0;i<4;i++){
  const x=i%2?KURAMA.pawX:-KURAMA.pawX,z=i<2?KURAMA.pawFront:KURAMA.pawBack,leg=new THREE.Group();root.add(leg);leg.position.set(x,0,z);
  const upper=mesh(geo.lowSphere,v.fox,leg,V(0,5.3,i<2?0:1.0),V(1.55,4.8,1.9)),paw=new THREE.Group();leg.add(paw);paw.position.y=1;
  if(i>=2){const hock=mesh(geo.lowSphere,v.fox,leg,V(0,7.3,1.3),V(2.3,3.0,2.9));hock.rotation.x=-.3;}
  mesh(geo.lowSphere,v.fox,paw,V(),V(2.35,1.1,3.2));for(let j=0;j<4;j++){mesh(geo.lowSphere,v.fox,paw,V((j-1.5)*1.12,-.25,-1.9),V(.64,.77,1.8));const claw=mesh(kuramaModelGeometry().fang,v.mats[4],paw,V((j-1.5)*1.12,-.22,-2.7),V(.44,KURAMA_LOOK.clawLength,.45));claw.rotation.x=-Math.PI/2;}
  legs.push({leg,upper,paw});
 }
 const tails=[];
 for(let i=0;i<KURAMA.tailCount;i++){
  const base=new THREE.Group();torso.add(base);base.position.set((i-4)*.6,1.1,7);const joints=[];let parent=base;
  for(let j=0;j<4;j++){const joint=new THREE.Group();parent.add(joint);if(j)joint.position.z=5.2;mesh(geo.sphere,v.fox,joint,V(0,0,2.6),V(2-j*.38,2-j*.38,4.2));joints.push(joint);parent=joint;}
  const tip=mesh(geo.cone,v.fox,parent,V(0,0,6),V(.9,3.4,.9));tip.rotation.x=Math.PI/2;tails.push({base,joints});
 }
 const warning=mesh(new THREE.RingGeometry(KURAMA.stomp.radius-.12,KURAMA.stomp.radius,64),new THREE.MeshBasicMaterial({color:0xff713c,transparent:true,opacity:0,side:THREE.DoubleSide,depthWrite:false}),v.g);warning.rotation.x=-Math.PI/2;warning.visible=false;
 v.mats.push(warning.material);
 return {root,torso,neck,head,jaw:face.jaw,ears:face.ears,legs,tails,warning,pose:V(),point:V()};
}
function animateKuramaAvatar(v,age,fade){
 const a=v.avatar,active=domain?.owner.character==='naruto'&&!clash,opening=active?narutoEase(age/.95):0;
 a.root.visible=!!active;a.warning.visible=false;v.foxHead.visible=!active;for(const c of v.claws)c.visible=!active;
 for(let i=0;i<37;i++){v.dummy.position.set((i-18)*1.85+(i<18?-1:1)*opening*22,11.5,0);v.dummy.rotation.set(0,0,0);v.dummy.scale.set(.38,23,.38);v.dummy.updateMatrix();v.bars.setMatrixAt(i,v.dummy.matrix);}v.bars.instanceMatrix.needsUpdate=true;
 for(let i=0;i<v.gateRails.length;i++)v.gateRails[i].position.x=(i%2?1:-1)*(18+opening*22);
 v.sealUniforms.uFade.value*=1-opening;if(!active)return;
 kuramaPoseAt(age,a.pose);a.root.position.set(a.pose.x,0,a.pose.z);a.root.rotation.y=a.pose.y;
 const finish=mindscapeFinisherAt(),rear=narutoEase((age-finish+KURAMA.slamWindup)/.75)*(1-narutoEase((age-finish+.13)/.13)),settle=Math.sin(clamp((age-finish)/.45,0,1)*Math.PI);
 a.torso.position.y=KURAMA_LOOK.torsoHeight+Math.sin(age*3)*.3+rear*2-settle*.9;a.torso.rotation.x=-rear*.27;a.torso.scale.set(1+settle*.04,1-settle*.07,1+settle*.025);a.neck.rotation.x=.08+Math.sin(age*2)*.045-rear*.23+settle*.28;
 const threat=.5+.5*Math.sin(age*3);a.jaw.rotation.x=lerp(KURAMA_LOOK.jawRest,KURAMA_LOOK.jawRoar,clamp(rear+settle*.75+threat*.18,0,1));for(let i=0;i<2;i++)a.ears[i].rotation.z=(i?1:-1)*(-.21-rear*.18)+Math.sin(age*3-i)*.035;
 for(let i=0;i<4;i++){
  let lift=0;
  for(let step=0;step<KURAMA.stomp.count;step++){if(kuramaPawIndex(step)!==i)continue;const at=KURAMA.stomp.first+step*KURAMA.stomp.interval,u=(age-at+KURAMA.stomp.windup)/KURAMA.stomp.windup;
   if(u>=0&&u<1)lift=Math.sin(narutoEase(u)*Math.PI)*5.2;
  }
  if(i<2)lift+=rear*8;const leg=a.legs[i];leg.paw.position.y=1+lift;leg.upper.position.y=5.3+lift*.5;leg.upper.scale.y=Math.max(1.1,4.8-lift*.3);leg.leg.rotation.x=Math.sin(age*3+i)*.025;
 }
 for(let i=0;i<a.tails.length;i++){const tail=a.tails[i];tail.base.rotation.set(-.12-(i%3)*.12,(i-4)*.23,0);for(let j=0;j<tail.joints.length;j++){tail.joints[j].rotation.x=-.10+Math.sin(age*1.8-i*.25-j*.38)*.095;tail.joints[j].rotation.y=Math.sin(age*1.15-i*.45-j*.42)*.12;}}
 const next=Math.ceil((age-KURAMA.stomp.first)/KURAMA.stomp.interval),at=KURAMA.stomp.first+next*KURAMA.stomp.interval;
 if(next>=0&&next<KURAMA.stomp.count&&age>at-KURAMA.stomp.windup){kuramaLocalFoot(at,kuramaPawIndex(next),a.point);a.warning.position.copy(a.point);a.warning.position.y=.34;a.warning.visible=true;a.warning.material.opacity=fade*.65*narutoEase((age-at+KURAMA.stomp.windup)/.12);}
}
