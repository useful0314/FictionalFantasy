// Naruto-only tuning. Durations are seconds; frame counts in NARUTO.md use 60 Hz.
const NARUTO={
 colors:{orange:0xf07b24,black:0x192331,hair:0xffd34b,chakra:0x59cfff,wind:0xc5f5ff,gold:0xffca40,dark:0x291142,ember:0xff7026},
 blend:.085,secondaryBlend:.12,clonePool:48,particlePool:900,fxPool:32,visualProjectiles:18,
 moves:[null,
  {name:'SHADOW CLONE BARRAGE',startup:.4,charge:.65,active:1.28,recovery:.32,cooldown:1.8,cost:8,drain:10,damage:120,range:18,radius:1.15,shake:.18,hitstop:.035,hits:[.24,.5,.76,1.08],weights:[.2,.2,.2,.4]},
  {name:'UZUMAKI COMBO',startup:.2,charge:.5,active:1.16,recovery:.3,cooldown:1.65,cost:10,drain:10,damage:160,range:10,radius:1.25,shake:.32,hitstop:.04,hits:[.2,.42,.64,1.02],weights:[.15625,.21875,.25,.375]},
  {name:'RASENGAN',startup:.45,charge:.75,active:.48,recovery:.32,cooldown:1.1,cost:12,drain:10,damage:180,range:16,radius:1.2,shake:.5,hitstop:.06},
  {name:'RASENSHURIKEN',startup:.85,charge:1.3,active:.3,recovery:.42,cooldown:1.5,cost:20,drain:13,damage:220,range:96,radius:1.1,zoneRadius:9,zoneTime:1.2,zoneTick:.2,speed:44,shake:.6,hitstop:.055,contact:60,cutting:60,burst:100},
  {name:'TAILED BEAST BOMB',startup:2.1,active:.65,recovery:.65,cooldown:12,cost:45,ultCost:30,damage:520,range:120,radius:3,zoneRadius:18,speed:82,shake:1.65,hitstop:.075}
 ]
};
const NARUTO_KIT={name:'NARUTO UZUMAKI',short:'NARUTO',title:'LEAF VILLAGE · NINJA',domain:'MINDSCAPE · KURAMA’S CAGE',color:NARUTO.colors.orange,
 names:['',...NARUTO.moves.slice(1,5).map(m=>m.name)],hints:['','Hand sign · three clone strikes','Dash · punch, kick, uppercut, slam','Charge chakra · lunging impact','Wind blades · ranged cutting zone'],
 tags:['','SHADOW CLONES','LAUNCH / SLAM','CHAKRA THRUST','WIND RELEASE'],colors:['','#ffbe71','#ffa957','#69d7ff','#c2f5ff']};
const narutoScratch={a:V(),b:V(),c:V(),d:V(),e:V(),ray:new THREE.Raycaster(),hits:[],surfaces:[]};
const narutoReplicas=new Map();let narutoReplicaAge=0,narutoFreeze=0;
function narutoAim(out,f){const a=f===player?yaw:f.input.yaw,p=f===player?pitch:f.input.pitch;return out.set(-Math.sin(a)*Math.cos(p),-Math.sin(p),-Math.cos(a)*Math.cos(p));}
function narutoHead(out,f){out.copy(f.pos);out.y+=1.45;return out;}
function narutoBusy(f){return f.narutoMobility?.kind===4||f.character==='naruto'&&(!!f.narutoAction&&!f.narutoAction.cancelled||narutoMobilityBusy(f));}
function narutoAge(a){return a.t+(mode==='online'&&net?.role==='guest'?narutoReplicaAge:0);}
function narutoEase(x){x=clamp(x,0,1);return x*x*(3-2*x);}
function narutoBack(x){x=clamp(x,0,1);return 1+2.70158*(x-1)**3+1.70158*(x-1)**2;}
function narutoMove(f,dir,distance){const s=narutoScratch;s.a.copy(f.pos);f.pos.addScaledVector(dir,distance);resolveDistrictCollision(f,s.a);constrainBarrier(f,f.pos,s.a,f.vel);const r=Math.hypot(f.pos.x,f.pos.z);if(r>WORLD.radius-1){f.pos.x*=(WORLD.radius-1)/r;f.pos.z*=(WORLD.radius-1)/r;}}
function narutoWallDistance(origin,dir,max){
 const s=narutoScratch;s.surfaces.length=0;for(const p of pieces)if(arenaPieceActive(p)&&p.solid)s.surfaces.push(p.m);s.hits.length=0;s.ray.set(origin,dir);s.ray.near=0;s.ray.far=max;s.ray.intersectObjects(s.surfaces,false,s.hits);
 const obstruction=Math.min(s.hits[0]?.distance??Infinity,barrierRayDistance(origin,dir,max),dir.y<0?Math.max(0,(.15-origin.y)/dir.y):Infinity);s.blocked=obstruction<=max;return Math.min(max,obstruction);
}
function narutoCapsuleTarget(owner,from,to,radius,forward=null){
 const s=narutoScratch;s.b.copy(to).sub(from);const len=s.b.length();if(len>.00001)s.b.divideScalar(len);let result=null,best=Infinity;
 for(const f of bodies){if(f===owner||f.hp<=0||barrierSeparates(owner,f))continue;narutoHead(s.c,f);if(forward&&s.d.copy(f.pos).sub(owner.pos).dot(forward)<=0)continue;s.d.copy(s.c).sub(from);const along=clamp(s.d.dot(s.b),0,len);s.e.copy(from).addScaledVector(s.b,along);if(s.e.distanceToSquared(s.c)<(radius+.8)**2&&along<best){result=f;best=along;}}
 return result;
}
function narutoImpact(owner,target,damage,dir,horizontal,vertical,kind=3){
 const cfg=NARUTO.moves[kind],knock=V(dir.x*horizontal,vertical,dir.z*horizontal);
 if(!hurt(target,damage,owner,'special',knock,kind===5?3:1))return false;
 narutoFreeze=Math.max(narutoFreeze,cfg.hitstop);netFX('narutoStop',[cfg.hitstop]);shakeIt(cfg.shake,target.pos,dir);narutoFX('impact',headPos(target),kind===5?5:kind===3?2.6:1,dir);sfx(kind===3?'rasenganImpact':'hit',target.pos,.8);return true;
}
function newNarutoAction(owner,kind,q,dir){
 const cfg=NARUTO.moves[kind],target=other(owner),a={id:++techniqueSerial,type:'naruto',owner,kind,q,t:0,origin:owner.pos.clone(),p:owner.pos.clone(),dir:dir.clone().normalize(),target:target.id,targetPos:target.pos.clone(),next:0,moved:0,hit:false,cancelled:false,cloneEnds:[],from:V(),to:V(),duration:kind===5?cfg.startup+cfg.active+cfg.recovery:cfg.active+cfg.recovery};
 a.to.copy(target.pos).sub(owner.pos);const ahead=a.to.dot(a.dir),aligned=a.to.lengthSq()-ahead*ahead<9;a.travel=Math.min(kind===1?10:cfg.range,aligned&&ahead>0?Math.max(0,ahead-2.15):kind===1?10:cfg.range);
 if(kind===1){a.targetPos.copy(owner.pos).addScaledVector(a.dir,cfg.range);for(let i=0;i<3;i++){const start=narutoCloneStart(V(),a,i);narutoHead(a.from,{pos:start});let travel=narutoWallDistance(a.from,a.dir,cfg.range);for(const victim of bodies){if(victim===owner||victim.hp<=0||barrierSeparates(owner,victim)||a.to.copy(victim.pos).sub(a.origin).dot(a.dir)<=0)continue;const hit=raySphere(a.from,a.dir,narutoHead(a.to,victim),cfg.radius+.8);if(hit<travel)travel=Math.min(travel,hit+.15);}const endpoint=start.clone().addScaledVector(a.dir,Math.max(0,travel-.1));constrainBarrier(owner,endpoint,start);a.cloneEnds.push(endpoint);}narutoHead(a.from,owner);a.to.copy(a.from).addScaledVector(a.dir,10);const front=narutoCapsuleTarget(owner,a.from,a.to,cfg.radius);a.travel=front?clamp(narutoHead(a.to,front).sub(a.from).dot(a.dir)-2.15,0,10):10;}
 techniques.push(a);owner.narutoAction=a;owner.block=false;owner.attackIsLight=false;owner.attack=owner.attackMax=a.duration;owner.specialKind=kind<=4?kind:0;owner.specialAge=0;owner.specialDuration=a.duration;owner.specialPower=q;return a;
}
function executeNarutoTechnique(owner,kind,q,dir){
 const a=newNarutoAction(owner,kind,q,dir);sfx(['','narutoClone','light','rasengan','rasenshuriken'][kind],owner.pos);
 if(kind===1)for(let i=0;i<3;i++)narutoFX('smoke',narutoCloneStart(V(),a,i).add(V(0,1.1,0)),1);
 if(kind===4){a.next=.13;}
}
function narutoCloneStart(out,a,i){return out.copy(a.origin).addScaledVector(a.dir,-.8).addScaledVector(narutoScratch.e.set(-a.dir.z,0,a.dir.x).normalize(),(i-1)*1.4);}
function castNarutoBomb(f){
 if(techniqueBurnedOut(f,true))return false;
 if(phase!=='play'||f.hp<=0||f.stun>0||f.ragdollT>0||f.recovery>0||f.dodge>0||narutoBusy(f)||(f.attackIsLight&&f.attack>.08)||trappedByVoid(f)||castFor(f))return;
 if(f.cooldown>0||f.energy<NARUTO.moves[5].cost||f.ult<NARUTO.moves[5].ultCost){if(f===player&&f.cooldown<=0)toast('Tailed Beast Bomb needs 45 chakra + 30% ultimate');return;}f.energy-=NARUTO.moves[5].cost;f.ult-=NARUTO.moves[5].ultCost;
 cancelCharge(f);const a=newNarutoAction(f,5,1,narutoAim(narutoScratch.b,f));f.cooldown=NARUTO.moves[5].cooldown;
 announce('NINE-TAILS CHAKRA MODE','TAILED BEAST BOMB',2);sfx('narutoUltimate',f.pos);narutoFX('transform',f.pos,4);flashIt(.25);shakeIt(.35,f.pos);cinematicShot(f,'naruto',a.duration);
}
function interruptNaruto(f){
 if(f.narutoMobility)f.narutoMobility.jumpQueue=0;
 cancelNarutoMobility(f);
 const a=f.narutoAction;if(!a)return;a.cancelled=true;f.narutoAction=null;f.attack=Math.min(f.attack,.12);f.specialKind=0;f.cooldown=Math.max(f.cooldown||0,.2);
 if(a.kind===1)for(let i=0;i<3;i++)if(a.t<NARUTO.moves[1].hits[i])narutoFX('smoke',a.cloneEnds[i],.7);
 if(cinematic?.type==='naruto'&&cinematic.owner===f)cinematic.t=Math.max(cinematic.t,cinematic.duration-.5);
}
function narutoLaunch(owner,kind,q,dir){
 const cfg=NARUTO.moves[kind],p=headPos(owner).addScaledVector(dir,2.1);if(kind===4)p.y+=.3;
 projectiles.push({id:++techniqueSerial,type:kind===4?'naruto-shuriken':'naruto-bomb',owner,p,previous:p.clone(),origin:p.clone(),dir:dir.clone().normalize(),q,t:0,hit:false});
 if(kind===5){narutoFX('muzzle',p,4,dir);flashIt(.5);shakeIt(1,p,dir);sfx('burst',p);}else sfx('rasenshuriken',p,.8);
}
function updateNarutoAction(a,dt){
 const f=a.owner,cfg=NARUTO.moves[a.kind];a.t+=dt;
 if(a.cancelled||f.hp<=0||f.stun>0||f.ragdollT>0||trappedByVoid(f)){if(f.narutoAction===a)interruptNaruto(f);return true;}
 if(a.kind===1||a.kind===2){
  const begin=a.kind===1?.78:0,end=a.kind===1?1.06:.22,max=a.travel;
  const progress=narutoEase((a.t-begin)/(end-begin)),travel=max*progress;if(travel>a.moved){narutoMove(f,a.dir,travel-a.moved);a.moved=travel;}
  while(a.next<cfg.hits.length&&a.t+1e-8>=cfg.hits[a.next]){
   const i=a.next++;if(a.kind===1&&i<3){a.from.copy(a.cloneEnds[i]);a.from.y+=1.2;a.to.copy(a.from).addScaledVector(a.dir,.65);narutoFX('smoke',a.from,1);}
   else{narutoHead(a.from,f);a.to.copy(a.from).addScaledVector(a.dir,i===3?2.9:2.5);}
   let target=narutoCapsuleTarget(f,a.from,a.to,cfg.radius,a.kind===1?a.dir:null);
   if(target){const upper=a.kind===2&&i===2,slam=a.kind===2&&i===3,final=i===3,damage=charged(cfg.damage,a.q)*cfg.weights[i];
    if(narutoImpact(f,target,damage,a.dir,slam?4:final?12:1.5,slam?-12:upper?9:final?6:1,a.kind)){
     target.stun=Math.max(target.stun,final?.24:.3);target.block=false;
     if(upper){f.vel.y=9;f.grounded=false;a.target=target.id;}
     if(slam){target.vel.y=-15;target.narutoSlamImpact=true;f.vel.y=-10;narutoFreeze=Math.max(narutoFreeze,.065);}
    }
   }
  }
 }else if(a.kind===3){
  if(!a.hit&&a.t<=cfg.active+dt){const progress=narutoEase(a.t/cfg.active),travel=cfg.range*lerp(.65,1,a.q)*progress;narutoHead(a.from,f);narutoMove(f,a.dir,Math.max(0,travel-a.moved));a.moved=travel;narutoHead(a.to,f);a.to.addScaledVector(a.dir,1.2);const target=narutoCapsuleTarget(f,a.from,a.to,cfg.radius);if(target){a.hit=true;narutoImpact(f,target,charged(cfg.damage,a.q),a.dir,20,5,3);narutoFX('spiral',headPos(target),4,a.dir);}}
 }else if(a.kind===4){if(!a.hit&&a.t>=a.next){a.hit=true;narutoLaunch(f,4,a.q,a.dir);}}
 else if(a.kind===5){if(!a.hit&&a.t>=cfg.startup){a.hit=true;narutoLaunch(f,5,1,a.dir);}}
 if(a.t>=a.duration){if(f.narutoAction===a)f.narutoAction=null;return true;}return false;
}
function updateNarutoProjectile(p,dt){
 const kind=p.type==='naruto-bomb'?5:4,cfg=NARUTO.moves[kind];p.t+=dt;const from=p.previous.copy(p.p),maxStep=Math.min(cfg.speed*dt,Math.max(0,cfg.range-p.t*cfg.speed+cfg.speed*dt)),wall=narutoWallDistance(from,p.dir,maxStep),blocked=narutoScratch.blocked;let distance=wall,contact=false;
 for(const f of bodies){if(f===p.owner||f.hp<=0||barrierSeparates(p.owner,f))continue;const d=raySphere(from,p.dir,narutoHead(narutoScratch.c,f),cfg.radius+.8);if(d<=distance){distance=d;contact=true;p.directId=f.id;}}
 p.p.copy(from).addScaledVector(p.dir,distance);
 if(contact||blocked||p.t*cfg.speed>=cfg.range||p.p.y<=.15){
  if(kind===4){const radius=lerp(4.5,cfg.zoneRadius,p.q);for(const f of bodies)if(f!==p.owner&&f.hp>0&&narutoHead(narutoScratch.c,f).distanceTo(p.p)<radius)hurt(f,charged(cfg.contact,p.q),p.owner,'special',V(),1);
   techniques.push({id:++techniqueSerial,type:'naruto-wind',kind:4,owner:p.owner,p:p.p.clone(),dir:p.dir.clone(),q:p.q,t:0,next:cfg.zoneTick,radius,duration:cfg.zoneTime});narutoFX('wind',p.p,radius,p.dir);
  }else{
   for(const f of bodies){if(f===p.owner||f.hp<=0)continue;const d=f.id===p.directId?0:narutoHead(narutoScratch.c,f).distanceTo(p.p);if(d<cfg.zoneRadius){const dir=headPos(f).sub(p.p).normalize();narutoImpact(p.owner,f,cfg.damage*(1-.55*clamp(d/cfg.zoneRadius,0,1)),dir,30,12,5);}}
   destroyAt(p.p,cfg.zoneRadius,180);narutoFX('bomb',p.p,cfg.zoneRadius,p.dir);shock(p.p,NARUTO.colors.gold,cfg.zoneRadius*1.4,1.1);flashIt(.65);shakeIt(cfg.shake,p.p,p.dir);sfx('burst',p.p,1.4);
  }return true;
 }return false;
}
function updateNarutoWind(a,dt){
 const cfg=NARUTO.moves[4];a.t=Math.min(a.duration,a.t+dt);
 while(a.next<=a.duration+1e-8&&a.t+1e-8>=a.next){a.next+=cfg.zoneTick;for(const f of bodies)if(f!==a.owner&&f.hp>0&&narutoHead(narutoScratch.c,f).distanceTo(a.p)<a.radius)hurt(f,charged(cfg.cutting,a.q)/(cfg.zoneTime/cfg.zoneTick),a.owner,'special',V(),.15);}
 if(a.t>=a.duration){for(const f of bodies){if(f===a.owner||f.hp<=0)continue;const d=narutoHead(narutoScratch.c,f).distanceTo(a.p);if(d<a.radius)narutoImpact(a.owner,f,charged(cfg.burst,a.q),headPos(f).sub(a.p).normalize(),14,6,4);}narutoFX('windBurst',a.p,a.radius,a.dir);destroyAt(a.p,a.radius,65);return true;}return false;
}
function resetNaruto(){
 for(const f of actorPool){resetNarutoMobility(f);f.narutoAction=null;f.narutoSlamImpact=false;if(f.narutoAnim){f.narutoAnim.last.copy(f.pos);f.narutoAnim.initialized=false;}}
 narutoReplicas.clear();narutoReplicaAge=0;narutoFreeze=0;clearNarutoVisuals();
}
// Finish only the presentation after a winner is decided; no post-match hits.
function finishNarutoPresentation(dt){
 for(const f of bodies)cancelNarutoMobility(f);
 for(let i=techniques.length-1;i>=0;i--){const a=techniques[i];if(a.type!=='naruto'&&a.type!=='naruto-wind')continue;
  if(a.type==='naruto'){if(!a.finished){a.finished=true;a.t=Math.max(a.t,a.duration-NARUTO.moves[a.kind].recovery);a.hit=true;}a.t+=dt;if(a.cancelled||a.t>=a.duration){if(a.owner.narutoAction===a)a.owner.narutoAction=null;techniques.splice(i,1);}}
  else{a.t+=dt;if(a.t>=a.duration)techniques.splice(i,1);}
 }
 for(let i=projectiles.length-1;i>=0;i--)if(projectiles[i].type.startsWith('naruto-'))projectiles.splice(i,1);
 if(cinematic?.type==='naruto')cinematic.t=Math.max(cinematic.t,cinematic.duration-.65);
}
function packNaruto(){return techniques.filter(a=>!a.cancelled&&(a.type==='naruto'||a.type==='naruto-wind')).map(a=>({id:a.id,type:a.type,owner:a.owner.id,kind:a.kind,q:a.q,t:a.t,duration:a.duration,p:vec(a.p),dir:vec(a.dir),origin:vec(a.origin||a.p),targetPos:vec(a.targetPos||a.p),cloneEnds:(a.cloneEnds||[]).map(vec),hit:!!a.hit}));}
function validNaruto(s,ids){return Array.isArray(s)&&s.length<=24&&new Set(s.map(a=>a?.id)).size===s.length&&s.every(a=>a&&Number.isSafeInteger(a.id)&&ids.has(a.owner)&&actorById(a.owner)?.character==='naruto'&&['naruto','naruto-wind'].includes(a.type)&&Number.isInteger(a.kind)&&a.kind>=1&&a.kind<=5&&Number.isFinite(a.q)&&a.q>=0&&a.q<=1&&Number.isFinite(a.t)&&a.t>=0&&a.t<=5&&Number.isFinite(a.duration)&&a.duration>0&&a.duration<=5&&[a.p,a.dir,a.origin,a.targetPos].every(validVector)&&Array.isArray(a.cloneEnds)&&a.cloneEnds.length===(a.kind===1?3:0)&&a.cloneEnds.every(validVector)&&typeof a.hit==='boolean');}
function receiveNaruto(s){
 narutoReplicaAge=0;for(const f of bodies)f.narutoAction=null;const live=new Set();
 for(const wire of s){live.add(wire.id);let a=narutoReplicas.get(wire.id);if(!a){a={p:V(),dir:V(),origin:V(),targetPos:V(),cloneEnds:wire.cloneEnds.map(()=>V())};narutoReplicas.set(wire.id,a);}for(const k of ['id','type','kind','q','t','duration','hit'])a[k]=wire[k];a.owner=actorById(wire.owner);for(const k of ['p','dir','origin','targetPos'])a[k].fromArray(wire[k]);for(let i=0;i<a.cloneEnds.length;i++)a.cloneEnds[i].fromArray(wire.cloneEnds[i]);if(a.type==='naruto')a.owner.narutoAction=a;else a.radius=lerp(4.5,NARUTO.moves[4].zoneRadius,a.q);}
 for(const [id]of narutoReplicas)if(!live.has(id))narutoReplicas.delete(id);
 if(cinematic?.type==='naruto'){const a=cinematic.owner.narutoAction;cinematic.t=Math.max(cinematic.t,a?.kind===5&&phase==='play'?a.t:cinematic.duration-.65);}
}
function narutoManual(){return '<p><kbd>1</kbd> Shadow Clone Barrage: three clones rush along your facing direction, then Naruto strikes.<br><kbd>2</kbd> Uzumaki Combo: dash, punch, spinning kick, uppercut, then a downward axe kick.<br><kbd>3</kbd> Rasengan: form a chakra sphere and lunge up to 16m.<br><kbd>4</kbd> Rasenshuriken: throw spinning wind blades up to 96m; impact leaves a 1.2s cutting zone.<br>Hold each special for more damage; full charge releases automatically after 3 seconds. Specials penetrate guard; a dodge can avoid them. Taking damage interrupts Naruto before a projectile is released.<br><kbd>5</kbd> Nine-Tails Chakra Mode into Tailed Beast Bomb: 45 chakra + 30% ultimate, 12s shared cooldown, 2.1s vulnerable startup.<br><kbd data-bind="domain">Q</kbd> Mindscape: Kurama’s Cage. Full ultimate meter, the existing domain/clash rules, and three stages. Early seal: weak clash pressure. Mid seal: stronger Kurama bonus. Six clones assault each trapped opponent with combos, Rasengan, Rasenshuriken and smaller Tailed Beast Bombs; Kurama feeds them chakra from behind the cage. Guard reduces domain damage by 45%. Shadow clones add a fragile clash bonus while they survive.<br>After any domain ends, its caster has 15 seconds of technique burnout. Ground jumps are free. Jump again for Clone Boost: 5 chakra, no cooldown or airtime cap; hold Jump up to 1.2s for a farther boost; auto-release at full charge. Hold Sprint and a direction to carry sprint speed. Dodge becomes Chakra Dash: 7.5m, 14 stamina + 4 chakra, 1.5s cooldown. Successfully avoiding a hit leaves a smoke puff and substitution log. Sprint toward a wall while airborne to stick and run up or along it; 8 stamina/s total, with no fixed duration or chakra cost. Wall sprint matches ground sprint. Jump off a wall in your camera aim direction, including up or down, for a stronger free regular jump without spending a clone. Naruto cannot fly. Four light hits deal 75 total. Chakra uses the existing energy bar and recharge controls.</p>';}
