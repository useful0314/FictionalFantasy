// Slot 5 uses the existing shared cooldown, energy/ultimate bars and host simulation.
const WORLD_CUT={cost:60,ultCost:50,damage:420,cooldown:16,startup:1.45,active:.30,recovery:.50,speed:180,range:140,halfWidth:4.5,halfHeight:11,knock:28,lift:8,shake:1.05,hitstop:.065,scarLife:35,scarPool:12,colors:{edge:0xff4069,core:0x030207,rim:0xffd6e5}};
const worldCutScars=Array.from({length:WORLD_CUT.scarPool},()=>({id:0,active:false,t:0,from:V(),to:V()}));
let worldCutScarCursor=0,worldCutReplicaAge=0,worldCutVisuals=null;
const worldCutScratch={from:V(),delta:V(),right:V(),up:V(),knock:V(),point:V(),normal:V(0,1,0)};
function worldCutBusy(f){return !!f.worldCut&&!f.worldCut.cancelled;}
function worldCutAge(a){return a.t+(mode==='online'&&net?.role==='guest'?worldCutReplicaAge:0);}
function castWorldCut(f){
 if(techniqueBurnedOut(f,true))return false;
 const c=WORLD_CUT;if(f.character!=='sukuna'||phase!=='play'||f.hp<=0||f.stun>0||f.ragdollT>0||f.recovery>0||f.dodge>0||worldCutBusy(f)||narutoBusy(f)||castFor(f)||trappedByVoid(f)||(f.attackIsLight&&f.attack>.08)||f.cooldown>0)return false;
 if(f.energy<c.cost||f.ult<c.ultCost){if(f===player)toast('World Cutting Slash needs 60 cursed energy + 50% ultimate',2);return false;}
 f.energy-=c.cost;f.ult-=c.ultCost;cancelCharge(f);f.block=false;f.energyCharging=false;f.attackIsLight=false;f.attack=f.attackMax=c.startup+c.active+c.recovery;f.cooldown=c.cooldown;
 const a={id:++techniqueSerial,type:'world-cut-cast',owner:f,t:0,dir:aimFor(f).normalize(),launched:false,cancelled:false};f.worldCut=a;techniques.push(a);sfx('slash',f.pos,.5);if(f===player)toast('WORLD CUTTING SLASH · forming the sign',1.4);return true;
}
function interruptWorldCut(f){const a=f.worldCut;if(!a)return;a.cancelled=true;f.worldCut=null;f.attack=0;}
function clearWorldCutScars(){for(const s of worldCutScars)s.active=false;if(worldCutVisuals)for(const s of worldCutVisuals.scars)s.g.visible=false;}
function resetWorldCut(){for(const f of bodies)interruptWorldCut(f);clearWorldCutScars();worldCutScarCursor=worldCutReplicaAge=0;if(worldCutVisuals){for(const v of worldCutVisuals.shots)v.g.visible=false;for(const v of worldCutVisuals.casts)v.g.visible=false;}}
function newWorldCutScar(id){const s=worldCutScars[worldCutScarCursor++%WORLD_CUT.scarPool];s.id=id;s.active=false;s.t=0;s.from.set(0,0,0);s.to.set(0,0,0);return s;}
function updateWorldCutAction(a,dt){
 const f=a.owner,c=WORLD_CUT;if(a.cancelled||f.hp<=0||phase!=='play'){if(f.worldCut===a)f.worldCut=null;return true;}a.t+=dt;
 if(!a.launched&&a.t>=c.startup){
  a.launched=true;const p=headPos(f).addScaledVector(a.dir,1.8),shot={id:++techniqueSerial,type:'world-cut',owner:f,p,dir:a.dir.clone(),right:V(),up:V(),q:1,t:0,travelled:0,hitIds:new Set(),scar:null};worldCutBasis(shot.dir,shot.right,shot.up);shot.scar=newWorldCutScar(shot.id);projectiles.push(shot);
  slashRibbon(p,a.dir,c.colors.edge,8,.35,Math.PI/2);sfx('slash',p,1.6);sfx('burst',p,.75);shakeIt(.6,p,a.dir);flashIt(.13);
 }
 if(a.t>=c.startup+c.active+c.recovery){if(f.worldCut===a)f.worldCut=null;return true;}return false;
}
function worldCutBasis(dir,right,up){right.set(-dir.z,0,dir.x);if(right.lengthSq()<.001)right.set(1,0,0);else right.normalize();up.crossVectors(right,dir).normalize();}
function updateWorldCutProjectile(p,dt){
 const c=WORLD_CUT,s=worldCutScratch;if(phase!=='play'||p.owner.hp<=0)return true;
 s.from.copy(p.p);const horizontal=p.dir.x*p.dir.x+p.dir.z*p.dir.z,alongEdge=s.from.x*p.dir.x+s.from.z*p.dir.z,edgeC=s.from.x*s.from.x+s.from.z*s.from.z-WORLD.radius*WORLD.radius,arenaExit=horizontal>.000001?Math.max(0,(-alongEdge+Math.sqrt(Math.max(0,alongEdge*alongEdge-horizontal*edgeC)))/horizontal):Infinity;const wanted=Math.min(c.speed*dt,c.range-p.travelled),barrier=barrierRayDistance(s.from,p.dir,wanted),ground=p.dir.y<-.001?Math.max(0,(.2-s.from.y)/p.dir.y):Infinity,travel=Math.max(0,Math.min(wanted,barrier,ground,arenaExit));
 p.t+=dt;p.p.addScaledVector(p.dir,travel);p.travelled+=travel;
 for(const f of bodies){if(f===p.owner||f.hp<=0||p.hitIds.has(f.id))continue;s.delta.copy(f.pos);s.delta.y+=1.1;s.delta.sub(s.from);const along=s.delta.dot(p.dir);
  if(along<-.85||along>travel+.85||Math.abs(s.delta.dot(p.right))>c.halfWidth+.6||Math.abs(s.delta.dot(p.up))>c.halfHeight+1.1)continue;
  p.hitIds.add(f.id);s.knock.copy(p.dir).multiplyScalar(c.knock);s.knock.y+=c.lift;
  if(hurt(f,c.damage,p.owner,'special',s.knock,3)){narutoFreeze=Math.max(narutoFreeze,c.hitstop);netFX('narutoStop',[c.hitstop]);shakeIt(c.shake,f.pos,p.dir);narutoFX('impact',headPos(f),4,p.dir);}
 }
 for(const part of pieces){if(!arenaPieceActive(part))continue;s.delta.copy(part.pos).sub(s.from);const hx=part.size.x*.5,hy=part.size.y*.5,hz=part.size.z*.5,along=s.delta.dot(p.dir),extent=Math.abs(p.dir.x)*hx+Math.abs(p.dir.y)*hy+Math.abs(p.dir.z)*hz;
  if(along < -extent||along>travel+extent)continue;
  const rw=Math.abs(p.right.x)*hx+Math.abs(p.right.y)*hy+Math.abs(p.right.z)*hz,uh=Math.abs(p.up.x)*hx+Math.abs(p.up.y)*hy+Math.abs(p.up.z)*hz;
  if(Math.abs(s.delta.dot(p.right))<=c.halfWidth+rw&&Math.abs(s.delta.dot(p.up))<=c.halfHeight+uh)breakPiece(part,p.dir,s.from);
 }
 // The arena keeps its solid floor. Reused recessed shading and broken stone rims mark the tear.
 if(travel>0&&Math.min(s.from.y,p.p.y)<c.halfHeight+.5){const scar=p.scar;if(!scar.active){scar.active=true;scar.from.copy(s.from).setY(.15);}scar.to.copy(p.p).setY(.15);scar.t=0;}
 if(ground<=wanted&&p.scar.active&&p.scar.from.distanceToSquared(p.scar.to)<.1){p.scar.from.copy(p.p).addScaledVector(p.right,-c.halfHeight).setY(.15);p.scar.to.copy(p.p).addScaledVector(p.right,c.halfHeight).setY(.15);}
 const skimming=ground<=wanted&&p.dir.y>-.35;if(skimming){p.dir.setY(0).normalize();worldCutBasis(p.dir,p.right,p.up);p.p.y=.2;}
 if(Number.isFinite(barrier)&&barrier<=wanted||ground<=wanted&&!skimming||arenaExit<=wanted||p.travelled>=c.range-1e-6){shock(p.p,c.colors.edge,5,.35);sfx('slash',p.p,.65);return true;}return false;
}
function ageWorldCutScars(dt){if(phase==='pause'||phase==='result')return;for(const s of worldCutScars)if(s.active){s.t+=dt;if(s.t>=WORLD_CUT.scarLife)s.active=false;}}
function packWorldCut(){return {casts:techniques.filter(a=>a.type==='world-cut-cast'&&!a.cancelled).map(a=>({id:a.id,owner:a.owner.id,t:a.t,dir:vec(a.dir),launched:a.launched})),scars:worldCutScars.filter(s=>s.active).map(s=>({id:s.id,t:s.t,from:vec(s.from),to:vec(s.to)}))};}
function validWorldCut(data,ids){
 const id=x=>Number.isSafeInteger(x)&&x>0,age=(x,max)=>Number.isFinite(x)&&x>=0&&x<=max;
 return !!data&&Array.isArray(data.casts)&&data.casts.length<=6&&new Set(data.casts.map(a=>a?.owner)).size===data.casts.length&&data.casts.every(a=>a&&id(a.id)&&ids.has(a.owner)&&actorById(a.owner).character==='sukuna'&&age(a.t,WORLD_CUT.startup+WORLD_CUT.active+WORLD_CUT.recovery+.05)&&validVector(a.dir)&&Math.abs(Math.hypot(...a.dir)-1)<.01&&typeof a.launched==='boolean')&&Array.isArray(data.scars)&&data.scars.length<=WORLD_CUT.scarPool&&data.scars.every(s=>s&&id(s.id)&&age(s.t,WORLD_CUT.scarLife)&&validVector(s.from)&&validVector(s.to)&&Math.hypot(s.to[0]-s.from[0],s.to[2]-s.from[2])<=WORLD_CUT.range+.1);
}
function receiveWorldCut(data){
 worldCutReplicaAge=0;for(const f of bodies)f.worldCut=null;
 for(const a of data.casts){const f=actorById(a.owner);f.worldCut={...a,owner:f,dir:V(...a.dir)};}
 for(let i=0;i<worldCutScars.length;i++){const s=worldCutScars[i],a=data.scars[i];s.active=!!a;if(a){s.id=a.id;s.t=a.t;s.from.fromArray(a.from);s.to.fromArray(a.to);}}
}
const worldCutPoseCache={arms:[V(),V(),V(),V()],elbows:[0,0,0,0],knees:[.25,.3],legs:[-.16,.18],lean:0,twist:0,bob:0,headTurn:0};
function worldCutPose(f){
 if(!worldCutBusy(f))return null;const p=worldCutPoseCache,c=WORLD_CUT,t=worldCutAge(f.worldCut),wind=narutoEase(t/.38),snap=narutoBack((t-c.startup)/.17),recovery=1-narutoEase((t-c.startup-c.active)/c.recovery),q=wind*recovery;
 p.arms[0].set(lerp(.12,-1.02-.7*snap,q),.2*q,(-.25+.95*snap)*q);p.arms[1].set(lerp(.12,-1.02-.55*snap,q),-.2*q,(.25-.85*snap)*q);p.arms[2].set(-.18-.65*q,0,.2*q);p.arms[3].set(-.18-1.35*q-.35*snap*q,-.1*q,-.3*q);
 p.elbows[0]=p.elbows[1]=lerp(-.25,-1.8+1.65*snap,q);p.elbows[2]=lerp(-1,-1.6,q);p.elbows[3]=lerp(-1,-1.5+1.35*snap,q);p.lean=(-.10+.26*snap)*q;p.twist=(-.38+.95*snap)*q;p.bob=(-.1+.16*snap)*q;p.headTurn=-.2*q;return p;
}
