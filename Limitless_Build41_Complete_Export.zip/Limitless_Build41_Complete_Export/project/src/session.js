// Shared keyboard / touch / gamepad input and the online presentation layer.
const INPUT_CODES={forward:'KeyW',back:'KeyS',left:'KeyA',right:'KeyD',sprint:'ShiftLeft',jump:'Space',fly:'KeyF',descend:'ControlLeft',light:'Mouse0',guard:'Mouse2',dodge:'KeyE',energy:'KeyC',special1:'Digit1',special2:'Digit2',special3:'Digit3',special4:'Digit4',special5:'Digit5',special6:'Digit6',domain:'KeyQ'};
function syncControlCopy(){
 if(!controls)return;syncCameraHUD();updateSelectionPresentation();
 // Dynamic kit descriptions use the same saved bindings as the actual input router.
 const hint=$('helpTechniques');let html=hint.innerHTML||'';for(let i=1;i<=6;i++)html=html.replace('<kbd>'+i+'</kbd>','<kbd data-bind="special'+i+'">'+controls.label('special'+i)+'</kbd>');hint.innerHTML=html;
 $('flightHint').innerHTML='<kbd data-bind="jump">'+controls.label('jump')+'</kbd> '+(player.character==='gojo'?'Jump ':'Air jump · 3 energy ')+(player.character==='gojo'?'<kbd data-bind="fly">'+controls.label('fly')+'</kbd> Levitate':'<kbd data-bind="special4">'+controls.label('special4')+'</kbd> Cursed Rush');
 for(const el of document.querySelectorAll('[data-bind]'))el.textContent=controls.label(el.dataset.bind);
 for(const el of document.querySelectorAll('[data-action]')){if(el.dataset.action==='jump')el.textContent=player.character==='sukuna'?'AIR JUMP':player.character==='naruto'?'JUMP / BOOST':'JUMP';if(el.dataset.action==='fly'||el.dataset.action==='descend')el.style.display=player.character==='gojo'||(player.character==='mahito'&&el.dataset.action==='descend')?'':'none';}
 const chosen=KITS[phase==='menu'?selectedCharacter:player.character];
 if(player.character==='spiderman')$('flightHint').innerHTML='<kbd>'+controls.label('special4')+'</kbd> Hold to swing / slide · let go to release · <kbd>'+controls.label('jump')+'</kbd> Release swing / toss cocoon upward';
 if(player.character==='mahito')$('flightHint').innerHTML='<kbd>'+controls.label('jump')+'</kbd> Jump / winged ascend · <kbd>'+controls.label('descend')+'</kbd> Winged descend';
 if(player.character!=='naruto')$('flightHint').innerHTML+='<br><kbd>'+controls.label('sprint')+'</kbd> + move into wall · Wall Run · '+controls.label('jump')+' to kick off';
 if(player.character==='naruto')$('flightHint').innerHTML='<kbd data-bind="jump">'+controls.label('jump')+'</kbd> Hold up to 1.2s · Clone Boost: 5 chakra · no jump limit · free wall jump<br><kbd data-bind="sprint">'+controls.label('sprint')+'</kbd> + move into wall · Wall Run';
 $('comboInstructions').textContent=chosen===KITS.spiderman?'1: pull / air chase · 2: combo / air slam · 3: catch, aim, tap to throw · hold 4 to swing / ground-slide; let go to release.':chosen===KITS.mahito?'1 cycles arm weapons; normal attack uses the selected weapon. 5 cycles temporary body forms. 6 spends 20% ultimate on Cursed Touch; Q expands your domain.':chosen===KITS.naruto?'Tap or hold '+controls.label('special1')+'–'+controls.label('special4')+' for ninja techniques. '+controls.label('domain')+' expands Mindscape; '+controls.label('special5')+' fires Tailed Beast Bomb for 45 chakra + 30% ultimate.':chosen===KITS.gojo?'Hold '+controls.label('special1')+', release, then tap again to anchor Blue. Aim '+controls.label('special2')+' at its center. 60–115m blast radius. Survive the three-second fusion.':'Hold '+controls.label('special4')+' to rush into range. Hold '+controls.label('special2')+' for a close cutting barrage. Hold '+controls.label('special3')+' for a fire arrow, then tap again to detonate. Charge two different moves together. '+controls.label('special5')+' uses World Cutting Slash: 60 energy + 50% ultimate.';
 for(let i=1;i<=4;i++)$('touchName'+i).textContent=(player.character==='spiderman'?['','YANK','COMBO','COCOON','HOLD SWING']:player.character==='mahito'?['','ARMS','HUMANS','SERPENT','HEAL']:player.character==='naruto'?['','CLONES','COMBO','RASENGAN','SHURIKEN']:player.character==='gojo'?['','BLUE','RED','PURPLE','SHIFT']:['','DISMANTLE','CLEAVE','FURNACE','RUSH'])[i];
}

// Persistent field contours make the attraction radius and fusion countdown readable.
const fieldVisuals=new THREE.Group();scene.add(fieldVisuals);
const fieldRings=Array.from({length:3},(_,i)=>{const ring=mesh(new THREE.TorusGeometry(1,.008+i*.004,4,128),new THREE.MeshBasicMaterial({color:C.blue,transparent:true,opacity:.25,depthWrite:false,blending:THREE.AdditiveBlending}),fieldVisuals);ring.rotation.x=Math.PI/2;return ring;});
const fieldSparks=mesh(new THREE.TorusGeometry(1,.009,4,96,Math.PI*1.6),new THREE.MeshBasicMaterial({color:C.purple,transparent:true,opacity:.5,depthWrite:false,blending:THREE.AdditiveBlending}),fieldVisuals);fieldSparks.rotation.x=Math.PI/2;
function updateFieldVisuals(dt){fieldVisuals.visible=false;updateDangerVolumes();}

function netFX(type,args){if(!replaying&&net?.role==='host'&&mode==='online'&&netEvents.length<150)netEvents.push([type,args]);}
function sfx(name,pos=player.pos,strength=1,replicate=true){const d=pos.clone().sub(headPos(player)),right=V(Math.cos(yaw),0,-Math.sin(yaw));sound.play(name,strength/(1+d.length()*.025),clamp(d.dot(right)/15,-.9,.9));if(replicate)netFX('sound',[name,pos.toArray(),strength]);}
function actionFor(f,action,down,webView=null,fromBuffer=false){
 const held=inputFor(f),code=INPUT_CODES[action];if(code){if(down)held.add(code);else held.delete(code);}
 if(!down){releaseBufferedAction(f,action);if(action==='jump'&&f.character==='naruto')releaseNarutoBoost(f);if(action.startsWith('special'))releaseCharge(+action.slice(-1),f);return;}
 if(phase!=='play'||countdown>0||f.hp<=0)return;
 if(!fromBuffer&&(['jump','dodge','light'].includes(action)||action.startsWith('special'))){clearBufferedAction(f);if(bufferAction(f,action,webView))return;}
 if(action==='fly'&&f.stun<=0&&!chargeFor(f)&&(f.flying||f.energy>0)&&f.character==='gojo'&&!castFor(f)&&!trappedByVoid(f)){f.flying=!f.flying;if(f.flying){if(f.narutoMobility?.kind===3||f.narutoMobility?.kind===4||f.narutoMobility?.wallExit>0)f.vel.x=f.vel.z=0;cancelNarutoMobility(f);if(f.narutoMobility)f.narutoMobility.wallExit=0;f.grounded=false;f.vel.y=3;}sfx('teleport',f.pos,.3);}
 if(action==='jump')jumpFighter(f);
 if(action==='dodge')dodge(f);if(action==='domain')castDomain(f);
 if(action==='light'){lightAttack(f);f.autoHit=.36;}
 if(action.startsWith('special'))startCharge(+action.slice(-1),f,webView);
}
function onAction(action,down,source){
 if(source==='clear'){clearBufferedAction(player);localInputClear=true;}
 if(action==='cursor'){
  if(down&&(phase!=='play'||menuOpen||controls?.layoutEditing))return;
  if(options.cursorBehavior==='hold')setCursorMode(down,source!=='clear');else if(down)setCursorMode(!cursorFree);return;
 }
 if(action==='orbitView'){if(down&&phase==='play'&&!menuOpen)setCharacterView(!options.freeOrbit);return;}
 if(action==='pause'){if(down)backFromPanel();return;}
 if(action==='help'){if(down){if(!$('help').classList.contains('hidden'))closeHelp();else showHelp();}return;}
 if(action==='lock'){if(down&&phase==='play'&&!menuOpen)lockOn=!lockOn;return;}
 if(down&&(phase!=='play'||menuOpen||countdown>0))return;
 if(mode==='online'&&net?.role==='guest'){
  if(INPUT_CODES[action]){const edge=[action,down];if(action==='special4'&&down&&player.character==='spiderman')edge.push(captureSpiderView());localEdges.push(edge);sendInputs();}
 }else actionFor(player,action,down);
}
let localInputClear=false;
function sendInputs(){if(net?.role!=='guest'||mode!=='online')return;const held=Array.from(controls.held).filter(a=>window.ArenaNet.actions.has(a));net.input({clear:menuOpen||localInputClear,held:menuOpen?[]:held,edges:localEdges.splice(0,32),yaw,pitch,move:menuOpen?[0,0]:[controls.move.x,controls.move.y]});localInputClear=false;}
function receiveInput(d,id=enemy.id){
 const f=actorById(id);if(!f||f===player||f.bot||f.hp<=0)return;const input=f.input;input.yaw=d.yaw;input.pitch=d.pitch;input.move={x:d.move[0],y:d.move[1]};input.lastAt=performance.now();
 if(d.clear){clearBufferedAction(f);cancelCharge(f);if(f.spider?.action?.kind===4)stopSpider(f,true);input.keys.clear();input.held.clear();input.move={x:0,y:0};f.block=false;return;}
 for(const [action,down,webView]of d.edges)actionFor(f,action,down,webView);for(const action of input.held)if(!d.held.includes(action))actionFor(f,action,false);
 input.held=new Set(d.held);input.keys.clear();for(const action of d.held)input.keys.add(INPUT_CODES[action]);
}
function showSettings(){if(phase==='play')pause();$('menu').classList.add('hidden');$('settingsPanel').classList.remove('hidden');controls.capture=null;controls.buildBindings();$('settingsClose').focus?.();}
function backFromPanel(){
 if(controls?.layoutEditing){controls.editLayout(false);return;}
 if(controls?.capture){controls.capture=null;controls.buildBindings();return;}
 if(!$('settingsPanel').classList.contains('hidden')){$('settingsPanel').classList.add('hidden');$('menu').classList.remove('hidden');return;}
 if(!$('help').classList.contains('hidden')){closeHelp();return;}
 if(!$('onlinePanel').classList.contains('hidden')){leaveOnline();return;}
 if(menuOpen||phase==='pause')resume();else if(phase==='play')pause();
}
function saveOptions(){try{localStorage.setItem('limitless.settings.v3',JSON.stringify(options));}catch{}}
function setQuality(){const mobile=window.matchMedia?.('(pointer: coarse)').matches||innerWidth<850,low=options.quality==='performance'||(options.quality==='auto'&&mobile);renderer.setPixelRatio(Math.min(devicePixelRatio,low?1:1.5));renderer.shadowMap.enabled=!low;particleBudget=low?700:2400;ambientDust.visible=!low;options.bloom=low?false:$('bloomToggle').checked;renderer.setSize(innerWidth,innerHeight);resizePost();pm.uniforms.ratio.value=renderer.getPixelRatio();resetAdaptiveQuality();}
function syncCameraHUD(){
 const active=phase==='play'&&!menuOpen,free=active&&cursorFree,orbit=active&&options.freeOrbit;
 document.body.classList.toggle('cursor-mode',free);document.body.classList.toggle('character-view',orbit);
 $('cursorButtonLabel').textContent=free?'RETURN TO AIM':'CURSOR';$('cursorButton').setAttribute('aria-pressed',String(free));
 $('cameraModeHint').classList.toggle('hidden',!free&&!orbit);
 $('cameraModeHint').textContent=orbit?'CHARACTER VIEW · '+(free?'drag arena':'move mouse')+' to orbit · wheel to zoom · '+(controls?.label('orbitView')||'V')+' to exit':free?'CURSOR FREE · drag arena to orbit · wheel to zoom · click practice buttons · '+(controls?.label('cursor')||'L Alt')+' to return':'';
}
function setCursorMode(enabled,lock=true){
 if(cursorFree===enabled)return;cursorFree=enabled;dragLook=false;cameraOrbit.active=false;
 if(enabled){clearBufferedAction(player);localInputClear=true;cancelCharge(player);controls?.releaseAll(['cursor','orbitView']);keys.clear();player.block=false;document.exitPointerLock?.();}
 else if(lock)requestLock();syncCameraHUD();
}
function setCharacterView(enabled){
 clearBufferedAction(player);localInputClear=true;options.freeOrbit=!!enabled;$('freeOrbit').checked=options.freeOrbit;cameraOrbit.active=false;
 cancelCharge(player);controls?.releaseAll(['cursor','orbitView']);keys.clear();player.block=false;syncCameraHUD();saveOptions();
}
function cameraLook(x,y){
 if(phase!=='play'||menuOpen)return;
 if(cameraOrbit.active||options.freeOrbit){cameraOrbit.yaw=THREE.MathUtils.euclideanModulo(cameraOrbit.yaw-x+Math.PI,Math.PI*2)-Math.PI;cameraOrbit.pitch=clamp(cameraOrbit.pitch+y,-1.45,airborneLook(player)?1.52:1.2);}
 else if(!lockOn){yaw-=x;pitch=clamp(pitch+y,-1.45,airborneLook(player)?1.52:1.2);}
}
function cameraWheel(e){
 if((!options.wheelCamera&&!options.freeOrbit&&!cursorFree)||phase!=='play'||menuOpen||!Number.isFinite(e.deltaY))return false;
 const delta=clamp(e.deltaY*(e.deltaMode===1?16:e.deltaMode===2?innerHeight:1),-120,120),zoom=cursorFree||options.freeOrbit||((options.wheelMode==='zoom')!==!!e.shiftKey);
 if(zoom){options.camDistance=clamp(options.camDistance+delta*.012,3,16);$('camDistance').value=options.camDistance;}
 else options.camTilt=clamp(options.camTilt+delta*.002,-.45,.75);saveOptions();return true;
}
controls=new window.ArenaControls({action:onAction,changed:syncControlCopy,playing:()=>phase==='play'&&!menuOpen&&!controls?.layoutEditing,mouseEnabled:()=>!cursorFree&&!options.freeOrbit,orbit:active=>{if(!options.wheelCamera&&!options.freeOrbit)return false;cameraOrbit.active=active;return true;},wheel:cameraWheel,layoutChanged:active=>{$('settingsPanel').classList.toggle('hidden',active);},look:cameraLook,unlock:()=>sound.unlock(),back:backFromPanel});

function lobbyUI(){
 if(!net)return;const hosting=net.role==='host',connected=net.state==='lobby';
 $('roomMap').textContent='ARENA · '+ARENA_MAPS[net.arena||selectedMap].name.toUpperCase();$('roomCode').textContent=net.code||'— — — —';$('roomCodeWrap').classList.toggle('hidden',!net.role);$('roomReady').disabled=!connected||!net.handshake;$('roomReady').textContent=net.ready?'READY · WAITING FOR PLAYERS':'I’M READY';
 $('roomCharacter').value=net.character||selectedCharacter;$('roomCharacter').disabled=!connected;$('roomBots').disabled=!hosting||!connected;$('roomDifficulty').disabled=!hosting||!connected;
 const bots=net.roster.filter(f=>f.bot);$('roomBots').value=String(bots.length);$('roomDifficulty').value=bots[0]?.difficulty||matchSetup.difficulty;
 $('roomRoster').replaceChildren();for(const f of net.roster){const row=document.createElement('div');row.className='roomFighter';const name=document.createElement('b');name.textContent=f.id.toUpperCase()+' · '+(f.id===net.localId?'YOU':f.bot?'AI':'PLAYER');const detail=document.createElement('span');detail.textContent=KITS[f.character].short+' · '+(f.bot?f.difficulty.toUpperCase():f.ready?'READY':'NOT READY');row.append(name,detail);if(f.bot&&hosting&&connected){const select=document.createElement('select');for(const character of Object.keys(KITS)){const option=document.createElement('option');option.value=character;option.textContent=KITS[character].short;select.append(option);}select.value=f.character;select.onchange=()=>net.configureBots(bots.map(b=>b.id===f.id?select.value:b.character),$('roomDifficulty').value);row.append(select);}$('roomRoster').append(row);}
 $('createRoom').disabled=!!net.role;$('joinRoom').disabled=!!net.role;
}
function beginOnline(character,arena='district'){
 selectedMap=ARENA_MAPS[arena]?arena:'district';syncMapUI();selectedCharacter=character;clearReplicas();resetMatch('online');countdown=3;replicaKey='';replicaState=null;lastRemoteCutout='';
 syncCharacterUI();$('matchMode').textContent='PRIVATE FREE-FOR-ALL · '+bodies.length+' FIGHTERS';$('modeHint').textContent='LAST FIGHTER STANDING';$('drillButton').classList.add('hidden');$('resetButton').classList.add('hidden');$('rematchButton').textContent='REQUEST REMATCH';$('rematchButton').disabled=false;
 camPos.copy(player.pos).addScaledVector(forward(false),-7).add(V(0,3,0));sound.unlock();announce('PRIVATE FREE-FOR-ALL','GET READY',3);requestLock();
}
function leaveOnline(){resetMahito();resetWorldCut();resetDomainCinema();mindscapeEnd=null;if(mindscapePool)mindscapePool.g.visible=mindscapePool.shards.visible=false;resetNaruto();clearFinisher();net.close();sound.stopCues();clearCombatVisuals();cancelCharge();cancelCharge(enemy);remoteCharge=null;controls.releaseAll();sound.setClash(false);clearReplicas();replicaState=null;mode='duel';phase='menu';menuOpen=false;countdown=0;cancelCharge();cancelCharge(enemy);clearDomainVisual();domain=clash=null;['onlinePanel','help','settingsPanel','result','hud'].forEach(id=>$(id).classList.add('hidden'));$('menu').classList.remove('hidden');$('resumeButton').classList.add('hidden');$('drillButton').classList.remove('hidden');$('resetButton').classList.remove('hidden');$('rematchButton').textContent='REMATCH';$('rematchButton').disabled=false;for(const f of bodies){cancelCharge(f);f.root.visible=f.shadow.visible=false;}bodies.splice(2);clearFields();clearDomainCutouts();assignRigs();syncCharacterUI();}
net=new window.ArenaNet({status:(text,state)=>{$('onlineStatus').textContent=text;$('onlineStatus').dataset.state=state;lobbyUI();},room:lobbyUI,lobby:lobbyUI,start:beginOnline,input:receiveInput,snapshot:receiveState,
 disconnected:message=>{if(mode==='online')leaveOnline();$('menu').classList.add('hidden');$('onlinePanel').classList.remove('hidden');$('onlineStatus').textContent=message;$('onlineStatus').dataset.state='error';lobbyUI();},
 departed:id=>{const f=actorById(id);if(f&&f.hp>0&&phase==='play'){f.hp=0;eliminateFighter(f,other(f));}},
 rematch:()=>{$('rematchButton').textContent=net.localRematch?'WAITING FOR PLAYERS…':'REQUEST REMATCH';$('rematchButton').disabled=!!net.localRematch;}});

// State contains only explicitly selected game fields. Guests never submit state.
const numberFields=['lightOutcome','lightOutcomeTime','mahitoArm','mahitoForm','mahitoFormTime','soulSlot','soulTime','techniqueBurnout','hp','stamina','energy','ult','stun','dodge','dodgeCooldown','dodgeWindow','attack','attackMax','attackKind','combo','comboTimer','blockTime','score','damageTaken','hitReact','chargeTime','releasePose','comboHits','comboLock','counterWindow','guardReact','ragdollT','ragdollAge','ragdollMax','ragdollSpin','recovery','airJumpCooldown','jumpPose','jumpSide','ragdollBounces','ragdollPitch','ragdollRoll','ragdollYaw','ragdollRate','launchImpactCD','redRecoil','castVoiceId','castVoiceAge','specialKind','specialAge','specialDuration','specialPower','auxSpecialKind','auxSpecialAge','auxSpecialDuration','auxSpecialPower'];
const boolFields=['emergency','grounded','flying','block','energyCharging','attackCounter','attackIsLight','attackAir','sprinting','ragdollGround','castVoiceActive'];
const vec=v=>v.toArray().map(n=>Math.round(n*1000)/1000),who=f=>f.id;
function packFighter(f){const input=f.input||remoteInput,o={id:f.id,character:f.character,pos:vec(f.pos),vel:vec(f.vel),aim:f===player?[yaw,pitch]:[input.yaw,input.pitch],charge:packCharge(f),aux:packCharge(f,f.auxCharge||null),cast:packCast(castFor(f)),mobility:packNarutoMobility(f),spider:packSpider(f),mahitoAction:packMahitoAction(f)};for(const k of numberFields)o[k]=Number.isFinite(f[k])?Math.round(f[k]*1000)/1000:0;for(const k of boolFields)o[k]=!!f[k];return o;}
function packCast(c){return c?{id:c.id,t:c.t,origin:vec(c.origin)}:null;}
function packCharge(f,c=primaryCharge(f)){return c?{kind:c.kind,slot:c.slot||0,t:c.t,max:c.max,elapsed:c.elapsed,spent:c.spent,fullHold:c.fullHold,releaseRequested:!!c.releaseRequested,releaseQ:c.releaseQ}:null;}
function onlineSnapshot(){return {
 burns:techniques.filter(a=>a.type==='burn').slice(0,96).map(a=>({owner:a.owner.id,p:vec(a.p),radius:a.radius,t:a.t})),arena:activeMap,phase,countdown,time:matchTime,restore:restoreTimer,actors:bodies.map(packFighter),
 clash:clash?{...clash,origin:vec(clash.origin),axis:vec(clash.axis)}:null,domain:domain?{id:domain.id,owner:who(domain.owner),t:domain.t,captured:domain.captured,capturedIds:domain.capturedIds,mindscapeLosers:domain.mindscapeLosers||[],origin:vec(domain.origin),axis:vec(domain.axis)}:null,
 blues:blues.map(b=>({id:b.id,owner:who(b.owner),p:vec(b.p),dir:vec(b.dir),age:b.age,q:b.q,phase:b.phase,hold:b.hold,sweep:b.sweep,travelled:b.travelled||0,range:b.range})),bombs:bombs.map(b=>({id:b.id,owner:who(b.owner),p:vec(b.p),q:b.q,t:b.t,radius:b.radius})),
 projectiles:projectiles.slice(0,96).map(p=>({id:p.id,type:p.type,owner:who(p.owner),p:vec(p.p),dir:vec(p.dir),q:p.q,t:p.t})),terrain:pieces.map(p=>p.alive?'1':'0').join(''),events:netEvents.splice(0,150),winner:winnerId,finisher:lastFinisher,execution:finisher?{id:finisher.id,kind:finisher.kind,winner:who(finisher.winner),loser:who(finisher.loser),t:finisher.t,anchor:vec(finisher.anchor),axis:vec(finisher.axis)}:null,finishTime,cutout:cutoutState,naruto:packNaruto(),worldCut:packWorldCut(),spiderThrows:packSpiderThrows(),mahito:packMahito()};}
let replicaState=null,replicaKey='',replicaFresh=0,lastRemoteCutout='';const replicas=new Map();
function validVector(a){return Array.isArray(a)&&a.length===3&&a.every(n=>Number.isFinite(n)&&Math.abs(n)<1e4);}
function validCharge(c){return c===null||!!(c&&Number.isInteger(c.kind)&&c.kind>=1&&c.kind<=4&&[0,1].includes(c.slot)&&Number.isFinite(c.t)&&c.t>=0&&c.t<=c.max&&Number.isFinite(c.max)&&c.max>0&&c.max<=3&&Number.isFinite(c.elapsed)&&c.elapsed>=0&&c.elapsed<8&&Number.isFinite(c.fullHold)&&c.fullHold>=0&&c.fullHold<=3.1&&typeof c.releaseRequested==='boolean'&&Number.isFinite(c.releaseQ)&&c.releaseQ>=0&&c.releaseQ<=1);}
function validState(s){
 if(!s||s.arena!==activeMap||!['play','finish','result'].includes(s.phase)||!Array.isArray(s.actors)||s.actors.length!==bodies.length)return false;
 const ids=new Set(bodies.map(f=>f.id)),id=v=>ids.has(v),finite=v=>Number.isFinite(v)&&Math.abs(v)<1e7,idList=v=>Array.isArray(v)&&v.length<=6&&new Set(v).size===v.length&&v.every(id),field=v=>v&&Number.isSafeInteger(v.id)&&id(v.owner)&&validVector(v.p)&&finite(v.q)&&v.q>=0&&v.q<=1;
 return Array.isArray(s.burns)&&s.burns.length<=96&&s.burns.every(a=>a&&id(a.owner)&&validVector(a.p)&&finite(a.radius)&&a.radius>=0&&a.radius<=16.5&&finite(a.t)&&a.t>=0&&a.t<=2.1)&&validSpiderThrows(s.spiderThrows,ids)&&validMahito(s.mahito,ids,s.domain)&&validWorldCut(s.worldCut,ids)&&validNaruto(s.naruto,ids)&&new Set(s.actors.map(f=>f?.id)).size===ids.size&&s.actors.every(f=>f&&id(f.id)&&f.character===actorById(f.id).character&&validVector(f.pos)&&validVector(f.vel)&&validNarutoMobility(f.mobility,f.character)&&validSpider(f.spider,f.character,ids)&&validMahitoAction(f.mahitoAction)&&Number.isInteger(f.mahitoArm)&&f.mahitoArm>=0&&f.mahitoArm<=3&&Number.isInteger(f.mahitoForm)&&f.mahitoForm>=0&&f.mahitoForm<=3&&f.soulTime>=0&&f.soulTime<=MAHITO.disableTime&&Number.isInteger(f.soulSlot)&&f.soulSlot>=0&&f.soulSlot<=6&&numberFields.every(k=>finite(f[k]))&&Number.isInteger(f.lightOutcome)&&f.lightOutcome>=0&&f.lightOutcome<=4&&f.lightOutcomeTime>=0&&f.lightOutcomeTime<=RESPONSE.outcomeLife+.001&&f.dodgeCooldown>=0&&f.dodgeCooldown<=DODGE.cooldown&&f.techniqueBurnout>=0&&f.techniqueBurnout<=DOMAIN_BURNOUT.duration&&boolFields.every(k=>typeof f[k]==='boolean')&&Array.isArray(f.aim)&&f.aim.length===2&&f.aim.every(finite)&&validCharge(f.charge)&&validCharge(f.aux)&&(!f.aux||f.charge&&f.charge.kind!==f.aux.kind&&f.charge.slot!==f.aux.slot)&&(!f.cast||Number.isSafeInteger(f.cast.id)&&finite(f.cast.t)&&f.cast.t>=0&&f.cast.t<=2&&validVector(f.cast.origin)))&&typeof s.terrain==='string'&&s.terrain.length===pieces.length&&/^[01]+$/.test(s.terrain)&&[s.time,s.restore,s.countdown,s.finishTime].every(finite)&&(!s.domain||Number.isSafeInteger(s.domain.id)&&id(s.domain.owner)&&idList(s.domain.capturedIds)&&idList(s.domain.mindscapeLosers)&&validVector(s.domain.origin)&&validVector(s.domain.axis)&&finite(s.domain.t))&&(!s.clash||Number.isSafeInteger(s.clash.id)&&idList(s.clash.participants)&&s.clash.participants.length>=2&&idList(s.clash.capturedIds)&&s.clash.scores&&s.clash.participants.every(id=>finite(s.clash.scores[id])&&s.clash.scores[id]>=0&&s.clash.scores[id]<=12)&&[s.clash.t,s.clash.joinRemaining].every(finite)&&validVector(s.clash.origin)&&validVector(s.clash.axis))&&Array.isArray(s.blues)&&s.blues.length<=6&&s.blues.every(b=>field(b)&&validVector(b.dir)&&[b.age,b.hold,b.sweep,b.travelled,b.range].every(finite)&&b.age>=0&&b.hold>=0&&b.hold<=LIMITLESS_OUTPUT.blue.holdTime+.1&&b.sweep>=0&&b.sweep<=LIMITLESS_OUTPUT.blue.sweepTime+.1&&b.travelled>=0&&b.travelled<=b.range+.1&&b.range>=LIMITLESS_OUTPUT.blue.travelMin&&b.range<=LIMITLESS_OUTPUT.blue.travelMax&&['travel','sweep','hold'].includes(b.phase))&&Array.isArray(s.bombs)&&s.bombs.length<=24&&s.bombs.every(b=>field(b)&&finite(b.t)&&finite(b.radius))&&Array.isArray(s.projectiles)&&s.projectiles.length<=96&&s.projectiles.every(p=>field(p)&&validVector(p.dir)&&finite(p.t)&&['purple','fire','slash','naruto-shuriken','naruto-bomb','world-cut'].includes(p.type))&&(!s.execution||Number.isSafeInteger(s.execution.id)&&['gojo','sukuna'].includes(s.execution.kind)&&id(s.execution.winner)&&id(s.execution.loser)&&finite(s.execution.t)&&s.execution.t>=0&&s.execution.t<=7&&validVector(s.execution.anchor)&&validVector(s.execution.axis))&&Array.isArray(s.events)&&s.events.length<=150&&(!s.cutout||typeof s.cutout.key==='string'&&s.cutout.key.length<80&&idList(s.cutout.ids)&&finite(s.cutout.t)&&finite(s.cutout.duration));
}
function clearReplicas(){for(const o of replicas.values())removeObject(o.g);replicas.clear();}
function mirrorOrb(key,color,pos,size,live){live.add(key);let o=replicas.get(key);if(!o||o.color!==color){if(o)removeObject(o.g);o=orb(color,size);replicas.set(key,o);}o.g.position.copy(pos);o.g.scale.setScalar(size);animateOrb(o,time);return o;}
function receiveState(s){
 if(!validState(s))return;const first=!replicaState,prior=phase,wasAlive=player.hp>0;replicaState=s;replicaFresh=performance.now();matchTime=s.time;restoreTimer=s.restore;countdown=s.countdown;phase=s.phase;lastFinisher=!!s.finisher;finishTime=s.finishTime;winnerId=s.winner;window._winner=s.winner===player.id?'player':'enemy';
 if(phase!=='play'){menuOpen=false;['menu','help','settingsPanel'].forEach(id=>$(id).classList.add('hidden'));}
 for(const a of s.actors){const f=actorById(a.id);for(const k of numberFields)f[k]=a[k];for(const k of boolFields)f[k]=a[k];f.vel.fromArray(a.vel);receiveNarutoMobility(f,a.mobility);receiveMahitoAction(f,a.mahitoAction);receiveSpider(f,a.spider);f.input.yaw=a.aim[0];f.input.pitch=a.aim[1];if(first||f.pos.distanceTo(V(...a.pos))>6)f.pos.fromArray(a.pos);f.root.visible=f.shadow.visible=f.hp>0||s.execution?.loser===f.id;setCast(f,a.cast?{...a.cast,origin:V(...a.cast.origin)}:null);}
 spiderThrowReplica=s.spiderThrows;receiveNaruto(s.naruto);receiveWorldCut(s.worldCut);mahitoReplica=s.mahito;receiveMahitoFormations(s.mahito.formations);receiveMahitoSouls(s.mahito.souls);
 if(wasAlive&&player.hp<=0&&phase==='play'){controls.releaseAll();setCursorMode(true);toast('YOU ARE ELIMINATED · watching the remaining fighters',5);}
 for(let i=0;i<pieces.length;i++){const alive=s.terrain[i]==='1';if(!alive&&pieces[i].alive)breakPiece(pieces[i]);pieces[i].alive=alive;pieces[i].m.visible=alive;}
 clash=s.clash?{...s.clash,participants:[...s.clash.participants],scores:{...s.clash.scores},origin:V(...s.clash.origin),axis:V(...s.clash.axis)}:null;syncClashScores();
 if(s.execution){const e=s.execution;if(!finisher||finisher.id!==e.id)beginDomainFinisher(actorById(e.winner),e.kind,e.id,e.t,V(...e.anchor),V(...e.axis),actorById(e.loser));finisher.t=e.t;}else clearFinisher();
 domain=s.domain?{...s.domain,owner:actorById(s.domain.owner),origin:V(...s.domain.origin),axis:V(...s.domain.axis)}:null;
 const kind=clash?clashBackdropKind():domain?domain.owner.character:'',key=kind+(clash?.id||domain?.id||'')+(clash?':'+clash.participants.join(','):'');if(key!==replicaKey){replicaKey=key;if(key)domainBackdrop(kind,enclosure().origin,enclosure().axis);else clearDomainVisual();}
 syncDomainTerrain();
 if(s.cutout&&s.cutout.key!==lastRemoteCutout){lastRemoteCutout=s.cutout.key;cutoutState={...s.cutout,ids:[...s.cutout.ids]};renderCutouts(s.cutout.ids);}
 sound.setClash(!!clash&&phase==='play');$('clashUI').classList.toggle('hidden',!clash);
 if(prior!==phase&&phase==='finish'){menuOpen=false;controls.releaseAll();document.exitPointerLock?.();}if(phase==='result')showResult();
 replaying=true;try{for(const ev of s.events)replayEvent(ev,actorById);}finally{replaying=false;}
}
function replayEvent(ev,actor){
 if(!Array.isArray(ev)||ev.length!==2||!Array.isArray(ev[1]))return;const [t,a]=ev,nums=(...indices)=>indices.every(i=>Number.isFinite(a[i])&&Math.abs(a[i])<1e9),v=i=>validVector(a[i]);
 if(t==='substitution'&&actor(a[0])?.character==='naruto'&&v(1))showNarutoSubstitution(actor(a[0]),V(...a[1]));
 if(t==='mindEnd'&&[0,1].includes(a[0])&&v(1))showMindscapeEnding(!!a[0],V(...a[1]));
 if(t==='narutoStop'&&nums(0))narutoFreeze=Math.max(narutoFreeze,clamp(a[0],0,.08));
 if(t==='naruto'&&['smoke','dust','impact','spiral','wind','windBurst','transform','bomb','muzzle','ground'].includes(a[0])&&v(1)&&nums(2)&&v(3))narutoFX(a[0],V(...a[1]),clamp(a[2],.1,30),V(...a[3]),false);
 if(t==='vfx'&&['hollow','blueRelease','red','redBeam','redMuzzle','purpleRelease','purpleImpact','airStep','launchImpact','furnace','cleave','teleport','warp','furnaceBurst'].includes(a[0])&&v(1)&&nums(2,3)&&v(4))playCombatFX(a[0],V(...a[1]),clamp(a[2],.1,WORLD.radius),clamp(a[3],0,1),V(...a[4]).normalize());
 if(t==='shock'&&v(0)&&nums(1,2,3))shock(V(...a[0]),a[1],clamp(a[2],0,WORLD.radius),clamp(a[3],.03,4));
 if(t==='slash'&&v(0)&&v(1)&&nums(2,3,4,5))slashRibbon(V(...a[0]),V(...a[1]).normalize(),a[2],clamp(a[3],0,40),clamp(a[4],.03,3),a[5]);
 if(t==='trail'&&v(0)&&v(1)&&nums(2,3,4))trail(V(...a[0]),V(...a[1]),a[2],clamp(a[3],.001,2),clamp(a[4],.03,3));
 if(t==='crown'&&v(0)&&nums(1,2,3))blastCrown(V(...a[0]),a[1],clamp(a[2],0,WORLD.radius),clamp(a[3],.03,4));
 if(t==='ghost'&&!!actor(a[0])&&nums(1))afterImage(actor(a[0]),a[1]);
 if(t==='announce'&&typeof a[0]==='string'&&typeof a[1]==='string'&&nums(2))announce(a[0].slice(0,120),a[1].slice(0,120),clamp(a[2],0,5));
 if(t==='sound'&&typeof a[0]==='string'&&v(1)&&nums(2))sfx(a[0],V(...a[1]),clamp(a[2],0,2),false);
 if(t==='shake'&&nums(0)){if(v(1))cameraImpulse(V(...a[1]),v(2)?V(...a[2]):null,clamp(a[0],0,2));else shakeIt(clamp(a[0],0,2));}if(t==='flash'&&nums(0))flashIt(clamp(a[0],0,1));
 if(t==='guard'&&!!actor(a[0])){actor(a[0]).shield.material.opacity=.65;if(actor(a[1])){combatCue(actor(a[0]),actor(a[1]),'guard');blockedContact(actor(a[0]),actor(a[1]));}}
 if(t==='evade'&&actor(a[0])&&actor(a[1])){combatCue(actor(a[0]),actor(a[1]),'evade');evadedContact(actor(a[0]),actor(a[1]));damageText(actor(a[0]),BALANCE.dodgeHeal,true);}
 if(t==='hit'&&!!actor(a[0])&&nums(1)&&a[1]>0){const amount=clamp(a[1],0,MAX_HEALTH*2),style=['hit','heavy','finish','chip'].includes(a[3])?a[3]:'hit';damageText(actor(a[0]),amount);if(actor(a[2])){combatCue(actor(a[0]),actor(a[2]),'hit',amount);confirmedContact(actor(a[0]),actor(a[2]),amount,style,v(4)?V(...a[4]):null);}if(a[0]===player.id||a[2]===player.id)controls.rumble(style==='finish'||amount>=80);}
 if(t==='cinema'&&!!actor(a[0])&&['domain','clash','purple','furnace','naruto'].includes(a[1])&&nums(2))cinematicShot(actor(a[0]),a[1],clamp(a[2],0,a[1]==='naruto'?3.4:1));
}
function updateReplica(dt){
 if(!replicaState)return;const s=replicaState,live=new Set();
 for(const a of s.actors){const f=actorById(a.id);if(f.spider)f.spider.releaseTime=Math.max(0,f.spider.releaseTime-dt);if(f.spider?.action)f.spider.action.t=Math.min(f.spider.action.t+dt,(a.spider?.a?.t||0)+.10);f.pos.lerp(V(...a.pos),1-Math.exp(-23*dt));const synced=[a.charge,a.aux].map(c=>{if(!c)return null;const ch={...c},q=clamp(c.t/c.max,0,1),dir=V(-Math.sin(a.aim[0])*Math.cos(a.aim[1]),-Math.sin(a.aim[1]),-Math.cos(a.aim[0])*Math.cos(a.aim[1])),p=headPos(f).addScaledVector(dir,1.5+q*.5),color=f.character==='gojo'?[0,C.blue,C.red,C.purple,C.mint][c.kind]:c.kind===3?0xff8a39:C.red;if(f.character!=='naruto'&&c.kind!==4)ch.orb=mirrorOrb('charge'+f.id+'-'+c.slot,color,p,lerp(.23,1.1,q),live);return ch;});setPrimaryCharge(f,synced[0]);f.auxCharge=synced[1];}
 blues.length=0;for(const b of s.blues)blues.push({...b,owner:actorById(b.owner),p:V(...b.p),dir:V(...b.dir),o:mirrorOrb('blue'+b.id,C.blue,V(...b.p),lerp(.4,1.35,b.q),live)});
 bombs.length=0;for(const b of s.bombs)bombs.push({...b,owner:actorById(b.owner),p:V(...b.p),o:mirrorOrb('bomb'+b.id,C.purple,V(...b.p),lerp(.9,3.5+b.q*2,b.t/3),live)});refreshFieldAliases();
 for(const p of s.projectiles)if(p.type!=='slash'&&p.type!=='world-cut'&&!p.type.startsWith('naruto-'))mirrorOrb('projectile'+p.id,p.type==='purple'?C.purple:0xff7d24,V(...p.p),p.type==='purple'?lerp(1.1,2.5,p.q):.9+p.q,live);
 for(const [key,o]of replicas)if(!live.has(key)){removeObject(o.g);replicas.delete(key);}animateDomainVisual();updateChargeHUD();
}

for(const id of Object.keys(ARENA_MAPS))$('map-'+id).onclick=()=>chooseMap(id);
$('selectGojo').onclick=()=>selectCharacter('gojo');$('selectSukuna').onclick=()=>selectCharacter('sukuna');$('selectNaruto').onclick=()=>selectCharacter('naruto');$('selectMahito').onclick=()=>selectCharacter('mahito');$('selectSpider').onclick=()=>selectCharacter('spiderman');
$('duelButton').onclick=()=>{leaveOnline();start('duel');};$('practiceButton').onclick=()=>{leaveOnline();start('practice');};$('resumeButton').onclick=resume;$('pauseButton').onclick=pause;$('helpButton').onclick=showHelp;$('closeHelp').onclick=closeHelp;$('drillButton').onclick=clashDrill;$('resetButton').onclick=()=>start(mode);
$('rematchButton').onclick=()=>{if(mode==='online')net.requestRematch();else start(mode);};$('resultMenuButton').onclick=leaveOnline;
$('settingsButton').onclick=showSettings;$('settingsClose').onclick=backFromPanel;$('resetBindings').onclick=()=>{controls.reset();$('bindStatus').textContent='Default keyboard and controller bindings restored.';};
for(const [id,key]of [['sensitivity','sensitivity'],['camDistance','camDistance']]){$(id).value=options[key];$(id).oninput=e=>{options[key]=+e.target.value;saveOptions();};}
for(const [id,key]of [['soundToggle','sound'],['shakeToggle','shake'],['flashToggle','flash'],['bloomToggle','bloom'],['cinemaToggle','cinematics'],['wheelCamera','wheelCamera']]){$(id).checked=!!options[key];$(id).onchange=e=>{options[key]=e.target.checked;if(key==='sound')sound.setEnabled(options.sound);if(key==='wheelCamera'&&!options.wheelCamera){cameraOrbit.active=false;if(!options.freeOrbit)cameraOrbit.yaw=cameraOrbit.pitch=0;}if(key==='cinematics'&&!options.cinematics)cinematic=null;saveOptions();};}
for(const bus of ['master','effects','music','recordings']){const el=$(bus+'Volume');el.value=sound.volumes[bus];el.oninput=e=>{sound.unlock();sound.setVolume(bus,+e.target.value);$(bus+'Value').textContent=Math.round(+e.target.value*100)+'%';};$(bus+'Value').textContent=Math.round(sound.volumes[bus]*100)+'%';}
sound.setEnabled(options.sound);
for(const [id,key]of [['padSensitivity','padSensitivity'],['touchSensitivity','touchSensitivity'],['deadzone','deadzone']]){$(id).value=controls.prefs[key];$(id).oninput=e=>{controls.prefs[key]=+e.target.value;controls.save();};}
$('invertY').checked=controls.prefs.invertY;$('invertY').onchange=e=>{controls.prefs.invertY=e.target.checked;controls.save();};
$('cursorButton').onclick=()=>setCursorMode(!cursorFree);$('cursorBehavior').value=options.cursorBehavior;$('cursorBehavior').onchange=e=>{options.cursorBehavior=e.target.value;setCursorMode(false,false);saveOptions();};$('freeOrbit').checked=!!options.freeOrbit;$('freeOrbit').onchange=e=>setCharacterView(e.target.checked);
$('wheelMode').value=options.wheelMode;$('wheelMode').onchange=e=>{options.wheelMode=e.target.value;saveOptions();};$('resetCamera').onclick=()=>{options.camTilt=0;options.camDistance=7;cameraOrbit.yaw=cameraOrbit.pitch=0;$('camDistance').value=7;saveOptions();};
$('editTouchLayout').onclick=()=>controls.editLayout(true);$('saveTouchLayout').onclick=()=>controls.editLayout(false);$('resetTouchLayout').onclick=()=>controls.resetLayout();
$('touchMode').value=controls.prefs.touch;$('touchMode').onchange=e=>{controls.prefs.touch=e.target.value;controls.save();};$('quality').value=options.quality;$('quality').onchange=e=>{options.quality=e.target.value;setQuality();saveOptions();};
$('previewAudio').onclick=async()=>{await sound.unlock();sound.play('parry');sound.play('blue',.6);};
$('onlineButton').onclick=()=>{if(phase==='play')pause();document.exitPointerLock?.();$('menu').classList.add('hidden');$('onlinePanel').classList.remove('hidden');lobbyUI();};
$('onlineClose').onclick=leaveOnline;$('leaveRoom').onclick=()=>{net.close();lobbyUI();};$('createRoom').onclick=()=>{sound.unlock();net.create(selectedCharacter,selectedMap);};$('joinRoom').onclick=()=>{sound.unlock();net.join($('joinCode').value,selectedCharacter);};$('roomReady').onclick=()=>{sound.unlock();net.setReady();};
$('copyCode').onclick=async()=>{try{await navigator.clipboard.writeText(net.code||'');$('copyCode').textContent='COPIED';setTimeout(()=>$('copyCode').textContent='COPY CODE',1500);}catch{$('onlineStatus').textContent='Select and copy the room code above.';}};
$('joinCode').addEventListener('keydown',e=>{if(e.code==='Enter')$('joinRoom').click();});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&mode==='online'&&net.role==='host')net.fail('Host tab was hidden. Match stopped; keep it visible during a duel.');});
let dragLook=false,dragPointer=null;
renderer.domElement.addEventListener('pointerdown',e=>{
 if(e.pointerType==='touch'||phase!=='play'||menuOpen)return;
 if(document.pointerLockElement===renderer.domElement&&!cursorFree)return;
 if(![0,1,2].includes(e.button))return;
 dragLook=true;dragPointer={id:e.pointerId,x:e.clientX,y:e.clientY};
 if(cursorFree||options.freeOrbit){e.preventDefault();cameraOrbit.active=true;try{renderer.domElement.setPointerCapture(e.pointerId);}catch{}return;}
 requestLock();
});
function endCameraDrag(){const id=dragPointer?.id;dragLook=false;dragPointer=null;if(cursorFree||options.freeOrbit)cameraOrbit.active=false;try{if(id!==undefined&&renderer.domElement.hasPointerCapture?.(id))renderer.domElement.releasePointerCapture(id);}catch{}}
window.addEventListener('pointerup',endCameraDrag);
window.addEventListener('pointercancel',endCameraDrag);
renderer.domElement.addEventListener('lostpointercapture',endCameraDrag);
window.addEventListener('pointermove',e=>{
 if(!dragLook||!dragPointer||phase!=='play'||menuOpen||document.pointerLockElement===renderer.domElement&&!cursorFree)return;
 if(dragPointer.id!==undefined&&e.pointerId!==undefined&&e.pointerId!==dragPointer.id)return;
 const dx=Number.isFinite(e.clientX)&&Number.isFinite(dragPointer.x)?e.clientX-dragPointer.x:e.movementX||0,dy=Number.isFinite(e.clientY)&&Number.isFinite(dragPointer.y)?e.clientY-dragPointer.y:e.movementY||0;
 dragPointer.x=e.clientX;dragPointer.y=e.clientY;cameraLook(dx*.0023*options.sensitivity,dy*.0023*options.sensitivity);
});
window.addEventListener('mousemove',e=>{
 if(phase!=='play'||menuOpen)return;
 if(!dragLook&&!cursorFree&&(document.pointerLockElement===renderer.domElement||cameraOrbit.active))cameraLook((e.movementX||0)*.0023*options.sensitivity,(e.movementY||0)*.0023*options.sensitivity);
});
document.addEventListener('pointerlockchange',()=>{
 if(document.pointerLockElement===renderer.domElement){endCameraDrag();if(cursorFree)document.exitPointerLock?.();return;}
 if(!cursorFree&&phase==='play'&&!controls.touchActive&&controls.inputMode==='keyboard')pause();
});
window.addEventListener('blur',()=>{endCameraDrag();if(phase==='play')pause();});window.addEventListener('pagehide',()=>{net.close(false);sound.setClash(false);sound.stopCues();sound.stopScore();});
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();setQuality();});setQuality();
function showResult(){$('result').classList.remove('hidden');$('resultTitle').textContent=window._winner==='player'?'VICTORY':'DEFEAT';$('resultEyebrow').textContent=lastFinisher?'DOMAIN FINISHER':'FREE-FOR-ALL COMPLETE';$('resultStats').textContent='Damage dealt: '+Math.round(player.score)+' · Damage received: '+Math.round(player.damageTaken)+' · Match time: '+Math.floor(matchTime)+'s';presentResults();}
function step(dt){
 narutoFreeze=Math.max(0,narutoFreeze-dt);time+=dt;frameCount++;orbLight.intensity*=Math.exp(-7*dt);controls.poll(dt);net.tick();
 const guest=mode==='online'&&net.role==='guest';
 if(guest){updateReplica(narutoFreeze>0?0:dt);}else if(phase==='play'){
  if(countdown>0){const previous=Math.ceil(countdown);countdown=Math.max(0,countdown-dt);if(Math.ceil(countdown)!==previous){announce('PRIVATE DUEL',countdown>0?String(Math.ceil(countdown)):'FIGHT',.85);sound.play('ui');}}
  else{matchTime+=dt;restoreTimer-=dt;if(restoreTimer<=0)restoreArena();const gameDt=narutoFreeze>0?0:hitStop>0?dt*.12:dt;hitStop=Math.max(0,hitStop-dt);
   if(mode==='online')for(const f of bodies)if(f!==player&&!f.bot&&performance.now()-(f.input.lastAt||0)>500){clearBufferedAction(f);f.input.keys.clear();f.input.move={x:0,y:0};cancelCharge(f);}
   if(player.hp>0)updateControlled(player,gameDt);updateEnemy(gameDt);
   for(const h of pendingHits)h.t-=gameDt;pendingHits.sort((a,b)=>a.t-b.t||a.seq-b.seq);while(pendingHits[0]?.t<=0)resolveLight(pendingHits.shift());

   for(const b of [...blues])updateBlue(gameDt,b);updateProjectiles(gameDt);updateTechniques(gameDt);updateMahitoEntities(gameDt);updateSpider(gameDt);for(const b of [...bombs])updateBomb(gameDt,b);refreshFieldAliases();updateMahitoSouls(gameDt);updateDomains(gameDt);for(const f of bodies)constrainBarrier(f,f.pos,f.pos,f.vel);
  }
 }
 if(phase==='finish'){cancelPendingMahitoSouls();if(!guest)finishNarutoPresentation(dt);if(finisher)updateFinisher(dt);else if(!guest)for(const f of bodies){updateCombatTimers(f,dt);moveFighter(f,dt);}}
 if(!guest&&phase==='finish'){finishTime-=dt;if(finishTime<=0){phase='result';showResult();}}
 if(phase!=='pause'&&phase!=='result'){updateEffects(narutoFreeze>0?0:dt);for(const f of bodies)if(f.hp>0||finisher?.loser===f||f.character==='naruto'&&phase==='finish'){restoreMahitoSoulPose(f);animateFighter(f,narutoFreeze>0?0:dt);animateMahitoDetail(f,narutoFreeze>0?0:dt);}for(const f of bodies)applyMahitoSoulPose(f);updateCamera(dt);}if(phase==='play'||phase==='finish')updateHUD();
 if(mode==='online'){$('networkBadge').textContent=(net.role==='host'?'HOST':'GUEST')+' · '+net.rtt+' ms';$('networkBadge').classList.remove('hidden');networkTick+=dt;if(networkTick>=1/(guest?30:20)){networkTick=0;if(guest)sendInputs();else net.snapshot(onlineSnapshot());}}else $('networkBadge').classList.add('hidden');
 battleVisual.activity=Math.max(0,battleVisual.activity-dt);syncBattleAudio();sound.update({charge:charge?Math.max(.01,charge.t/charge.max):0,color:charge?.kind===2?'red':'blue',domain:domain?.owner.character||''});
 if(annTime>0){annTime-=dt;if(annTime<=0)$('announcement').style.opacity=0;}if(toastTime>0){toastTime-=dt;if(toastTime<=0)$('toast').style.opacity=0;}flash=Math.max(0,flash-dt*.8);impact=Math.max(0,impact-dt);$('flash').style.opacity=flash;$('impact').style.opacity=impact>0&&options.flash?.8:0;
 if(phase!=='play'&&phase!=='pause'){for(const f of bodies){interruptWorldCut(f);stopSpider(f);}spiderThrows.length=0;}ageWorldCutScars(dt);updateWorldCutVisuals(narutoFreeze>0?0:dt);updateFieldVisuals(dt);syncCombatVisuals();updateNarutoVisuals(narutoFreeze>0?0:dt);updateMahitoVisuals(phase==='pause'?0:dt);updateSpiderVisuals(phase==='pause'?0:dt);updateBarrierVisuals();syncDomainTerrain();updateMindscapePresentation(narutoFreeze>0?0:dt);if(phase!=='pause')updateDomainCutouts(dt);updatePresentation(dt);updateCombatFeel(dt);renderFrame();
}

function syncBattleAudio(){
 sound.setClash(!!clash&&phase==='play');
 for(const f of bodies){const channel='cast-'+f.id;if(['gojo','sukuna'].includes(f.character)&&f.castVoiceActive&&(phase==='play'||phase==='finish'))sound.syncCue(channel,f.character==='gojo'?'gojoCast':'sukunaCast',f.castVoiceId,f.castVoiceAge,{level:.98});else sound.stopCue(channel,.1);}
 if(domain?.owner.character==='gojo'&&(phase==='play'||phase==='finish'))sound.syncCue('voidTheme','gojoTheme','void-'+domain.id,domain.t,{duration:DOMAIN_RULES.duration,level:.65,bus:'music'});
 else sound.stopCue('voidTheme');
 if(domain?.owner.character==='sukuna'&&(phase==='play'||phase==='finish'))sound.syncCue('shrine','sukunaDomain','shrine-'+domain.id,domain.t,{duration:DOMAIN_RULES.duration,level:.85});
 else sound.stopCue('shrine');
 const speaking=bodies.some(f=>f.castVoiceActive);const ultimate=bombs.length>0||mode==='online'&&net?.role==='guest'&&replicaState?.bombs.length>0||bodies.some(f=>f.narutoAction?.kind===5||worldCutBusy(f)),engaged=!!domain||!!clash||bodies.some(f=>f.attack>0||chargeFor(f)||f!==player&&f.hp>0&&f.pos.distanceToSquared(player.pos)<22*22);sound.mixBattle(['play','finish'].includes(phase)&&!menuOpen,engaged?1:clamp(battleVisual.activity/4,0,1),player.hp/MAX_HEALTH,!!clash,ultimate,speaking,!!clash&&!!sound.buffer||domain?.owner.character==='gojo',options.adaptiveMusic,matchTime);sound.duckCue('shrine',speaking?.3:1);sound.duckCue('voidTheme',speaking?.3:1);
 if(['menu','pause','result'].includes(phase))sound.stopCue('nuke');
}

$('aiCount').onchange=e=>{const count=clamp(+e.target.value,1,5);while(matchSetup.bots.length<count)matchSetup.bots.push(matchSetup.bots.length%2?'gojo':'sukuna');matchSetup.bots.length=count;saveMatchSetup();refreshBotOptions();};
$('aiDifficulty').onchange=e=>{if(AI_LEVELS[e.target.value])matchSetup.difficulty=e.target.value;saveMatchSetup();refreshBotOptions();};refreshBotOptions();
$('roomCharacter').onchange=e=>net.setCharacter(e.target.value);
function configureRoomBots(){const count=clamp(+$('roomBots').value,0,5),bots=net.roster.filter(f=>f.bot).map(f=>f.character);while(bots.length<count)bots.push(bots.length%2?'gojo':'sukuna');bots.length=count;if(!net.configureBots(bots,$('roomDifficulty').value)){$('onlineStatus').textContent='Six fighters maximum. Remove an AI to make space.';lobbyUI();}}
$('roomBots').onchange=configureRoomBots;$('roomDifficulty').onchange=configureRoomBots;
