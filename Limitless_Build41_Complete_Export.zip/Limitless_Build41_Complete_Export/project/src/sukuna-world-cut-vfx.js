// Fixed pools for six simultaneous casters/projectiles and twelve ground scars.
const WORLD_CUT_VFX={casts:6,shots:6,scarSegments:48,sparkInterval:.055,scarWidth:2.7,scarLip:.7};
function ensureWorldCutVisuals(){
 if(worldCutVisuals)return worldCutVisuals;
 const c=WORLD_CUT,casts=[],shots=[],scars=[],normal=V(0,0,1),tmp=V(),dummy=new THREE.Object3D(),scratch=V();
 const slashMaterial=()=>new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,uniforms:{uTime:{value:0},uFade:{value:1}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:`varying vec2 vUv;uniform float uTime,uFade;void main(){vec2 p=vUv*2.-1.;float end=pow(max(0.,1.-p.y*p.y),.65);float bend=sin(p.y*2.6)*.18;float noise=sin(p.y*91.+uTime*35.)*.014+sin(p.y*41.-uTime*21.)*.018;float d=abs(p.x-bend)-end*.27-noise;float edge=exp(-abs(d)*95.);float alpha=(1.-smoothstep(-.006,.032,d))*end;vec3 col=vec3(.004,.001,.008)+vec3(2.8,.18,.42)*edge;col+=vec3(2.4,1.8,2.)*pow(edge,6.);gl_FragColor=vec4(col,alpha*uFade);}`});
 for(let i=0;i<WORLD_CUT_VFX.shots;i++){
  const g=new THREE.Group();g.name='world-cut-black-rift';scene.add(g);g.visible=false;const material=slashMaterial(),blade=mesh(new THREE.PlaneGeometry(c.halfWidth*2,c.halfHeight*2,1,1),material,g);
  const echoes=[];for(let j=0;j<3;j++){const e=mesh(new THREE.PlaneGeometry(c.halfWidth*2,c.halfHeight*2),slashMaterial(),g,V((j%2?1:-1)*.3,0,-(j+1)*1.8));e.scale.set(.75-j*.15,1-j*.07,1);echoes.push(e);}
  shots.push({g,blade,echoes,sparks:0});
 }
 const ringGeo=new THREE.TorusGeometry(1,.013,4,72);
 for(let i=0;i<WORLD_CUT_VFX.casts;i++){
  const g=new THREE.Group();g.name='world-cut-formation';g.visible=false;scene.add(g);const rings=[];
  for(let j=0;j<3;j++)rings.push(mesh(ringGeo,new THREE.MeshBasicMaterial({color:j===2?c.colors.rim:c.colors.edge,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false}),g));
  const tear=mesh(new THREE.PlaneGeometry(.7,3.8),slashMaterial(),g);casts.push({g,rings,tear,sparks:0});
 }
 const rockMat=new THREE.MeshStandardMaterial({color:0x3c323d,roughness:.96,metalness:.06});
 for(let i=0;i<c.scarPool;i++){
  const g=new THREE.Group();g.name='world-cut-ground-crater';scene.add(g);g.visible=false;
  const positions=[],uvs=[],indices=[],n=WORLD_CUT_VFX.scarSegments;
  for(let j=0;j<=n;j++){const u=j/n,edge=Math.pow(Math.sin(u*Math.PI),.3),jag=.7+domainHash(j+123)*.6;for(const side of [-1,1]){positions.push(side*edge*jag,.004,u);uvs.push(side<0?0:1,u);}if(j<n){const k=j*2;indices.push(k,k+2,k+1,k+1,k+2,k+3);}}
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setIndex(indices);geometry.computeVertexNormals();
  const material=new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,uniforms:{uTime:{value:0},uFade:{value:1}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:`varying vec2 vUv;uniform float uTime,uFade;void main(){float side=abs(vUv.x-.5)*2.;float rim=smoothstep(.74,1.,side);float glow=pow(rim,8.)*exp(-uTime*.5);vec3 c=mix(vec3(.004,.002,.008),vec3(.105,.068,.079),pow(side,5.));c+=vec3(1.6,.075,.14)*glow*(.5+.5*sin(vUv.y*96.+uTime*12.));gl_FragColor=vec4(c,uFade);}`});
  const surface=mesh(geometry,material,g);const lips=new THREE.InstancedMesh(geo.lowSphere,rockMat,n*2);lips.frustumCulled=false;lips.instanceMatrix.setUsage(THREE.DynamicDrawUsage);g.add(lips);
  scars.push({g,surface,material,lips,id:0,length:-1});
 }
 return worldCutVisuals={casts,shots,scars,tmp,normal,dummy,scratch};
}
function updateWorldCutVisuals(dt){
 if(mode==='online'&&net?.role==='guest'&&phase!=='pause')worldCutReplicaAge=Math.min(.12,worldCutReplicaAge+dt);
 const guest=mode==='online'&&net?.role==='guest',shots=guest?replicaState?.projectiles:projectiles;
 let active=false;for(const f of bodies)if(worldCutBusy(f))active=true;for(const p of shots||[])if(p.type==='world-cut')active=true;for(const s of worldCutScars)if(s.active)active=true;
 if(!active&&!worldCutVisuals)return;const v=ensureWorldCutVisuals(),c=WORLD_CUT,live=['play','pause','finish'].includes(phase);if(phase==='pause')dt=0;
 let index=0;for(const f of bodies){if(!worldCutBusy(f)||!live)continue;const a=f.worldCut,t=worldCutAge(a),rig=v.casts[index++];if(!rig)break;rig.g.visible=t<c.startup;rig.g.position.copy(f.pos);rig.g.position.y+=1.65;rig.g.position.addScaledVector(a.dir,.85);rig.g.quaternion.setFromUnitVectors(v.normal,a.dir);
  const q=narutoEase(t/c.startup);rig.tear.scale.setScalar(.2+q*.8);rig.tear.material.uniforms.uTime.value=t;rig.tear.material.uniforms.uFade.value=q;
  for(let j=0;j<3;j++){const ring=rig.rings[j];ring.rotation.set(t*(1+j*.3),j*.8,t*(j%2?2:-2));ring.scale.setScalar(1.7-j*.24-q*.8);ring.material.opacity=q*.55;}
  rig.sparks+=dt;if(rig.g.visible&&dt>0&&rig.sparks>=WORLD_CUT_VFX.sparkInterval){rig.sparks=0;narutoEmit(rig.g.position,c.colors.edge,3,.4,2,.085,false,true);}
 }for(;index<v.casts.length;index++)v.casts[index].g.visible=false;
 index=0;for(const p of shots||[]){if(p.type!=='world-cut'||!live)continue;const rig=v.shots[index++];if(!rig)break;rig.g.visible=true;if(guest){rig.g.position.fromArray(p.p);v.tmp.fromArray(p.dir);rig.g.position.addScaledVector(v.tmp,worldCutReplicaAge*c.speed);}else{rig.g.position.copy(p.p);v.tmp.copy(p.dir);}rig.g.quaternion.setFromUnitVectors(v.normal,v.tmp);const age=p.t+(guest?worldCutReplicaAge:0);rig.blade.material.uniforms.uTime.value=age;
  for(let j=0;j<rig.echoes.length;j++){const e=rig.echoes[j];e.material.uniforms.uTime.value=age+j*.13;e.material.uniforms.uFade.value=.45-j*.12;}
  rig.sparks+=dt;if(dt>0&&rig.sparks>=WORLD_CUT_VFX.sparkInterval){rig.sparks=0;narutoEmit(rig.g.position,c.colors.edge,6,.35,6,.15);}
 }for(;index<v.shots.length;index++)v.shots[index].g.visible=false;
 for(let i=0;i<worldCutScars.length;i++){
  const s=worldCutScars[i],r=v.scars[i];r.g.visible=live&&s.active;if(!r.g.visible)continue;v.tmp.copy(s.to).sub(s.from);const length=v.tmp.length();if(length<.1){r.g.visible=false;continue;}r.g.position.copy(s.from);r.g.rotation.y=Math.atan2(v.tmp.x,v.tmp.z);r.surface.scale.set(WORLD_CUT_VFX.scarWidth,1,length);r.material.uniforms.uTime.value=s.t;r.material.uniforms.uFade.value=1-narutoEase((s.t-c.scarLife+1.5)/1.5);
  if(r.id!==s.id||Math.abs(r.length-length)>.05){r.id=s.id;r.length=length;const n=WORLD_CUT_VFX.scarSegments;
   for(let j=0;j<n*2;j++){const k=Math.floor(j/2),u=(k+.5)/n,side=j%2?1:-1,edge=Math.pow(Math.sin(u*Math.PI),.3),seed=domainHash(k+123);v.dummy.position.set(side*edge*(.7+seed*.6)*WORLD_CUT_VFX.scarWidth,.12+seed*.15,u*length);v.dummy.rotation.set(seed*2,seed*4,side*.4);v.dummy.scale.set(.45+seed*.45,(.25+seed*WORLD_CUT_VFX.scarLip)*edge,.55+seed*.9);v.dummy.updateMatrix();r.lips.setMatrixAt(j,v.dummy.matrix);}r.lips.instanceMatrix.needsUpdate=true;
  }
 }
}
