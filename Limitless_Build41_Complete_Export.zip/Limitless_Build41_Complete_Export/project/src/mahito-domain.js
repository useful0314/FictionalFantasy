// Host-authoritative pursuing hands; reuse domain capture, guard, dodge, damage and networking.
const MAHITO_DOMAIN={backgroundHands:MAHITO.domainHands,lowBackgroundHands:96,handsPerEnemy:4,maxHunters:20,damage:24,windup:.55,stagger:.16,chaseSpeed:23,turnSpeed:7,chaseTime:2.4,recovery:.70,spawnRadius:8.5,hitRadius:1.32,knockback:3,handScale:.72};
const mahitoHandScratch={center:V(),target:V(),delta:V(),direction:V(),previous:V(),knock:V(),q:new THREE.Quaternion(),turn:new THREE.Quaternion()};
function spawnMahitoHunter(d,h,stagger=false){
 const s=mahitoHandScratch,b=actorById(h.target),angle=h.slot*2.399963+h.cycle*1.7;if(!b){h.phase=3;return;}s.center.copy(d.origin);s.center.y+=1.45;s.target.copy(b.pos);s.target.y+=1.45;
 h.p.copy(s.target).add(s.delta.set(Math.cos(angle)*MAHITO_DOMAIN.spawnRadius,(h.slot%3-1)*3.3,Math.sin(angle)*MAHITO_DOMAIN.spawnRadius));s.delta.copy(h.p).sub(s.center).clampLength(0,DOMAIN_ENCLOSURE.radius-5);h.p.copy(s.center).add(s.delta);h.dir.copy(s.target).sub(h.p).normalize();h.phase=0;h.age=stagger?-(h.slot%MAHITO_DOMAIN.handsPerEnemy)*MAHITO_DOMAIN.stagger:0;
}
function initializeMahitoHunters(d){const hands=[];for(const b of bodies)if(b!==d.owner&&b.hp>0&&d.capturedIds.includes(b.id))for(let i=0;i<MAHITO_DOMAIN.handsPerEnemy&&hands.length<MAHITO_DOMAIN.maxHunters;i++){const h={slot:hands.length,target:b.id,p:V(),dir:V(0,0,1),age:0,phase:0,cycle:0};spawnMahitoHunter(d,h,true);hands.push(h);}d.mahitoHunters=hands;}
function updateMahitoDomain(d,dt){
 const c=MAHITO_DOMAIN,s=mahitoHandScratch,active=Math.min(dt,Math.max(0,DOMAIN_RULES.duration-d.t));d.t+=active;
 if(d.owner.hp<=0||d.t>=DOMAIN_RULES.duration-1e-8){if(phase==='play')endActiveDomain(d);return;}if(!d.mahitoHunters)initializeMahitoHunters(d);
 for(const h of d.mahitoHunters){if(phase!=='play'||domain!==d)break;const target=actorById(h.target);if(!target||target.hp<=0||!d.capturedIds.includes(target.id)||barrierSeparates(d.owner,target)){h.phase=3;continue;}if(h.phase===3)continue;
  h.age+=active;s.target.copy(target.pos);s.target.y+=1.45;
  if(h.phase===0){h.dir.copy(s.target).sub(h.p).normalize();if(h.age>=c.windup){h.phase=1;h.age=0;}continue;}
  if(h.phase===2){h.p.addScaledVector(h.dir,-1.8*active);if(h.age>=c.recovery){h.cycle++;spawnMahitoHunter(d,h);}continue;}
  s.direction.copy(s.target).sub(h.p);const distance=s.direction.length();if(distance>.0001){s.direction.divideScalar(distance);s.q.setFromUnitVectors(h.dir,s.direction);s.turn.identity().slerp(s.q,1-Math.exp(-c.turnSpeed*active));h.dir.applyQuaternion(s.turn).normalize();}
  const travel=c.chaseSpeed*active,contact=raySphere(h.p,h.dir,s.target,c.hitRadius),hit=contact<=travel;s.previous.copy(h.p);h.p.addScaledVector(h.dir,hit?Math.max(0,contact):travel);constrainBarrier(d.owner,h.p,s.previous);
  if(hit){s.knock.copy(h.dir).multiplyScalar(c.knockback);s.knock.y+=1.6;const damaged=hurt(target,c.damage,d.owner,'ultimate',s.knock,0);h.phase=2;h.age=0;if(damaged){narutoFX('impact',h.p,.65);shakeIt(.09);}else narutoFX('smoke',h.p,.5);}
  else if(h.age>=c.chaseTime){h.phase=2;h.age=0;}
 }
}
function packMahitoHands(){return domain?.owner.character==='mahito'?(domain.mahitoHunters||[]).map(h=>({slot:h.slot,target:h.target,p:vec(h.p),dir:vec(h.dir),age:h.age,phase:h.phase,cycle:h.cycle})):[];}
function validMahitoHands(hands,ids,d){return Array.isArray(hands)&&hands.length<=MAHITO_DOMAIN.maxHunters&&(!hands.length||d&&actorById(d.owner)?.character==='mahito')&&new Set(hands.map(h=>h?.slot)).size===hands.length&&hands.every(h=>h&&Number.isInteger(h.slot)&&h.slot>=0&&h.slot<MAHITO_DOMAIN.maxHunters&&ids.has(h.target)&&h.target!==d.owner&&Array.isArray(d.capturedIds)&&d.capturedIds.includes(h.target)&&validVector(h.p)&&validVector(h.dir)&&Number.isFinite(h.age)&&h.age>=-1&&h.age<=3&&Number.isInteger(h.phase)&&h.phase>=0&&h.phase<=3&&Number.isInteger(h.cycle)&&h.cycle>=0&&h.cycle<=30);}
function animateMahitoHunters(batch){
 const guest=mode==='online'&&net?.role==='guest',list=domain?.owner.character==='mahito'?(guest?mahitoReplica?.hands:domain.mahitoHunters)||[]:[];let count=0;const dt=clamp(time-batch.lastTime,0,.05);batch.lastTime=time;
 for(const h of list){if(h.phase===3)continue;const extra=guest?Math.min(.10,narutoReplicaAge):0,age=h.age+extra,entry=narutoEase(age/MAHITO_DOMAIN.windup),exit=1-narutoEase(age/MAHITO_DOMAIN.recovery),size=MAHITO_DOMAIN.handScale*(h.phase===0?entry:h.phase===2?exit:1),curl=h.phase===0?.05+.25*entry:h.phase===1?.3:.3+narutoEase(age/.22)*1.05;
  if(guest){batch.p.fromArray(h.p);batch.normal.fromArray(h.dir);if(h.phase===1)batch.p.addScaledVector(batch.normal,MAHITO_DOMAIN.chaseSpeed*extra);const shown=batch.display[h.slot];if(shown.cycle!==h.cycle||shown.domain!==domain.id){shown.p.copy(batch.p);shown.cycle=h.cycle;shown.domain=domain.id;}else shown.p.lerp(batch.p,1-Math.exp(-dt/.045));batch.p.copy(shown.p);}else{batch.p.copy(h.p);batch.normal.copy(h.dir);}batch.p.sub(batch.g.parent.position);setMahitoHand(batch,count++,batch.p,batch.normal,size,curl,Math.sin(h.slot*2.4)*.48);
 }flushMahitoHands(batch,count);
}
