// Preserve the existing character/clone factory contract.
function fighterModelNaruto(attach=true){return fighterBlockModel('naruto',attach);}
