// Three instanced draws per batch: palm/forearm, jointed fingers, stitched palm lines.
const MAHITO_HAND_DESIGN={lengths:[1.16,1.42,1.31,1.01],skin:0x51465f,ink:0x30263c};
function mahitoMergeParts(parts){
 const positions=[],normals=[],uvs=[];for(const [geometry,p,s,rotation=0]of parts){const m=new THREE.Matrix4().compose(p,new THREE.Quaternion().setFromAxisAngle(V(0,0,1),rotation),s),g=(geometry.index?geometry.toNonIndexed():geometry.clone()).applyMatrix4(m);positions.push(...g.attributes.position.array);normals.push(...g.attributes.normal.array);uvs.push(...g.attributes.uv.array);g.dispose();}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));return g;
}
function makeMahitoHandBatch(parent,count,pursuing=false){
 const g=new THREE.Group();g.name=pursuing?'pursuing-articulated-hands':'surrounding-articulated-hands';parent.add(g);
 const palmGeometry=mahitoMergeParts([[mahitoBlock,V(),V(1.16,1.26,.38)],[mahitoBlock,V(0,-.9,-.025),V(.63,.64,.42)],[mahitoBlock,V(0,-2.02,-.07),V(.82,1.75,.51)],[mahitoBlock,V(-.43,-.19,.075),V(.43,.58,.36),-.24]]);
 const detailParts=[[geo.box,V(0,-1.14,.219),V(.63,.045,.014)],[geo.box,V(0,-.09,.196),V(.76,.018,.012),-.16],[geo.box,V(.23,-.29,.198),V(.31,.014,.012),.62]];for(let j=0;j<5;j++)detailParts.push([geo.box,V(-.3+j*.15,-.09+(.3-j*.15)*.16,.209),V(.018,.1,.012),.16]);
 const material=new THREE.MeshStandardMaterial({color:pursuing?0xf7eedc:MAHITO_HAND_DESIGN.skin,emissive:pursuing?0xaaa399:0x191021,emissiveIntensity:pursuing?.38:.35,roughness:.88}),ink=new THREE.MeshStandardMaterial({color:MAHITO_HAND_DESIGN.ink,roughness:.8});
 const palm=new THREE.InstancedMesh(palmGeometry,material,count),fingers=new THREE.InstancedMesh(mahitoBlock.clone(),material,count*14),details=new THREE.InstancedMesh(mahitoMergeParts(detailParts),ink,count);g.add(palm,fingers,details);for(const m of [palm,fingers,details]){m.frustumCulled=false;m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);}
 return {g,palm,fingers,details,wrists:palm,display:Array.from({length:count},()=>({p:V(),cycle:-1,domain:-1})),lastTime:time,dummy:new THREE.Object3D(),base:new THREE.Object3D(),joint:new THREE.Object3D(),mat:new THREE.Matrix4(),q:new THREE.Quaternion(),p:V(),normal:V(),forward:V(0,0,1),jointPos:V(),step:V(),zAxis:V(0,0,1),xAxis:V(1,0,0)};
}
function setMahitoHand(h,index,position,direction,size,curl,roll=0){
 const b=h.base,d=h.dummy,j=h.joint;b.position.copy(position);b.quaternion.setFromUnitVectors(h.forward,direction);b.rotateZ(roll);b.scale.setScalar(Math.max(.00001,size));b.updateMatrix();h.palm.setMatrixAt(index,b.matrix);h.details.setMatrixAt(index,b.matrix);let part=0;
 for(let finger=0;finger<5;finger++){const thumb=finger===4,length=thumb?.94:MAHITO_HAND_DESIGN.lengths[finger],segments=thumb?2:3,width=thumb?.29:.235;h.jointPos.set(thumb?-.60:(finger-1.5)*.295,thumb?-.23:.56,thumb?.09:0);j.quaternion.setFromAxisAngle(h.zAxis,thumb?.88:(1.5-finger)*.07);
  for(let k=0;k<segments;k++){const len=length*(thumb?.5:k===0?.43:k===1?.33:.24);h.q.setFromAxisAngle(h.xAxis,curl*(thumb?.52:k===0?.55:.92));j.quaternion.multiply(h.q);d.quaternion.copy(j.quaternion);d.position.copy(h.jointPos).add(h.step.set(0,len*.5,0).applyQuaternion(j.quaternion));d.scale.set(width*(1-k*.07),len+.025,width*.84);d.updateMatrix();h.mat.multiplyMatrices(b.matrix,d.matrix);h.fingers.setMatrixAt(index*14+part++,h.mat);h.jointPos.add(h.step.set(0,len,0).applyQuaternion(j.quaternion));}
 }
}
function flushMahitoHands(h,count){h.palm.count=h.details.count=count;h.fingers.count=count*14;h.palm.instanceMatrix.needsUpdate=h.fingers.instanceMatrix.needsUpdate=h.details.instanceMatrix.needsUpdate=true;}
