// Fixed cast origins and one shared geometry definition drive capture, collision and both peers.
const DOMAIN_ENCLOSURE={radius:54,startup:1.55};
const barrierVisuals=new Map();
function enclosure(){return domain||clash;}
function enclosureCenter(e=enclosure()){return e?e.origin.clone().add(V(0,1.45,0)):null;}
function insideEnclosure(f){const e=enclosure();return !!e&&(e.capturedIds?e.capturedIds.includes(f.id):!!clash||domain.owner===f||domain.captured);}
function barrierSeparates(a,b){return !!enclosure()&&insideEnclosure(a)!==insideEnclosure(b);}
function barrierRayDistance(origin,dir,max=Infinity){
 const e=enclosure();if(!e)return Infinity;const center=enclosureCenter(e),oc=origin.clone().sub(center),b=oc.dot(dir),disc=b*b-oc.lengthSq()+DOMAIN_ENCLOSURE.radius**2;
 if(disc<0)return Infinity;const root=Math.sqrt(disc),near=-b-root,far=-b+root,t=near>.0001?near:far>.0001?far:Infinity;return t<=max?t:Infinity;
}
function constrainBarrier(f,pos=f.pos,previous=f.pos,velocity=null){
 const e=enclosure();if(!e)return pos;const center=enclosureCenter(e),head=pos.clone().add(V(0,1.45,0)),offset=head.clone().sub(center),distance=offset.length(),inside=insideEnclosure(f),limit=DOMAIN_ENCLOSURE.radius+(inside?-.7:.7);
 let normal=offset.clone().normalize(),correct=inside?distance>limit:distance<limit;
 if(!inside){const from=previous.clone().add(V(0,1.45,0)),travel=head.clone().sub(from),length=travel.length();if(length>.001){const t=barrierRayDistance(from,travel.clone().normalize(),length);if(Number.isFinite(t)){normal=from.addScaledVector(travel.normalize(),Math.max(0,t-.7)).sub(center).normalize();correct=true;}}}
 if(correct){if(normal.lengthSq()<.1)normal.set(0,0,1);pos.copy(center).addScaledVector(normal,limit).sub(V(0,1.45,0));pos.y=Math.max(.12,pos.y);if(velocity){const outward=velocity.dot(normal);if(inside?outward>0:outward<0)velocity.addScaledVector(normal,-outward*1.12);}}
 return pos;
}
function stopCastVoice(f){f.castVoiceActive=false;}
function beginCastVoice(f){f.castVoiceId=++techniqueSerial;f.castVoiceAge=0;f.castVoiceActive=true;beginMahitoFormation(f);}
function clearBarrierVisuals(){for(const v of barrierVisuals.values())removeObject(v.g);barrierVisuals.clear();}
function makeBarrierVisual(kind,origin){
 const g=new THREE.Group();g.name='domain-barrier-'+kind;scene.add(g);g.position.copy(origin).add(V(0,1.45,0));const color=0xf5f8ff;
 const uniforms={uBuild:{value:0},uSealed:{value:0},uTime:{value:0},uInside:{value:0},uColor:{value:new THREE.Color(color)}};
 const material=new THREE.ShaderMaterial({side:THREE.FrontSide,depthWrite:true,uniforms,
  vertexShader:'varying vec3 vP;void main(){vP=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:`varying vec3 vP;uniform float uBuild,uSealed,uTime,uInside;uniform vec3 uColor;
   void main(){vec3 p=normalize(vP);float a=atan(p.z,p.x);float top=mix(-1.025,1.025,uBuild)+sin(a*11.+uTime*2.)*.022*(1.-uBuild);if(p.y>top)discard;float front=exp(-abs(p.y-top)*100.);float softLight=.82+.18*max(0.,dot(p,normalize(vec3(-.4,.8,.5))));float seams=pow(abs(sin(a*18.+p.y*16.)),45.)*.017;vec3 c=vec3(.94,.97,1.)*(softLight-seams)+vec3(1.)*front*1.8*(1.-uSealed);gl_FragColor=vec4(c,1.);}`});
 const geometry=new THREE.SphereGeometry(DOMAIN_ENCLOSURE.radius,80,48),shell=mesh(geometry,material,g);shell.name='opaque-white-exterior';
 const insideMaterial=material.clone();insideMaterial.uniforms=uniforms;insideMaterial.side=THREE.BackSide;
 const inner=mesh(geometry.clone(),insideMaterial,g);inner.name='forming-white-interior';
 const ring=mesh(new THREE.TorusGeometry(DOMAIN_ENCLOSURE.radius,.065,5,128),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.9,depthWrite:false,blending:THREE.AdditiveBlending}),g,V(0,-1.35,0));ring.rotation.x=Math.PI/2;
 const crown=mesh(new THREE.TorusGeometry(1,.045,5,128),ring.material.clone(),g);crown.rotation.x=Math.PI/2;
 return {g,shell,inner,uniforms,ring,crown,kind};
}
function updateBarrierVisuals(){
 const live=new Set(),active=['play','finish','pause'].includes(phase);
 const show=(key,kind,origin,age,build,sealed,inside)=>{live.add(key);let v=barrierVisuals.get(key);if(!v){v=makeBarrierVisual(kind,origin);barrierVisuals.set(key,v);}v.g.position.copy(origin).add(V(0,1.45,0));v.uniforms.uTime.value=age;v.uniforms.uBuild.value=build;v.uniforms.uSealed.value=sealed?1:0;v.uniforms.uInside.value=inside?1:0;v.inner.visible=!sealed;v.ring.material.opacity=sealed?.3:.8;const y=DOMAIN_ENCLOSURE.radius*clamp(build,0,.999),r=Math.sqrt(DOMAIN_ENCLOSURE.radius**2-y*y);v.crown.position.y=y;v.crown.scale.set(Math.max(.03,r),Math.max(.03,r),1);v.crown.visible=!sealed;};
 if(active){
  for(const f of bodies){const c=castFor(f);if(c)show('cast-'+f.character+'-'+c.id,f.character,c.origin||f.pos,c.t,clamp(c.t/DOMAIN_ENCLOSURE.startup,0,1),false,true);}
  const e=enclosure();if(e)show('sealed-'+e.id,clash?'clash':domain.owner.character,e.origin,e.t,1,true,insideEnclosure(player));
 }
 for(const [key,v]of barrierVisuals)if(!live.has(key)){removeObject(v.g);barrierVisuals.delete(key);}
 if(phase==='play'&&bodies.some(f=>castFor(f))){
  const f=bodies.find(f=>castFor(f)),c=castFor(f),inRange=headPos(f===player?other(f):player).distanceTo((c.origin||f.pos).clone().add(V(0,1.45,0)))<DOMAIN_ENCLOSURE.radius;
  $('domainState').classList.remove('hidden');$('domainStage').textContent=(f===player?(inRange?'TARGET INSIDE':'TARGET OUTSIDE'):(inRange?'YOU ARE INSIDE':'YOU ARE OUTSIDE'))+' · BARRIER FORMING';$('domainTime').textContent=Math.max(0,DOMAIN_ENCLOSURE.startup-c.t).toFixed(1)+'s';$('domainState').dataset.kind=f.character;
 }else if(phase==='play'&&domain&&!insideEnclosure(player)){
  $('domainState').classList.remove('hidden');$('domainStage').textContent='DOMAIN SEALED · YOU ARE OUTSIDE';$('domainTime').textContent=Math.max(0,DOMAIN_RULES.duration-domain.t).toFixed(1)+'s';$('domainState').dataset.kind=domain.owner.character;
 }else if(!domain)$('domainState').classList.add('hidden');
}

// Domain interiors temporarily displace arena scenery; destruction state stays intact.
const DOMAIN_TERRAIN={padding:5,debrisPadding:3};
const domainTerrain={key:'',map:null,roots:[],inside:false};
function arenaPieceActive(p){return !!p?.alive&&!p.domainHidden;}
function domainTouchesPiece(p,e){
 const dx=Math.max(0,Math.abs(p.pos.x-e.origin.x)-p.size.x*.5-DOMAIN_TERRAIN.padding),dy=Math.max(0,Math.abs(p.pos.y-e.origin.y-1.45)-p.size.y*.5-DOMAIN_TERRAIN.padding),dz=Math.max(0,Math.abs(p.pos.z-e.origin.z)-p.size.z*.5-DOMAIN_TERRAIN.padding);
 return dx*dx+dy*dy+dz*dz<=DOMAIN_ENCLOSURE.radius**2;
}
function syncDomainTerrain(){
 const e=enclosure(),inside=!!e&&insideEnclosure(player),key=e?e.id+':'+e.origin.x+':'+e.origin.y+':'+e.origin.z:'';
 if(key!==domainTerrain.key||activeMap!==domainTerrain.map||inside!==domainTerrain.inside){
  for(const item of domainTerrain.roots)item.object.visible=domainTerrain.map===activeMap&&item.visible;
  domainTerrain.roots.length=0;
  // Remove complete intersecting buildings, including attached windows, roofs and ledges.
  const displaced=new Set();if(e)for(const p of pieces)if(p.building!==undefined&&domainTouchesPiece(p,e))displaced.add(p.building);
  for(const p of pieces)p.domainHidden=!!e&&(displaced.has(p.building)||domainTouchesPiece(p,e));
  if(inside){const pieceMeshes=new Set(pieces.map(p=>p.m));for(const object of mapCache.get(activeMap).objects)if(!pieceMeshes.has(object))domainTerrain.roots.push({object,visible:object.visible});}
  domainTerrain.key=key;domainTerrain.map=activeMap;domainTerrain.inside=inside;
  for(const f of bodies)if(f.narutoMobility?.kind===3&&!arenaPieceActive(pieces[f.narutoMobility.wallIndex]))leaveWallMotion(f);
 }
 for(const p of pieces)p.m.visible=arenaPieceActive(p);
 for(const item of domainTerrain.roots)item.object.visible=false;
 for(const d of debris){const dx=e?d.m.position.x-e.origin.x:0,dy=e?d.m.position.y-e.origin.y-1.45:0,dz=e?d.m.position.z-e.origin.z:0;d.m.visible=!e||dx*dx+dy*dy+dz*dz>(DOMAIN_ENCLOSURE.radius+DOMAIN_TERRAIN.debrisPadding)**2;}
}
