// Shared wall movement uses the existing mobility states (3: run, 4: jump),
// input router, stamina bar and moveFighter collision/gravity step.
const WALL_MOTION={attachBlend:.12,steerBlend:.10,exitBlend:.16,poseBlend:.11,jumpSpeedMultiplier:1.38,aimLift:20,minLift:-9,maxLift:22,jumpClearance:.18};
// Keep camera pitch and along-wall aim, but do not launch into the attached face.
function prepareWallJumpDirection(f){
 const m=narutoMobility(f),horizontal=Math.hypot(m.dir.x,m.dir.z),outward=m.dir.dot(m.normal),pitch=m.dir.y;
 if(horizontal<.001||outward>=horizontal*WALL_MOTION.jumpClearance)return;
 m.point.copy(m.dir).addScaledVector(m.normal,-outward).setY(0);
 // Looking straight into the wall keeps the run's direction instead of erasing it.
 if(m.point.lengthSq()<.01)m.point.copy(m.wallCarry).addScaledVector(m.normal,-m.wallCarry.dot(m.normal)).setY(0);
 if(m.point.lengthSq()<.01){m.dir.copy(m.normal).multiplyScalar(horizontal);m.dir.y=pitch;return;}
 m.point.normalize().multiplyScalar(horizontal*Math.sqrt(1-WALL_MOTION.jumpClearance**2));
 m.dir.copy(m.point).addScaledVector(m.normal,horizontal*WALL_MOTION.jumpClearance);m.dir.y=pitch;
}
function beginWallMotion(f,move){
 const m=narutoMobility(f);
 m.wallVelocity.copy(f.vel).addScaledVector(move,WORLD.sprint);m.wallVelocity.addScaledVector(m.normal,-m.wallVelocity.dot(m.normal));
 const horizontal=Math.hypot(m.wallVelocity.x,m.wallVelocity.z);if(horizontal>WORLD.sprint){m.wallVelocity.x*=WORLD.sprint/horizontal;m.wallVelocity.z*=WORLD.sprint/horizontal;}
 m.wallExit=0;
}
function stepWallMotion(f,dt,move){
 const m=narutoMobility(f),w=NARUTO_MOBILITY.wall;
 m.tangent.copy(move).addScaledVector(m.normal,-move.dot(m.normal));const amount=m.tangent.length(),along=narutoEase((amount-.12)/.48);
 if(amount>.001)m.tangent.multiplyScalar(1/amount);else m.tangent.set(0,0,0);
 const blend=1-Math.exp(-dt/WALL_MOTION.steerBlend),rise=1-Math.exp(-dt/WALL_MOTION.attachBlend);
 m.wallVelocity.x=lerp(m.wallVelocity.x,m.tangent.x*w.speed*along,blend);m.wallVelocity.z=lerp(m.wallVelocity.z,m.tangent.z*w.speed*along,blend);
 m.wallVelocity.y=lerp(m.wallVelocity.y,lerp(w.climb,w.lift,along),rise);
 f.vel.copy(m.wallVelocity);m.dir.copy(m.tangent).multiplyScalar(along).addScaledVector(m.normal,-(1-along)).normalize();constrainWallVelocity(f,dt);
}
function leaveWallMotion(f){
 const m=narutoMobility(f);rememberWall(f);m.wallExit=WALL_MOTION.exitBlend;m.wallCarry.copy(m.wallVelocity);cancelNarutoMobility(f);
}
function stepWallExit(f,dt,move,held){
 const m=narutoMobility(f);if(m.wallExit<=0)return false;
 m.wallExit=Math.max(0,m.wallExit-dt);if(m.wallExit===0){f.vel.x=f.vel.z=0;return false;}
 const q=narutoEase(1-m.wallExit/WALL_MOTION.exitBlend),speed=held.has('ShiftLeft')&&f.stamina>1?WORLD.sprint:WORLD.walk;
 f.vel.x=lerp(m.wallCarry.x,move.x*speed,q);f.vel.z=lerp(m.wallCarry.z,move.z*speed,q);constrainWallVelocity(f,dt);return true;
}
function stepWallJump(f,dt,move,held){
 const m=narutoMobility(f),c=NARUTO_MOBILITY.wallJump,end=c.startup+c.active+c.recovery;
 if(m.t>=end){f.vel.x=f.vel.z=0;cancelNarutoMobility(f);return false;}
 const gather=narutoEase(m.t/c.startup),push=narutoEase((m.t-c.startup)/.14),settle=narutoEase((m.t-c.startup-c.active+.10)/(.10+c.recovery));
 const speed=held.has('ShiftLeft')&&f.stamina>1?WORLD.sprint:WORLD.walk;
 const horizontal=Math.hypot(m.dir.x,m.dir.z),carrySpeed=Math.hypot(m.wallCarry.x,m.wallCarry.z),launchSpeed=c.distance/c.active*WALL_MOTION.jumpSpeedMultiplier;
 const scale=horizontal>.001?Math.max(launchSpeed,carrySpeed/horizontal):launchSpeed;
 m.point.copy(m.wallCarry).lerp(m.tangent.copy(m.dir).multiplyScalar(scale),push);
 m.point.x=lerp(m.point.x,move.x*speed,settle);m.point.z=lerp(m.point.z,move.z*speed,settle);
 // Raise the impulse over the planted-foot anticipation, then let shared gravity make the arc.
 if(!m.launched){f.vel.y=lerp(m.wallCarry.y,clamp(c.impulse+m.dir.y*WALL_MOTION.aimLift,WALL_MOTION.minLift,WALL_MOTION.maxLift),gather);if(m.t>=c.startup){m.launched=true;sfx('airStep',f.pos,.65);}}
 f.vel.x=m.point.x;f.vel.z=m.point.z;constrainWallVelocity(f,dt);f.grounded=false;return true;
}
function constrainWallVelocity(f,dt){
 const m=narutoMobility(f),speed=Math.hypot(f.vel.x,f.vel.z);if(speed<.001||dt<=0)return;
 m.tangent.set(f.vel.x/speed,0,f.vel.z/speed);const allowed=narutoMobilityDistance(f,m.tangent,speed*dt)/dt;f.vel.x=m.tangent.x*allowed;f.vel.z=m.tangent.z*allowed;
}
function sharedWallPose(f){
 const m=f.narutoMobility;if(!m||m.kind!==3&&m.kind!==4)return null;
 const p=m.sharedPose;p.fill(0);p[NP.stretch]=1;animateNarutoMobilityPose(f,p);return p;
}
function sharedWallFacing(f,dt){
 const m=f.narutoMobility;if(!m)return null;const on=m.kind===3||m.kind===4;
 m.wallVisualWeight=lerp(m.wallVisualWeight,on?1:0,1-Math.exp(-dt/WALL_MOTION.poseBlend));
 return on?Math.atan2(m.dir.x,m.dir.z):null;
}
