// Domain sure-hit timeline and pooled presentation. Clones use the existing rig/pose/VFX pools.
// They are attacks owned by Naruto, not fighters: no extra HP bars, AI or clash points.
const MINDSCAPE_ASSAULT={
 clonesPerTarget:6,waves:4,firstHit:1.45,waveInterval:3,anticipation:1.15,recovery:.55,
 offsets:[0,.13,.26,.39,.60,.90],techniques:[2,2,3,3,4,5],damage:[12,12,18,18,30,60],
 orbitRadius:8,tetherSegments:8,tetherColor:0xff6a32,tetherOpacity:.36,shake:.10
};
let mindscapeClones=null;
function updateMindscapeAssault(d){
 const c=MINDSCAPE_ASSAULT;d.clonePulse??=0;
 while(d.clonePulse<c.waves*c.clonesPerTarget&&phase==='play'){
  const pulse=d.clonePulse,role=pulse%c.clonesPerTarget,wave=Math.floor(pulse/c.clonesPerTarget),at=c.firstHit+wave*c.waveInterval+c.offsets[role];
  if(d.t+1e-8<at)break;d.clonePulse++;
  for(const victim of bodies){if(victim===d.owner||victim.hp<=0||!d.capturedIds.includes(victim.id))continue;
   if(hurt(victim,c.damage[role],d.owner,'ultimate',V(),0)){
    const kind=c.techniques[role],pos=headPos(victim);narutoFX(kind===2?'impact':kind===3?'spiral':kind===4?'windBurst':'bomb',pos,kind===5?3:kind===4?2:1.2,d.axis);
    if(victim===player||d.owner===player)shakeIt(c.shake*(kind===5?2:1));
   }
  }
  if(role===5&&wave===c.waves-1){sfx('kuramaRoar',d.origin,.9);flashIt(.15);}
 }
}
function ensureMindscapeClones(){
 if(mindscapeClones)return mindscapeClones;
 const c=MINDSCAPE_ASSAULT,count=(MAX_FIGHTERS-1)*c.clonesPerTarget,g=new THREE.Group();g.name='mindscape-clone-chakra';scene.add(g);
 const positions=new Float32Array(count*c.tetherSegments*6),geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(positions,3).setUsage(THREE.DynamicDrawUsage));
 const lines=new THREE.LineSegments(geometry,new THREE.LineBasicMaterial({color:c.tetherColor,transparent:true,opacity:c.tetherOpacity,depthWrite:false,blending:THREE.AdditiveBlending}));lines.frustumCulled=false;g.add(lines);
 const slots=[];for(let i=0;i<count;i++){const sphere=i%6>=2?narutoSphereRig():null;if(sphere)g.add(sphere.g);slots.push({sphere,domainId:-1,wave:-1,targetId:'',visible:false,last:V()});}
 return mindscapeClones={g,lines,geometry,positions,slots,center:V(),anchor:V(),target:V(),home:V(),point:V(),direction:V(),up:V(0,0,1),origin:V(),domainId:-1};
}
function clearMindscapeClones(){
 if(!mindscapeClones)return;const v=mindscapeClones;v.g.visible=false;for(const s of v.slots){s.visible=false;s.domainId=-1;s.wave=-1;if(s.sphere)s.sphere.g.visible=false;}
}
function confineMindscapeClonePoint(p,v){
 v.point.copy(p).sub(v.center);v.point.y+=1.45;const r=DOMAIN_ENCLOSURE.radius-3,len=v.point.length();
 if(len>r)p.copy(v.center).addScaledVector(v.point,r/len).y-=1.45;
 p.y=Math.max(.12,p.y);
}
function animateMindscapeClones(clones,index,dt){
 const d=domain;
 if(!d||d.owner.character!=='naruto'||d.owner.hp<=0||!insideEnclosure(player)||!['play','pause','finish'].includes(phase)){clearMindscapeClones();return index;}
 const v=ensureMindscapeClones(),c=MINDSCAPE_ASSAULT,age=domainPresentationAge(d.t);v.g.visible=true;
 if(v.domainId!==d.id){clearMindscapeClones();v.g.visible=true;v.domainId=d.id;v.origin.copy(d.origin);
  if(!v.clipped){confineDomainVisual(v.g,d.origin);v.clipped=true;}
  v.g.traverse(o=>{if(o.material?.userData.domainClip)o.material.userData.domainClip.center.copy(d.origin).y+=1.45;});
 }
 v.center.copy(d.origin);v.center.y+=1.45;v.anchor.copy(d.origin).addScaledVector(d.axis,29);v.anchor.y+=12;
 let targetIndex=0,vertices=0;
 for(const s of v.slots)if(s.sphere)s.sphere.g.visible=false;
 for(const victim of bodies){if(victim===d.owner||victim.hp<=0||!d.capturedIds.includes(victim.id))continue;
  v.target.copy(victim.pos);v.target.y+=1.25;
  for(let role=0;role<c.clonesPerTarget;role++){
   const slot=v.slots[targetIndex*c.clonesPerTarget+role],start=c.firstHit-c.anticipation+c.offsets[role],wave=Math.floor((age-start)/c.waveInterval),local=age-start-wave*c.waveInterval;
   if(wave<0||wave>=c.waves||local>c.anticipation+c.recovery||index>=NARUTO.clonePool){if(slot.visible&&dt>0)narutoFX('smoke',slot.last,.65,null,false);slot.visible=false;continue;}
   ensureNarutoClones();const clone=clones.clones[index++],kind=c.techniques[role],angle=role/c.clonesPerTarget*Math.PI*2+wave*.71+targetIndex*.4;
   v.home.set(Math.cos(angle)*c.orbitRadius,role%2?2.2:-1.2,Math.sin(angle)*c.orbitRadius).add(victim.pos);
   const rush=kind<=3?narutoEase((local-.35)/.8):0,settle=narutoEase((local-c.anticipation)/c.recovery);
   clone.f.pos.copy(v.home).lerp(victim.pos,rush*.84*(1-settle*.12));clone.f.pos.y+=Math.sin(clamp(local/c.anticipation,0,1)*Math.PI)*(kind<=3?1.4:.55);confineMindscapeClonePoint(clone.f.pos,v);
   if(slot.domainId!==d.id||slot.wave!==wave||slot.targetId!==victim.id){slot.domainId=d.id;slot.wave=wave;slot.targetId=victim.id;if(dt>0)narutoFX('smoke',clone.f.pos,.8,null,false);}slot.visible=true;slot.last.copy(clone.f.pos);
   v.direction.copy(v.target).sub(clone.f.pos).normalize();clone.f.cloneFacing=Math.atan2(v.direction.x,v.direction.z);clone.f.vel.copy(v.direction).multiplyScalar(kind<=3&&rush>0&&rush<1?15:0);clone.f.grounded=false;
   clone.used=clone.active=true;clone.pose.boost=false;clone.pose.technique=kind;
   // Time-warp established attack tracks into a readable wind-up, strike, then recovery.
   clone.pose.age=kind===2?local/c.anticipation*1.02:kind===3?Math.max(0,(local-c.anticipation+.15)*1.2):kind===4?Math.max(0,(local-c.anticipation+.2)*1.3):local<=c.anticipation?local/c.anticipation*2.23:2.23+(local-c.anticipation)*2.1;
   animateNaruto(clone.f,dt,clone.pose);const fade=narutoEase(local/.12)*(1-narutoEase((local-c.anticipation-.34)/.21));clone.f.root.scale.setScalar(Math.max(.015,fade));clone.f.root.updateMatrixWorld(true);
   for(const entry of clone.entries)entry.batch.mesh.setMatrixAt(entry.index,entry.node.matrixWorld);
   if(slot.sphere){const r=slot.sphere,flight=kind>=4?narutoEase((local-c.anticipation+.22)/.22):0,size=(kind===5?.95:kind===4?.6:.35)*narutoEase(local/.5)*(1-narutoEase((local-c.anticipation)/.14));
    if(size>.005){narutoSphereAppearance(r,kind,age,.45,size);clone.f.limbs[1].hand.getWorldPosition(r.g.position);if(kind===4)r.g.position.y+=.7;if(kind===5)r.g.position.addScaledVector(v.direction,1.1);if(kind>=4)r.g.position.lerp(v.target,flight);r.g.quaternion.setFromUnitVectors(v.up,v.direction);}
   }
   // Eight flowing segments per tether; positions and line geometry are reused every frame.
   for(let segment=0;segment<c.tetherSegments;segment++)for(let end=0;end<2;end++){
    const q=(segment+end)/c.tetherSegments,wiggle=Math.sin(q*Math.PI)*.45;
    v.point.copy(v.anchor).lerp(clone.f.pos,q);v.point.y+=1.45*q+Math.sin(q*12-age*7+role)*wiggle;v.point.x+=Math.cos(q*17-age*6+role)*wiggle;
    v.positions[vertices++]=v.point.x;v.positions[vertices++]=v.point.y;v.positions[vertices++]=v.point.z;
   }
  }
  targetIndex++;
 }
 for(let i=targetIndex*c.clonesPerTarget;i<v.slots.length;i++)v.slots[i].visible=false;
 v.geometry.setDrawRange(0,vertices/3);v.geometry.attributes.position.needsUpdate=true;v.lines.material.opacity=c.tetherOpacity*(.7+.3*Math.sin(age*5)**2);
 return index;
}
