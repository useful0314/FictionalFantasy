// Existing articulated block rig, with a dedicated suit and mask. No shared materials are modified.
function fighterModelSpider(){
 const r=fighterBlockModel('spiderman'),p=r.blockRig.parts;
 const red=new THREE.MeshStandardMaterial({color:0xc92f43,roughness:.68}),blue=new THREE.MeshStandardMaterial({color:0x163c70,roughness:.73}),black=new THREE.MeshStandardMaterial({color:0x111827,roughness:.7}),white=new THREE.MeshStandardMaterial({color:0xf4fbff,roughness:.28,metalness:.18}),web=new THREE.LineBasicMaterial({color:0x331725,transparent:true,opacity:.8});
 r.blockRig.hair.visible=false;
 for(const [name,m]of Object.entries(p)){if(/^(nose|mouth|ear-|eye-|iris|pupil|brow|shoe-seam)/.test(name)){m.visible=false;continue;}m.material=/^(thigh|upper-arm|hips)/.test(name)?blue:/^(sole|cuff)/.test(name)?black:red;}
 const add=(name,parent,pos,size,mat)=>{const o=mesh(blockUnitGeometry(),mat,parent,pos,size);o.name=name;o.castShadow=true;p[name]=o;return o;};
 for(const side of [-1,1]){
  const eye=add('mask-frame-'+side,r.headGroup,V(side*.142,.055,.253),V(.224,.175,.035),black);eye.rotation.z=-side*.31;
  add('mask-lens-'+side,eye,V(0,0,.55),V(.79,.72,.25),white);
  add('suit-blue-side-'+side,r.blockRig.torso,V(side*.324,-.14,.249),V(.15,.56,.022),blue);
  add('web-shooter-'+side,r.limbs[side<0?0:1].hand,V(0,.02,.085),V(.14,.065,.035),white);
 }
 const emblem=new THREE.Group();r.blockRig.torso.add(emblem);emblem.position.set(0,.13,.269);
 add('spider-abdomen',emblem,V(0,-.04,0),V(.095,.18,.022),black);add('spider-head',emblem,V(0,.07,0),V(.065,.065,.025),black);
 for(const side of [-1,1])for(let j=0;j<4;j++){const leg=add('spider-leg-'+side+'-'+j,emblem,V(side*.108,.09-j*.064,0),V(.19,.019,.022),black);leg.rotation.z=side*(.7-j*.47);const tip=add('spider-tip-'+side+'-'+j,emblem,V(side*.19,.14-j*.098,0),V(.018,.12,.022),black);tip.rotation.z=side*(j<2?-.15:.2);}
 const lines=[];const segment=(a,b)=>lines.push(...a,...b);
 // Curved radial mask web, following the block silhouette without floating rings.
 for(let i=0;i<7;i++){const angle=i*Math.PI/3;segment([0,-.06,.24],[Math.cos(angle)*.26,Math.sin(angle)*.28-.015,.24]);}
 for(const radius of [.12,.22])for(let i=0;i<12;i++){const a=i/12*Math.PI*2,b=(i+1)/12*Math.PI*2;segment([Math.cos(a)*radius,Math.sin(a)*radius-.015,.243],[Math.cos(b)*radius,Math.sin(b)*radius-.015,.243]);}
 const faceLines=new THREE.LineSegments(new THREE.BufferGeometry().setAttribute('position',new THREE.Float32BufferAttribute(lines,3)),web);r.headGroup.add(faceLines);
 for(const limb of r.limbs){for(let j=0;j<3;j++)add('glove-web-'+limb.arm.name+'-'+j,limb.elbow,V(0,-.07-j*.1,.133),V(.24,.009,.005),black);}
 return r;
}
