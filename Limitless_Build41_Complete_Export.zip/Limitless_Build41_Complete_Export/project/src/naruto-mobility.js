// Naruto boost/dash and shared wall tuning. Seconds/metres; existing gravity, collision and inputs remain authoritative.
const NARUTO_MOBILITY={
 boost:{cooldown:0,cost:5,startup:.08,active:.36,recovery:.10,impulse:12,dashDistance:10.4,distance:4.6,nudge:1.6,cloneLife:.26,buffer:.16,maxHold:1.2,chargedActive:.52,chargedDashDistance:15.9,chargedDistance:8.5,chargedNudge:4.2},
 dash:{distance:7.5,cooldown:DODGE.cooldown,stamina:14,cost:4,startup:.07,active:.18,recovery:.10,dodge:.34,perfect:.20},
 wallJump:{startup:.12,active:.42,recovery:.16,impulse:13.5,distance:8.5,cooldown:.28},
 wall:{startup:.12,climb:11,speed:26,lift:3,stamina:8,cooldown:.12,probe:.7,skin:.46},
 trailInterval:.03,trailLife:.3,smokeLife:.36,blue:0x59cfff,gold:0xffcb64
};
const NARUTO_MOBILITY_POSES={
 gather:narutoPoseTemplate({lean:-.12,twist:-.25,bob:-.13,stretch:.94,lx:-1.05,rx:-.95,le:-1.5,re:-1.5,ll:-1.15,lk:1.8,rl:-.75,rk:1.45,lz:.2,rz:-.2}),
 kickoff:narutoPoseTemplate({lean:.2,twist:.25,bob:.04,stretch:1.08,lx:-.7,rx:.35,le:-.7,re:-.4,lz:.48,rz:-.45,ll:-1.05,lk:1.3,rl:.2,rk:.06,rf:-.3}),
 support:narutoPoseTemplate({lean:.1,bob:-.24,stretch:.93,lx:-2.65,rx:-2.65,le:-.5,re:-.5,lz:.1,rz:-.1,lh:-.8,rh:-.8,ll:-.65,rl:-.65,lk:1.4,rk:1.4}),
 dash:narutoPoseTemplate({lean:.65,twist:.18,bob:-.2,stretch:1.045,lx:.85,rx:.65,le:-.28,re:-.45,ll:-1.05,lk:1.25,rl:.65,rk:.25})
};
function narutoMobility(f){
 if(f.narutoMobility)return f.narutoMobility;
 return f.narutoMobility={kind:0,t:0,uses:0,boostCD:0,dashCD:0,wallCD:0,wallJumpCD:0,jumpQueue:0,baseSpeed:0,wallSpent:0,wallIndex:-1,serial:0,charging:false,chargeTime:0,power:0,directional:false,launched:false,poofed:false,moved:0,trail:0,wasGrounded:f.grounded,dir:V(0,0,-1),normal:V(),cloneOrigin:V(),point:V(),tangent:V(),wallVelocity:V(),wallCarry:V(),wallExit:0,wallVisualWeight:0,sharedPose:new Float32Array(30)};
}
function narutoMobilityBusy(f){const k=f.narutoMobility?.kind;return k===1||k===2||k===4;}
function narutoMobilityAge(m){return m.t+(mode==='online'&&net?.role==='guest'?narutoReplicaAge:0);}
function cancelNarutoMobility(f,quiet=false){
 const m=f.narutoMobility;if(!m||!m.kind)return;
 if(m.kind===1&&!m.poofed&&!quiet){narutoFX('smoke',m.cloneOrigin,.65);m.poofed=true;}
 if(m.kind===3)m.wallCD=NARUTO_MOBILITY.wall.cooldown;
 m.kind=0;m.t=0;m.charging=false;m.wallIndex=-1;m.trail=0;
}
function resetNarutoMobility(f){
 const m=f.narutoMobility;if(!m)return;cancelNarutoMobility(f,true);m.uses=m.boostCD=m.dashCD=m.wallCD=m.wallJumpCD=m.jumpQueue=m.wallSpent=m.serial=0;m.wasGrounded=true;m.wallExit=m.wallVisualWeight=0;m.wallVelocity.set(0,0,0);m.wallCarry.set(0,0,0);
}
function narutoMobilityBlocked(f){return phase!=='play'||f.hp<=0||f.stun>0||f.ragdollT>0||f.recovery>0||chargeFor(f)||castFor(f)||trappedByVoid(f)||!!f.narutoAction||worldCutBusy(f)||mahitoBusy(f)||spiderBusy(f)||f.flying;}
function startNarutoBoost(f){
 const c=NARUTO_MOBILITY.boost,m=narutoMobility(f);
 if(f.character!=='naruto'||f.grounded||narutoMobilityBlocked(f)||(narutoMobilityBusy(f)&&!(m.kind===1&&m.launched))||f.dodge>0||f.energy<c.cost||f.pos.y>WORLD.ceiling-2)return false;
 m.dir.copy(moveDirection(f)).setY(0);const moving=m.dir.lengthSq()>.1;m.directional=inputFor(f).has('ShiftLeft')&&moving;m.baseSpeed=moving?(m.directional?WORLD.sprint:WORLD.walk):0;
 if(m.dir.lengthSq()<.1)narutoAim(m.dir,f).setY(0);m.dir.normalize();
 responseState(f).groundGrace=responseState(f).wallGrace=0;cancelNarutoMobility(f);m.kind=1;m.wallExit=0;m.t=0;m.serial++;m.uses++;m.boostCD=c.cooldown;m.wasGrounded=false;m.launched=false;m.poofed=false;m.moved=0;m.trail=0;
 m.charging=inputFor(f).has('Space');m.chargeTime=0;m.power=0;m.jumpQueue=0;m.cloneOrigin.copy(f.pos);m.cloneOrigin.y-=2.4;f.energy-=c.cost;f.vel.x=f.vel.z=0;f.block=false;f.airJumpCooldown=c.cooldown;f.jumpPose=c.startup+c.active;
 narutoFX('smoke',m.cloneOrigin,.8);sfx('narutoClone',f.pos,.55);return true;
}
function narutoBoostActive(m){return lerp(NARUTO_MOBILITY.boost.active,NARUTO_MOBILITY.boost.chargedActive,m.power||0);}
function releaseNarutoBoost(f){
 const m=f.narutoMobility;if(!m||m.kind!==1||!m.charging)return false;
 m.power=clamp(m.chargeTime/NARUTO_MOBILITY.boost.maxHold,0,1);m.charging=false;m.t=Math.min(NARUTO_MOBILITY.boost.startup,m.chargeTime);m.moved=narutoBoostTravel(m,m.t);return true;
}
// One buffered press avoids losing Jump at the end of a boost; holding never auto-spams.
function requestNarutoAirJump(f){
 const m=narutoMobility(f);if(narutoMobilityBlocked(f)||f.flying||f.dodge>0||f.pos.y>WORLD.ceiling-2)return false;
 if(m.kind===3)return startNarutoWallJump(f);
 if(narutoMobilityBusy(f)&&!(m.kind===1&&m.launched)){if(m.kind===1&&f.energy>=NARUTO_MOBILITY.boost.cost)m.jumpQueue=NARUTO_MOBILITY.boost.buffer;return false;}
 return startNarutoBoost(f);
}
function startNarutoWallJump(f,grace=false){
 const m=narutoMobility(f),c=NARUTO_MOBILITY.wallJump,p=pieces[m.wallIndex];
 if(m.kind!==3||m.wallJumpCD>0||!arenaPieceActive(p)||!grace&&!narutoWallFits(f,m,p)||narutoMobilityBlocked(f))return false;
 responseState(f).groundGrace=responseState(f).wallGrace=0;m.dir.copy(aimFor(f)).normalize();
 m.wallCarry.copy(m.wallVelocity);prepareWallJumpDirection(f);cancelNarutoMobility(f);m.wallExit=0;m.kind=4;m.t=0;m.serial++;m.wallJumpCD=c.cooldown;m.wallCD=c.startup+c.active+c.recovery;m.launched=false;m.moved=0;m.trail=0;m.jumpQueue=0;m.wasGrounded=false;f.block=false;f.airJumpCooldown=.12;f.jumpPose=c.startup+c.active;
 sfx('step',f.pos,.8);return true;
}
// Integral of an eased speed pulse: preserve approach speed instead of stopping during wind-up.
function narutoBoostTravel(m,t){
 const c=NARUTO_MOBILITY.boost,base=m.baseSpeed,active=narutoBoostActive(m),power=m.power||0,distance=m.directional?lerp(c.dashDistance,c.chargedDashDistance,power):base>0?lerp(c.distance,c.chargedDistance,power):lerp(c.nudge,c.chargedNudge,power);
 const a=clamp(t-c.startup,0,active),u=a/active,extra=Math.max(0,distance-base*active),pulse=u-Math.sin(u*Math.PI*2)/(Math.PI*2);
 return base*Math.min(t,c.startup+active+c.recovery)+extra*pulse;
}
function startNarutoChakraDash(f){
 const c=NARUTO_MOBILITY.dash,m=narutoMobility(f);
 if(f.character!=='naruto'||narutoMobilityBlocked(f)||narutoMobilityBusy(f)||f.dodge>0||f.dodgeCooldown>0||m.dashCD>0||f.stamina<c.stamina||f.energy<c.cost)return false;
 m.dir.copy(moveDirection(f)).setY(0);if(m.dir.lengthSq()<.1)narutoAim(m.dir,f).setY(0).multiplyScalar(-1);m.dir.normalize();
 cancelNarutoMobility(f);m.kind=2;m.wallExit=0;m.t=0;m.serial++;m.dashCD=c.cooldown;m.launched=false;m.moved=0;m.trail=0;
 f.stamina-=c.stamina;f.energy-=c.cost;f.dodgeCooldown=DODGE.cooldown;f.dodge=c.dodge;f.dodgeWindow=c.perfect;f.substitutionUsed=false;f.block=false;f.vel.x=f.vel.z=0;return true;
}
// Swept expanded AABBs match resolveDistrictCollision's .43m capsule margin.
// This prevents a fast chakra dash tunnelling through thin scenery without new collision objects.
function narutoMobilityDistance(f,dir,distance){
 let allowed=distance;
 for(const p of pieces){if(!arenaPieceActive(p)||!p.solid||f.pos.y+2.3<p.pos.y-p.size.y/2||f.pos.y>p.pos.y+p.size.y/2-.08)continue;
  const hx=p.size.x/2+.43,hz=p.size.z/2+.43,dx=f.pos.x-p.pos.x,dz=f.pos.z-p.pos.z;
  let near=-Infinity,far=Infinity;
  if(Math.abs(dir.x)<1e-7){if(Math.abs(dx)>=hx)continue;}else{const a=(-hx-dx)/dir.x,b=(hx-dx)/dir.x;near=Math.max(near,Math.min(a,b));far=Math.min(far,Math.max(a,b));}
  if(Math.abs(dir.z)<1e-7){if(Math.abs(dz)>=hz)continue;}else{const a=(-hz-dz)/dir.z,b=(hz-dz)/dir.z;near=Math.max(near,Math.min(a,b));far=Math.min(far,Math.max(a,b));}
  if(far>=Math.max(0,near)&&near>=-.025)allowed=Math.min(allowed,Math.max(0,near-.015));
 }
 return allowed;
}
function narutoMobilityTravel(f,dir,distance){const allowed=narutoMobilityDistance(f,dir,distance);narutoMove(f,dir,allowed);return allowed;}
function narutoWallCandidate(f,move,continuing=false){
 const m=narutoMobility(f),c=NARUTO_MOBILITY.wall;let best=c.probe,index=-1,nx=0,nz=0;
 for(let i=0;i<pieces.length;i++){const p=pieces[i];if(!arenaPieceActive(p)||!p.solid||p.size.y<1.5||f.pos.y+1.4<p.pos.y-p.size.y/2||f.pos.y+1>p.pos.y+p.size.y/2)continue;
  const dx=f.pos.x-p.pos.x,dz=f.pos.z-p.pos.z,hx=p.size.x/2,hz=p.size.z/2;
  for(let face=0;face<4;face++){const x=face<2?(face===0?1:-1):0,z=face>=2?(face===2?1:-1):0,gap=x?dx*x-hx:dz*z-hz,inside=x?Math.abs(dz)<hz-.05:Math.abs(dx)<hx-.05;
   if(inside&&gap>=.38&&gap<best&&(continuing?m.normal.x*x+m.normal.z*z>.99:move.x*x+move.z*z<-.2)){best=gap;index=i;nx=x;nz=z;}
  }
 }
 if(index<0)return false;m.wallIndex=index;m.normal.set(nx,0,nz);return true;
}
function narutoWallFits(f,m,p){return (m.normal.x?Math.abs(f.pos.z-p.pos.z)<p.size.z/2:Math.abs(f.pos.x-p.pos.x)<p.size.x/2)&&f.pos.y+1.4>p.pos.y-p.size.y/2&&f.pos.y+1<p.pos.y+p.size.y/2;}
function updateNarutoMobility(f,dt,move,held){
 const m=narutoMobility(f),c=NARUTO_MOBILITY;
 m.boostCD=Math.max(0,m.boostCD-dt);m.dashCD=Math.max(0,m.dashCD-dt);m.wallCD=Math.max(0,m.wallCD-dt);m.wallJumpCD=Math.max(0,m.wallJumpCD-dt);
 if(narutoMobilityBlocked(f)){m.jumpQueue=0;m.wallExit=0;cancelNarutoMobility(f);return false;}
 if(m.jumpQueue>0){m.jumpQueue=Math.max(0,m.jumpQueue-dt);if((m.kind===0||m.kind===1&&m.launched)&&!f.grounded)startNarutoBoost(f);}
 const wallInput=held.has('ShiftLeft')&&f.stamina>1&&move.lengthSq()>.1&&!f.grounded&&!f.block&&!held.has('Mouse2')&&!held.has('KeyC')&&f.attack<=0&&f.dodge<=0;
 if(m.kind===0&&wallInput&&m.wallCD<=0&&narutoWallCandidate(f,move)){
  m.kind=3;m.t=0;m.serial++;m.trail=0;m.wasGrounded=false;beginWallMotion(f,move);
 }
 if(!m.kind)return stepWallExit(f,dt,move,held);
 if(m.kind===1&&m.charging){
  m.chargeTime=Math.min(c.boost.maxHold,m.chargeTime+dt);m.power=m.chargeTime/c.boost.maxHold;
  narutoMobilityTravel(f,m.dir,m.baseSpeed*dt);f.vel.y=Math.max(f.vel.y,-3);m.cloneOrigin.copy(f.pos);m.cloneOrigin.y-=2.4;
  if(!held.has('Space')||m.chargeTime>=c.boost.maxHold)releaseNarutoBoost(f);else return true;
 }
 m.t+=dt;
 if(m.kind===4)return stepWallJump(f,dt,move,held);
 if(m.kind===3){
  const w=c.wall;let p=pieces[m.wallIndex];
  // Buildings are stacked breakable floors: cross an intact seam without buying more airtime.
  if(arenaPieceActive(p)&&!narutoWallFits(f,m,p)&&narutoWallCandidate(f,move,true))p=pieces[m.wallIndex];
  const dx=p?f.pos.x-p.pos.x:0,dz=p?f.pos.z-p.pos.z:0,gap=p?(m.normal.x?dx*m.normal.x-p.size.x/2:dz*m.normal.z-p.size.z/2):Infinity,faceFits=p&&narutoWallFits(f,m,p);
  if(!wallInput||!arenaPieceActive(p)||!p.solid||!faceFits||gap>w.probe+.15||gap<.35||move.dot(m.normal)>.35||f.stamina<w.stamina*dt){leaveWallMotion(f);return stepWallExit(f,dt,move,held);}
  m.wallSpent=Math.min(60,m.wallSpent+dt);m.t=Math.min(60,m.t);f.stamina=Math.max(0,f.stamina-w.stamina*dt);
  // Stick along the face only. Shared gravity/ground/platform/barrier resolution still runs below.
  m.point.copy(f.pos);f.pos.addScaledVector(m.normal,(w.skin-gap)*(1-Math.exp(-dt/.08)));constrainBarrier(f,f.pos,m.point,f.vel);
  stepWallMotion(f,dt,move);return true;
 }
 const k=m.kind===1?c.boost:m.kind===4?c.wallJump:c.dash,end=k.startup+(m.kind===1?narutoBoostActive(m):k.active)+k.recovery;
 if(!m.launched&&m.t>=k.startup){
  m.launched=true;if(m.kind===1||m.kind===4){f.vel.y=k.impulse;f.vel.x=f.vel.z=0;f.grounded=false;sfx('airStep',f.pos,.65);}
  else{afterImage(f,c.blue);sfx('dodge',f.pos,.8);}
 }
 if(m.kind===1||m.launched){const total=m.kind===1?narutoBoostTravel(m,m.t):k.distance*narutoEase((m.t-k.startup)/k.active);narutoMobilityTravel(f,m.dir,Math.max(0,total-m.moved));m.moved=total;}
 if(m.kind===1&&!m.poofed&&m.t>=c.boost.cloneLife){narutoFX('smoke',m.cloneOrigin,.75);m.poofed=true;}
 if(m.t>=end)cancelNarutoMobility(f);return true;
}
function finishNarutoMobilityStep(f){
 const m=narutoMobility(f);
 if(f.grounded&&!m.wasGrounded){m.uses=0;m.wallSpent=0;m.jumpQueue=0;m.wallExit=0;if(f.character!=='naruto'&&(m.kind===3||m.kind===4)){particles(f.pos,0xc8c4b7,12,1.8,.32,.12);}if(m.kind===1||m.kind===3||m.kind===4)cancelNarutoMobility(f);}
 m.wasGrounded=f.grounded;
}
function narutoMobilityFacing(f){const m=f.narutoMobility;return m&&(m.kind===3||m.kind===4)?Math.atan2(m.dir.x,m.dir.z):null;}
function animateNarutoMobilityPose(f,p){
 const m=f.narutoMobility;if(!m?.kind)return;const t=m.charging?Math.min(m.chargeTime,NARUTO_MOBILITY.boost.startup):narutoMobilityAge(m),c=NARUTO_MOBILITY;
 if(m.kind===3){const q=narutoEase(t/c.wall.startup),stride=Math.sin(t*27);p[NP.lean]=lerp(p[NP.lean],Math.abs(m.dir.dot(m.normal))>.5?-.10:.2,q);p[NP.ll]=-.5+stride*.75;p[NP.rl]=-.5-stride*.75;p[NP.lk]=.6+Math.max(0,-stride)*1.1;p[NP.rk]=.6+Math.max(0,stride)*1.1;p[NP.lx]=-.8-stride*.6;p[NP.rx]=-.8+stride*.6;p[NP.le]=p[NP.re]=-1.2;p[NP.bob]=Math.abs(stride)*.04;p[NP.tilt]=-clamp(m.normal.x*m.dir.z-m.normal.z*m.dir.x,-1,1)*.34*q;p[NP.twist]=stride*.08;return;}
 const k=m.kind===1?c.boost:m.kind===4?c.wallJump:c.dash,gather=m.kind!==2?NARUTO_MOBILITY_POSES.gather:NARUTO_POSES.crouch,action=m.kind!==2?NARUTO_MOBILITY_POSES.kickoff:NARUTO_MOBILITY_POSES.dash;
 const active=m.kind===1?narutoBoostActive(m):k.active;
 if(m.charging){narutoMixPose(p,p,gather,narutoEase(t/k.startup));p[NP.bob]-=.04*Math.sin(time*8);return;}
 if(t<k.startup)narutoMixPose(p,p,gather,narutoEase(t/k.startup));
 else if(t<k.startup+active)narutoMixPose(p,gather,action,narutoBack((t-k.startup)/Math.min(.10,k.active)));
 else narutoMixPose(p,action,p,narutoEase((t-k.startup-active)/k.recovery));
}
function animateNarutoBoostClones(v,index,dt){
 for(const f of bodies){const m=f.narutoMobility;if(f.character!=='naruto'||m?.kind!==1||f.hp<=0)continue;const t=m.charging?Math.min(.12,m.chargeTime):narutoMobilityAge(m),life=NARUTO_MOBILITY.boost.cloneLife;if(t>=life||index>=NARUTO.clonePool)continue;
  ensureNarutoClones();const c=v.clones[index++];c.used=c.active=true;c.pose.boost=true;c.pose.strike=narutoEase(t/.1);c.f.pos.copy(m.cloneOrigin);c.f.cloneFacing=Math.atan2(m.dir.x,m.dir.z);animateNaruto(c.f,dt,c.pose);
  c.f.root.scale.setScalar(Math.max(.02,narutoEase(t/.055)*(1-narutoEase((t-life+.045)/.045))));c.f.root.updateMatrixWorld(true);for(const entry of c.entries)entry.batch.mesh.setMatrixAt(entry.index,entry.node.matrixWorld);
 }
 return index;
}
function updateNarutoMobilityTrails(dt){
 if(dt<=0||phase!=='play')return;const c=NARUTO_MOBILITY;
 for(const f of bodies){const m=f.narutoMobility;if(f.character!=='naruto'||!m?.kind||f.hp<=0)continue;const t=narutoMobilityAge(m);
  if(m.kind===1||m.kind===4||m.kind===2&&t<c.dash.startup)continue;m.trail+=dt;if(m.trail<c.trailInterval)continue;m.trail%=c.trailInterval;
  if(m.kind===3){f.narutoRig.feet[Math.floor(t*12)%2].getWorldPosition(m.point);narutoEmit(m.point,c.blue,2,.2,.4,.085);narutoEmit(m.point,c.gold,1,.15,.5,.055);}
  else{m.point.copy(f.pos).addScaledVector(m.dir,-.3);m.point.y+=.65;narutoEmit(m.point,c.blue,3,c.trailLife,.65,.13);narutoEmit(m.point,c.gold,2,c.trailLife,.45,.1);narutoEmit(m.point,0x739fae,2,c.smokeLife,.55,.35,true);}
 }
}
function packNarutoMobility(f){
 const m=narutoMobility(f);return {kind:m.kind,t:m.t,serial:m.serial,uses:m.uses,boostCD:m.boostCD,dashCD:m.dashCD,wallCD:m.wallCD,wallJumpCD:m.wallJumpCD,baseSpeed:m.baseSpeed,wallSpent:m.wallSpent,wallIndex:m.wallIndex,charging:m.charging,chargeTime:m.chargeTime,power:m.power,directional:m.directional,dir:vec(m.dir),normal:vec(m.normal),cloneOrigin:vec(m.cloneOrigin)};
}
function validNarutoMobility(m,character){
 if(character!=='naruto'&&(!m||![0,3,4].includes(m.kind)||m.uses!==0||m.charging))return false;const c=NARUTO_MOBILITY;
 return !!m&&Number.isInteger(m.kind)&&m.kind>=0&&m.kind<=4&&Number.isSafeInteger(m.serial)&&m.serial>=0&&Number.isInteger(m.uses)&&m.uses>=0&&m.uses<=1000000&&Number.isInteger(m.wallIndex)&&m.wallIndex>=-1&&m.wallIndex<pieces.length&&typeof m.charging==='boolean'&&Number.isFinite(m.chargeTime)&&m.chargeTime>=0&&m.chargeTime<=c.boost.maxHold&&Number.isFinite(m.power)&&m.power>=0&&m.power<=1&&typeof m.directional==='boolean'&&Number.isFinite(m.t)&&m.t>=0&&m.t<=60.1&&Number.isFinite(m.wallSpent)&&m.wallSpent>=0&&m.wallSpent<=60&&Number.isFinite(m.boostCD)&&m.boostCD>=0&&m.boostCD<=c.boost.cooldown&&Number.isFinite(m.dashCD)&&m.dashCD>=0&&m.dashCD<=c.dash.cooldown&&Number.isFinite(m.wallCD)&&m.wallCD>=0&&m.wallCD<=Math.max(c.wall.cooldown,c.wallJump.startup+c.wallJump.active+c.wallJump.recovery)&&Number.isFinite(m.wallJumpCD)&&m.wallJumpCD>=0&&m.wallJumpCD<=c.wallJump.cooldown&&Number.isFinite(m.baseSpeed)&&m.baseSpeed>=0&&m.baseSpeed<=WORLD.sprint&&validVector(m.dir)&&validVector(m.normal)&&validVector(m.cloneOrigin);
}
function receiveNarutoMobility(f,data){
 const m=narutoMobility(f);if(m.serial!==data.serial||m.kind!==data.kind)m.trail=0;
 m.kind=data.kind;m.t=data.t;m.serial=data.serial;m.uses=data.uses;m.boostCD=data.boostCD;m.dashCD=data.dashCD;m.wallCD=data.wallCD;m.wallJumpCD=data.wallJumpCD;m.baseSpeed=data.baseSpeed;m.wallSpent=data.wallSpent;m.wallIndex=data.wallIndex;m.charging=data.charging;m.chargeTime=data.chargeTime;m.power=data.power;m.directional=data.directional;m.dir.fromArray(data.dir);m.normal.fromArray(data.normal);m.cloneOrigin.fromArray(data.cloneOrigin);
}
function updateNarutoMobilityHUD(){
 const el=$('narutoMobilityStatus'),show=player.character==='naruto'||player.narutoMobility?.kind===3||player.narutoMobility?.kind===4;el.classList.toggle('hidden',!show);if(!show)return;const m=narutoMobility(player),c=NARUTO_MOBILITY;
 if(player.character!=='naruto'){el.textContent='WALL RUN · '+Math.round(player.stamina)+' STAMINA · JUMP TO KICK OFF';return;}
 el.textContent='CLONE BOOST · '+c.boost.cost+' CHAKRA · DASH '+(m.dashCD>0?m.dashCD.toFixed(1)+'s':'READY')+(m.charging?' · BOOST '+Math.round(m.power*100)+'% / '+c.boost.maxHold.toFixed(1)+'s':'')+' · WALL '+Math.round(player.stamina)+' STAMINA';
}
