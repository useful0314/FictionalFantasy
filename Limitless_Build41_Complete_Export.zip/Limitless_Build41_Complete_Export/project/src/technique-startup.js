// A tap queues a low-power release after anticipation; holding charges normally.
const TECHNIQUE_TIMING={fullHold:3,gojo:[0,.42,.48,.9,.06],sukuna:[0,.36,.44,.85,.32]};
const startupRigs=new Map();
function techniqueStartup(f,kind){return f.character==='naruto'?NARUTO.moves[kind].startup:TECHNIQUE_TIMING[f.character][kind];}
function chargeAge(ch){return ch.elapsed??ch.t;}
function chargePower(ch){return ch.max?clamp(ch.t/ch.max,0,1):clamp(ch.t/ch.duration,0,1)*(ch.q||0);}
function chargeFormation(f,ch){return clamp(chargeAge(ch)/techniqueStartup(f,ch.kind),0,1);}
function updateHeldCharge(f,dt){
 const held=chargesFor(f);if(!held.length)return;
 if(f.stun>0||f.ragdollT>0||castFor(f)||trappedByVoid(f)){cancelCharge(f);return;}
 for(const ch of held){
 ch.elapsed+=dt;
 if(!ch.releaseRequested){
  const spend=f.character==='naruto'?NARUTO.moves[ch.kind].drain:[0,10,12,13,10][ch.kind],before=ch.t;
  if(ch.t<ch.max&&f.energy>0){const payment=Math.min(f.energy,spend*dt,spend*(ch.max-ch.t));f.energy-=payment;ch.spent+=payment;ch.t=Math.min(ch.max,ch.t+payment/spend);}
  if(ch.t>=ch.max-1e-7||f.energy<=1e-7)ch.fullHold+=Math.max(0,dt-(ch.t-before));else ch.fullHold=0;
 }
 const q=chargePower(ch),dir=aimFor(f),p=headPos(f).addScaledVector(dir,1.5+q*.5);
 if(ch.orb){ch.orb.g.position.copy(p);orbLight.position.copy(p);orbLight.color.set(ch.orb.color);orbLight.intensity=(4+q*10)*chargeFormation(f,ch);}
 if(ch.marker){ch.marker.position.copy(teleportDestination(q,f)).add(V(0,.8,0));ch.marker.scale.setScalar(.8+Math.sin(time*8)*.12);}
 if(ch.releaseRequested&&ch.elapsed+1e-8>=techniqueStartup(f,ch.kind)||ch.fullHold+1e-8>=TECHNIQUE_TIMING.fullHold)releaseCharge(ch.kind,f);
 }
}
function techniqueChargePosition(f,ch,dir=aimFor(f)){
 f.root.position.copy(f.pos);f.root.updateMatrixWorld(true);
 if(f.character==='gojo'&&ch.kind===2)return redMuzzlePosition(f,dir);
 if(ch.kind===4)return headPos(f).add(V(0,-.3,0));
 if(f.character==='sukuna'&&ch.kind===3)return f.limbs[(ch.slot||0)*2].hand.getWorldPosition(V()).addScaledVector(dir,.65);
 if(ch.kind===3)return f.limbs[0].hand.getWorldPosition(V()).lerp(f.limbs[1].hand.getWorldPosition(V()),.5).addScaledVector(dir,.55);
 return f.limbs[f.character==='sukuna'?(ch.slot||0)*2+1:ch.kind===1?0:1].hand.getWorldPosition(V()).addScaledVector(dir,.18);
}
function makeStartupRig(f,kind){
 const g=new THREE.Group();scene.add(g);g.name='startup-'+f.character+'-'+kind;
 const color=f.character==='gojo'?[0,C.blue,C.red,C.purple,C.mint][kind]:kind===3?0xff8b24:kind===2?0xff6c85:C.red;
 const count=f.character==='gojo'&&kind===1?128:90,material=new THREE.MeshBasicMaterial({color,transparent:true,opacity:.9,depthWrite:false,blending:THREE.AdditiveBlending});material.color.multiplyScalar(1.6);
 const streaks=new THREE.InstancedMesh(new THREE.CylinderGeometry(.022,.006,1,4),material,count);streaks.instanceMatrix.setUsage(THREE.DynamicDrawUsage);streaks.frustumCulled=false;g.add(streaks);
 const rings=[0,1,2].map(i=>{const a=arcStrip(g,i===2?0xfff4ed:color,{radius:1+i*.25,start:i*2,length:Math.PI*(1.3+i*.2),width:i===2?.009:.018,helix:.25});a.rotation.x=i*.85;return a;});
 const halo=glow(color,2,.25,g),core=mesh(geo.sphere,new THREE.MeshBasicMaterial({color:0xfff3e7,toneMapped:false}),g,V(),V(.055,.055,.055));
 const satellites=[];if(f.character==='gojo'&&kind===3)for(const c of [C.blue,C.red]){const s=new THREE.Group();g.add(s);mesh(geo.sphere,new THREE.MeshBasicMaterial({color:c}),s,V(),V(.16,.16,.16));const skin=mesh(new THREE.SphereGeometry(.28,20,14),energySkin(c),s);glow(c,1.35,.65,s);satellites.push({g:s,skin});}
 const blades=f.character==='sukuna'&&kind<3?[cutBlade(g,1.4,-.45),cutBlade(g,1.4,.55)]:[];
 return {g,streaks,rings,halo,core,satellites,blades,count,dummy:new THREE.Object3D(),point:V(),direction:V(),tangent:V(),up:V(0,1,0),kind,character:f.character};
}
function animateStartupRig(rig,f,ch){
 const age=chargeAge(ch),form=chargeFormation(f,ch),q=chargePower(ch),dir=aimFor(f),power=.65+q*.45,full=ch.fullHold||0;
 rig.g.position.copy(techniqueChargePosition(f,ch,dir));rig.g.quaternion.setFromUnitVectors(V(0,0,1),dir);
 const count=particleBudget<1000?(rig.character==='gojo'&&rig.kind===1?60:40):rig.count;rig.streaks.count=count;
 const purple=f.character==='gojo'&&ch.kind===3,merge=1-THREE.MathUtils.smoothstep(form,.18,.88),extent=ch.kind===4?1.8:ch.kind===2?3.1:2.6;
 for(let i=0;i<count;i++){
  const phase=(age*(form<1?1.55:1.05)+domainHash(i+300))%1,shrink=(1-phase)**1.7,a=i*2.399963+age*1.9+phase*1.1,y=domainHash(i+510)*2-1,r=extent*shrink*(.6+domainHash(i+20)*.4);
  const center=purple?(i%2?1:-1)*merge*1.5:0,p=rig.point.set(Math.cos(a)*Math.sqrt(1-y*y)*r+center,y*r,Math.sin(a)*Math.sqrt(1-y*y)*r*.75);
  rig.dummy.position.copy(p);const direction=rig.direction.set(center,0,0).sub(p).addScaledVector(rig.tangent.set(-Math.sin(a),.05,Math.cos(a)),.35*shrink).normalize();rig.dummy.quaternion.setFromUnitVectors(rig.up,direction);
  const fade=Math.sin(phase*Math.PI)*clamp(age*9,0,1);rig.dummy.scale.set(power*fade,(.12+.45*shrink)*fade,power*fade);rig.dummy.updateMatrix();rig.streaks.setMatrixAt(i,rig.dummy.matrix);
 }
 rig.streaks.instanceMatrix.needsUpdate=true;rig.streaks.material.opacity=.65+Math.sin(age*14)**2*.3;
 rig.rings.forEach((ring,i)=>{const collapse=1-THREE.MathUtils.smoothstep(form,.1,1);ring.scale.setScalar((ch.kind===4?1.15:.18+collapse*1.9)+q*.12);ring.rotation.z=age*(i%2?-2.4:2.8)+i*1.6;ring.material.opacity=(.28+collapse*.55)*(full>2?.7+Math.sin(age*26)**2*.3:1);});
 rig.halo.material.opacity=.12+form*.17;rig.halo.scale.setScalar(ch.kind===4?2.5:.6+form*.6+q*.3);rig.core.visible=ch.kind!==3&&!(f.character==='gojo'&&ch.kind===2);rig.core.scale.setScalar((ch.kind===4?.035:.04)*form);
 rig.satellites.forEach((s,i)=>{s.g.position.set((i?1:-1)*merge*1.5,Math.sin(age*4+i*Math.PI)*merge*.16,0);s.g.scale.setScalar((.5+form*.65)*clamp(merge*4,0,1));s.skin.material.uniforms.uTime.value=age;});
 rig.blades.forEach((b,i)=>{b.g.scale.setScalar(.15+form*.6+q*.35);b.g.rotation.z=(i?.55:-.45)+(1-form)*(i?1:-1);b.core.material.opacity=.6+form*.3;});
}
function syncStartupVisuals(){
 const live=new Set();if(['play','finish','pause'].includes(phase))for(const [i,f]of bodies.entries())for(const ch of chargesFor(f)){
  if(f.character==='naruto')continue;const key=i+'-'+(ch.slot||0);live.add(key);let rig=startupRigs.get(key);if(!rig||rig.kind!==ch.kind||rig.character!==f.character){if(rig)removeObject(rig.g);rig=makeStartupRig(f,ch.kind);startupRigs.set(key,rig);}animateStartupRig(rig,f,ch);
 }
 for(const [key,rig]of startupRigs)if(!live.has(key)){removeObject(rig.g);startupRigs.delete(key);}
}
function clearStartupVisuals(){for(const rig of startupRigs.values())removeObject(rig.g);startupRigs.clear();}
// Anticipation and follow-through use the same poses for local, CPU, and remote fighters.
const TECHNIQUE_MOTION={snapTime:.09,settleStart:.48,breathe:.012,blueRelease:.56,redRelease:.5,blueGather:.55,bluePresent:.40,redGather:.58,redPresent:.38,airBrake:.07,airBob:.028};
// Derived from the existing charge/release state: no new flight mode or network state.
function limitlessAirCast(f){
 if(f.character!=='gojo'||f.grounded||f.hp<=0||f.stun>0||f.ragdollT>0||f.recovery>0||f.dodge>0||f.block||castFor(f)||trappedByVoid(f)||f.techniqueBurnout>0)return false;
 const ch=primaryCharge(f);if(ch)return ch.kind===1||ch.kind===2;
 return !f.attackIsLight&&(f.specialKind===1||f.specialKind===2)&&f.specialAge<f.specialDuration;
}
function specialBodyPose(f,ch,slot=0){
 if(f.character==='gojo'&&(f.hp<=0||f.stun>0||f.hitReact>0||f.ragdollT>0||f.recovery>0||f.dodge>0||f.block||f.attackIsLight&&f.attack>0))return null;
 const kindNow=slot?f.auxSpecialKind:f.specialKind,age=slot?f.auxSpecialAge:f.specialAge,duration=slot?f.auxSpecialDuration:f.specialDuration,power=slot?f.auxSpecialPower:f.specialPower,release=!ch&&kindNow>0&&age<duration,activeBlue=!slot&&!ch&&!release&&f.character==='gojo'?blueFor(f):null,guidedBlue=!!activeBlue&&activeBlue.phase!=='hold';if(!ch&&!release&&!guidedBlue)return null;
 const kind=guidedBlue?1:ch?.kind||kindNow,q=guidedBlue?activeBlue.q:ch?chargePower(ch):power||0,form=ch?narutoEase(chargeFormation(f,ch)):1,progress=release?clamp(age/duration,0,1):0,follow=release?narutoBack(age/TECHNIQUE_MOTION.snapTime):0,weight=release?1-narutoEase((progress-TECHNIQUE_MOTION.settleStart)/(1-TECHNIQUE_MOTION.settleStart)):1;
 const cache=f.specialPoseCache||(f.specialPoseCache=[]),p=cache[slot]||(cache[slot]={arms:[V(),V()],elbows:[0,0],lean:0,twist:0,bob:0,knees:[0,0],legs:[0,0],headTurn:0,stretch:1,wrists:[V(),V()],grips:[-.3,-.3],spread:[0,0],point:-1,limitless:false});
 p.arms[0].set(-.35,0,.35);p.arms[1].set(-.35,0,-.35);p.elbows[0]=p.elbows[1]=-1.3;p.lean=p.twist=p.bob=p.headTurn=0;p.knees[0]=p.knees[1]=.15;p.legs[0]=p.legs[1]=0;p.stretch=1;
 p.wrists[0].set(0,0,0);p.wrists[1].set(0,0,0);p.grips[0]=p.grips[1]=-.3;p.spread[0]=p.spread[1]=0;p.point=-1;p.limitless=f.character==='gojo'&&(kind===1||kind===2);
 if(f.character==='gojo'){
 if(kind===1){
  const gather=narutoEase(form/TECHNIQUE_MOTION.blueGather),present=narutoEase((form-TECHNIQUE_MOTION.bluePresent)/(1-TECHNIQUE_MOTION.bluePresent)),pitch=Math.asin(clamp(aimFor(f).y,-.95,.95));
  p.arms[0].set(lerp(-.35,-.88,gather)-present*(.54+pitch*.65)-follow*.19,lerp(-.48,.08,present)*gather,.35+gather*.45-present*.61-follow*.1);p.elbows[0]=lerp(-1.3,-1.85,gather)+present*1.63+follow*.12;
  p.arms[1].set(-.45-gather*.34+follow*.18,.17,-.22-follow*.22);p.elbows[1]=-1.35;p.twist=-.38*gather+.18*present-.17*follow;p.lean=-.065*gather+.09*present+.12*follow;p.headTurn=.14*gather;p.bob=-.05*gather+.05*present;p.legs[0]=-.12*form;p.legs[1]=.22*form;p.knees[0]=.22;p.knees[1]=.33;p.stretch=1-.018*gather+.018*present+.035*follow;
  p.wrists[0].set(-.3*present,-.15*gather,.28*(1-present)*gather);p.grips[0]=lerp(-.75,-.04,present);p.grips[1]=-.65;p.spread[0]=.075*present;
  if(guidedBlue){const sweep=activeBlue.phase==='sweep'?narutoEase((activeBlue.sweep||0)/LIMITLESS_OUTPUT.blue.sweepTime):0,lift=clamp(aimFor(f).y*1.4,-.45,.72);p.arms[0].set(-1.42-lift*.2,.06+sweep*.22,.1-sweep*.12);p.elbows[0]=-.16-sweep*.12;p.arms[1].set(-.72-lift*.08,-.12,-.28);p.elbows[1]=-1.05;p.twist=-.2-sweep*.18;p.lean=.045+sweep*.07;p.bob=Math.sin(time*4.4)*.012;p.headTurn=.1+sweep*.08;p.wrists[0].z=Math.sin(time*3.4)*.05;}
 }
 if(kind===2){
  const gather=narutoEase(form/TECHNIQUE_MOTION.redGather),present=narutoEase((form-TECHNIQUE_MOTION.redPresent)/(1-TECHNIQUE_MOTION.redPresent)),pitch=Math.asin(clamp(aimFor(f).y,-.95,.95)),recoil=release?Math.sin(narutoEase(progress)*Math.PI):0;
  p.arms[1].set(lerp(-.35,-1.02,gather)-present*(.48+pitch)+recoil*.20,.24*gather*(1-present),-.25-gather*.2+present*.42);p.elbows[1]=lerp(-1.3,-2.05,gather)+present*1.78+follow*.23-recoil*.28;
  p.arms[0].set(-.47-gather*.28,0,.28+recoil*.2);p.elbows[0]=-1.35;p.twist=.26*gather-.21*present-.16*recoil;p.lean=-.06*gather+.05*present-.17*recoil;p.headTurn=-.11*gather+.08*present;p.bob=-.045*gather+.035*present-.025*recoil;p.legs[0]=-.21*form;p.legs[1]=.25*form;p.knees[0]=.28;p.knees[1]=.2;p.stretch=1-.018*gather+.018*present+.025*recoil;
  p.wrists[1].set(-.08*present+.18*recoil,0,-.2*gather*(1-present));p.grips[0]=-.6;p.grips[1]=-1.55;p.point=1;
 }
 if(kind===3){const meet=narutoEase((form-.28)/.72);p.arms[0].set(-1.35-follow*.22,-.55*(1-meet),.48*(1-meet)+follow*.1);p.arms[1].set(-1.35-follow*.22,.55*(1-meet),-.48*(1-meet)-follow*.1);p.elbows[0]=p.elbows[1]=-.18-meet*.5+follow*.57;p.lean=-.09*q+.25*follow;p.bob=-.10*(1-form)+follow*.025;p.knees[0]=.23;p.knees[1]=.3;p.legs[0]=-.17;p.legs[1]=.17;p.stretch=1+follow*.032;}
 if(kind===4){p.arms[0].set(-.85,0,-.33);p.arms[1].set(-.85,0,.33);p.elbows[0]=p.elbows[1]=-1.75;p.lean=.1+follow*.13;p.bob=-.14*form+follow*.06;p.knees[0]=.32;p.knees[1]=.4;p.stretch=.97+follow*.06;}
 }else{
 if(kind===1){p.arms[0].set(-.65,-.15,.36);p.arms[1].set(-.85-form*.52,.42-follow*1.02,-.32+follow*.54);p.elbows[0]=-1.25;p.elbows[1]=-.7+form*.4+follow*.23;p.twist=-.34+follow*.9;p.lean=.12*follow;p.headTurn=-p.twist*.18;p.legs[0]=-.12;p.legs[1]=.2;}
 if(kind===2){p.arms[0].set(-1.03-follow*.26,-.2,-.36+follow*.95);p.arms[1].set(-1.03-follow*.26,.2,.36-follow*.95);p.elbows[0]=p.elbows[1]=-1.25+follow*.99;p.lean=.10+follow*.22;p.bob=-.09+follow*.035;p.knees[0]=p.knees[1]=.3;p.stretch=.985+follow*.04;}
 if(kind===3){const draw=form*(.35+.65*q);p.arms[0].set(-Math.PI/2,-.32,.06);p.arms[1].set(-1.48+draw*.42+follow*.26,.45+draw*.45+follow*.12,-.2-draw*.22-follow*.26);p.elbows[0]=-.04;p.elbows[1]=-.55-draw*1.3+follow*.18;p.twist=-.4+follow*.13;p.lean=-.06+follow*.13;p.legs[0]=-.2;p.legs[1]=.2;p.knees[0]=.3;p.knees[1]=.15;p.headTurn=.28;p.stretch=1+follow*.025;}
 if(kind===4){p.arms[0].set(.25+follow*.4,-.2,.38);p.arms[1].set(-.8-follow*.72,.15,-.12);p.elbows[0]=-1.35;p.elbows[1]=-1.1+follow*.9;p.lean=.32+follow*.23;p.bob=-.2*(1-follow*.6);p.legs[0]=-.4;p.legs[1]=.45;p.knees[0]=.7;p.knees[1]=.25;p.stretch=.97+follow*.07;}
 }
 if(p.limitless&&limitlessAirCast(f)){p.legs[0]=-.23;p.legs[1]=.34;p.knees[0]=.54;p.knees[1]=.76;p.bob+=Math.sin(time*3.8)*TECHNIQUE_MOTION.airBob;}
 if(ch)p.bob+=Math.sin(time*4)*TECHNIQUE_MOTION.breathe*form;
 if(release){const idle=rosterPoseLibrary()[f.character];for(let i=0;i<2;i++){const j=i?NP.rx:NP.lx;p.arms[i].x=lerp(idle[j],p.arms[i].x,weight);p.arms[i].y=lerp(idle[j+1],p.arms[i].y,weight);p.arms[i].z=lerp(idle[j+2],p.arms[i].z,weight);p.elbows[i]=lerp(idle[j+3],p.elbows[i],weight);p.legs[i]=lerp(idle[i?NP.rl:NP.ll],p.legs[i],weight);p.knees[i]=lerp(idle[i?NP.rk:NP.lk],p.knees[i],weight);}p.lean*=weight;p.twist*=weight;p.bob*=weight;p.headTurn*=weight;p.stretch=lerp(1,p.stretch,weight);}
 if(release&&p.limitless)for(let i=0;i<2;i++){p.wrists[i].multiplyScalar(weight);p.grips[i]=lerp(-.3,p.grips[i],weight);p.spread[i]*=weight;}
 return p;
}
