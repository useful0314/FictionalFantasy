import * as THREE from '../vendor/three.module.js';
// LIMITLESS / Cursed Duel — Build 41. Host-authoritative private rooms. Three.js is MIT licensed.
const $=id=>document.getElementById(id), V=(x=0,y=0,z=0)=>new THREE.Vector3(x,y,z), clamp=THREE.MathUtils.clamp, lerp=THREE.MathUtils.lerp;
let controls=null,net=null,menuOpen=false,countdown=0,remoteCharge=null,networkTick=0,netEvents=[],replaying=false;
const remoteInput={keys:new Set(),yaw:Math.PI,pitch:.06,move:{x:0,y:0},held:new Set()};
const localEdges=[];
const MAX_HEALTH=1000;
const NUKE_RADIUS={min:60,max:115};
function maxStamina(f){return f.character==='sukuna'?150:100;}
// Accepted Proposal B. Charge scales from 35% to 100%; spatial falloff is applied separately.
const BALANCE={light:[12,16,20,27],sukunaLight:[10,14,17,23],blueDPS:24,red:140,purple:280,nukeDPS:15,nukeBurst:380,dismantle:80,cleave:180,furnace:240,burn:60,rush:100,dodgeHeal:15,ultDeal:.085,ultTake:.062};
const DODGE={cooldown:1.5,impulse:36,duration:.34,perfect:.20};
const WORLD={radius:176,walk:6.4,sprint:26,ceiling:72};
function charged(max,q){return max*lerp(.35,1,clamp(q,0,1));}
const C={blue:0x47bbff,red:0xff345b,purple:0xb157ff,mint:0x91ffdf,white:0xe7f6ff};
let seed=7261;function rand(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296}const rr=(a,b)=>a+(b-a)*rand();
let renderer;try{renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});}catch(e){$('boot').innerHTML='WEBGL 2 IS REQUIRED<span>Open this file in a desktop browser with hardware acceleration enabled.</span>';throw e}
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;$('world').append(renderer.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color(0x091322);scene.fog=new THREE.FogExp2(0x0c1c2f,.0038);
const camera=new THREE.PerspectiveCamera(62,innerWidth/innerHeight,.08,520);
const hemi=new THREE.HemisphereLight(0x91cbff,0x18202e,2.2);scene.add(hemi);
const sun=new THREE.DirectionalLight(0xc2dcff,3.1);sun.position.set(-15,65,16);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-85,right:85,top:85,bottom:-85,near:1,far:150});sun.shadow.bias=-.001;scene.add(sun);
const rim=new THREE.DirectionalLight(0x8670ef,1.3);rim.position.set(16,8,-25);scene.add(rim);
const orbLight=new THREE.PointLight(C.blue,0,22,2);scene.add(orbLight);
const geo={box:new THREE.BoxGeometry(1,1,1),sphere:new THREE.SphereGeometry(1,20,14),lowSphere:new THREE.IcosahedronGeometry(1,1),cylinder:new THREE.CylinderGeometry(.5,.5,1,10),cone:new THREE.ConeGeometry(.5,1,7),ring:new THREE.TorusGeometry(1,.018,5,64)};
const assetTextures={};
if(window.ARENA_ASSETS){for(const key of ['stone','fabric'])if(window.ARENA_ASSETS[key]){const t=new THREE.TextureLoader().load(window.ARENA_ASSETS[key]);t.colorSpace=THREE.SRGBColorSpace;t.wrapS=t.wrapT=THREE.MirroredRepeatWrapping;t.repeat.set(key==='stone'?2:6,key==='stone'?2:6);t.anisotropy=Math.min(4,renderer.capabilities?.getMaxAnisotropy?.()||1);assetTextures[key]=t;}}
const mats={stone:new THREE.MeshStandardMaterial({color:0x7e96a8,roughness:.84,metalness:.14}),dark:new THREE.MeshStandardMaterial({color:0x162a3b,roughness:.68,metalness:.25}),pale:new THREE.MeshStandardMaterial({color:0xbcd1df,roughness:.85}),black:new THREE.MeshStandardMaterial({color:0x101827,roughness:.7}),skin:new THREE.MeshStandardMaterial({color:0xeac6ae,roughness:.85}),white:new THREE.MeshStandardMaterial({color:0xdde9f4,roughness:.55}),sukuna:new THREE.MeshStandardMaterial({color:0x322334,roughness:.82}),hairPink:new THREE.MeshStandardMaterial({color:0xc58797,roughness:.75})};
function mesh(geometry,material,parent=scene,pos=V(),scale=V(1,1,1)){const m=new THREE.Mesh(geometry,material);m.position.copy(pos);m.scale.copy(scale);parent.add(m);return m}
function box(parent,pos,scale,mat=mats.stone){return mesh(geo.box,mat,parent,pos,scale)}
function glowTexture(){const c=document.createElement('canvas');c.width=c.height=128;const ctx=c.getContext('2d'),g=ctx.createRadialGradient(64,64,0,64,64,64);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.18,'rgba(255,255,255,.8)');g.addColorStop(.42,'rgba(255,255,255,.22)');g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.fillRect(0,0,128,128);return new THREE.CanvasTexture(c)}
const glowMap=glowTexture();
function glow(color,size=3,opacity=.65,parent=scene){const s=new THREE.Sprite(new THREE.SpriteMaterial({map:glowMap,color,transparent:true,opacity,blending:THREE.AdditiveBlending,depthWrite:false}));s.scale.set(size,size,1);parent.add(s);return s}
/*CITY*/

function buildShrine(parent,origin,scale=1){
 const g=new THREE.Group();parent.add(g);g.position.copy(origin);g.scale.setScalar(scale);
 const stone=new THREE.MeshStandardMaterial({color:0x2c1624,roughness:.7}),red=new THREE.MeshStandardMaterial({color:0x731c37,metalness:.25,roughness:.5}),bone=new THREE.MeshStandardMaterial({color:0xe3c3ac,roughness:.7}),hot=new THREE.MeshBasicMaterial({color:0xff3157});
 for(let i=0;i<4;i++)box(g,V(0,i*.3,0),V(14-i*1.1,.35,8-i*.6),stone);
 for(const x of [-5,-3,3,5]){box(g,V(x,4.5,0),V(.65,7,.65),red);box(g,V(x,4.5,.36),V(.12,6.8,.07),bone);}
 box(g,V(0,6.8,0),V(12,.7,2),red);
 for(let i=0;i<2;i++){const roof=mesh(new THREE.ConeGeometry(9-i*2,2.4,4),stone,g,V(0,8.1+i*2.1,0),V(1,1,.58));roof.rotation.y=Math.PI/4;const rim=mesh(new THREE.ConeGeometry(9.1-i*2,.3,4),red,g,V(0,7.05+i*2.1,0),V(1,1,.58));rim.rotation.y=Math.PI/4;}
 for(let i=-4;i<=4;i++){const skull=mesh(geo.sphere,bone,g,V(i*1.04,2.2,2.6),V(.54,.64,.4));for(const x of [-.16,.16])mesh(geo.sphere,stone,skull,V(x,.12,.78),V(.23,.22,.15));mesh(geo.cone,bone,g,V(i*1.04,3.2,2.65),V(.35,1.1,.4)).rotation.z=i*.04;}
 box(g,V(0,4.3,.2),V(4.5,4.5,.5),stone);for(let i=-2;i<=2;i++)box(g,V(i*.68,4.1,.49),V(.07,3.7,.1),hot);
 for(const side of [-1,1]){const pts=[];for(let i=0;i<=12;i++){const t=i/12;pts.push(V(side*(6+Math.sin(t*Math.PI)*2),2+t*8,0));}mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts),24,.19,6,false),bone,g);}
 const halo=glow(0xff2548,23,.36,g);halo.position.set(0,4,0);return g;
}
buildShrine(shrine,V(0,0,-1),.65);
/*MAPS*/

let cinematic=null,finisher=null;
function cinematicShot(owner,type,duration=.6){if(type==='domain'||type==='clash')return;netFX('cinema',[who(owner),type,duration]);if(options.cinematics)cinematic={owner,type,t:0,duration};}
function slashRibbon(pos,dir,color,radius=2,life=.25,roll=0){
 netFX('slash',[pos.toArray(),dir.toArray(),color,radius,life,roll]);
 const vertices=[],colors=[],c=new THREE.Color(color),segments=20;
 for(let i=0;i<segments;i++){const a=-1.2+i/segments*2.4,b=-1.2+(i+1)/segments*2.4,w=Math.sin((i+.5)/segments*Math.PI)*.2+.025;
  for(const [angle,r]of [[a,radius],[b,radius],[a,radius-w],[b,radius],[b,radius-w],[a,radius-w]]){vertices.push(Math.cos(angle)*r-radius*.45,Math.sin(angle)*r,0);colors.push(c.r*2,c.g*2,c.b*2);}}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));
 const m=mesh(g,new THREE.MeshBasicMaterial({vertexColors:true,transparent:true,opacity:.92,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}),scene,pos.clone());m.quaternion.setFromUnitVectors(V(0,0,1),dir);m.rotateZ(roll);effects.push({m,t:0,max:life,type:'slash'});
}
function blastCrown(pos,color,radius,life){netFX('crown',[pos.toArray(),color,radius,life]);
 for(let i=0;i<10;i++){const a=i/10*Math.PI*2,dir=V(Math.cos(a),rr(-.15,.6),Math.sin(a)).normalize();trail(pos.clone().addScaledVector(dir,.5),pos.clone().addScaledVector(dir,radius*.8),color,.06+radius*.003,life*.7);}
 const mat=new THREE.MeshBasicMaterial({color,wireframe:true,transparent:true,opacity:.6,blending:THREE.AdditiveBlending,depthWrite:false});const m=mesh(new THREE.IcosahedronGeometry(1,2),mat,scene,pos.clone());effects.push({m,t:0,max:life,radius,type:'crown'});
}
function afterImage(f,color){netFX('ghost',[who(f),color]);poseAfterImage(f,color);}

// A small, self-contained HDR bloom pipeline; the direct renderer remains available.
let post=null;
if(typeof renderer.setRenderTarget==='function'){
 const type=renderer.extensions.has('EXT_color_buffer_float')?THREE.HalfFloatType:THREE.UnsignedByteType;
 const main=new THREE.WebGLRenderTarget(1,1,{type,depthBuffer:true}),a=new THREE.WebGLRenderTarget(1,1,{type,depthBuffer:false}),b=new THREE.WebGLRenderTarget(1,1,{type,depthBuffer:false});
 const v='varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}';
 const threshold=new THREE.ShaderMaterial({toneMapped:false,uniforms:{map:{value:main.texture}},vertexShader:v,fragmentShader:'varying vec2 vUv;uniform sampler2D map;void main(){vec3 c=texture2D(map,vUv).rgb;float l=max(c.r,max(c.g,c.b));gl_FragColor=vec4(c*smoothstep(.65,1.6,l),1.);}'});
 const blur=new THREE.ShaderMaterial({toneMapped:false,uniforms:{map:{value:a.texture},direction:{value:new THREE.Vector2()}},vertexShader:v,fragmentShader:'varying vec2 vUv;uniform sampler2D map;uniform vec2 direction;void main(){vec3 c=texture2D(map,vUv).rgb*.227027;c+=(texture2D(map,vUv+direction*1.384615).rgb+texture2D(map,vUv-direction*1.384615).rgb)*.316216;c+=(texture2D(map,vUv+direction*3.230769).rgb+texture2D(map,vUv-direction*3.230769).rgb)*.070270;gl_FragColor=vec4(c,1.);}'});
 const composite=new THREE.ShaderMaterial({uniforms:{map:{value:main.texture},bloom:{value:a.texture},aberration:{value:0},strength:{value:.7},narutoHeat:{value:0},narutoTime:{value:0},narutoCenter:{value:new THREE.Vector2(.5,.5)}},vertexShader:v,fragmentShader:'varying vec2 vUv;uniform sampler2D map;uniform sampler2D bloom;uniform float aberration;uniform float strength,narutoHeat,narutoTime;uniform vec2 narutoCenter;void main(){vec2 uv=vUv;float h=exp(-dot(uv-narutoCenter,uv-narutoCenter)*75.)*narutoHeat;uv.x+=sin(uv.y*180.-narutoTime*9.)*.003*h;vec2 d=(vUv-.5)*aberration;vec3 c=texture2D(map,uv).rgb;c.r=texture2D(map,uv+d).r;c.b=texture2D(map,uv-d).b;c+=texture2D(bloom,vUv).rgb*strength;c*=1.-.25*pow(length(vUv-.5),1.7);gl_FragColor=vec4(c,1.);\n#include <tonemapping_fragment>\n#include <colorspace_fragment>\n}'});
 const ps=new THREE.Scene(),pcam=new THREE.OrthographicCamera(-1,1,1,-1,0,1),quad=new THREE.Mesh(new THREE.PlaneGeometry(2,2),threshold);ps.add(quad);post={main,a,b,threshold,blur,composite,scene:ps,camera:pcam,quad};
}
function resizePost(){if(!post)return;const ratio=renderer.getPixelRatio(),w=Math.round(innerWidth*ratio),h=Math.round(innerHeight*ratio);post.main.setSize(w,h);post.a.setSize(Math.max(1,w>>2),Math.max(1,h>>2));post.b.setSize(Math.max(1,w>>2),Math.max(1,h>>2));}
function renderFrame(){
 if(renderDomainSplit())return;
 if(!post||!options.bloom){renderer.render(scene,camera);return;}
 const p=post;renderer.setRenderTarget(p.main);renderer.render(scene,camera);
 p.quad.material=p.threshold;renderer.setRenderTarget(p.a);renderer.render(p.scene,p.camera);
 p.quad.material=p.blur;p.blur.uniforms.map.value=p.a.texture;p.blur.uniforms.direction.value.set(1/p.a.width,0);renderer.setRenderTarget(p.b);renderer.render(p.scene,p.camera);
 p.blur.uniforms.map.value=p.b.texture;p.blur.uniforms.direction.value.set(0,1/p.a.height);renderer.setRenderTarget(p.a);renderer.render(p.scene,p.camera);
 p.quad.material=p.composite;p.composite.uniforms.aberration.value=options.flash?Math.min(.012,shake*.008):0;p.composite.uniforms.strength.value=(domain||clash)?.85:.65;renderer.setRenderTarget(null);renderer.render(p.scene,p.camera);
}
resizePost();
const outlineMaterial=new THREE.MeshBasicMaterial({color:0x080e1d,side:THREE.BackSide});
/*BLOCK_MODELS*/
function fighterModel(isGojo){return fighterBlockModel(isGojo?'gojo':'sukuna');}
const rigs={gojo:fighterModel(true),sukuna:fighterModel(false)};
/*NARUTO*/
let selectedCharacter='gojo';
const KITS={
 spiderman:SPIDER_KIT,
 mahito:MAHITO_KIT,
 naruto:NARUTO_KIT,
 gojo:{name:'SATORU GOJO',short:'GOJO',title:'THE STRONGEST',domain:'UNLIMITED VOID',color:C.blue,
  names:['','LAPSE: BLUE','REVERSAL: RED','HOLLOW PURPLE','SPATIAL SHIFT'],
  hints:['','Release · aim-guided · tap to anchor','Tap / hold · repulsive shot','Tap / hold · fuse and release','Tap to chain · hold for distance'],
  tags:['','ATTRACTION','REPULSION','FUSION','REPOSITION'],colors:['','#50c8ff','#ff777f','#c79aff','#a6efdd']},
 sukuna:{name:'RYOMEN SUKUNA',short:'SUKUNA',title:'HEIAN ERA · KING OF CURSES',domain:'MALEVOLENT SHRINE',color:C.red,
  names:['','DISMANTLE','CLEAVE','FURNACE','CURSED RUSH'],
  hints:['','Tap / hold · cutting wave','Tap / hold · close barrage','Fire arrow · tap again to detonate','Fast rush · launch on contact'],
  tags:['','RANGED CUT','CLOSE BARRAGE','FIRE ARROW','RUSH'],colors:['','#ff7b9c','#ffa6c9','#ffb15c','#ff647b']}
};
function kit(f){return KITS[f.character];}
function fighterColor(f){return kit(f).color;}
function aimFor(f){if(f===player)return forward();const i=f.input||remoteInput;return V(-Math.sin(i.yaw)*Math.cos(i.pitch),-Math.sin(i.pitch),-Math.cos(i.yaw)*Math.cos(i.pitch));}
function inputFor(f){return f===player?keys:(f.input||remoteInput).keys;}
function primaryCharge(f){return f===player?charge:f===enemy?(mode==='online'&&!f.bot?remoteCharge:cpuCharge):f.primaryCharge;}
function chargesFor(f){return [primaryCharge(f),f.auxCharge].filter(Boolean);}
function chargeFor(f,kind){return kind===undefined?primaryCharge(f)||f.auxCharge:chargesFor(f).find(c=>c.kind===kind);}
function chargeInSlot(f,slot){return chargesFor(f).find(c=>(c.slot||0)===slot);}
function castFor(f){return f===player?playerCast:f===enemy?enemyCast:f.cast;}
function setCast(f,c){if(f===player)playerCast=c;else if(f===enemy)enemyCast=c;else f.cast=c;}
function setPrimaryCharge(f,ch){if(f===player)charge=ch;else if(f===enemy){if(mode==='online'&&!f.bot)remoteCharge=ch;else cpuCharge=ch;}else f.primaryCharge=ch;}
function setCharge(f,ch){if(primaryCharge(f))f.auxCharge=ch;else setPrimaryCharge(f,ch);}
function trappedByVoid(f){return !!(domain&&domain.owner!==f&&domain.owner.character==='gojo'&&insideEnclosure(f));}
function assignRigs(){ensureActorRig(player,selectedCharacter);ensureActorRig(enemy,selectedCharacter==='gojo'?'sukuna':'gojo');}
const player={...rigs.gojo,character:'gojo',pos:V(0,.13,13),vel:V(),hp:MAX_HEALTH,stamina:100,energy:100,ult:0,emergency:false,grounded:true,flying:false,stun:0,dodge:0,dodgeCooldown:0,dodgeWindow:0,attack:0,attackKind:0,combo:0,comboTimer:0,block:false,blockTime:0,hitCooldown:0,score:0,damageTaken:0};
const enemy={...rigs.sukuna,character:'sukuna',pos:V(0,.13,-7),vel:V(),hp:MAX_HEALTH,stamina:150,energy:100,ult:0,stun:0,dodge:0,attack:0,attackKind:0,block:false,blockTime:0,grounded:true,brain:0,nextSlash:4,nextFire:11,domainCD:18,score:0,damageTaken:0,blockTimer:0};
const bodies=[player,enemy];
function headPos(f){return f.pos.clone().add(V(0,1.45,0))}function opponents(f){return bodies.filter(b=>b!==f&&b.hp>0);}
function other(f){const live=opponents(f),reachable=live.filter(b=>!barrierSeparates(f,b)),list=reachable.length?reachable:live;return list.find(b=>b.id===f.targetId)||list.sort((a,b)=>a.pos.distanceToSquared(f.pos)-b.pos.distanceToSquared(f.pos))[0]||bodies.find(b=>b!==f)||f;}
const options={sound:true,shake:true,flash:true,bloom:true,cinematics:true,sensitivity:1,camDistance:7,camTilt:0,cursorBehavior:'toggle',freeOrbit:false,wheelCamera:false,wheelMode:'angle',quality:'auto'};
try{Object.assign(options,JSON.parse(localStorage.getItem('limitless.settings.v3')||'{}'));}catch{}
const sound=new window.ArenaAudio(window.ARENA_ASSETS||{});
function tone(freq=200,duration=.2,type='sine',volume=.06,slide=.3){if(options.sound)sound.tone(freq,duration,type,volume,slide);}
function rumble(big=false){sound.play(big?'burst':'hit',big?1:.75);controls?.rumble(big);}
const effects=[],projectiles=[],techniques=[],blues=[],bombs=[];let cpuCharge=null;let blue=null,bomb=null,charge=null,domain=null,clash=null,enemyCast=null,playerCast=null;
let phase='menu',mode='duel',time=0,matchTime=0,restoreTimer=35,annTime=0,toastTime=0,shake=0,flash=0,impact=0,hitStop=0,finishTime=0,lastFinisher=false;
let yaw=0,pitch=.13,lockOn=false,keys=new Set(),mouseDown=false,castCooldown=0,regenCharge=0,autoHit=0,frameCount=0,fpsTime=0,fpsValue=60;
let cursorFree=false;
const cameraOrbit={active:false,yaw:0,pitch:0};
const camPos=V(7,6,20),camLook=V(0,1,0);camera.position.copy(camPos);
function forward(full=true){return V(-Math.sin(yaw)*(full?Math.cos(pitch):1),full?-Math.sin(pitch):0,-Math.cos(yaw)*(full?Math.cos(pitch):1)).normalize()}
function aimPoint(range=70){return headPos(player).addScaledVector(forward(),range)}
function toast(s,d=2.5){$('toast').textContent=s;toastTime=d;$('toast').style.opacity=1}
function announce(s,b,d=2.1){netFX('announce',[s,b,d]);$('annSmall').textContent=s;$('annBig').textContent=b;annTime=d;$('announcement').style.opacity=1}
function shakeIt(n,pos=null,dir=null){netFX('shake',pos?[n,pos.toArray(),dir?dir.toArray():null]:[n]);if(pos)cameraImpulse(pos,dir,n);else if(options.shake)shake=Math.max(shake,n)}function flashIt(n=1){netFX('flash',[n]);flash=Math.max(flash,options.flash?n:n*.2)}
function damageText(f,n,heal=false){showDamageNumber(f,n,heal);}
let particleBudget=2400;const maxParticles=2400,pp=new Float32Array(maxParticles*3),pc=new Float32Array(maxParticles*3),ps=new Float32Array(maxParticles),particleData=[];
const pg=new THREE.BufferGeometry();pg.setAttribute('position',new THREE.BufferAttribute(pp,3).setUsage(THREE.DynamicDrawUsage));pg.setAttribute('color',new THREE.BufferAttribute(pc,3).setUsage(THREE.DynamicDrawUsage));pg.setAttribute('size',new THREE.BufferAttribute(ps,1).setUsage(THREE.DynamicDrawUsage));
const pm=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,vertexColors:true,uniforms:{ratio:{value:renderer.getPixelRatio()}},vertexShader:'attribute float size; varying vec3 vColor; uniform float ratio; void main(){vColor=color;vec4 p=modelViewMatrix*vec4(position,1.);gl_Position=projectionMatrix*p;gl_PointSize=clamp(size*ratio*260./max(1.,-p.z),1.,70.);}',fragmentShader:'varying vec3 vColor;void main(){float r=length(gl_PointCoord-.5);if(r>.5)discard;float a=pow(1.-r*2.,1.6);gl_FragColor=vec4(vColor,a);}' });const particleSystem=new THREE.Points(pg,pm);particleSystem.frustumCulled=false;scene.add(particleSystem);
function particles(pos,color,count=25,speed=5,life=.6,size=.2){emitBattleParticles(pos,color,count,speed,life,size);}
function orb(color,radius=1){
 const g=new THREE.Group();scene.add(g);const blueCore=color===C.blue;
 const inner=mesh(geo.sphere,new THREE.MeshBasicMaterial({color:blueCore?0x010c21:0xf8eaff}),g,V(),V(.28,.28,.28));
 const shell=mesh(new THREE.SphereGeometry(1,32,24),new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,uniforms:{uTime:{value:0},uColor:{value:new THREE.Color(color)}},
 vertexShader:'varying vec3 vN;varying vec3 vP;varying vec3 vView;void main(){vN=normalMatrix*normal;vP=position;vec4 mv=modelViewMatrix*vec4(position,1.);vView=-mv.xyz;gl_Position=projectionMatrix*mv;}',
 fragmentShader:'varying vec3 vN;varying vec3 vP;varying vec3 vView;uniform float uTime;uniform vec3 uColor;float n(vec3 p){return sin(p.x)*sin(p.y)*sin(p.z);}void main(){vec3 p=vP*5.;float f=n(p+uTime*.8)*.5+n(p*2.1-uTime*1.3)*.25+n(p*4.3+uTime*2.)*.125;float fres=pow(1.-abs(dot(normalize(vN),normalize(vView))),2.3);float veins=pow(1.-abs(sin(f*9.+vP.y*7.+uTime*1.5)),12.);vec3 c=uColor*(.25+f*.4+fres*2.8)+vec3(.65,.8,1.)*veins*1.8;gl_FragColor=vec4(c,.72+fres*.28);}' }),g,V(),V(.64,.64,.64));
 const aura=glow(color,4.5,.65,g),rings=[];
 for(let i=0;i<4;i++){const ring=mesh(new THREE.TorusGeometry(1,.012+i*.003,4,96),new THREE.MeshBasicMaterial({color:i===3?0xf5eeff:color,transparent:true,opacity:.7,blending:THREE.AdditiveBlending,depthWrite:false}),g);ring.rotation.set(i*.9,.6+i*.7,i);rings.push(ring);}
 const arcs=[];for(let i=0;i<5;i++){const pts=[];for(let j=0;j<22;j++){const a=j/21*Math.PI*1.4;pts.push(V(Math.cos(a)*rr(.8,1.15),Math.sin(a)*rr(.8,1.15),rr(-.15,.15)));}const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:0xc8efff,transparent:true,opacity:.8,blending:THREE.AdditiveBlending}));line.rotation.set(rr(0,6),rr(0,6),rr(0,6));g.add(line);arcs.push(line);}
 g.scale.setScalar(radius);return {g,inner,shell,aura,rings,arcs,radius,color};
}
function animateOrb(o,t){o.shell.material.uniforms.uTime.value=t;o.inner.scale.setScalar(.22+Math.sin(t*18)*.025);for(let i=0;i<o.rings.length;i++){const r=o.rings[i];r.rotation.x=t*(.8+i*.3)+i;r.rotation.y=t*(.6+i*.2);r.scale.setScalar(.9+Math.sin(t*5+i)*.13);}for(let i=0;i<o.arcs.length;i++){o.arcs[i].rotation.z=t*(i+1);o.arcs[i].visible=Math.sin(t*25+i*3)>.05;}o.aura.material.opacity=.6+Math.sin(t*9)*.12;}
function removeObject(g){if(!g)return;g.removeFromParent();const disposed=new Set();g.traverse(o=>{if(o.isMesh||o.isLine||o.isSprite||o.isPoints){if(o.geometry&&!g.userData.sharedGeometry&&!Object.values(geo).includes(o.geometry)&&!disposed.has(o.geometry)){o.geometry.dispose();disposed.add(o.geometry);}for(const m of Array.isArray(o.material)?o.material:[o.material])if(m&&!Object.values(mats).includes(m)&&!disposed.has(m)){m.dispose();disposed.add(m);}}});}
function shock(pos,color,radius=8,life=.5){netFX('shock',[pos.toArray(),color,radius,life]);for(let j=0;j<2;j++){const m=mesh(geo.ring,new THREE.MeshBasicMaterial({color,transparent:true,opacity:.9,blending:THREE.AdditiveBlending,depthWrite:false}),scene,pos.clone());m.rotation.x=j?0:Math.PI/2;effects.push({m,t:0,max:life,radius,type:'ring'});}particles(pos,color,35,radius*1.3,life,.25);}
function trail(a,b,color,width=.035,life=.17){netFX('trail',[a.toArray(),b.toArray(),color,width,life]);const delta=b.clone().sub(a),m=mesh(new THREE.CylinderGeometry(width,width,delta.length(),5),new THREE.MeshBasicMaterial({color,transparent:true,opacity:1,blending:THREE.AdditiveBlending,depthWrite:false}),scene,a.clone().add(b).multiplyScalar(.5));m.quaternion.setFromUnitVectors(V(0,1,0),delta.normalize());effects.push({m,t:0,max:life,type:'fade'});}
function breakPiece(p,force=V(),origin=null,cascade=true){if(!arenaPieceActive(p))return;p.alive=false;p.m.visible=false;const d=box(scene,p.pos.clone(),p.size.clone().multiplyScalar(.64),p.m.material);d.castShadow=false;let vel=force.clone();if(origin)vel.add(p.pos.clone().sub(origin).normalize().multiplyScalar(rr(4,10)));vel.y+=rr(3,8);debris.push({m:d,v:vel,spin:V(rr(-3,3),rr(-3,3),rr(-3,3)),t:rr(3,5),max:5});particles(p.pos,0xa1c3d8,5,4,.5,.14);if(debris.length>120){debris[0].m.removeFromParent();debris.shift();}if(cascade&&p.building!==undefined)for(const upper of buildings[p.building].parts)if(upper.level>p.level&&upper.alive)breakPiece(upper,force,origin,false);}
function destroyAt(pos,radius,power=30){let n=0;for(const p of pieces){if(!arenaPieceActive(p))continue;const d=p.pos.distanceTo(pos);if(d<radius+p.size.length()*.2){p.hp-=power*(1-d/(radius+p.size.length()*.3));if(p.hp<=0){breakPiece(p,V(),pos);n++;}}}return n;}
function restoreArena(){clearWorldCutScars();for(const p of pieces){p.hp=p.max;p.alive=true;p.m.visible=true;}for(const d of debris)d.m.removeFromParent();debris.length=0;shock(V(0,.12,0),0x8ed5d6,WORLD.radius,1.5);toast('ARENA RECONSTRUCTED · all terrain restored',2);restoreTimer=35;syncDomainTerrain();}
function groundHeight(p,prevY){let h=.12;for(const b of pieces){if(!arenaPieceActive(b)||!b.platform)continue;const top=b.pos.y+b.size.y/2;if(Math.abs(p.x-b.pos.x)<b.size.x/2+.25&&Math.abs(p.z-b.pos.z)<b.size.z/2+.25&&prevY>=top-.3)h=Math.max(h,top);}return h;}

const pendingHits=[];
function cancelCharge(f=player,kind){
 const removed=chargesFor(f).filter(c=>kind===undefined||c.kind===kind);
 for(const ch of removed){removeObject(ch.orb?.g||ch.o?.g);removeObject(ch.marker);ch.satellites?.forEach(o=>removeObject(o.g));if(ch===f.auxCharge)f.auxCharge=null;else setPrimaryCharge(f,null);}
 if(!primaryCharge(f)&&f.auxCharge){setPrimaryCharge(f,f.auxCharge);f.auxCharge=null;}
 if(removed.length)f.cooldown=.14;if(f===player&&!chargeFor(f))$('chargeUI').classList.add('hidden');
}
function win(winner,domainKill=false){
 if(phase!=='play')return;menuOpen=false;['menu','help','settingsPanel'].forEach(id=>$(id).classList.add('hidden'));lastFinisher=!!(domainKill&&domain?.captured&&domain.owner===winner&&['gojo','sukuna'].includes(winner.character));phase='finish';finishTime=lastFinisher?FINISHER_DURATION[winner.character]:1.6;mouseDown=false;keys.clear();for(const f of bodies){cancelCharge(f);f.block=false;}winnerId=winner.id;document.exitPointerLock?.();window._winner=winner===player?'player':'enemy';
 if(lastFinisher){beginDomainFinisher(winner,winner.character,undefined,0,lastEliminated?.pos.clone(),undefined,lastEliminated);announce('DOMAIN EXECUTION',winner.character==='gojo'?'INFINITE INFORMATION':'MALEVOLENT SHRINE',1.8);}else announce('DUEL COMPLETE',winner===player?'VICTORY':'DEFEAT',1.5);
}
function hurt(target,amount,attacker,kind='special',knock=V(),gain=1){if(phase!=='play'||target===attacker||target.hp<=0||attacker.hp<=0||barrierSeparates(attacker,target))return false;
 if(soulExecutionPending(target))return false;if(kind==='light')lightOutcome(attacker,4);
 const soulTouch=mahitoExecution(attacker,target,kind);if(soulTouch){amount=MAX_HEALTH*2;kind='ultimate';}
 if(target.dodge>0&&!(kind==='ultimate'&&domain?.owner===attacker&&(attacker.character==='naruto'||domain.mindscapeLosers?.includes(target.id)))){if(target.character==='naruto')triggerNarutoSubstitution(target);if(target.dodgeWindow>0){target.dodgeWindow=0;target.hp=Math.min(MAX_HEALTH,target.hp+BALANCE.dodgeHeal);attacker.stun=Math.max(attacker.stun,.3);particles(headPos(target),C.mint,34,5,.6,.2);shock(headPos(target),C.mint,2,.24);damageText(target,BALANCE.dodgeHeal,true);combatCue(target,attacker,'evade');evadedContact(target,attacker);netFX('evade',[who(target),who(attacker)]);sfx('parry',target.pos);if(target===player){toast('PERFECT DODGE · +15 HP · light counter opening');tone(880,.2,'sine',.07,1.5);}}return false;}
 if(target.bot&&target.difficulty==='impossible'&&!attacker.bot){target.shield.material.opacity=.8;return false;}
 if(soulTouch&&mode!=='practice'&&!clash)return beginMahitoTransfiguration(attacker,target);
 const trapped=trappedByVoid(target);
 if(domain?.owner===attacker&&(kind==='ultimate'||kind==='domain-stomp')&&target.block&&target.blockTime>(trapped?.38:0)){amount*=DOMAIN_GUARD_MULTIPLIER;target.shield.material.opacity=Math.max(target.shield.material.opacity,.28);}
 const face=aimFor(target).setY(0).normalize();const incoming=headPos(attacker).sub(headPos(target)).normalize();
 if(target.block&&target.blockTime>(trapped?.38:0)&&face.dot(incoming)>-.25&&kind!=='ultimate'&&kind!=='bomb'){
   if(kind==='light'&&!(target.comboLock>0)){lightOutcome(attacker,2);target.guardReact=.25;if(!(attacker.comboHits>0)){target.counterWindow=.44;attacker.stun=Math.max(attacker.stun,.32);breakLightChain(attacker);if(target===player)toast('OPENER BLOCKED · attack to counter',.7);}target.shield.material.opacity=.65;sfx('guard',target.pos);netFX('guard',[who(target),who(attacker)]);combatCue(target,attacker,'guard');blockedContact(target,attacker);target.stamina=Math.max(0,target.stamina-3);shock(headPos(target),C.blue,1.8,.16);tone(650,.1,'triangle',.045,.7);return false;}
   // Specials always penetrate guard.
 }
 if(chargeFor(target)){if(target.character==='gojo'&&chargeFor(target).kind===1)amount*=.15;cancelCharge(target);if(target===player)toast('CAST INTERRUPTED · energy spent is lost',1.5);}
 if(target.character==='gojo'&&(target.specialKind===1||target.specialKind===2)){target.specialKind=0;target.redRecoil=0;}
 if(castFor(target)&&kind!=='ultimate'){stopCastVoice(target);setCast(target,null);if(target===player)toast('DOMAIN INTERRUPTED · ultimate spent',2);}
 interruptSpider(target);interruptMahito(target);
 if(target.character==='naruto')interruptNaruto(target);else cancelNarutoMobility(target);if(target.narutoMobility)target.narutoMobility.wallExit=0;interruptWorldCut(target);
 clearBufferedAction(target);const response=responseState(target);response.groundGrace=response.wallGrace=response.alignTime=0;if(kind==='light')lightOutcome(attacker,1);target.hitReact=.22;amount=Math.max(kind==='mahito-touch'?0:.05,amount);target.hp=Math.max(clash||mode==='practice'?1:0,target.hp-amount);if(target.hp<1e-7&&mode!=='practice'&&!clash)target.hp=0;target.damageTaken+=amount;attacker.score+=amount;target.ult=clamp(target.ult+amount*BALANCE.ultTake,0,100);attacker.ult=clamp(attacker.ult+amount*BALANCE.ultDeal,0,100);
 if(kind==='light'){attacker.energy=Math.min(100,attacker.energy+4);target.stun=Math.max(target.stun,.2);}
 target.vel.add(knock);if(knock.length()>4)target.grounded=false;if((kind==='bomb'&&knock.length()>4)||(kind!=='light'&&knock.length()>16))startRagdoll(target,knock);
 if(clash&&clash.participants.includes(attacker.id)&&clash.participants.includes(target.id)){clash.scores[attacker.id]=Math.min(12,(clash.scores[attacker.id]||0)+mindscapeClashGain(attacker,gain));syncClashScores();}
 if(amount>0&&time>(target.lastFeedback||0)){const style=contactStyle(amount,kind,knock,attacker);damageText(target,amount);sfx(contactSound(style,kind,attacker),target.pos,Math.min(1.2,.45+amount/100));netFX('hit',[who(target),amount,who(attacker),style,knock.toArray()]);combatCue(target,attacker,'hit',amount);confirmedContact(target,attacker,amount,style,knock);target.lastFeedback=time+.18;if(kind==='light'){hitStop=.035;if(target===player||attacker===player)controls?.rumble(style==='finish');}}
 if(target.hp<=0)eliminateFighter(target,attacker,kind==='ultimate'||(domain&&domain.owner===attacker));return true;
}
/*COMBAT_SYSTEM*/
function dodge(f=player){if(f.character==='naruto')return startNarutoChakraDash(f);if((narutoBusy(f)||worldCutBusy(f)||mahitoBusy(f)||spiderBusy(f)))return;if(phase!=='play'||f.hp<=0||f.stun>0||f.ragdollT>0||f.recovery>0||f.dodge>0||f.dodgeCooldown>0||f.stamina<14||chargeFor(f)||castFor(f)||trappedByVoid(f))return;f.stamina-=14;f.dodgeCooldown=DODGE.cooldown;f.dodge=DODGE.duration;f.dodgeWindow=DODGE.perfect;let d=moveDirection(f);if(d.lengthSq()<.1)d=aimFor(f).setY(0).multiplyScalar(-1);f.vel.addScaledVector(d.normalize(),DODGE.impulse);f.block=false;afterImage(f,C.mint);particles(headPos(f),C.mint,25,2,.5,.16);sfx('dodge',f.pos);}
function startCharge(kind,f=player,webView=null){
 if(soulLocked(f,kind,true))return;
 if(f.character==='spiderman')return startSpiderMove(f,kind,webView);
 if(f.character==='mahito')return startMahitoMove(f,kind);
 if(techniqueBurnedOut(f,true))return;
 if(!Number.isInteger(kind)||kind<1||kind>(f.character==='gojo'?4:5)||(narutoBusy(f)||worldCutBusy(f)||mahitoBusy(f)||spiderBusy(f)))return;
 if(phase!=='play'||f.hp<=0||f.stun>0||f.ragdollT>0||f.recovery>0||(f.attackIsLight&&f.attack>.08)||f.dodge>0||castFor(f)||trappedByVoid(f))return;
 if(f.character==='sukuna'&&kind===3&&detonateFurnace(f))return;
 if(f.cooldown>0&&!(f.character==='sukuna'&&chargeFor(f)))return;
 if(kind===5){if(f.character==='naruto')castNarutoBomb(f);else castWorldCut(f);return;}
 if(f.character==='gojo'&&kind===1&&blueFor(f)){anchorBlue(blueFor(f));return;}
 const existing=chargeFor(f);if(existing){
  if(f.character==='sukuna'){if(chargeFor(f,kind)||chargesFor(f).length>=2)return;}
  else if(kind===4&&existing.kind!==4){cancelCharge(f);if(f===player)toast('Previous charged attack canceled · energy spent lost',1.4);}else return;
 }
 const minimum=f.character==='naruto'?NARUTO.moves[kind].cost:(f.character==='gojo'?[0,5,7,16,2]:[0,7,9,16,7])[kind];
 if(f.energy<minimum){if(f===player)toast('Need cursed energy · charge energy or land light attacks');return;}
 f.energy-=minimum;f.chargeTime=0;f.block=false;if(f.comboHits>0){const victim=other(f);if(victim.comboLock>0){victim.comboLock=0;victim.stun=Math.min(victim.stun,.08);}breakLightChain(f);}
 const ch={kind,slot:chargeInSlot(f,0)?1:0,t:0,elapsed:0,fullHold:0,releaseRequested:false,releaseQ:0,max:f.character==='naruto'?NARUTO.moves[kind].charge:(f.character==='gojo'?[0,2,1.6,2.5,.45]:[0,1.5,1.4,2.5,1.2])[kind],spent:minimum,orb:null,marker:null};setCharge(f,ch);
 if(f.character==='naruto'){sfx(kind===3?'rasengan':kind===4?'rasenshuriken':'narutoClone',f.pos,.6);return;}
 if(kind!==4){ch.orb=orb(f.character==='gojo'?[0,C.blue,C.red,C.purple][kind]:kind===3?0xff8f35:C.red,.4);if(f.character==='gojo'&&kind===3)ch.satellites=[orb(C.blue,.45),orb(C.red,.45)];}
 else ch.marker=mesh(new THREE.SphereGeometry(.42,16,12),new THREE.MeshBasicMaterial({color:f.character==='gojo'?C.mint:C.red,transparent:true,opacity:.23,depthWrite:false}),scene);
 tone(kind===4?620:kind===2?180:320,.25,'sine',.035,1.3);
}
function teleportDestination(q,f=player){const range=lerp(8,36,q),p=headPos(f).addScaledVector(aimFor(f),range);p.y-=1.2;p.y=Math.max(.15,p.y);const r=Math.hypot(p.x,p.z);if(r>WORLD.radius-1){p.x*=(WORLD.radius-1)/r;p.z*=(WORLD.radius-1)/r;}for(const b of pieces){if(!arenaPieceActive(b)||!b.platform)continue;if(Math.abs(p.x-b.pos.x)<b.size.x/2+.35&&Math.abs(p.z-b.pos.z)<b.size.z/2+.35&&p.y>b.pos.y-.7&&p.y<b.pos.y+b.size.y/2+.4)p.y=b.pos.y+b.size.y/2+.12;}resolveDistrictCollision({pos:p,vel:V()},f.pos);constrainBarrier(f,p,f.pos);return p;}
function releaseCharge(kind,f=player){
 if(f.character==='spiderman'&&kind===4){if(f.spider?.action?.kind===4)stopSpider(f,true);return;}
 if(soulLocked(f,kind)){cancelCharge(f,kind);return;}
 if(techniqueBurnedOut(f)){cancelCharge(f,kind);return;}
 const ch=chargeFor(f,kind);if(!ch||ch.kind!==kind||phase!=='play')return;
 if(!ch.releaseRequested){ch.releaseRequested=true;ch.releaseQ=clamp(ch.t/ch.max,0,1);}
 if(ch.elapsed+1e-8<techniqueStartup(f,kind))return;const q=ch.releaseQ;
 executeTechnique(f,kind,q,aimFor(f),ch.slot||0);cancelCharge(f,kind);f.cooldown=f.character==='naruto'?NARUTO.moves[kind].cooldown:f.character==='gojo'&&kind===4?0:.2;
}
function createBlue(owner,q,dir){
 const old=blueFor(owner);if(old)removeBlue(old);
 blue={id:++techniqueSerial,owner,o:orb(C.blue,lerp(.4,1.35,q)),p:techniqueChargePosition(owner,{kind:1},dir).addScaledVector(dir,.12),dir:dir.clone(),aimTarget:dir.clone(),guidePoint:V(),guideDirection:V(),steerRotation:new THREE.Quaternion(),steerBlend:new THREE.Quaternion(),origin:headPos(owner),q,phase:'travel',t:0,age:0,sweep:0,hold:0,pulse:0,trail:0,travelled:0,range:lerp(LIMITLESS_OUTPUT.blue.travelMin,LIMITLESS_OUTPUT.blue.travelMax,q)};
 blue.o.g.position.copy(blue.p);blues.push(blue);
 playCombatFX('blueRelease',blue.p,2.6+q*2.2,q,dir);shakeIt(.12+q*.12,blue.p,dir);flashIt(.06+q*.08);
 if(owner===player)toast('BLUE GUIDANCE · steer with your aim · tap Blue again to anchor',2.8);
}
function executeTechnique(owner,kind,q,dir,slot=0){
 if(soulLocked(owner,kind))return;
 if(owner.character==='spiderman'){startSpiderMove(owner,kind);return;}
 if(owner.character==='mahito'){startMahitoMove(owner,kind);return;}
 if(techniqueBurnedOut(owner))return;
 if(owner.character==='naruto'){executeNarutoTechnique(owner,kind,q,dir);return;}
 const origin=headPos(owner).addScaledVector(dir,1.7),target=other(owner);sfx(owner.character==='gojo'?['','blue','red','purple','teleport'][kind]:kind===3?'fire':kind===4?'dodge':'slash',owner.pos,.6+q*.5);
 owner.attackIsLight=false;owner.attack=.42;owner.attackMax=.42;owner.attackKind=kind===2?2:0;
 const prefix=slot===1?'auxSpecial':'special';owner[prefix+'Kind']=kind;owner[prefix+'Age']=0;owner[prefix+'Duration']=owner.character==='gojo'&&kind<3?(kind===1?TECHNIQUE_MOTION.blueRelease:TECHNIQUE_MOTION.redRelease):kind===3?.6:.42;owner[prefix+'Power']=q;
 if(owner.character==='gojo'){
  if(kind===1)createBlue(owner,q,dir);
  if(kind===2){owner.redRecoil=.42;fireRed(redMuzzlePosition(owner,dir),dir,q,owner);}
  if(kind===3){const o=orb(C.purple,lerp(1.1,2.5,q));projectiles.push({id:++techniqueSerial,type:'purple',owner,o,p:origin.clone(),dir:dir.clone(),q,t:0,hit:false,impactShown:false});announce('HOLLOW TECHNIQUE','PURPLE',1.1);playCombatFX('purpleRelease',origin,4+q*3.5,q,dir);shock(origin,C.purple,6+q*2,.48);cinematicShot(owner,'purple',.72);shakeIt(.48,origin,dir);flashIt(.4);tone(95,.8,'sawtooth',.06,.4);}
  if(kind===4){const old=headPos(owner),dst=teleportDestination(q,owner);const r=Math.hypot(dst.x,dst.z);if(r>WORLD.radius-1){dst.x*=(WORLD.radius-1)/r;dst.z*=(WORLD.radius-1)/r;}afterImage(owner,C.mint);const arrival=dst.clone().add(V(0,1.45,0)),path=arrival.clone().sub(old);playCombatFX('warp',old,path.length(),q,path.clone().normalize());playCombatFX('teleport',old,2,q,dir);playCombatFX('teleport',arrival,2,q,dir);particles(old,C.mint,55,5,.6,.16);trail(old,dst.clone().add(V(0,1.2,0)),C.mint,.024,.35);owner.pos.copy(dst);owner.vel.set(0,0,0);owner.grounded=false;shock(headPos(owner),C.mint,2,.25);tone(1000,.17,'sine',.055,.25);}
 }else{
  if(kind===1){for(let i=0;i<(q>.72?3:1);i++){const d=dir.clone().applyAxisAngle(V(0,1,0),i===0?0:i===1?-.12:.12);projectiles.push({id:++techniqueSerial,type:'slash',owner,p:origin.clone(),dir:d,q,damage:charged(BALANCE.dismantle,q)*(i===0?1:.5),t:0,hit:false});}slashRibbon(origin,dir,C.red,3+q,.4,-.3);tone(440,.22,'sawtooth',.055,.15);}
  if(kind===2){const delta=headPos(target).sub(headPos(owner));if(delta.length()<5+q&&delta.normalize().dot(dir)>-.15){techniques.push({type:'cleave',owner,target,q,t:0,next:0,count:0});announce('CURSED TECHNIQUE','CLEAVE',.7);}else{slashRibbon(origin,dir,C.red,3,.35,.6);toast('CLEAVE missed · get within '+Math.round(5+q)+'m',1.5);}shakeIt(.2);}
  if(kind===3){if(slot===0)owner.releasePose=.5;const o=orb(0xff7d24,.9+q);projectiles.push({id:++techniqueSerial,type:'fire',owner,o,p:origin.clone(),dir:dir.clone(),q,t:0,hit:false});announce('DIVINE FLAME','FURNACE',1.1);cinematicShot(owner,'furnace',.55);shock(origin,0xff9439,5,.4);tone(110,.9,'sawtooth',.07,.35);}
  if(kind===4){techniques.push({type:'rush',owner,dir:dir.clone(),q,t:0,hit:false});afterImage(owner,C.red);shock(headPos(owner),C.red,3,.25);tone(380,.25,'sawtooth',.035,.3);}
 }
}
function updateTechniques(dt){
 for(let i=techniques.length-1;i>=0;i--){const a=techniques[i];if(a.type==='world-cut-cast'){if(updateWorldCutAction(a,dt))techniques.splice(i,1);continue;}if(a.type==='naruto'||a.type==='naruto-wind'){const done=a.type==='naruto'?updateNarutoAction(a,dt):updateNarutoWind(a,dt);if(done)techniques.splice(i,1);continue;}a.t+=dt;let victim=a.target?.hp>0?a.target:other(a.owner);let done=false;if(a.owner.hp<=0){techniques.splice(i,1);continue;}
  if(a.type==='cleave'){if(a.owner.stun>0)done=true;else if(a.t>=a.next){a.next+=.095;a.count++;const p=headPos(victim);playCombatFX('cleave',p,2.5,a.q,aimFor(a.owner));if(p.distanceTo(headPos(a.owner))<6.3){hurt(victim,charged(BALANCE.cleave,a.q)/(5+Math.floor(a.q*3)),a.owner,'special',V(),.3);destroyAt(p,2,8);if(a.count===1)impact=.026;}done=a.count>=5+Math.floor(a.q*3);}}
  if(a.type==='rush'&&a.owner.stun>0){techniques.splice(i,1);continue;}
  if(a.type==='rush'){const prev=a.owner.pos.clone();a.owner.pos.addScaledVector(a.dir,(48+28*a.q)*dt);resolveDistrictCollision(a.owner,prev);constrainBarrier(a.owner,a.owner.pos,prev,a.owner.vel);if(frameCount%3===0)afterImage(a.owner,C.red);const line=new THREE.Line3(prev.clone().add(V(0,1.45,0)),headPos(a.owner));victim=opponents(a.owner).sort((x,y)=>line.closestPointToPoint(headPos(x),true,V()).distanceTo(headPos(x))-line.closestPointToPoint(headPos(y),true,V()).distanceTo(headPos(y)))[0]||victim;const nearest=line.closestPointToPoint(headPos(victim),true,V());if(!a.hit&&nearest.distanceTo(headPos(victim))<1.9){a.hit=true;hurt(victim,charged(BALANCE.rush,a.q),a.owner,'special',a.dir.clone().multiplyScalar(24+8*a.q).add(V(0,9,0)),2);slashRibbon(headPos(victim),a.dir,C.red,3,.3,.2);shock(headPos(victim),C.red,5,.4);}done=a.t>=.46||a.owner.stun>0||a.owner.pos.distanceTo(prev)<dt*8;}
  if(a.type==='burn'){if(a.t>=a.next){a.next+=.4;for(const victim of opponents(a.owner))if(headPos(victim).distanceTo(a.p)<a.radius)hurt(victim,charged(BALANCE.burn,a.q)/5,a.owner,'special',V(),.1);particles(a.p,0xff913b,12,5,.8,.25);}done=a.t>2;}
  if(done)techniques.splice(i,1);
 }
}
function anchorBlue(b=blue){if(!b)return;if(b.phase!=='hold'){b.phase='hold';b.hold=0;shock(b.p,C.blue,1.6+b.q*2,.3);toast('BLUE ANCHORED · fire Red into its core for Hollow Bomb',2.5);}}
function raySphere(origin,dir,center,radius){const oc=origin.clone().sub(center),b=oc.dot(dir),c=oc.lengthSq()-radius*radius,d=b*b-c;if(d<0)return Infinity;const t=-b-Math.sqrt(d);return t>=0?t:(-b+Math.sqrt(d)>=0?0:Infinity);}
function fireRed(origin,dir,q,owner=player){
 playCombatFX('redMuzzle',origin,1,q,dir);
 const targets=opponents(owner),ray=new THREE.Raycaster(origin,dir,0,90),hits=ray.intersectObjects(pieces.filter(p=>arenaPieceActive(p)).map(p=>p.m),false);let distance=hits.length?hits[0].distance:80;
 distance=Math.min(distance,barrierRayDistance(origin,dir));
 const targetDistance=Math.min(...targets.map(target=>raySphere(origin,dir,headPos(target),.85)));let bdist=Infinity;const ownBlue=blueFor(owner);
 if(ownBlue?.phase==='hold')bdist=raySphere(origin,dir,ownBlue.p,Math.max(1,ownBlue.o.radius*1.1));
 if(bdist<distance&&bdist<targetDistance){trail(origin,origin.clone().addScaledVector(dir,bdist),C.red,.035+q*.02,.12);playCombatFX('redBeam',origin,bdist,q,dir);startBomb(q,ownBlue);return;}
 distance=Math.min(distance,targetDistance);const pos=origin.clone().addScaledVector(dir,distance),radius=lerp(2.6,7,q);
 trail(origin,pos,C.red,.035+q*.02,.13);trail(origin,pos,0xfff0dd,.012,.09);playCombatFX('redBeam',origin,distance,q,dir);playCombatFX('red',pos,radius,q,dir);sfx('redImpact',pos,.7+q*.4);destroyAt(pos,radius,20+q*35);
 for(const target of targets){const d=headPos(target).distanceTo(pos);if(d<radius+1)hurt(target,charged(BALANCE.red,q)*(targetDistance<=distance+.001?1:1-.45*clamp(d/radius,0,1)),owner,'special',headPos(target).sub(pos).normalize().multiplyScalar(12+q*13).add(V(0,5,0)),2);}
 shakeIt(.2+q*.35,pos,dir);flashIt(.13+q*.18);impact=.035;rumble(q>.7);particles(pos,C.red,48,6+q*4,.45,.14);
}
function startBomb(redCharge,b=blue){
 if(!b)return;const q=(b.q+redCharge)*.5,p=b.p.clone(),owner=b.owner;removeBlue(b);
 bomb={id:++techniqueSerial,owner,p,q,t:0,pulse:0,o:orb(C.purple,1),radius:lerp(NUKE_RADIUS.min,NUKE_RADIUS.max,q)};bomb.o.g.position.copy(p);bombs.push(bomb);announce('RED × BLUE · THREE-SECOND FUSION','HOLLOW BOMB',2.8);sfx('fusion',p);shock(p,C.purple,bomb.radius,.6);
}
function detonateBomb(b=bomb){
 if(!b)return;const {p,q,radius,owner}=b;for(const target of opponents(owner)){const d=headPos(target).distanceTo(p),falloff=1-.7*clamp(d/radius,0,1);
 if(d<radius)hurt(target,charged(BALANCE.nukeBurst,q)*falloff,owner,'bomb',headPos(target).sub(p).normalize().multiplyScalar(24+q*18).add(V(0,12,0)),3);}
 const pd=headPos(owner).distanceTo(p);if(pd<radius){owner.vel.add(headPos(owner).sub(p).normalize().multiplyScalar((1-pd/radius)*26).add(V(0,7,0)));owner.grounded=false;startRagdoll(owner,owner.vel);}
 destroyAt(p,radius,160);shock(p,C.purple,radius,1.5);shock(p,0xffffff,radius*.75,.9);playCombatFX('hollow',p,radius,q);sfx('hollowNuke',p);particles(p,C.purple,300,40,2,.45);shakeIt(1.8,p);flashIt(1);impact=.07;rumble(true);tone(40,1.8,'sine',.21,.4);announce('FUSION DETONATED','HOLLOW BOMB',1.3);
 removeBomb(b);
}
function spendUltimate(f){if(f.ult>=99){f.ult=0;return true;}if((f===player||mode==='online')&&f.hp<5&&!f.emergency){f.emergency=true;return true;}return false;}
/*BARRIERS*/
/*DOMAINS*/
/*COMBAT_VFX*/
/*TECHNIQUE_STARTUP*/
/*FINISHERS*/
function moveDirection(f=player){const dir=aimFor(f).setY(0).normalize(),r=V(-dir.z,0,dir.x),v=V(),held=inputFor(f);const analog=f===player?controls?.move:(f.input||remoteInput).move;
 if(analog&&Math.hypot(analog.x,analog.y)>.12)return v.addScaledVector(dir,-analog.y).addScaledVector(r,analog.x).clampLength(0,1);
 if(held.has('KeyW'))v.add(dir);if(held.has('KeyS'))v.sub(dir);if(held.has('KeyD'))v.add(r);if(held.has('KeyA'))v.sub(r);return v.lengthSq()>0?v.normalize():v;}
function moveFighter(f,dt){
 if(spiderPhysicsOwned(f))return;
 const wasGrounded=f.grounded;updateMeleeAlignment(f,dt);const hover=limitlessAirCast(f);if(hover)f.vel.y*=Math.exp(-dt/TECHNIQUE_MOTION.airBrake);
 const before=f.pos.clone(),previous=f.pos.y,ragdoll=f.ragdollT>0,velocityBefore=f.vel.clone();f.pos.addScaledVector(f.vel,dt);if(f.dodge>0&&!ragdoll&&f.character!=='naruto'){const dir=mahitoScratch.a.set(f.vel.x,0,f.vel.z),travel=dir.length()*dt;if(travel>.001){dir.normalize();const endY=f.pos.y;f.pos.copy(before);f.pos.addScaledVector(dir,narutoMobilityDistance(f,dir,travel));f.pos.y=endY;}}if(!f.flying&&!hover)f.vel.y-=22*dt;
 const drag=f.character==='spiderman'&&f.spider?.momentum>0&&!f.grounded?.25:ragdoll?(f.ragdollGround?3.2:.28):6;f.vel.x*=Math.exp(-drag*dt);f.vel.z*=Math.exp(-drag*dt);
 if(ragdoll&&!f.ragdollGround){
  const travel=f.pos.clone().sub(before),distance=travel.length();if(distance>.001){const ray=new THREE.Raycaster(before.clone().add(V(0,1.05,0)),travel.normalize(),0,distance+.55),hit=ray.intersectObjects(pieces.filter(p=>arenaPieceActive(p)&&p.solid).map(p=>p.m),false)[0];
   if(hit&&velocityBefore.length()>13){const wall=pieces.find(p=>p.m===hit.object);if(wall){breakPiece(wall,velocityBefore.clone().multiplyScalar(.24),hit.point);destroyAt(hit.point,2.4,48);f.vel.x*=.76;f.vel.z*=.76;f.ragdollRate*=.8;launchImpact(f,hit.point,1.3);}}
  }
 }
 const h=groundHeight(f.pos,previous);if(f.pos.y<h&&f.vel.y<=0){
  const impactSpeed=-f.vel.y;f.pos.y=h;
  if(ragdoll&&!f.ragdollGround){launchImpact(f,f.pos.clone(),clamp(impactSpeed/15,.4,1.4));destroyAt(f.pos,1.8,18);
   if(impactSpeed>9&&f.ragdollBounces===0){f.ragdollBounces=1;f.vel.y=Math.min(4.8,impactSpeed*.28);f.vel.x*=.78;f.vel.z*=.78;f.grounded=false;}
   else{f.vel.y=0;f.grounded=true;f.ragdollGround=true;f.ragdollT=Math.min(f.ragdollT,.62);}
  }else{f.vel.y=0;f.grounded=true;}
 }else if(f.pos.y>h+.2)f.grounded=false;
 if(f.narutoSlamImpact&&f.grounded){f.narutoSlamImpact=false;narutoFX('ground',f.pos,3);narutoFreeze=Math.max(narutoFreeze,.06);shakeIt(.4);sfx('launchImpact',f.pos);}
 if(f.character==='spiderman'&&f.spider?.momentum>0){const next=f.pos.clone(),landed=f.grounded;f.pos.copy(before);if(spiderMoveTo(f,next)){f.vel.x*=.35;f.vel.z*=.35;f.spider.momentum=0;}if(landed&&f.pos.y<=groundHeight(f.pos,previous)+.03){f.grounded=true;f.spider.momentum=f.spider.releaseTime=0;}}
 const r=Math.hypot(f.pos.x,f.pos.z);if(r>WORLD.radius){f.pos.x*=WORLD.radius/r;f.pos.z*=WORLD.radius/r;f.vel.x*=-.2;f.vel.z*=-.2;}
 f.pos.y=clamp(f.pos.y,.12,WORLD.ceiling);resolveDistrictCollision(f,before);constrainBarrier(f,f.pos,before,f.vel);groundResponse(f,wasGrounded);
}
function updateControlled(f,dt){
 if(soulExecutionPending(f)){f.vel.set(0,0,0);f.block=false;return;}
 updateCombatTimers(f,dt);updateMahitoFighter(f,dt);
 if(spiderHeld(f)||spiderThrows.some(t=>t.target===f)){f.block=false;return;}
 f.comboDisplay=Math.max(0,(f.comboDisplay||0)-dt);if(f===player&&f.comboDisplay===0)$('comboReadout').classList.add('hidden');
 for(const name of ['stun','dodge','dodgeWindow','dodgeCooldown','attack','comboTimer','cooldown','autoHit'])f[name]=Math.max(0,(f[name]||0)-dt);
 const held=inputFor(f),ch=chargeFor(f),casting=castFor(f),trapped=trappedByVoid(f);
 const energyCharging=held.has('KeyC')&&!(narutoBusy(f)||worldCutBusy(f)||mahitoBusy(f)||spiderBusy(f))&&!ch&&f.stun<=0&&!casting&&f.dodge<=0&&!trapped;f.energyCharging=energyCharging;
 const move=moveDirection(f),sprint=held.has('ShiftLeft')&&f.stamina>1&&!ch&&!energyCharging&&!f.block,freeMobility=[1,3,4].includes(f.narutoMobility?.kind);
 const mobility=updateNarutoMobility(f,dt,move,held);f.sprinting=sprint&&move.lengthSq()>0;let speed=sprint?(f.flying&&f.character==='gojo'?36:WORLD.sprint):WORLD.walk;if(ch)speed*=.28;if(energyCharging||casting||(narutoBusy(f)||worldCutBusy(f)||mahitoBusy(f)||spiderBusy(f))||mobility)speed=0;if(f.attack>0)speed*=.65;if(f.block)speed*=.4;if(trapped)speed*=.22;if(f.stun>0)speed=0;
 speed*=mahitoSpeedScale(f);f.pos.addScaledVector(move,speed*dt);if(sprint&&move.lengthSq()>0&&!freeMobility&&![1,3,4].includes(f.narutoMobility?.kind))f.stamina=Math.max(0,f.stamina-4.5*dt);
 if(f.flying){f.energy=Math.max(0,f.energy-2*dt);f.vel.y*=Math.exp(-8*dt);if(f.stun<=0&&!mahitoBusy(f)&&!limitlessAirCast(f)){if(held.has('Space'))f.vel.y=10;if(held.has('ControlLeft'))f.vel.y=-10;}if(f.energy===0)f.flying=false;}
 if(f.grounded&&!sprint&&!f.flying&&f.attack<=0&&f.dodge<=0&&f.stun<=0&&f.recovery<=0)f.stamina=Math.min(maxStamina(f),f.stamina+27*dt);
 if(energyCharging){f.chargeTime=(f.chargeTime||0)+dt;f.energy=Math.min(100,f.energy+Math.min(8,.8*Math.exp(f.chargeTime*1.2))*dt);if(frameCount%3===0)particles(headPos(f),fighterColor(f),2,1.7,.6,.13);}else f.chargeTime=0;
 if(f===player)regenCharge=f.chargeTime;
 if(held.has('Mouse0')&&!ch&&!energyCharging&&f.autoHit<=0){lightAttack(f);f.autoHit=.36;}
 f.block=held.has('Mouse2')&&!ch&&!energyCharging&&!narutoBusy(f)&&!worldCutBusy(f)&&!mahitoBusy(f)&&!spiderBusy(f)&&f.attack<=0&&f.dodge<=0&&f.stun<=0&&!casting;f.blockTime=f.block?f.blockTime+dt:0;
 if(mode==='practice'&&f===player){f.energy=100;f.ult=100;}moveFighter(f,dt);finishNarutoMobilityStep(f);updateBufferedAction(f,dt);
 if(ch)updateHeldCharge(f,dt);
 if(f===player)updateChargeHUD();
}
function updateChargeHUD(){
 if(charge){const q=clamp(charge.t/charge.max,0,1);$('chargeUI').classList.remove('hidden');$('chargeName').textContent=chargesFor(player).map(c=>kit(player).names[c.kind]).join(' + ');$('chargeProgress').style.width=q*100+'%';$('chargeHint').textContent=charge.releaseRequested?'FORMING · RELEASE QUEUED':charge.fullHold>0?'AUTO RELEASE IN '+Math.max(0,3-charge.fullHold).toFixed(1)+'s · '+Math.round(q*100)+'% OUTPUT':charge.elapsed<techniqueStartup(player,charge.kind)?'GATHERING ENERGY · tap to fire, hold for power':charge.kind===4&&player.character!=='naruto'?(player.character==='gojo'?Math.round(lerp(8,36,q))+'m · release to teleport':'Release to rush forward'):Math.round(q*100)+'% OUTPUT · release to fire';if(chargesFor(player).length===2)$('chargeHint').textContent=chargesFor(player).map(c=>kit(player).names[c.kind]+': '+(c.releaseRequested?'QUEUED':Math.round(chargePower(c)*100)+'%'+(c.fullHold>0?' · '+Math.max(0,3-c.fullHold).toFixed(1)+'s':''))).join(' / ');}
 else if(player.energyCharging){$('chargeUI').classList.remove('hidden');$('chargeName').textContent=player.character==='naruto'?'CHAKRA':'CURSED ENERGY';$('chargeProgress').style.width=player.energy+'%';$('chargeHint').textContent='Vulnerable while charging';}else $('chargeUI').classList.add('hidden');
}
function updateEnemy(dt){for(const f of bodies)if(f!==player&&f.hp>0){if(f.bot)updateAI(f,dt);else updateControlled(f,dt);}separateFighters();}
// Two angular blends give the aim a short trailing delay, then turn the fast field
// toward it. Quaternion turns also work for a full reversal without a zero vector.
function steerBlue(b,dt,rate){
 const desired=aimFor(b.owner),rotation=b.steerRotation,blend=b.steerBlend;
 rotation.setFromUnitVectors(b.aimTarget,desired);blend.identity().slerp(rotation,1-Math.exp(-dt/LIMITLESS_OUTPUT.blue.aimLag));b.aimTarget.applyQuaternion(blend).normalize();
 // Aim defines a position around the caster, not an endless forward heading.
 b.guidePoint.copy(b.owner.pos);b.guidePoint.y+=1.45;b.guidePoint.addScaledVector(b.aimTarget,b.range);b.guidePoint.y=clamp(b.guidePoint.y,.65,WORLD.ceiling-4);
 b.guideDirection.copy(b.guidePoint).sub(b.p);const distance=b.guideDirection.length();
 if(distance>.0001){b.guideDirection.divideScalar(distance);rotation.setFromUnitVectors(b.dir,b.guideDirection);blend.identity().slerp(rotation,1-Math.exp(-rate*dt));b.dir.applyQuaternion(blend).normalize();}
 return distance;
}
function updateBlue(dt,b=blue){if(!b)return;b.age+=dt;b.trail+=dt;b.t+=dt;const prev=b.p.clone();
 if(b.phase==='travel'){
  steerBlue(b,dt,LIMITLESS_OUTPUT.blue.steer);const launch=lerp(.62,1,THREE.MathUtils.smoothstep(b.age,0,.2)),remaining=Math.max(0,b.range-(b.travelled||0)),step=Math.min(remaining,LIMITLESS_OUTPUT.blue.speed*launch*dt);b.p.addScaledVector(b.dir,step);b.travelled=(b.travelled||0)+step;
  if(b.travelled>=b.range-1e-6){b.phase='sweep';b.sweep=0;b.arrival=b.p.clone();if(b.owner===player)toast('BLUE CONTROL · 6s to sweep all around you · tap Blue to anchor',2.5);}
 }
 else if(b.phase==='sweep'){
  b.sweep+=dt;const distance=steerBlue(b,dt,LIMITLESS_OUTPUT.blue.sweepSteer),step=Math.min(lerp(LIMITLESS_OUTPUT.blue.sweepSpeedMin,LIMITLESS_OUTPUT.blue.sweepSpeedMax,b.q)*dt,distance*(1-Math.exp(-dt/LIMITLESS_OUTPUT.blue.arrivalBrake)));b.p.addScaledVector(b.dir,step);if(b.sweep>=LIMITLESS_OUTPUT.blue.sweepTime)anchorBlue(b);
 }
 else{b.hold+=dt;if(b.hold>=LIMITLESS_OUTPUT.blue.holdTime){for(const target of opponents(b.owner))if(headPos(target).distanceTo(b.p)<lerp(4,9,b.q))target.vel.add(target.pos.clone().sub(b.p).normalize().multiplyScalar(7));removeBlue(b);orbLight.intensity=0;return;}}
 const movement=b.p.clone().sub(prev),travel=movement.length();if(travel>.001){const wall=barrierRayDistance(prev,movement.clone().normalize(),travel);if(Number.isFinite(wall)){b.p.copy(prev).addScaledVector(movement.normalize(),Math.max(0,wall-.15));anchorBlue(b);}}
 b.p.y=clamp(b.p.y,.65,WORLD.ceiling-4);b.o.g.position.copy(b.p);animateOrb(b.o,time);orbLight.position.copy(b.p);orbLight.color.set(C.blue);orbLight.intensity=16+8*b.q;
 if(b.trail>.075){b.trail=0;trail(prev,b.p,C.blue,.04,.3);const a=rr(0,Math.PI*2),r=lerp(3,8,b.q);const point=b.p.clone().add(V(Math.cos(a)*r,rr(-2,2),Math.sin(a)*r));trail(point,point.clone().lerp(b.p,.3),C.blue,.015,.16);particles(b.p,C.blue,2,1.4,.6,.12);}
 const radius=lerp(4,9,b.q),inner=lerp(1.2,3.7,b.q);b.pulse+=dt;const ticks=Math.floor((b.pulse+1e-8)/.25);b.pulse-=ticks*.25;
 for(const target of opponents(b.owner)){const d=headPos(target).distanceTo(b.p);if(d<radius&&!barrierSeparates(b.owner,target)){const pull=b.p.clone().sub(headPos(target));if(d<inner){target.pos.lerp(b.p.clone().add(V(.15,-1.2,.15)),1-Math.exp(-14*dt));target.vel.set(0,0,0);target.stun=Math.max(target.stun,.12);}else target.vel.addScaledVector(pull.normalize(),(1-d/radius)*(18+24*b.q)*dt);for(let tick=0;tick<ticks&&phase==='play';tick++)hurt(target,charged(BALANCE.blueDPS,b.q)*.25*(1-.35*d/radius),b.owner,'special',V(),.13);}}

 if(Math.floor(b.age*7)!==Math.floor((b.age-dt)*7))destroyAt(b.p,lerp(1.5,5,b.q),9+10*b.q);
 for(const d of debris){const distance=d.m.position.distanceTo(b.p);if(distance<radius)d.v.addScaledVector(b.p.clone().sub(d.m.position).normalize(),45*dt*(1-distance/radius));}
}
function hasFurnaceArrow(f){
 if(mode==='online'&&net?.role==='guest')return !!replicaState?.projectiles.some(p=>p.type==='fire'&&p.owner===f.id);
 return projectiles.some(p=>p.type==='fire'&&p.owner===f&&!p.hit);
}
function explodeFurnace(p){
 if(p.hit)return;p.hit=true;const radius=lerp(12,22,p.q);
 shock(p.p,0xff8c2a,radius,1);shock(p.p,0xfff0c7,radius*.7,.65);playCombatFX('furnaceBurst',p.p,radius,p.q,p.dir);playCombatFX('furnace',p.p,radius,p.q,p.dir);sfx('furnaceImpact',p.p);destroyAt(p.p,radius,160);
 for(const target of opponents(p.owner)){const d=headPos(target).distanceTo(p.p);if(d<radius)hurt(target,charged(BALANCE.furnace,p.q)*(1-.55*d/radius),p.owner,'special',headPos(target).sub(p.p).normalize().multiplyScalar(24+8*p.q).add(V(0,10,0)),2);}
 techniques.push({type:'burn',owner:p.owner,p:p.p.clone(),radius:radius*.75,q:p.q,t:0,next:.4});particles(p.p,0xff9a30,100,18,1.2,.24);shakeIt(.75,p.p,p.dir);flashIt(.35);rumble(true);
}
function detonateFurnace(f){
 const i=projectiles.findIndex(p=>p.type==='fire'&&p.owner===f&&!p.hit);if(i<0)return false;
 const p=projectiles[i];explodeFurnace(p);removeObject(p.o?.g);projectiles.splice(i,1);return true;
}
function updateProjectiles(dt){
 for(let i=projectiles.length-1;i>=0;i--){const p=projectiles[i];if(p.type==='world-cut'){if(updateWorldCutProjectile(p,dt))projectiles.splice(i,1);continue;}if(p.type.startsWith('naruto-')){if(updateNarutoProjectile(p,dt))projectiles.splice(i,1);continue;}const targets=opponents(p.owner);p.t+=dt;const old=p.p.clone(),travel=(p.type==='purple'?29:p.type==='slash'?38:90+30*p.q)*dt;p.p.addScaledVector(p.dir,travel);
  if(p.type==='fire'){
   const wall=barrierRayDistance(old,p.dir,travel),terrain=new THREE.Raycaster(old,p.dir,0,travel).intersectObjects(pieces.filter(b=>arenaPieceActive(b)).map(b=>b.m),false)[0]?.distance??Infinity,ground=p.dir.y<0?Math.max(0,(.12-old.y)/p.dir.y):Infinity,targetDistance=Math.min(...targets.map(target=>raySphere(old,p.dir,headPos(target),1.6))),impact=Math.min(wall,terrain,ground,targetDistance),hit=impact<=travel;
   if(hit)p.p.copy(old).addScaledVector(p.dir,Math.max(0,impact-(impact===wall?.15:0)));
   if(p.o)p.o.g.position.copy(p.p);trail(old,p.p,0xffa032,.085,.2);
   if(hit||p.t>=3||Math.hypot(p.p.x,p.p.z)>WORLD.radius+10){explodeFurnace(p);removeObject(p.o?.g);projectiles.splice(i,1);}else if(frameCount%2===0)particles(p.p,0xffad38,5,4,.5,.19);
   continue;
  }
  const wall=barrierRayDistance(old,p.dir,travel);if(Number.isFinite(wall)){const impact=old.clone().addScaledVector(p.dir,wall);shock(impact,p.type==='purple'?C.purple:C.red,2,.25);if(p.type==='purple')playCombatFX('purpleImpact',impact,lerp(LIMITLESS_OUTPUT.purple.impactMin,LIMITLESS_OUTPUT.purple.impactMax,p.q),p.q,p.dir);removeObject(p.o?.g);projectiles.splice(i,1);continue;}
  if(p.o){p.o.g.position.copy(p.p);animateOrb(p.o,time);}
  if(p.type==='purple'){trail(old,p.p,C.purple,.13,.23);if(frameCount%2===0)particles(p.p,C.purple,5,4,.5,.19);}
  let remove=p.t>(p.type==='purple'?2.8:3)||p.p.y<0;
  const segment=new THREE.Line3(old,p.p);for(const target of targets){const nearest=segment.closestPointToPoint(headPos(target),true,V()),distance=headPos(target).distanceTo(nearest);
  if(p.type==='purple'){const radius=lerp(1.4,3.2,p.q);destroyAt(p.p,radius+1,70);if(!(p.hitIds||[]).includes(target.id)&&distance<radius+.8){hurt(target,charged(BALANCE.purple,p.q),p.owner,'special',p.dir.clone().multiplyScalar(22).add(V(0,5,0)),3);(p.hitIds||=[]).push(target.id);if(!p.impactShown){p.impactShown=true;playCombatFX('purpleImpact',p.p,lerp(LIMITLESS_OUTPUT.purple.impactMin,LIMITLESS_OUTPUT.purple.impactMax,p.q),p.q,p.dir);}shock(p.p,C.purple,9,.65);blastCrown(p.p,C.purple,10,.8);shakeIt(.72,p.p,p.dir);flashIt(.25+.2*p.q);rumble(true);}}
  else{destroyAt(p.p,1.7+p.q,9);if(!p.hit&&distance<1.3+p.q*.5){hurt(target,p.damage??charged(BALANCE.dismantle,p.q),p.owner,'special',p.dir.clone().multiplyScalar(5),1);p.hit=true;slashRibbon(headPos(target),p.dir,0xffe4ee,3,.3,.8);remove=true;}}
  }
  if(remove){removeObject(p.o?.g);projectiles.splice(i,1);}
 }
}

function updateBomb(dt,b=bomb){if(!b)return;const bomb=b;const active=Math.min(dt,3-bomb.t);bomb.t+=active;bomb.pulse+=active;const q=bomb.t/3;bomb.o.g.scale.setScalar(lerp(.9,3.5+bomb.q*2,q));animateOrb(bomb.o,time);bomb.o.g.position.copy(bomb.p);orbLight.position.copy(bomb.p);orbLight.color.set(C.purple);orbLight.intensity=20+q*35;
 if(frameCount%3===0){particles(bomb.p,C.purple,4,7,.7,.3);const a=rr(0,6.28),p=bomb.p.clone().add(V(Math.cos(a)*bomb.radius,rr(-1,3),Math.sin(a)*bomb.radius));trail(p,p.clone().lerp(bomb.p,.35),C.purple,.02,.3);}
 while(bomb.pulse>=.5-1e-8&&phase==='play'){bomb.pulse-=.5;for(const target of opponents(bomb.owner)){const d=headPos(target).distanceTo(bomb.p);if(d<bomb.radius)hurt(target,charged(BALANCE.nukeDPS,bomb.q)*.5*(1-.6*d/bomb.radius),bomb.owner,'bomb',V(),.1);}shock(bomb.p,C.purple,(bomb.radius*.3)*(q+.2),.4);destroyAt(bomb.p,4+q*5,5);}
 shakeIt(.05+q*.11,b.p);if(bomb.t>=3-1e-8&&phase==='play')detonateBomb(b);}
function updateEffects(dt){ambientDust.rotation.y=time*.007;ambientDust.position.y=Math.sin(time*.2)*.3;for(let i=effects.length-1;i>=0;i--){const e=effects[i];e.t+=dt;const q=e.t/e.max;if(e.type==='technique'){e.update(Math.min(e.t,e.max));}else if(e.type==='slash'){e.m.scale.setScalar(1+q*.2);e.m.material.opacity=(1-q)*.92;}else if(e.type==='crown'){e.m.scale.setScalar(.1+e.radius*(1-Math.pow(1-q,3)));e.m.rotation.y+=dt*.7;e.m.material.opacity=(1-q)*.45;}else if(e.type==='ghost'){e.mat.opacity=(1-q)*.25;}else if(e.type==='ring'){e.m.scale.setScalar(.1+e.radius*(1-Math.pow(1-q,2)));e.m.material.opacity=(1-q)*.8;}else if(e.type==='fade')e.m.material.opacity=1-q;else if(e.type==='explosion'){e.m.scale.setScalar(.3+Math.sin(q*Math.PI)*e.radius);animateOrb(e.o,time);e.o.aura.material.opacity=(1-q)*.9;}if(e.t>=e.max){removeObject(e.m);effects.splice(i,1);}}
 for(let i=debris.length-1;i>=0;i--){const d=debris[i];d.t-=dt;d.v.y-=18*dt;d.m.position.addScaledVector(d.v,dt);d.m.rotation.x+=d.spin.x*dt;d.m.rotation.y+=d.spin.y*dt;if(d.m.position.y<.15){d.m.position.y=.15;d.v.y=Math.abs(d.v.y)*.28;d.v.x*=.9;d.v.z*=.9;}if(d.t<1)d.m.scale.multiplyScalar(Math.exp(-2*dt));if(d.t<=0){d.m.removeFromParent();debris.splice(i,1);}}
 for(let i=particleData.length-1;i>=0;i--){const p=particleData[i];p.t-=dt;if(p.t<=0){battleVisual.free.push(p);particleData[i]=particleData[particleData.length-1];particleData.pop();continue;}p.p.addScaledVector(p.v,dt);p.v.multiplyScalar(Math.exp(-.8*dt));p.v.y-=dt*.8;}
 for(let i=0;i<particleData.length;i++){const p=particleData[i],f=clamp(p.t/p.max,0,1);pp[i*3]=p.p.x;pp[i*3+1]=p.p.y;pp[i*3+2]=p.p.z;pc[i*3]=p.c.r*f;pc[i*3+1]=p.c.g*f;pc[i*3+2]=p.c.b*f;ps[i]=p.size;}
 pg.setDrawRange(0,particleData.length);pg.attributes.position.needsUpdate=true;pg.attributes.color.needsUpdate=true;pg.attributes.size.needsUpdate=true;
}
/*ANIMATION*/
function updateCamera(dt){updateBattleCamera(dt);if(phase==='menu'){const a=Math.sin(time*.12)*.22;camPos.copy(player.pos).add(V(4.5+a,3,6.5));camLook.copy(player.pos).add(V(-2.8,1.4,0));}else if(phase==='finish'&&finisher&&options.cinematics){finisherCamera();}else if(player.hp<=0&&phase==='play'){const subject=other(player),angle=yaw+cameraOrbit.yaw;camLook.copy(headPos(subject));camPos.lerp(headPos(subject).add(V(Math.sin(angle)*options.camDistance,3,Math.cos(angle)*options.camDistance)),1-Math.exp(-6*dt));}else{if(lockOn&&!options.freeOrbit&&!cursorFree&&!cameraOrbit.active){const d=headPos(other(player)).sub(headPos(player));let target=Math.atan2(-d.x,-d.z);let da=THREE.MathUtils.euclideanModulo(target-yaw+Math.PI,Math.PI*2)-Math.PI;yaw+=da*(1-Math.exp(-7*dt));pitch=lerp(pitch,Math.atan2(-d.y,Math.hypot(d.x,d.z)),1-Math.exp(-6*dt));}
 if(!cameraOrbit.active&&!options.freeOrbit&&!cursorFree){cameraOrbit.yaw*=Math.exp(-12*dt);cameraOrbit.pitch*=Math.exp(-12*dt);}
 const f=forward(),viewYaw=yaw+cameraOrbit.yaw,viewPitch=clamp(pitch+options.camTilt+cameraOrbit.pitch,-1.45,airborneLook(player)?1.52:1.2),view=V(-Math.sin(viewYaw)*Math.cos(viewPitch),-Math.sin(viewPitch),-Math.cos(viewYaw)*Math.cos(viewPitch)),side=V(Math.cos(viewYaw),0,-Math.sin(viewYaw)),orbitWeight=cameraOrbit.active||options.freeOrbit||cursorFree?1:clamp(Math.abs(cameraOrbit.yaw)+Math.abs(cameraOrbit.pitch),0,1);
 camLook.copy(headPos(player)).addScaledVector(f,30*(1-orbitWeight));positionGameplayCamera(view,side,orbitWeight,dt);}
 if(cinematic&&(phase==='play'||phase==='finish'&&cinematic.type==='naruto')){cinematic.t+=dt;if(!options.freeOrbit&&!cursorFree){const f=cinematic.owner,dir=aimFor(f).setY(0).normalize(),right=V(-dir.z,0,dir.x);if(cinematic.type==='naruto'){narutoCinematic(cinematic,dt);}else if(cinematic.type==='domain'){camPos.copy(headPos(f)).addScaledVector(dir,3.2).addScaledVector(right,1.3).add(V(0,.25,0));camLook.copy(f.pos).add(V(0,1.85,0));}else if(cinematic.type==='clash'){camPos.copy(player.pos).add(V(9,7,10));camLook.copy(headPos(player)).lerp(headPos(enemy),.5);}else{camPos.copy(headPos(f)).addScaledVector(dir,-3.8).addScaledVector(right,2.3).add(V(0,.55,0));camLook.copy(headPos(f)).addScaledVector(dir,5);}}if(cinematic.t>=cinematic.duration)cinematic=null;}
 updateDomainCinema(phase==='pause'?0:dt);
 $('letterbox').classList.toggle('on',domainOrbitVisible()||domainSplitVisible()||!!cinematic&&!options.freeOrbit&&!cursorFree||phase==='finish'&&lastFinisher);const fov=finisher&&phase==='finish'&&options.cinematics?48:cinematic&&!options.freeOrbit&&!cursorFree?53:options.cinematics&&domain?.owner===player&&domain.owner.character==='gojo'&&domain.t<DOMAIN_RULES.voidReveal?lerp(75,62,THREE.MathUtils.smoothstep(domain.t,0,DOMAIN_RULES.voidReveal)):phase==='play'&&!options.freeOrbit&&!cursorFree?speedFov():62;camera.fov=lerp(camera.fov,fov,1-Math.exp(-7*dt));camera.updateProjectionMatrix();
 if(enclosure()){const center=enclosureCenter(),delta=camPos.clone().sub(center),inside=insideEnclosure(player),limit=DOMAIN_ENCLOSURE.radius+(inside?-.6:.6);if(inside?delta.length()>limit:delta.length()<limit){if(delta.lengthSq()<.01)delta.set(0,0,1);camPos.copy(center).addScaledVector(delta.normalize(),limit);}}
 camera.position.copy(camPos);presentationShake();applyDirectionalCamera();camera.lookAt(camLook);shake*=Math.exp(-6*dt);
}
const DOMAIN_GUARD_MULTIPLIER=.55;
function airborneLook(f){return f.flying||!f.grounded;}
function updateHUD(){const dodgeCD=player.dodgeCooldown||0;$('dodgeStatus').textContent=dodgeCD>0?'Dodge '+dodgeCD.toFixed(1)+'s':'Dodge';$('touchDodge').textContent=dodgeCD>0?dodgeCD.toFixed(1)+'s':'DODGE';updateNarutoMobilityHUD();updateRosterHUD();syncCameraHUD();if(player.character==='sukuna'){const armed=hasFurnaceArrow(player);$('abilityTag3').textContent=armed?'DETONATE':'FIRE ARROW';$('abilityHint3').textContent=armed?'Tap Furnace to explode now':kit(player).hints[3];$('touchName3').textContent=armed?'DETONATE':'FURNACE';}$('ability5').classList.toggle('active',player.narutoAction?.kind===5||worldCutBusy(player));const guestCombo=mode==='online'&&net?.role==='guest'&&player.attackIsLight&&player.attack>0,comboShown=player.counterWindow>0||player.comboDisplay>0||guestCombo;$('comboReadout').classList.toggle('hidden',!comboShown);if(player.counterWindow>0)$('comboReadout').textContent='COUNTER · '+(controls?.label('light')||'ATTACK');else if(guestCombo)$('comboReadout').textContent=(player.combo+1)+' / 4';for(const [id,v] of [['phealth',player.hp/MAX_HEALTH*100],['ehealth',other(player).hp/MAX_HEALTH*100],['stamBar',player.stamina/maxStamina(player)*100],['energyBar',player.energy],['ultBar',player.ult]])$(id).style.width=clamp(v,0,100)+'%';$('php').textContent=Math.ceil(player.hp).toLocaleString('en-US');$('ehp').textContent=Math.ceil(other(player).hp).toLocaleString('en-US');$('stamNum').textContent=Math.round(player.stamina);$('energyNum').textContent=Math.round(player.energy);$('ultNum').textContent=Math.round(player.ult)+'%';$('ultLabel').textContent=player.hp<5&&!player.emergency?'EMERGENCY READY':'ULTIMATE';$('abilityQ').classList.toggle('ready',player.ult>=99||(player.hp<5&&!player.emergency));for(let i=1;i<=4;i++)$('ability'+i).classList.toggle('active',!!chargeFor(player,i)||(i===1&&blue?.owner===player)||(i===3&&hasFurnaceArrow(player)));$('clock').textContent=String(Math.floor(matchTime/60)).padStart(2,'0')+':'+String(Math.floor(matchTime%60)).padStart(2,'0');$('targetLabel').textContent=lockOn?'TARGET LOCKED · '+(controls?.label('lock')||'TAB')+' TO RELEASE':'';$('worldStatus').textContent=ARENA_MAPS[activeMap].name.toUpperCase()+' · RESTORES IN '+Math.ceil(restoreTimer)+'s';$('objective').textContent=blue?'Blue: '+blue.phase.toUpperCase()+(blue.phase==='hold'?' · '+Math.max(0,LIMITLESS_OUTPUT.blue.holdTime-blue.hold).toFixed(1)+'s remaining':blue.phase==='sweep'?' · '+Math.max(0,LIMITLESS_OUTPUT.blue.sweepTime-blue.sweep).toFixed(1)+'s steering':''):bomb?'FUSION: '+Math.max(0,3-bomb.t).toFixed(1)+'s':mode==='practice'?'Unlimited energy. CPU waits unless you start a clash drill.':'Light hits restore energy. '+(mode==='online'?'Opponent':'CPU')+' domain: '+Math.round(enemy.ult)+'%';updateBurnoutHUD();updateMahitoHUD();updateSpiderHUD();}

function resetMatch(nextMode='duel'){resetCombatResponse();resetPresentation();resetSpider();resetMahito();resetWorldCut();resetDomainCinema();mindscapeEnd=null;if(mindscapePool)mindscapePool.g.visible=mindscapePool.shards.visible=false;resetNaruto();clearFinisher();clearBarrierVisuals();sound.setClash(false);sound.stopCues();clearCombatVisuals();cancelCharge();cancelCharge(enemy);controls?.releaseAll();remoteInput.keys.clear();remoteInput.held.clear();remoteInput.move={x:0,y:0};localEdges.length=0;countdown=0;menuOpen=false;netEvents.length=0;assignRigs();mode=nextMode;configureRoster(nextMode);syncCharacterUI();phase='play';keys.clear();mouseDown=false;cancelCharge();clearFields();blue=bomb=null;for(const p of projectiles)removeObject(p.o?.g);projectiles.length=0;techniques.length=0;removeObject(cpuCharge?.o?.g);cpuCharge=null;cinematic=null;for(const e of effects)removeObject(e.m);effects.length=0;pendingHits.length=0;resetBattleParticles();domain=clash=playerCast=enemyCast=null;clearDomainVisual();applyArenaMap(selectedMap);restoreArena();toastTime=0;annTime=0;flash=0;impact=0;hitStop=0;matchTime=0;regenCharge=0;castCooldown=0;lastFinisher=false;lockOn=false;cursorFree=false;cameraOrbit.active=false;cameraOrbit.yaw=cameraOrbit.pitch=0;yaw=0;pitch=.06;
 for(const f of bodies){Object.assign(f,{rosterAnim:null,lastPos:null,techniqueBurnout:0,substitutionUsed:false,primaryCharge:null,cast:null,targetId:null,aiThink:0,brain:.5,nextSlash:2,nextFire:6,domainCD:8,blockTimer:1,auxCharge:null,auxSpecialKind:0,auxSpecialAge:0,auxSpecialDuration:0,auxSpecialPower:0,specialKind:0,specialAge:0,specialDuration:0,specialPower:0,castVoiceId:0,castVoiceAge:0,castVoiceActive:false,airJumpCooldown:0,jumpPose:0,jumpSide:0,ragdollGround:false,ragdollBounces:0,ragdollPitch:0,ragdollRoll:0,ragdollYaw:0,ragdollRate:0,launchImpactCD:0,redRecoil:0,navPoint:null,navGoal:null,attackIsLight:false,releasePose:0,comboHits:0,comboLock:0,counterWindow:0,guardReact:0,ragdollT:0,ragdollAge:0,ragdollMax:0,ragdollSpin:1,recovery:0,attackCounter:false,attackAir:false,sprinting:false,comboDisplay:0,hp:MAX_HEALTH,energy:nextMode==='practice'?100:80,stamina:maxStamina(f),ult:nextMode==='practice'&&f===player?100:0,stun:0,dodge:0,dodgeCooldown:0,dodgeWindow:0,attack:0,block:false,blockTime:0,combo:0,comboTimer:0,score:0,damageTaken:0,lastFeedback:0,grounded:true,flying:false,emergency:false,cooldown:0,autoHit:0});f.vel.set(0,0,0);f.body.rotation.set(0,0,0);f.body.position.set(0,0,0);f.body.visible=true;f.shadow.visible=true;f.headGroup.rotation.set(0,0,0);}
 placeRoster();if(bodies.some(f=>f.character==='naruto')){ensureNarutoVisuals();ensureNarutoClones();}warmDomainPortraits();player.flying=false;player.emergency=false;for(const f of bodies){f.lastPos=null;f.hitReact=0;f.walkPhase=0;f.energyCharging=false;f.chargeTime=0;}enemy.nextSlash=4;enemy.nextFire=12;enemy.domainCD=18;enemy.brain=.5;enemy.blockTimer=1;camPos.copy(player.pos).add(V(.8,3,7));camLook.copy(headPos(player)).add(V(0,0,-30));
 ['menu','help','result','clashUI','settingsPanel','onlinePanel'].forEach(id=>$(id).classList.add('hidden'));$('hud').classList.remove('hidden');$('resumeButton').classList.add('hidden');$('matchMode').textContent=nextMode==='practice'?'PRACTICE · UNLIMITED ENERGY':bodies.length+' FIGHTERS · FREE-FOR-ALL';$('modeHint').textContent=nextMode==='practice'?'PRACTICE FIELD':'CPU DUEL';announce(nextMode==='practice'?'EXPERIMENT WITH EVERY TECHNIQUE':kit(player).short+' vs '+kit(enemy).short,nextMode==='practice'?'PRACTICE FIELD':'THE DUEL BEGINS',1.8);updateHUD();
}
function requestLock(){if(cursorFree||phase!=='play'||menuOpen||document.hasFocus?.()===false||controls?.inputMode!=='keyboard'||controls?.touchActive)return;try{const result=renderer.domElement.requestPointerLock();result?.catch?.(()=>{toast('Click the arena to enable mouse look',4)});}catch{toast('Mouse lock unavailable · drag the arena to look',4);}}
function start(nextMode){if(mode==='online'||net?.role)net.close();resetMatch(nextMode==='online'?'duel':nextMode);sound.unlock();sound.play('ui');requestLock();}
function pause(){if(phase!=='play'||menuOpen)return;menuOpen=true;clearBufferedAction(player);localInputClear=true;cancelCharge();controls?.releaseAll();if(mode!=='online'){phase='pause';cancelCharge();sound.setClash(false);sound.stopCues();}else{cancelCharge();toast('Online combat continues while the menu is open.',3);}keys.clear();mouseDown=false;player.block=false;document.exitPointerLock?.();$('menu').classList.remove('hidden');$('resumeButton').classList.remove('hidden');}
function resume(){if(phase!=='pause'&&!menuOpen)return;menuOpen=false;if(phase==='pause')phase='play';['menu','help','settingsPanel'].forEach(id=>$(id).classList.add('hidden'));syncCameraHUD();requestLock();}
function showHelp(){syncManual(phase==='menu'?selectedCharacter:player.character);syncControlCopy();if(phase==='play')pause();$('menu').classList.add('hidden');$('help').classList.remove('hidden');}
function closeHelp(){if(phase==='pause'||menuOpen)resume();else{$('help').classList.add('hidden');$('menu').classList.remove('hidden');}}
function clashDrill(){net?.close();sound.unlock();resetMatch('practice');for(const [i,f]of bodies.entries()){f.pos.set(Math.sin(i*2)*7,.13,Math.cos(i*2)*7);f.ult=100;f.domainCD=0;}castDomain(enemy,true);toast('CAST YOUR DOMAIN NOW · AI participants will join the clash',3);requestLock();}


function updateSelectionUI(){
 const selected=KITS[selectedCharacter];
 for(const [id,key]of [['selectGojo','gojo'],['selectSukuna','sukuna'],['selectNaruto','naruto'],['selectMahito','mahito'],['selectSpider','spiderman']]){$(id).classList.toggle('selected',selectedCharacter===key);$(id).setAttribute('aria-pressed',String(selectedCharacter===key));}
 $('duelButton').textContent='PLAY AS '+selected.short;
 $('selectedDescription').textContent=selectedCharacter==='spiderman'?'Link web pulls, rising kicks and air combos. Sling cocooned opponents into scenery, then swing through the city at high speed.':selectedCharacter==='mahito'?'Shape your arms, command morphed humans, ride a serpent, regenerate and transfigure your body. Cursed Touch trades ultimate meter for a technique seal.':selectedCharacter==='naruto'?'Three shadow clones, a launching combo, Rasengan and Rasenshuriken. Use Tailed Beast Bomb on 5. Expand Mindscape on Q.':selectedCharacter==='gojo'?'Control space with Blue. Combine it with Red to trigger Hollow Bomb.':'Four arms, two simultaneous techniques. 150 stamina, agile air steps, and a remote-detonated flame arrow.';
 $('comboLabel').textContent=selected.short+' / TECHNIQUE LAB';
 $('comboTitle').innerHTML=selectedCharacter==='spiderman'?'WEB. LAUNCH.<br><span>KEEP IT GOING.</span>':selectedCharacter==='mahito'?'SHAPE THE BODY.<br><span>TOUCH THE SOUL.</span>':selectedCharacter==='naruto'?'SHADOW CLONES.<br><span>WIND RELEASE.</span>':selectedCharacter==='gojo'?'BLUE + RED<br><span>HOLLOW BOMB.</span>':'RUSH. CLEAVE.<br><span>FURNACE.</span>';
 $('comboInstructions').textContent=selectedCharacter==='spiderman'?'1 pulls and launches; 2 combos or air slams; 3 catches and slings; hold 4 to swing from buildings or slide on the ground; let go to release.':selectedCharacter==='mahito'?'1 cycles arm weapons; 5 cycles body forms; 6 spends 20% ultimate for Cursed Touch. Q expands your domain.':selectedCharacter==='naruto'?'Use 1–4 for ninja techniques, 5 for Tailed Beast Bomb, and Q to expand Mindscape: Kurama’s Cage.':selectedCharacter==='gojo'?'Hold 1, release, then tap Blue again to anchor Blue. Aim Red at its center. 60–115m blast radius. Survive the three-second fusion.':'Charge two different specials together. Draw Furnace, release, then tap Furnace again to detonate in flight.';
 if(phase==='menu')syncManual(selectedCharacter);syncControlCopy();updateSelectionPresentation();
}
function syncManual(character){
 $('helpKitName').textContent=KITS[character].short+"'S TECHNIQUES";
 $('helpTechniques').innerHTML=character==='spiderman'?spiderManual():character==='mahito'?mahitoManual():character==='naruto'?narutoManual():character==='gojo'?'<p><kbd>1</kbd> Blue: hold, release, then steer its moving gravity field with your aim. It follows your aim with a short, smooth delay at 24m/s, travels 26–40m, then follows your aim for up to 6s, including full-circle turns. Tap again to anchor it for 3s.<br><kbd>2</kbd> Red: hold, release a near-instant repulsive beam and explosion. Shoot anchored Blue to create Hollow Bomb. Blue and Red briefly hover while casting in the air.<br><kbd>3</kbd> Purple: charge and release a fused projectile with a wide visual wake.<br><kbd>4</kbd> Spatial Shift: tap repeatedly for 8m warps, or charge up to 36m in 0.45s. Uses cursed energy. Cancels a previous charge.</p>':'<p><kbd>1</kbd> Dismantle: charge a cutting wave; high charge adds two spread cuts.<br><kbd>2</kbd> Cleave: release within 5–6m for a cutting barrage. Opponents can move out of range.<br><kbd>3</kbd> Furnace: launch a 90–120m/s arrow; tap Furnace again to detonate it in flight. Impact creates a 12–22m miniature nuke and burning area.<br><kbd>4</kbd> Cursed Rush: dash 22–35m along your aim. Contact ragdolls and launches your opponent.<br><kbd>5</kbd> World Cutting Slash: 60 energy + 50% ultimate, 1.45s vulnerable wind-up, 420 damage, 140m range, 16s shared cooldown. Cuts through scenery and opponents; guard does not stop it. Domain barriers stop the slash.<br>Use two different specials at once, each with its own release and energy cost. Press Jump again in midair for air steps costing 3 cursed energy each; no jump-count limit. Ground jumps stay free. Sukuna’s light combo deals 64 damage. Stamina returns on the ground while not sprinting.</p>';
}
function syncCharacterUI(){
 const p=kit(player),e=kit(enemy);$('pname').textContent=p.name;$('ename').textContent=e.name;$('ptitle').textContent=p.title;$('etitle').textContent=e.title+(mode==='online'?' · ONLINE':' · CPU');
 $('hud').style.setProperty('--player',player.character==='gojo'?'#73d5ff':'#ff829e');$('hud').style.setProperty('--opponent',enemy.character==='gojo'?'#73d5ff':'#ff829e');
 for(let i=1;i<=4;i++){$('abilityName'+i).textContent=p.names[i];$('abilityHint'+i).textContent=p.hints[i];$('abilityTag'+i).textContent=p.tags[i];$('ability'+i).style.setProperty('--accent',p.colors[i]);}
 $('energyLabel').textContent=player.character==='naruto'?'CHAKRA':'CURSED ENERGY';$('abilityHintQ').textContent=player.character==='naruto'?'Kurama’s Cage · full ultimate meter':'Counter a domain within 1.5s';$('abilityTagQ').textContent='DOMAIN';$('touchUltimateName').textContent=player.character==='naruto'?'MINDSCAPE':'DOMAIN';
 $('ability5').classList.toggle('hidden',['gojo','spiderman'].includes(player.character));$('touchSpecial5').classList.toggle('hidden',['gojo','spiderman'].includes(player.character));$('abilityName5').textContent=player.character==='sukuna'?'WORLD CUTTING SLASH':'TAILED BEAST BOMB';$('abilityHint5').textContent=player.character==='sukuna'?'60 energy + 50% ultimate':'45 chakra + 30% ultimate';$('abilityTag5').textContent=player.character==='sukuna'?'SPACE TEAR':'NINE-TAILS';$('touchName5').textContent=player.character==='sukuna'?'WORLD CUT':'BOMB';
 if(player.character==='mahito'){for(let i=5;i<=6;i++){$('abilityName'+i).textContent=p.names[i];$('abilityHint'+i).textContent=p.hints[i];$('abilityTag'+i).textContent=p.tags[i];}$('touchName5').textContent='BODY FORMS';}
 $('ability6').classList.toggle('hidden',player.character!=='mahito');$('touchSpecial6').classList.toggle('hidden',player.character!=='mahito');
 $('abilityNameQ').textContent=p.domain;$('flightHint').innerHTML=player.character==='gojo'?'<kbd>SPACE</kbd> Jump <kbd>F</kbd> Levitate':'<kbd>SPACE</kbd> Jump <kbd>4</kbd> Cursed Rush';
 $('abilityQ').classList.toggle('hidden',player.character==='spiderman');$('energyLabel').textContent=player.character==='spiderman'?'WEB ENERGY':player.character==='naruto'?'CHAKRA':'CURSED ENERGY';
 for(const el of document.querySelectorAll('[data-action]'))if(el.dataset.action==='domain')el.style.display=player.character==='spiderman'?'none':'';
 syncManual(player.character);updateSelectionUI();syncControlCopy();
}
function selectCharacter(id){
 selectedCharacter=id;
 if(phase==='menu'){assignRigs();syncCharacterUI();}else{updateSelectionUI();toast('Character selected for the next match. Choose Play to switch.',3);}
}
/*ROSTER*/
/*CUTOUTS*/
/*PRESENTATION*/
/*SESSION*/
let last=performance.now();function frame(now){const raw=(now-last)/1000;last=now;sampleAdaptiveQuality(raw);fpsTime+=raw;fpsValue=lerp(fpsValue,1/Math.max(.001,raw),.04);if(fpsTime>.5){fpsTime=0;$('fps').textContent=Math.round(fpsValue)+' FPS · BUILD '+PRESENTATION.build;}step(Math.min(raw,.05));requestAnimationFrame(frame);}
initPresentation();initBattleReadability();initCombatFeel();player.root.position.copy(player.pos);enemy.root.position.copy(enemy.pos);camera.lookAt(headPos(player));syncCharacterUI();syncMapUI();applyArenaMap(selectedMap);renderFrame();$('boot').classList.add('hidden');$('menu').classList.remove('hidden');requestAnimationFrame(frame);
// Read-only state is useful for reproducing bugs. Scenario setup is restricted to ?test=1.
function snapshot(){return {actors:bodies.map(f=>({id:f.id,character:f.character,bot:!!f.bot,hp:f.hp,pos:f.pos.toArray()})),map:activeMap,maxHealth:MAX_HEALTH,balance:BALANCE,world:WORLD,finisher:finisher?{kind:finisher.kind,t:finisher.t,duration:finisher.duration,id:finisher.id}:null,phase,mode,time,selectedCharacter,techniques:techniques.map(t=>t.type),cpuCharge:cpuCharge?{kind:cpuCharge.kind,t:cpuCharge.t}:null,player:{character:player.character,pos:player.pos.toArray(),hp:player.hp,energy:player.energy,stamina:player.stamina,ult:player.ult,stun:player.stun,emergency:player.emergency},enemy:{character:enemy.character,pos:enemy.pos.toArray(),hp:enemy.hp,stun:enemy.stun,ult:enemy.ult},blue:blue?{owner:blue.owner===player?'player':'enemy',phase:blue.phase,pos:blue.p.toArray(),q:blue.q,hold:blue.hold,sweep:blue.sweep,travelled:blue.travelled,range:blue.range}:null,bomb:bomb?{t:bomb.t,q:bomb.q,radius:bomb.radius}:null,charge:charge?{kind:charge.kind,t:charge.t,spent:charge.spent}:null,domain:domain?{kind:domain.owner.character,owner:domain.owner===player?'player':'enemy',t:domain.t,stage:domain.owner.character==='gojo'?domainPhase(domain.t):'slashing',captured:domain.captured}:null,clash:clash?{...clash}:null,enemyCast:enemyCast?{t:enemyCast.t}:null,playerCast:playerCast?{t:playerCast.t}:null,destroyed:pieces.filter(p=>!p.alive).length,restoreTimer,projectiles:projectiles.map(p=>p.type),renderer:{calls:renderer.info.render.calls,triangles:renderer.info.render.triangles}};}
window.arena={snapshot};if(new URLSearchParams(location.search).has('test'))window.arena.debug={select:id=>{if(KITS[id])selectedCharacter=id;},technique:(who,kind,q=.5)=>executeTechnique(who==='player'?player:enemy,kind,q,aimFor(who==='player'?player:enemy)),start:resetMatch,step,setup:o=>{if(o.player)for(const[k,v]of Object.entries(o.player)){if(k==='pos'||k==='vel')player[k].fromArray(v);else player[k]=v;}if(o.enemy)for(const[k,v]of Object.entries(o.enemy)){if(k==='pos'||k==='vel')enemy[k].fromArray(v);else enemy[k]=v;}if(o.yaw!==undefined)yaw=o.yaw;if(o.pitch!==undefined)pitch=o.pitch;if(o.restoreTimer!==undefined)restoreTimer=o.restoreTimer;},clash:()=>{player.ult=100;enemy.ult=100;castDomain(enemy,true)},hurt:(who,amount,kind='light')=>hurt(who==='player'?player:enemy,amount,who==='player'?enemy:player,kind),restore:restoreArena};
