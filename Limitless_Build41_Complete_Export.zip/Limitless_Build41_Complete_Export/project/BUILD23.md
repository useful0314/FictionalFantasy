# Build 23 — spherical domains and Kurama's clone assault

This is an update to the existing game. The same fighter roster, inputs, damage rules, domain capture list, clash scores, resources, joints, particle pools and host-authoritative networking remain in use.

## Implemented behavior

| Change | Exact behavior |
| --- | --- |
| Full-sphere domain effects | Shrine slashes fill both hemispheres around the cast origin. Outer slash marks, sigils, rings and Void motes cover the sphere. Shrine geometry follows the cast height. The white barrier forms from its bottom to its top. |
| Airborne Mindscape | A spherical sewer vault surrounds the fight at any height. The cage stays in the background; broad flat walls/ceilings no longer cut across the combat space. Reflective water remains at the arena floor and is clipped to the sphere. |
| Clone sure-hit | Six clones per trapped rival, up to 30, in four staggered waves. Two combo clones, two Rasengan clones, one Rasenshuriken clone and one small Tailed Beast Bomb clone. They appear in smoke and receive visible red-orange chakra tethers from Kurama. |
| Domain damage | Per wave: 12 + 12 + 18 + 18 + 30 + 60 = 150. Four waves total 600; guard reduces this to 330. Hits occur at 1.45, 4.45, 7.45 and 10.45 seconds plus role offsets 0, .13, .26, .39, .60 and .90. The last strike is at 11.35 seconds. Dodge cannot avoid this sure-hit; uncaptured players are unaffected. Existing Impossible AI immunity remains. |
| Kurama | His angular fox head, claws, seal, eyes and roar remain behind the bars. Roaming, stomp damage and the old final slam no longer run. The retained full-body model is hidden. The existing three-stage clash bonus remains. |
| Post-domain burnout | 15 seconds for the caster when an active domain ends. Clash losers begin immediately when the clash resolves; the winner begins when their surviving domain ends. Slots 1–5 and Q are blocked, and a held charge is canceled. Movement, dodge, guard, light attacks and energy recovery remain available. Already launched attacks continue. An interrupted startup never established a domain, so it does not begin burnout. |
| Burnout UI / multiplayer | Countdown inside the movable resource HUD, dimmed technique cards, host-owned timer replicated to guests, and reset on rematch. |
| Substitution | A successfully avoided incoming hit during Naruto's dodge creates smoke and a wooden log, once per dodge. Naruto briefly vanishes for .09 seconds; the log tumbles, then poofs out by .95 seconds. This adds no damage, healing or new dodge immunity. Existing perfect-dodge rewards still apply. |
| Clone Boost | 5 chakra per activation, zero stamina, no cooldown and no five-use cap. Hold up to 1.2 seconds for the existing stronger boost. A new press after launch can chain immediately; an anticipation press can buffer once. Holding does not repeatedly spend chakra. |
| Wall Run | All three characters spend 8 stamina/second total, down from 26.5. Existing target speeds remain 26 m/s along walls or 11 m/s climbing. |
| Wall jump | Free for every character and directed by camera aim, including vertical pitch. Level aim retains 13.5 m/s lift and roughly 27.9 m/s horizontal push. Pitch adds up to 20 m/s before clamping lift to −9…22 m/s. Collision still prevents travel through walls. Existing anticipation, easing, recovery and white speed lines remain. |

Naruto's five ordinary techniques, full-meter domain cost, 12-second domain duration, fixed capture radius of 54 metres and existing clash/camera behavior remain. Normal Shadow Clone Barrage still follows facing direction. Only the new domain sure-hit pursues each trapped rival.

## Exact source excerpts

From `src/domain-burnout.js`:

```js
const DOMAIN_BURNOUT={duration:15};
```

From `src/mindscape-clones.js`:

```js
const MINDSCAPE_ASSAULT={
 clonesPerTarget:6,waves:4,firstHit:1.45,waveInterval:3,anticipation:1.15,recovery:.55,
 offsets:[0,.13,.26,.39,.60,.90],techniques:[2,2,3,3,4,5],damage:[12,12,18,18,30,60],
 orbitRadius:8,tetherSegments:8,tetherColor:0xff6a32,tetherOpacity:.36,shake:.10
};
```

From `src/naruto-mobility.js`:

```js
 boost:{cooldown:0,cost:5,startup:.08,active:.36,recovery:.10,impulse:12,dashDistance:10.4,distance:4.6,nudge:1.6,cloneLife:.26,buffer:.16,maxHold:1.2,chargedActive:.52,chargedDashDistance:15.9,chargedDistance:8.5,chargedNudge:4.2},
 wall:{startup:.12,climb:11,speed:26,lift:3,stamina:8,cooldown:.12,probe:.7,skin:.46},
```

The wall-jump direction in that file is:

```js
 m.dir.copy(aimFor(f)).normalize();
```

From `src/naruto-substitution.js`:

```js
const NARUTO_SUBSTITUTION={pool:6,life:.95,vanish:.09,poofAt:.78,smokeRadius:.9};
```

## Separate helpers and narrow hooks

| New helper | Where it plugs in |
| --- | --- |
| `src/domain-burnout.js` | Domain expiry in `domains.js` / `mindscape.js`, clash resolution in `roster.js`, technique entry points, `updateCombatTimers`, HUD and the existing snapshot number fields. |
| `src/mindscape-sphere.js` | Pooled Mindscape dome material and presentation update; ground-level reflective water uses the existing water shader. |
| `src/mindscape-clones.js` | Host hits from `updateMindscapeDomain`; visual slots appended by `animateNarutoClones`; existing Naruto attack tracks and sphere/particle effects. |
| `src/naruto-substitution.js` | Successful dodge branch of `hurt`; reset once per Chakra Dash; existing VFX event replication and Naruto presentation cleanup. |

All four helpers are registered in `build.py` and `tests/harness.mjs`. No input binding, asset download or manual hookup is needed. No paid plugin or new audio recording is used. The ordinary model/animation modules retain their file names and structure.

The clone pool grows from 18 to 48 slots to accommodate 18 ordinary barrage clones plus up to 30 domain clones. Only active instances draw. Domain tethers use one reusable typed buffer; sphere rigs and six substitution logs are pooled. Guests reconstruct clone presentation from the existing domain/fighter snapshot rather than adding 30 networked fighters. The host alone applies damage.

## Validation

The current suites are Builds 14 and 17–23: 132 simulation checks covering combat, resources, domains/clashes, camera/input routing, all three characters, scenery/barrier collision and host/guest snapshots. Earlier assertions were updated only where this build intentionally changes behavior, including the retired stomps, old boost cap and wall cost/direction.

Custom domain GLSL is compiled and linked on native Mesa GLES. Six isolated scene previews inspect the aerial clone assault, tethers, lower spherical vault, aerial Shrine slash fields and substitution model. These previews use real Three.js geometry and shader source with approximate lighting.

This environment has no supported browser QA surface. Browser gameplay/audio, live Internet WebRTC, physical touch/controller input and device FPS are not verified. Pools are bounded, but this is not a measured 60 FPS claim.

Refresh every private-room client to **Build 23**, protocol `limitless-23.0` / room prefix `limitless23-`.

The complete source archive includes every source file, procedural model, animation, VFX helper, test, original asset/library and rebuilt `Limitless-Arena.html`.
