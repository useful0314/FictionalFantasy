Build 40 is the current combat-feedback pass: white character hit flashes, directional recoil, pooled contact bursts, distinct impact sounds, incoming-hit direction and weighted landing accents. See [BUILD40.md](BUILD40.md) for sources, tuning, integration and verification.

# Build 39 — Combat and presentation polish

A consistent five-fighter roster, selected-character move list, health damage trails, hit/guard feedback, cooldown and resource hints, and match statistics. All fighters gain smoother strafe/braking poses; camera collision, shake, shadow coverage and Auto render resolution are refined. Read [BUILD39.md](BUILD39.md) for exact changes, tuning and verification. Refresh everyone in private rooms to Build 39 (`limitless-39.0`).

# Build 38 — Ground webs and sliding

Aim at the ground and hold Web Swing (default 4) to pull into a slide. Landing while holding a building web keeps the attachment and horizontal momentum, with a low sliding pose and pooled dust. Let go to release; Jump releases and jumps out of a ground slide. See [BUILD38.md](BUILD38.md) for controls, tuning and checks. Refresh every private-room player to Build 38 (`limitless-38.0`).

# Build 37 — Hold-to-swing and Spider-Man motion

Hold the Web Swing input (default 4); let go to release. Eased launch, damped web tension, smooth turning, banked dive/rise poses and a tuck-to-open release preserve momentum. See [BUILD37.md](BUILD37.md) for controls, tuning and checks. Refresh every private-room player to Build 37 (`limitless-37.0`).

# Build 36 — Bigger Skyline Boroughs and exact web aiming

Skyline Boroughs is now 520m across, with 24 additional high rises (32 total), eight new mid-rise blocks and a 124m flight ceiling. Spider-Man attaches to the actual surface under the crosshair up to 125m away, including in private rooms. See [BUILD36.md](BUILD36.md) for tuning and checks. Refresh every player to Build 36 (`limitless-36.0`).

# Build 35 — Playable Spider-Man

Web yank into an aerial combo, four distinct martial-arts strikes, aim-controlled cocoon throws and high-speed building swings. See [BUILD35.md](BUILD35.md) for controls, tuning and verification. Refresh every private-room player to Build 35 (`limitless-35.0`).

# Current release: Build 34 — Clear domain interiors and full-circle Blue control

Buildings and collisions disappear inside domains and return afterward. Blue can sweep all around you, with six seconds of guidance after its initial flight. Move your aim to steer; tap Blue again to anchor. Read [BUILD34.md](BUILD34.md) for tuning and verification. Refresh every private-room player to Build 34.

## Play and edit

1. Extract the ZIP. Open `Limitless-Arena.html` in your browser to play the bundled version. Solo play works offline; private online rooms need an Internet connection.
2. Open the extracted folder in a code editor. Edit the files in `src/`.
3. Install Python 3 if you do not have it. In a terminal in this folder, run `python build.py` (or `python3 build.py`).
4. Reopen or refresh `Limitless-Arena.html`. The script combines your edits, libraries, textures and audio into this one file.

Do not open `src/index.html` to play: it is a build template containing insertion markers. Editing the generated HTML directly also works for experimenting, but rebuilding overwrites it.

## Where everything lives

| What you want to change | File / function |
| --- | --- |
| Naruto model, move constants and combat | `src/naruto-model.js`, `src/naruto.js` |
| Naruto animation, clones and VFX | `src/naruto-animation.js`, `src/naruto-vfx.js`, `src/naruto.css` |
| Naruto mobility, poses, pooled boost clones, tuning and network state | `src/naruto-mobility.js` |
| Shared wall physics, jump blending and Gojo/Sukuna wall poses | `src/wall-motion.js` |
| Shared Kurama head, fangs, ears and jaw geometry | `src/kurama-model.js` |
| Domain clone assault and Kurama tethers | `src/mindscape-clones.js` |
| Full spherical sewer vault and post-domain burnout | `src/mindscape-sphere.js`, `src/domain-burnout.js` |
| Successful-dodge substitution log | `src/naruto-substitution.js` |
| Pooled white movement streaks | `src/naruto-speedlines.js` |
| World Cutting Slash combat, pose, pooled black blade and crater | `src/sukuna-world-cut.js`, `src/sukuna-world-cut-vfx.js` |
| Retained Kurama model geometry (roaming and stomp logic no longer used) | `src/kurama-domain.js` |
| Extra opponent health bars | `src/roster-health.js` |
| Gojo, Sukuna and Naruto block models | `src/block-models.js`; existing `fighterModel` / `fighterModelNaruto` wrappers |
| Air selection, pose templates and vertical knockback | `src/air-combat.js` |
| Neutral combo timing, linked kicks and combat entry blending | `src/light-combo.js` |
| Walking, sprinting, punches, kicks and cast poses | `src/animation.js`, `src/animation-polish.js`, `src/naruto-animation.js` |
| Health, move damage, flight cost, player simulation and camera placement | `src/game.js` |
| Jump costs, combos and knockback | `src/combat-system.js` |
| Keyboard, mouse, gamepad and phone controls | `src/controls.js` |
| Cursor dragging, settings and multiplayer integration | `src/session.js` |
| Night District buildings / terrain | `src/city.js` |
| Map selection, Sunlit Harbor and Shattered Sanctuary | `src/maps.js` |
| Skyline Boroughs city / floor collision / landing routes | `src/map-metro.js` and `SKYLINE-BOROUGHS.md` |
| Mixed Mindscape / Void / Shrine composition | `src/domain-mixed.js` |
| Domain appearance and damage | `src/domains.js` |
| Mindscape seal stages, clash strength, sewer and Kurama | `src/mindscape.js`, `src/mindscape-vfx.js` |
| Caster orbit and clash split-screen views | `src/domain-cinematics.js` |
| White domain shell and collision | `src/barriers.js` |
| Technique effects, bow, arrows and blast visuals | `src/combat-vfx.js`, `src/technique-startup.js`, `src/game.js` |
| Finishers | `src/finishers.js` |
| Menus, HUD and appearance | `src/index.html`, `src/style.css` |
| Sound synthesis and recording playback | `src/audio.js` |
| Fighter rosters, AI difficulty and domain clashes | `src/roster.js` |
| Domain character portraits, cutout timing and design | `src/cutouts.js`, `src/cutouts.css` |
| Private room transport and validation | `src/network.js` |
| Six supplied recordings | `assets/audio/` |
| Stone / clothing textures | `assets/textures/` |
| Bundled third-party engine and networking | `vendor/` |
| Simulation checks | `tests/` |

## How the models work

The playable models are procedural Three.js objects, made from shared bevelled block geometry with nested groups for shoulders, elbows, hands, fingers, hips, knees and ankles. Hair uses chunky extruded shapes. There are no imported Blender/FBX/GLB files or separate animation clips.

`src/block-models.js` contains `fighterBlockModel(character, attach=true)`. The existing factories remain the entry points:

```js
function fighterModel(isGojo){return fighterBlockModel(isGojo?'gojo':'sukuna');}
function fighterModelNaruto(attach=true){return fighterBlockModel('naruto',attach);}
```

`src/mahito-model.js` retains Mahito's model, weapons and forms and uses the same block geometry. `ensureActorRig()` in `src/roster.js` still selects and caches the model for each fighter. The new helpers in `src/animation-polish.js` supply visual poses, hand-sign IK, secondary motion and afterimages to the existing animators.

To see the models in the game, start Practice, press Left Alt, then drag across the arena. Release and drag again to continue around to the front. Scroll to zoom. Press Left Alt again to return to combat aim. V also toggles a persistent character view.

## Checks and limitations

With a recent Node.js installation, run `node tests/build22.mjs` for the latest additions, `node tests/build21.mjs` for the prior combat changes, then `node tests/build20.mjs` for mobility fixes, new city and mixed clashes, `node tests/build19.mjs` for mobility regressions, `node tests/build18.mjs` for Mindscape, cameras, directional clones and move 5, `node tests/build17.mjs` for Naruto and removed-cut-in behavior, and `node tests/build14.mjs` for free-for-all/network behavior. Earlier build-specific scripts document historical behavior and can contain superseded expectations (for example, Build 15 expected the cut-in overlays now removed). These use simulated browser input and real Three.js math/geometry; they are not live browser or device playtests. `README.md` lists the other checks and build history. Some isolated GPU inspection utilities require additional Python/Mesa packages and are not needed to play or build.

Third-party license text is in `THIRD-PARTY-NOTICES.txt` and `vendor/`. The download excludes deployment identity, Git metadata and credentials; those are not needed to edit, build or play the game.
