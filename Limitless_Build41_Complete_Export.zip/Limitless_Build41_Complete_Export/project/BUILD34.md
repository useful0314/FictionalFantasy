# Build 34 — Clear domain interiors and full-circle Blue control

## Domain terrain

All four domains and their clashes temporarily displace arena buildings and obstacles intersecting the barrier. Affected buildings disappear as complete structures, including their roofs, windows and ledges. Captured players also stop seeing the map's static decorations. Domain scenery, such as the Shrine and Kurama's cage, remains.

The shared `arenaPieceActive` helper in `src/barriers.js` feeds movement, platforms, wall-running, AI navigation, camera obstruction, attack rays and terrain damage. Removed scenery cannot leave invisible collisions. Wall runners smoothly leave a displaced wall. Debris within the enclosure is hidden too.

Destructible HP/alive state is preserved separately. Buildings return when the domain ends; previously destroyed pieces stay destroyed until normal reconstruction. Airborne domains use the sphere's actual elevation. Hosts and guests derive displacement from the existing enclosure ID, origin and captured-player list. Repeated snapshots and reconstruction cannot reveal displaced scenery.

`DOMAIN_TERRAIN.padding` accounts for attachments extending beyond a building section's collision box. Suppression is recalculated on enclosure/map/viewer changes, with no particle or geometry creation per frame.

## Blue control

- Blue follows an aim-selected position around its caster, allowing real 180-degree reversals and full-circle sweeps.
- Initial flight remains 26–40m at 24m/s, depending on charge.
- The subsequent steering window increases from 1 to **6 seconds**, at **46–58m/s** while repositioning.
- A 0.10s aim lag preserves the trailing response; a 0.08s arrival brake smoothly settles the orb near the aim-selected position.
- Aim up/down to lift/lower Blue. It follows a moving caster and stays within the existing reach instead of drifting endlessly forward.
- The HUD shows remaining steering time. Tap Blue again to anchor immediately; automatic anchoring and the three-second anchored lifetime remain.
- Damage per tick, energy cost, pull radius, Red fusion, casting animations and airborne cast hover are unchanged. The longer guidance window also permits longer total exposure to Blue's existing damage.

Tune `LIMITLESS_OUTPUT.blue` in `src/combat-vfx.js`. Steering remains host-authoritative in `src/game.js`; existing snapshots transmit the result.

## Verification

`tests/build34.mjs` checks opposite-side positioning at minimum/full charge and 30/60/144fps, full-circle steering, vertical steering, caster movement, anchoring, barrier collision, all four domains on all four maps, airborne skyscrapers, collision removal, wall release, clashes, destruction preservation, arena reconstruction and guest synchronization. Existing steering/VFX, domain, mechanics, online-control and wall-momentum suites cover surrounding behavior.

These are simulation and scene-state checks. Browser rendering and on-device frame rate were not verified in this workspace.

Private rooms use `limitless-34.0` / `limitless34-`; all players must refresh to Build 34.
